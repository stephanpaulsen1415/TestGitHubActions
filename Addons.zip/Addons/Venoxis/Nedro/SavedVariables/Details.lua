
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["tipo"] = 2,
					["combatId"] = 226,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.0055,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 26479,
							},
							["end_time"] = 1675841551,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 18547.0055,
							["last_dps"] = 1210.911670555504,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 26479.0055,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 6192,
										["g_amt"] = 0,
										["n_max"] = 1723,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 9638,
										},
										["n_dmg"] = 3446,
										["n_min"] = 1723,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[6] = 3446,
											[15] = 7224,
											[18] = 7224,
											[12] = 7224,
											[9] = 7224,
											[21] = 9638,
										},
										["total"] = 9638,
										["c_max"] = 3778,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 2414,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3502,
										["g_amt"] = 0,
										["n_max"] = 1985,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 5487,
										},
										["n_dmg"] = 1985,
										["n_min"] = 1985,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[6] = 3502,
											[15] = 3502,
											[18] = 3502,
											[12] = 3502,
											[9] = 3502,
											[21] = 3502,
										},
										["total"] = 5487,
										["c_max"] = 3502,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 3502,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 556,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2450,
										},
										["n_dmg"] = 2450,
										["n_min"] = 391,
										["g_dmg"] = 0,
										["counter"] = 5,
										["ChartData"] = {
											[6] = 1112,
											[15] = 1668,
											[18] = 1668,
											[12] = 1668,
											[9] = 1668,
											[21] = 2450,
										},
										["total"] = 2450,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47843] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 972,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 972,
										},
										["n_dmg"] = 972,
										["n_min"] = 972,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[21] = 972,
										},
										["total"] = 972,
										["c_max"] = 0,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 1012.0055,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675841550,
							["on_hold"] = false,
							["start_time"] = 1675841529,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007109,
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["targets"] = {
								["Onslaught Gryphon Rider"] = 7932,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 7932.007109,
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7932.007109,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675841551,
							["friendlyfire_total"] = 0,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 2,
										["c_dmg"] = 0,
										["g_amt"] = 1,
										["n_max"] = 398,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3898,
										},
										["n_dmg"] = 3511,
										["n_min"] = 279,
										["g_dmg"] = 387,
										["counter"] = 11,
										["total"] = 3898,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 596,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 934,
										["g_amt"] = 0,
										["n_max"] = 489,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 4034,
										},
										["n_dmg"] = 3100,
										["n_min"] = 314,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 4034,
										["c_max"] = 934,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 934,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 2754.007109,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675841550,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841530,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["classe"] = "PET",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008058,
							["fight_component"] = true,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Corrupted Scarlet Onslaught"] = true,
								["Nedro"] = true,
							},
							["targets"] = {
								["Droomon <Nedro>"] = 2754,
								["Nedro"] = 1012,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3766.008058,
							["on_hold"] = false,
							["last_event"] = 1675841549,
							["monster"] = true,
							["total"] = 3766.008058,
							["delay"] = 0,
							["aID"] = "29333",
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 486,
										["targets"] = {
											["Droomon <Nedro>"] = 1231,
											["Droomon"] = 0,
											["Nedro"] = 937,
										},
										["n_dmg"] = 2168,
										["n_min"] = 295,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 2168,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["extra"] = {
										},
										["n_amt"] = 6,
										["DODGE"] = 1,
										["a_dmg"] = 0,
									}, -- [1]
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 75,
										["targets"] = {
											["Nedro"] = 75,
										},
										["n_dmg"] = 75,
										["n_min"] = 75,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 75,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[54617] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 797,
										["targets"] = {
											["Droomon <Nedro>"] = 1523,
										},
										["n_dmg"] = 1523,
										["n_min"] = 726,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1523,
										["c_max"] = 0,
										["id"] = 54617,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 27516.008058,
							["end_time"] = 1675841551,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841531,
							["serial"] = "Creature-0-4457-571-176-29333-0004E3197D",
							["last_dps"] = 0,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 226,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 3195,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 3195.006111,
							["total_without_pet"] = 1012.006111,
							["total"] = 1012.006111,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.006111,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 1012,
							},
							["totalover_without_pet"] = 0.006111,
							["healing_taken"] = 3012.006111,
							["fight_component"] = true,
							["end_time"] = 1675841551,
							["healing_from"] = {
								["Nedro"] = true,
								["Onslaught Gryphon Rider"] = true,
							},
							["last_event"] = 1675841549,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 2256,
										},
										["n_max"] = 690,
										["targets"] = {
											["Nedro"] = 698,
										},
										["n_min"] = 0,
										["counter"] = 4,
										["overheal"] = 2256,
										["total"] = 698,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 698,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 939,
										},
										["n_max"] = 314,
										["targets"] = {
											["Nedro"] = 314,
										},
										["n_min"] = 0,
										["counter"] = 4,
										["overheal"] = 939,
										["total"] = 314,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 314,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.006111,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675841531,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 3277.006915,
							["total_without_pet"] = 2000.006915,
							["monster"] = true,
							["total"] = 2000.006915,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-29333-0004E3197D",
							["totalabsorb"] = 0.006915,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 2000,
							},
							["totalover_without_pet"] = 0.006915,
							["healing_taken"] = 0.006915,
							["fight_component"] = true,
							["end_time"] = 1675841551,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 3277,
										},
										["n_max"] = 2000,
										["targets"] = {
											["Nedro"] = 2000,
										},
										["n_min"] = 2000,
										["counter"] = 2,
										["overheal"] = 3277,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 2000,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 3277,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.006915,
							["custom"] = 0,
							["last_event"] = 1675841550,
							["classe"] = "UNKNOW",
							["start_time"] = 1675841550,
							["delay"] = 1675841536,
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 226,
					["_ActorTable"] = {
						{
							["received"] = 2952.004827,
							["resource"] = 0.004827,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 2952,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 0.004827,
							["fight_component"] = true,
							["total"] = 4129.004827,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 2952,
										["id"] = 31818,
										["totalover"] = 0,
										["targets"] = {
											["Nedro"] = 2952,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.004827,
							["last_event"] = 1675841550,
							["alternatepower"] = 0.004827,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 1177.008097,
							["resource"] = 0.008097,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1177,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 3517.008097,
							["total"] = 1177.008097,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 1177,
										["id"] = 54425,
										["totalover"] = 3517,
										["targets"] = {
											["Droomon <Nedro>"] = 1177,
										},
										["counter"] = 9,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675841550,
							["passiveover"] = 0.008097,
							["alternatepower"] = 0.008097,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 226,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -1,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -1,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 329,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[17941] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 17941,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[55637] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 55637,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[60064] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 60064,
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57567] = {
										["activedamt"] = 5,
										["id"] = 57567,
										["targets"] = {
										},
										["uptime"] = 219,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 5,
									},
									[61595] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 61595,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 63321,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 56,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[17941] = 1,
								[47857] = 1,
								[47813] = 1,
								[47864] = 2,
								[57946] = 1,
								[47836] = 1,
								[47843] = 2,
								[59164] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675844216,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["spell_cast"] = {
								[54053] = 9,
							},
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "29333",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[40652] = 1,
								[54617] = 2,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-29333-0004E3197D",
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 226,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					30244.94068099999, -- [1]
					3011.897615000001, -- [2]
					{
						0, -- [1]
						[0] = 4128.986089,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					18547, -- [1]
					1012, -- [2]
					{
						0, -- [1]
						[0] = 2952,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:32:32",
				["hasTimer"] = 21,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 693709.057,
				["CombatEndedAt"] = 693709.057,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 26479.0055,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 1012.006111,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693709.057,
				["combat_id"] = 226,
				["TimeData"] = {
				},
				["tempo_start"] = 1675841529,
				["frags"] = {
					["Onslaught Gryphon Rider"] = 2,
					["Corrupted Scarlet Onslaught"] = 2,
				},
				["combat_counter"] = 243,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "08:32:10",
				["start_time"] = 693687.1900000001,
				["contra"] = "Onslaught Gryphon Rider",
				["spells_cast_timeline"] = {
				},
			}, -- [1]
			{
				{
					["tipo"] = 2,
					["combatId"] = 225,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007134,
							["classe"] = "WARLOCK",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 24606,
							},
							["damage_taken"] = 3179.007134,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 17728.007134,
							["last_event"] = 1675841511,
							["aID"] = "4477-04D9C328",
							["dps_started"] = false,
							["total"] = 24606.007134,
							["delay"] = 0,
							["end_time"] = 1675841511,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1444,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 4004,
										},
										["n_dmg"] = 4004,
										["n_min"] = 1117,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[15] = 4004,
											[18] = 4004,
											[12] = 2887,
											[9] = 1443,
											[21] = 4004,
										},
										["total"] = 4004,
										["c_max"] = 0,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 527,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2665,
										},
										["n_dmg"] = 2665,
										["n_min"] = 364,
										["g_dmg"] = 0,
										["counter"] = 6,
										["ChartData"] = {
											[15] = 1304,
											[18] = 1668,
											[12] = 940,
											[9] = 470,
											[21] = 2138,
										},
										["total"] = 2665,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1787,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3562,
										},
										["n_dmg"] = 3562,
										["n_min"] = 1775,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[6] = 1787,
											[15] = 1787,
											[18] = 3562,
											[12] = 1787,
											[9] = 1787,
											[21] = 3562,
										},
										["total"] = 3562,
										["c_max"] = 0,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47843] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1815,
										["g_amt"] = 0,
										["n_max"] = 1313,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3128,
										},
										["n_dmg"] = 1313,
										["n_min"] = 1313,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[18] = 1815,
											[15] = 1815,
											[21] = 1815,
										},
										["total"] = 3128,
										["c_max"] = 1815,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 1815,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47857] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 843,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1496,
										},
										["n_dmg"] = 1496,
										["n_min"] = 653,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[18] = 653,
											[15] = 653,
											[21] = 653,
										},
										["total"] = 1496,
										["c_max"] = 0,
										["id"] = 47857,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47834] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2873,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2873,
										},
										["n_dmg"] = 2873,
										["n_min"] = 2873,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[18] = 2873,
											[15] = 2873,
											[21] = 2873,
										},
										["total"] = 2873,
										["c_max"] = 0,
										["id"] = 47834,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841488,
							["serial"] = "Player-4477-04D9C328",
							["last_dps"] = 1079.210839213833,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007947,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1545,
								["Nedro"] = 3179,
								["Roghaye"] = 349,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Corrupted Scarlet Onslaught"] = true,
								["Nedro"] = true,
								["Roghaye"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 5073.007947,
							["last_dps"] = 0,
							["last_event"] = 1675841509,
							["dps_started"] = false,
							["end_time"] = 1675841511,
							["aID"] = "29333",
							["total"] = 5073.007947,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 475,
										["targets"] = {
											["Droomon <Nedro>"] = 590,
											["Nedro"] = 2221,
											["Roghaye"] = 349,
										},
										["n_dmg"] = 3160,
										["n_min"] = 174,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 3160,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["extra"] = {
										},
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["MISS"] = 1,
									}, -- [1]
									[54617] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 958,
										["targets"] = {
											["Droomon <Nedro>"] = 898,
											["Nedro"] = 958,
										},
										["n_dmg"] = 1856,
										["n_min"] = 898,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1856,
										["c_max"] = 0,
										["id"] = 54617,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 4,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 57,
										["targets"] = {
											["Droomon <Nedro>"] = 57,
											["Nedro"] = 0,
											["Roghaye"] = 0,
										},
										["n_dmg"] = 57,
										["n_min"] = 57,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 57,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["MISS"] = 1,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 32875.007947,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841494,
							["serial"] = "Creature-0-4457-571-176-29333-00006339F4",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007008,
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["targets"] = {
								["Onslaught Gryphon Rider"] = 6878,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 6878.007008000001,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6878.007008000001,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675841511,
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1470,
										["g_amt"] = 1,
										["n_max"] = 366,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3856,
										},
										["n_dmg"] = 2095,
										["n_min"] = 326,
										["g_dmg"] = 291,
										["counter"] = 9,
										["total"] = 3856,
										["c_max"] = 738,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 732,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 441,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3022,
										},
										["n_dmg"] = 3022,
										["n_min"] = 333,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 3022,
										["c_max"] = 0,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1545.007008,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675841510,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841493,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 225,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 1301,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 1301.006479,
							["total_without_pet"] = 2412.006479,
							["total"] = 2412.006479,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.006479,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 2412,
							},
							["totalover_without_pet"] = 0.006479,
							["healing_taken"] = 3179.006479,
							["fight_component"] = true,
							["end_time"] = 1675841511,
							["healing_from"] = {
								["Nedro"] = true,
								["Onslaught Gryphon Rider"] = true,
							},
							["last_event"] = 1675841510,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 660,
										},
										["n_max"] = 475,
										["targets"] = {
											["Nedro"] = 942,
										},
										["n_min"] = 0,
										["counter"] = 3,
										["overheal"] = 660,
										["total"] = 942,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 942,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 626,
										},
										["n_max"] = 314,
										["targets"] = {
											["Nedro"] = 627,
										},
										["n_min"] = 313,
										["counter"] = 4,
										["overheal"] = 626,
										["total"] = 627,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 627,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47857] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 15,
										},
										["n_max"] = 843,
										["targets"] = {
											["Nedro"] = 843,
										},
										["n_min"] = 843,
										["counter"] = 2,
										["overheal"] = 15,
										["total"] = 843,
										["c_max"] = 0,
										["id"] = 47857,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 843,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.006479,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675841493,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 3430.003427,
							["total_without_pet"] = 767.003427,
							["monster"] = true,
							["total"] = 767.003427,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-29333-00006339F4",
							["totalabsorb"] = 0.003427,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 767,
							},
							["totalover_without_pet"] = 0.003427,
							["healing_taken"] = 0.003427,
							["fight_component"] = true,
							["end_time"] = 1675841511,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 3430,
										},
										["n_max"] = 528,
										["targets"] = {
											["Nedro"] = 767,
										},
										["n_min"] = 239,
										["counter"] = 2,
										["overheal"] = 3430,
										["total"] = 767,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 767,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 3430,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.003427,
							["custom"] = 0,
							["last_event"] = 1675841511,
							["classe"] = "UNKNOW",
							["start_time"] = 1675841510,
							["delay"] = 1675841500,
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 225,
					["_ActorTable"] = {
						{
							["received"] = 0.006676,
							["resource"] = 0.006676,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 0.006676,
							["fight_component"] = true,
							["total"] = 1047.006676,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.006676,
							["last_event"] = 0,
							["alternatepower"] = 0.006676,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 1047.004223,
							["resource"] = 0.004223,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1047,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 3124.004223,
							["total"] = 1047.004223,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 1047,
										["id"] = 54425,
										["totalover"] = 3124,
										["targets"] = {
											["Droomon <Nedro>"] = 1047,
										},
										["counter"] = 8,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675841510,
							["passiveover"] = 0.004223,
							["alternatepower"] = 0.004223,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 225,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 17,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47836] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47836,
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -1,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = 47864,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 121,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 63321,
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 23,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 23,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 23,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[61595] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 61595,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[64371] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 64371,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[17941] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 17941,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 62,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[17941] = 1,
								[47813] = 1,
								[47843] = 2,
								[59164] = 1,
								[47864] = 3,
								[47836] = 1,
								[47857] = 2,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675841511,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "29333",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[54617] = 4,
								[40652] = 3,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-29333-0005631982",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["spell_cast"] = {
								[54053] = 8,
							},
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 225,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 693685.723,
				["tempo_start"] = 1675841488,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 242,
				["playing_solo"] = true,
				["totals"] = {
					29678.986561, -- [1]
					3179, -- [2]
					{
						0, -- [1]
						[0] = 1047,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:31:52",
				["hasTimer"] = 22,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 693669.2390000001,
				["CombatEndedAt"] = 693669.2390000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:31:29",
				["end_time"] = 693669.2390000001,
				["combat_id"] = 225,
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Corrupted Scarlet Onslaught"] = 2,
					["Onslaught Gryphon Rider"] = 3,
				},
				["totals_grupo"] = {
					17728, -- [1]
					2412, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 24606.007134,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 2412.006479,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693646.356,
				["contra"] = "Onslaught Gryphon Rider",
				["overall_added"] = true,
			}, -- [2]
			{
				{
					["tipo"] = 2,
					["combatId"] = 224,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007638,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 25486,
							},
							["end_time"] = 1675841472,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 21700.007638,
							["last_dps"] = 1751.615645217762,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 25486.007638,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3116,
										["g_amt"] = 0,
										["n_max"] = 1559,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 5882,
										},
										["n_dmg"] = 2766,
										["n_min"] = 1207,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[5] = 1559,
											[9] = 4675,
											[12] = 4675,
										},
										["total"] = 5882,
										["c_max"] = 3116,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 3116,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47836] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 939,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 939,
										},
										["n_dmg"] = 939,
										["n_min"] = 939,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[5] = 939,
											[9] = 939,
											[12] = 939,
										},
										["total"] = 939,
										["c_max"] = 0,
										["id"] = 47836,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2410,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 4309,
										},
										["n_dmg"] = 4309,
										["n_min"] = 1899,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 1899,
											[9] = 1899,
											[12] = 1899,
										},
										["total"] = 4309,
										["c_max"] = 0,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47834] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 4328,
										["g_amt"] = 0,
										["n_max"] = 3542,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 7870,
										},
										["n_dmg"] = 3542,
										["n_min"] = 3542,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 7870,
											[9] = 7870,
											[12] = 7870,
										},
										["total"] = 7870,
										["c_max"] = 4328,
										["id"] = 47834,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 4328,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 506,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1794,
										},
										["n_dmg"] = 1794,
										["n_min"] = 391,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[5] = 505,
											[9] = 1011,
											[12] = 1402,
										},
										["total"] = 1794,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47857] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 906,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 906,
										},
										["n_dmg"] = 906,
										["n_min"] = 906,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[9] = 906,
											[12] = 906,
										},
										["total"] = 906,
										["c_max"] = 0,
										["id"] = 47857,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 4937.007638,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675841470,
							["on_hold"] = false,
							["start_time"] = 1675841457,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007736,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Corrupted Scarlet Onslaught"] = 89,
								["Nedro"] = 4937,
								["Roghaye"] = 327,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Corrupted Scarlet Onslaught"] = true,
								["Nedro"] = true,
								["Roghaye"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 5353.007736,
							["last_dps"] = 0,
							["last_event"] = 1675841487,
							["dps_started"] = false,
							["end_time"] = 1675841472,
							["aID"] = "29333",
							["total"] = 5353.007736,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1013,
										["g_amt"] = 0,
										["n_max"] = 480,
										["targets"] = {
											["Nedro"] = 2766,
											["Roghaye"] = 327,
										},
										["n_dmg"] = 2080,
										["n_min"] = 158,
										["g_dmg"] = 0,
										["counter"] = 13,
										["r_amt"] = 0,
										["total"] = 3093,
										["c_max"] = 1013,
										["b_dmg"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["a_amt"] = 0,
										["extra"] = {
										},
										["PARRY"] = 3,
										["c_min"] = 1013,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["MISS"] = 1,
									}, -- [1]
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 89,
										["targets"] = {
											["Corrupted Scarlet Onslaught"] = 89,
											["Nedro"] = 74,
											["Roghaye"] = 0,
										},
										["n_dmg"] = 163,
										["n_min"] = 74,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 163,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["BLOCK"] = 1,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[54617] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1097,
										["targets"] = {
											["Nedro"] = 2097,
										},
										["n_dmg"] = 2097,
										["n_min"] = 1000,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2097,
										["c_max"] = 0,
										["id"] = 54617,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 33738.007736,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841457,
							["serial"] = "Creature-0-4457-571-176-29333-0001633991",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007745,
							["damage_from"] = {
							},
							["targets"] = {
								["Onslaught Gryphon Rider"] = 3786,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 3786.007745,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 3786.007745,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675841472,
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 384,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1769,
										},
										["n_dmg"] = 1769,
										["n_min"] = 320,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1769,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 912,
										["g_amt"] = 0,
										["n_max"] = 409,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2017,
										},
										["n_dmg"] = 1105,
										["n_min"] = 310,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 2017,
										["c_max"] = 912,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 912,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.007745,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675841470,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841462,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 224,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 0.005863,
							["total_without_pet"] = 3272.005863,
							["total"] = 3272.005863,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.005863,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 3272,
							},
							["totalover_without_pet"] = 0.005863,
							["healing_taken"] = 7544.005863,
							["fight_component"] = true,
							["end_time"] = 1675841472,
							["healing_from"] = {
								["Nedro"] = true,
								["Onslaught Gryphon Rider"] = true,
							},
							["last_event"] = 1675841470,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 624,
										["targets"] = {
											["Nedro"] = 1426,
										},
										["n_min"] = 319,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 1426,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 1426,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 314,
										["targets"] = {
											["Nedro"] = 940,
										},
										["n_min"] = 313,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 940,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 940,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47857] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 906,
										["targets"] = {
											["Nedro"] = 906,
										},
										["n_min"] = 906,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 906,
										["c_max"] = 0,
										["id"] = 47857,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 906,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.005863,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675841458,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 1794.006435,
							["total_without_pet"] = 4272.006435,
							["monster"] = true,
							["total"] = 4272.006435,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-29333-0001633991",
							["totalabsorb"] = 0.006435,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 4272,
							},
							["totalover_without_pet"] = 0.006435,
							["healing_taken"] = 0.006435,
							["fight_component"] = true,
							["end_time"] = 1675841472,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 1794,
										},
										["n_max"] = 1899,
										["targets"] = {
											["Nedro"] = 4272,
										},
										["n_min"] = 635,
										["counter"] = 3,
										["overheal"] = 1794,
										["total"] = 4272,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 4272,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 1794,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.006435,
							["custom"] = 0,
							["last_event"] = 1675841470,
							["classe"] = "UNKNOW",
							["start_time"] = 1675841464,
							["delay"] = 0,
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 224,
					["_ActorTable"] = {
						{
							["received"] = 3394.008975,
							["resource"] = 0.008975,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 3394,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 0.008975,
							["fight_component"] = true,
							["total"] = 3917.008975,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 3394,
										["id"] = 31818,
										["totalover"] = 0,
										["targets"] = {
											["Nedro"] = 3394,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.008975,
							["last_event"] = 1675841470,
							["alternatepower"] = 0.008975,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 523.006976,
							["resource"] = 0.006976,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 523,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 1563.006976,
							["total"] = 523.006976,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 523,
										["id"] = 54425,
										["totalover"] = 1563,
										["targets"] = {
											["Droomon <Nedro>"] = 523,
										},
										["counter"] = 4,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675841469,
							["passiveover"] = 0.006976,
							["alternatepower"] = 0.006976,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 224,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47836] = {
										["activedamt"] = -1,
										["id"] = 47836,
										["targets"] = {
										},
										["actived_at"] = 1675841458,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 67,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[55637] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 55637,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[60064] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 60064,
										["uptime"] = 5,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 63321,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 30,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[47813] = 2,
								[47864] = 2,
								[59164] = 2,
								[47857] = 1,
								[57946] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675841472,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "29333",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[40652] = 2,
								[54617] = 2,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-29333-0001633991",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["spell_cast"] = {
								[54053] = 4,
							},
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 224,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 693644.822,
				["tempo_start"] = 1675841457,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 241,
				["playing_solo"] = true,
				["totals"] = {
					30838.983772, -- [1]
					7544, -- [2]
					{
						0, -- [1]
						[0] = 3916.991631,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = -0.00332700000000008,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:31:13",
				["hasTimer"] = 14,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 693629.9720000001,
				["CombatEndedAt"] = 693629.9720000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:30:58",
				["end_time"] = 693629.9720000001,
				["combat_id"] = 224,
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 2,
				},
				["totals_grupo"] = {
					21700, -- [1]
					3272, -- [2]
					{
						0, -- [1]
						[0] = 3394,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 25486.007638,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 3272.005863,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693615.422,
				["contra"] = "Onslaught Gryphon Rider",
				["overall_added"] = true,
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 223,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005083,
							["classe"] = "WARLOCK",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 39850,
							},
							["damage_taken"] = 8645.005083,
							["pets"] = {
								"Unknown <Nedro>", -- [1]
							},
							["damage_from"] = {
								["Onslaught Harbor Guard"] = true,
								["Onslaught Gryphon Rider"] = true,
							},
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 35276.005083,
							["last_event"] = 1675841409,
							["aID"] = "4477-04D9C328",
							["dps_started"] = false,
							["total"] = 39850.005083,
							["delay"] = 1675841409,
							["end_time"] = 1675841422,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47809] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3382,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3382,
										},
										["n_dmg"] = 3382,
										["n_min"] = 3382,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[113] = 3382,
											[101] = 3382,
											[110] = 3382,
											[107] = 3382,
											[104] = 3382,
										},
										["total"] = 3382,
										["c_max"] = 0,
										["id"] = 47809,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47813] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3446,
										["g_amt"] = 0,
										["n_max"] = 1889,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 11958,
										},
										["n_dmg"] = 8512,
										["n_min"] = 1117,
										["g_dmg"] = 0,
										["counter"] = 7,
										["ChartData"] = {
											[27] = 2560,
											[107] = 11958,
											[62] = 2560,
											[92] = 9619,
											[77] = 2560,
											[14] = 1117,
											[110] = 11958,
											[48] = 2560,
											[56] = 2560,
											[80] = 2560,
											[65] = 2560,
											[113] = 11958,
											[21] = 2560,
											[98] = 10826,
											[42] = 2560,
											[50] = 2560,
											[68] = 2560,
											[35] = 2560,
											[101] = 11958,
											[59] = 2560,
											[18] = 2560,
											[86] = 4284,
											[30] = 2560,
											[71] = 2560,
											[44] = 2560,
											[104] = 11958,
											[39] = 2560,
											[33] = 2560,
											[89] = 7730,
											[53] = 2560,
											[95] = 9619,
											[74] = 2560,
											[23] = 2560,
											[83] = 2560,
										},
										["total"] = 11958,
										["c_max"] = 3446,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 3446,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 557,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 4452,
										},
										["n_dmg"] = 4452,
										["n_min"] = 364,
										["g_dmg"] = 0,
										["counter"] = 10,
										["ChartData"] = {
											[27] = 1198,
											[107] = 4452,
											[62] = 1198,
											[92] = 2868,
											[77] = 1198,
											[14] = 728,
											[110] = 4452,
											[48] = 1198,
											[56] = 1198,
											[80] = 1198,
											[65] = 1198,
											[113] = 4452,
											[21] = 1198,
											[98] = 3650,
											[42] = 1198,
											[50] = 1198,
											[68] = 1198,
											[35] = 1198,
											[11] = 364,
											[101] = 4452,
											[59] = 1198,
											[18] = 1198,
											[86] = 1755,
											[30] = 1198,
											[71] = 1198,
											[44] = 1198,
											[104] = 4452,
											[39] = 1198,
											[95] = 3259,
											[89] = 2868,
											[53] = 1198,
											[33] = 1198,
											[74] = 1198,
											[23] = 1198,
											[83] = 1198,
										},
										["total"] = 4452,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3343,
										["g_amt"] = 0,
										["n_max"] = 1757,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 5100,
										},
										["n_dmg"] = 1757,
										["n_min"] = 1757,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[27] = 3343,
											[107] = 5100,
											[62] = 3343,
											[92] = 5100,
											[77] = 3343,
											[14] = 3343,
											[110] = 5100,
											[48] = 3343,
											[56] = 3343,
											[80] = 3343,
											[65] = 3343,
											[113] = 5100,
											[21] = 3343,
											[98] = 5100,
											[42] = 3343,
											[50] = 3343,
											[68] = 3343,
											[35] = 3343,
											[101] = 5100,
											[59] = 3343,
											[18] = 3343,
											[86] = 5100,
											[30] = 3343,
											[71] = 3343,
											[44] = 3343,
											[104] = 5100,
											[39] = 3343,
											[33] = 3343,
											[89] = 5100,
											[53] = 3343,
											[95] = 5100,
											[74] = 3343,
											[23] = 3343,
											[83] = 5100,
										},
										["total"] = 5100,
										["c_max"] = 3343,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 3343,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47843] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 5026,
										["g_amt"] = 0,
										["n_max"] = 1172,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 9050,
										},
										["n_dmg"] = 4024,
										["n_min"] = 908,
										["g_dmg"] = 0,
										["counter"] = 6,
										["ChartData"] = {
											[27] = 2080,
											[107] = 9050,
											[62] = 2080,
											[92] = 5065,
											[77] = 2080,
											[14] = 2080,
											[110] = 9050,
											[48] = 2080,
											[56] = 2080,
											[80] = 2080,
											[65] = 2080,
											[113] = 9050,
											[21] = 2080,
											[98] = 6037,
											[42] = 2080,
											[50] = 2080,
											[68] = 2080,
											[35] = 2080,
											[11] = 908,
											[101] = 7009,
											[59] = 2080,
											[18] = 2080,
											[86] = 2080,
											[30] = 2080,
											[71] = 2080,
											[44] = 2080,
											[104] = 9050,
											[39] = 2080,
											[95] = 5065,
											[89] = 5065,
											[53] = 2080,
											[33] = 2080,
											[74] = 2080,
											[23] = 2080,
											[83] = 2080,
										},
										["total"] = 9050,
										["c_max"] = 2985,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 2041,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47857] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 667,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1334,
										},
										["n_dmg"] = 1334,
										["n_min"] = 667,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[113] = 1334,
											[101] = 667,
											[110] = 1334,
											[107] = 1334,
											[104] = 1334,
										},
										["total"] = 1334,
										["c_max"] = 0,
										["id"] = 47857,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841391,
							["serial"] = "Player-4477-04D9C328",
							["last_dps"] = 346.0643765027064,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003752,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1405,
								["Unknown <Nedro>"] = 298,
								["Nedro"] = 8071,
							},
							["pets"] = {
							},
							["delay"] = 1675841408,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Unknown <Nedro>"] = true,
								["Corrupted Scarlet Onslaught"] = true,
								["Nedro"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 9774.003752,
							["last_dps"] = 0,
							["last_event"] = 1675841408,
							["dps_started"] = false,
							["end_time"] = 1675841422,
							["aID"] = "29333",
							["total"] = 9774.003752,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 758,
										["g_amt"] = 0,
										["n_max"] = 490,
										["targets"] = {
											["Droomon <Nedro>"] = 654,
											["Unknown <Nedro>"] = 298,
											["Nedro"] = 6708,
										},
										["n_dmg"] = 6902,
										["n_min"] = 298,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 7660,
										["c_max"] = 758,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 758,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 17,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 92,
										["targets"] = {
											["Nedro"] = 247,
										},
										["n_dmg"] = 247,
										["n_min"] = 75,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 247,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[54617] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1116,
										["targets"] = {
											["Droomon <Nedro>"] = 751,
											["Nedro"] = 1116,
										},
										["n_dmg"] = 1867,
										["n_min"] = 751,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1867,
										["c_max"] = 0,
										["id"] = 54617,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 751,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 39924.003752,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841390,
							["serial"] = "Creature-0-4457-571-176-29333-000C631982",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00729,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Corrupted Scarlet Onslaught"] = 6745,
								["Nedro"] = 574,
								["Roghaye"] = 878,
							},
							["pets"] = {
							},
							["delay"] = 1675841353,
							["damage_from"] = {
								["Corrupted Scarlet Onslaught"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 8197.00729,
							["last_dps"] = 0,
							["last_event"] = 1675841456,
							["dps_started"] = false,
							["end_time"] = 1675841457,
							["aID"] = "29330",
							["total"] = 8197.00729,
							["nome"] = "Onslaught Harbor Guard",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 812,
										["g_amt"] = 0,
										["n_max"] = 504,
										["targets"] = {
											["Corrupted Scarlet Onslaught"] = 6745,
										},
										["n_dmg"] = 5933,
										["n_min"] = 370,
										["g_dmg"] = 0,
										["counter"] = 24,
										["r_amt"] = 0,
										["total"] = 6745,
										["c_max"] = 812,
										["b_dmg"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["a_amt"] = 0,
										["extra"] = {
										},
										["PARRY"] = 3,
										["c_min"] = 812,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 14,
										["MISS"] = 4,
										["a_dmg"] = 0,
									}, -- [1]
									[6660] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 574,
										["targets"] = {
											["Nedro"] = 574,
											["Roghaye"] = 878,
										},
										["n_dmg"] = 1452,
										["n_min"] = 199,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 1452,
										["c_max"] = 0,
										["id"] = 6660,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["BLOCK"] = 2,
										["successful_casted"] = 0,
										["c_min"] = 0,
										["n_amt"] = 5,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 3182.00729,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841375,
							["serial"] = "Creature-0-4457-571-176-29330-0018E31983",
							["on_hold"] = false,
						}, -- [3]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005375,
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["targets"] = {
								["Onslaught Gryphon Rider"] = 4574,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 4574.005375,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4574.005375,
							["delay"] = 1675841323,
							["dps_started"] = false,
							["end_time"] = 1675841422,
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Unknown <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1257,
										["g_amt"] = 0,
										["n_max"] = 354,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2656,
										},
										["n_dmg"] = 1399,
										["n_min"] = 339,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2656,
										["c_max"] = 645,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 612,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 453,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1918,
										},
										["n_dmg"] = 1918,
										["n_min"] = 303,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1918,
										["c_max"] = 0,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1703.005375,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675841323,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841411,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 223,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 5264,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 5264.005833,
							["total_without_pet"] = 7076.005833,
							["total"] = 7076.005833,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.005833,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 7076,
							},
							["totalover_without_pet"] = 0.005833,
							["healing_taken"] = 10645.005833,
							["fight_component"] = true,
							["end_time"] = 1675841422,
							["healing_from"] = {
								["Nedro"] = true,
								["Onslaught Gryphon Rider"] = true,
							},
							["last_event"] = 1675841418,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 302,
										},
										["n_max"] = 1077,
										["targets"] = {
											["Nedro"] = 3503,
										},
										["n_min"] = 115,
										["counter"] = 7,
										["overheal"] = 302,
										["total"] = 3503,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 7,
										["n_curado"] = 3503,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 4962,
										},
										["n_max"] = 313,
										["targets"] = {
											["Nedro"] = 2239,
										},
										["n_min"] = 0,
										["counter"] = 23,
										["overheal"] = 4962,
										["total"] = 2239,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 23,
										["n_curado"] = 2239,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47857] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 667,
										["targets"] = {
											["Nedro"] = 1334,
										},
										["n_min"] = 667,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 1334,
										["c_max"] = 0,
										["id"] = 47857,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 1334,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.005833,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675841308,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 4033.007009,
							["total_without_pet"] = 3569.007009,
							["monster"] = true,
							["total"] = 3569.007009,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-29333-000C631982",
							["totalabsorb"] = 0.007009,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 3569,
							},
							["totalover_without_pet"] = 0.007009,
							["healing_taken"] = 0.007009,
							["fight_component"] = true,
							["end_time"] = 1675841422,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 4033,
										},
										["n_max"] = 2409,
										["targets"] = {
											["Nedro"] = 3569,
										},
										["n_min"] = 1160,
										["counter"] = 2,
										["overheal"] = 4033,
										["total"] = 3569,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 3569,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 4033,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.007009,
							["custom"] = 0,
							["last_event"] = 1675841398,
							["classe"] = "UNKNOW",
							["start_time"] = 1675841421,
							["delay"] = 1675841398,
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 223,
					["_ActorTable"] = {
						{
							["received"] = 2455.001172,
							["resource"] = 0.001172,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 2455,
							},
							["pets"] = {
								"Unknown <Nedro>", -- [1]
								"Droomon <Nedro>", -- [2]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 542.001172,
							["fight_component"] = true,
							["total"] = 3263.001172,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 2455,
										["id"] = 31818,
										["totalover"] = 542,
										["targets"] = {
											["Nedro"] = 2455,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.001172,
							["last_event"] = 1675841322,
							["alternatepower"] = 0.001172,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 131.003925,
							["resource"] = 0.003925,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Unknown <Nedro>"] = 131,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 376.003925,
							["total"] = 131.003925,
							["ownerName"] = "Nedro",
							["nome"] = "Unknown <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 131,
										["id"] = 54425,
										["totalover"] = 376,
										["targets"] = {
											["Unknown <Nedro>"] = 131,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675841313,
							["passiveover"] = 0.003925,
							["alternatepower"] = 0.003925,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
						}, -- [2]
						{
							["received"] = 677.0074050000001,
							["resource"] = 0.007405,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 677,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 1396.007405,
							["total"] = 677.0074050000001,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 677,
										["id"] = 54425,
										["totalover"] = 1396,
										["targets"] = {
											["Droomon <Nedro>"] = 677,
										},
										["counter"] = 4,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675841322,
							["passiveover"] = 0.007405,
							["alternatepower"] = 0.007405,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
						}, -- [3]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 223,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 20,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47836] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47836,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[17800] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 17800,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 436,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[55637] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 55637,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 115,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 115,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[60064] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 60064,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57567] = {
										["activedamt"] = 1,
										["id"] = 57567,
										["targets"] = {
										},
										["actived_at"] = 1675841313,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									[61595] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 61595,
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 115,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 1,
										["id"] = 63321,
										["uptime"] = 55,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32245] = {
										["activedamt"] = 1,
										["id"] = 32245,
										["targets"] = {
										},
										["actived_at"] = 1675841307,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 90,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[47809] = 1,
								[47864] = 3,
								[47813] = 3,
								[47857] = 2,
								[59164] = 2,
								[57946] = 1,
								[47836] = 1,
								[47843] = 3,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675841422,
							["pets"] = {
								"Unknown <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "29333",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[40652] = 3,
								[54617] = 2,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-29333-000C631982",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Unknown <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-0A007B88D5",
							["spell_cast"] = {
								[23832] = 1,
								[54053] = 5,
							},
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 223,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 693611.672,
				["tempo_start"] = 1675841307,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 240,
				["playing_solo"] = true,
				["totals"] = {
					57820.988347, -- [1]
					10645, -- [2]
					{
						0, -- [1]
						[0] = 3263,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:30:23",
				["hasTimer"] = 115.0519999999087,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Harbor Guard",
				["TotalElapsedCombatTime"] = 693580.205,
				["CombatEndedAt"] = 693580.205,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:28:28",
				["end_time"] = 693580.205,
				["combat_id"] = 223,
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 3,
					["Corrupted Scarlet Onslaught"] = 1,
				},
				["totals_grupo"] = {
					35276, -- [1]
					7076, -- [2]
					{
						0, -- [1]
						[0] = 2455,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 39850.005083,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 7076.005833,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693465.0530000001,
				["contra"] = "Onslaught Harbor Guard",
				["overall_added"] = true,
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 222,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004731,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 12895,
							},
							["end_time"] = 1675841296,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 9451.004731,
							["last_dps"] = 1137.828000619255,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 12895.004731,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47843] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 2273,
										["g_amt"] = 0,
										["n_max"] = 880,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3153,
										},
										["n_dmg"] = 880,
										["n_min"] = 880,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[9] = 880,
										},
										["total"] = 3153,
										["c_max"] = 2273,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 2273,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 4259,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 4259,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 4259,
										["c_max"] = 4259,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 4259,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 352,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 704,
										},
										["n_dmg"] = 704,
										["n_min"] = 352,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[9] = 704,
										},
										["total"] = 704,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47813] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1335,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1335,
										},
										["n_dmg"] = 1335,
										["n_min"] = 1335,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[9] = 1335,
										},
										["total"] = 1335,
										["c_max"] = 0,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 487.004731,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675841295,
							["on_hold"] = false,
							["start_time"] = 1675841286,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.008066,
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["targets"] = {
								["Onslaught Gryphon Rider"] = 3444,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 3444.008066,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 3444.008066,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675841296,
							["aID"] = "Pet-0-4457-571-176-417-09007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 395,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1850,
										},
										["n_dmg"] = 1850,
										["n_min"] = 344,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1850,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 505,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1594,
										},
										["n_dmg"] = 1594,
										["n_min"] = 291,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1594,
										["c_max"] = 0,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1160.008066,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675841294,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841286,
							["serial"] = "Pet-0-4457-571-176-417-09007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006939,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1160,
								["Nedro"] = 487,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Nedro"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1647.006939,
							["last_dps"] = 0,
							["last_event"] = 1675841294,
							["dps_started"] = false,
							["end_time"] = 1675841296,
							["aID"] = "29333",
							["total"] = 1647.006939,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 487,
										["targets"] = {
											["Droomon <Nedro>"] = 1160,
											["Nedro"] = 487,
										},
										["n_dmg"] = 1647,
										["n_min"] = 255,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1647,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 5,
										["spellschool"] = 1,
										["MISS"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 12895.006939,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675841284,
							["serial"] = "Creature-0-4457-571-176-29333-000DE31982",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 222,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 139,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 139.006836,
							["total_without_pet"] = 1021.006836,
							["total"] = 1021.006836,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.006836,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 1021,
							},
							["totalover_without_pet"] = 0.006836,
							["healing_taken"] = 2487.006836,
							["fight_component"] = true,
							["end_time"] = 1675841296,
							["healing_from"] = {
								["Nedro"] = true,
								["Onslaught Gryphon Rider"] = true,
							},
							["last_event"] = 1675841293,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 139,
										},
										["n_max"] = 313,
										["targets"] = {
											["Nedro"] = 487,
										},
										["n_min"] = 174,
										["counter"] = 2,
										["overheal"] = 139,
										["total"] = 487,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 487,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 534,
										["targets"] = {
											["Nedro"] = 534,
										},
										["n_min"] = 534,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 534,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 534,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.006836,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675841288,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 221.006878,
							["total_without_pet"] = 1466.006878,
							["monster"] = true,
							["total"] = 1466.006878,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-29333-000DE31982",
							["totalabsorb"] = 0.006878,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 1466,
							},
							["totalover_without_pet"] = 0.006878,
							["healing_taken"] = 0.006878,
							["fight_component"] = true,
							["end_time"] = 1675841296,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 221,
										},
										["n_max"] = 1466,
										["targets"] = {
											["Nedro"] = 1466,
										},
										["n_min"] = 1466,
										["counter"] = 1,
										["overheal"] = 221,
										["total"] = 1466,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 1466,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 221,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.006878,
							["custom"] = 0,
							["last_event"] = 1675841295,
							["classe"] = "UNKNOW",
							["start_time"] = 1675841295,
							["delay"] = 0,
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 222,
					["_ActorTable"] = {
						{
							["received"] = 2425.002857,
							["resource"] = 0.002857,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 2425,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 970.002857,
							["fight_component"] = true,
							["total"] = 3109.002857,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 2425,
										["id"] = 31818,
										["totalover"] = 970,
										["targets"] = {
											["Nedro"] = 2425,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.002857,
							["last_event"] = 1675841293,
							["alternatepower"] = 0.002857,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 684.00608,
							["resource"] = 0.00608,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 684,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 1375.00608,
							["total"] = 684.00608,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 684,
										["id"] = 54425,
										["totalover"] = 1375,
										["targets"] = {
											["Droomon <Nedro>"] = 684,
										},
										["counter"] = 4,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675841293,
							["passiveover"] = 0.00608,
							["alternatepower"] = 0.00608,
							["serial"] = "Pet-0-4457-571-176-417-09007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-09007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 222,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 70,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32245] = {
										["activedamt"] = 1,
										["id"] = 32245,
										["targets"] = {
										},
										["actived_at"] = 1675841284,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									[55637] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 55637,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57567] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57567,
										["uptime"] = 20,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[60064] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 60064,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 63321,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 20,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[47813] = 1,
								[47843] = 1,
								[59164] = 1,
								[47864] = 1,
								[57946] = 1,
								[47857] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675841305,
							["pets"] = {
								"Unknown <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-09007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Unknown <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-09007B88D5",
							["spell_cast"] = {
								[23832] = 1,
								[54053] = 4,
							},
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 222,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 693464.036,
				["tempo_start"] = 1675841284,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 239,
				["playing_solo"] = true,
				["totals"] = {
					14541.994194, -- [1]
					2487, -- [2]
					{
						0, -- [1]
						[0] = 3109,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:28:17",
				["hasTimer"] = 11,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 693453.902,
				["CombatEndedAt"] = 693453.902,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:28:05",
				["end_time"] = 693453.902,
				["combat_id"] = 222,
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 1,
				},
				["totals_grupo"] = {
					9451, -- [1]
					1021, -- [2]
					{
						0, -- [1]
						[0] = 2425,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 12895.004731,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 1021.006836,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693442.569,
				["contra"] = "Onslaught Gryphon Rider",
				["overall_added"] = true,
			}, -- [5]
			{
				{
					["tipo"] = 2,
					["combatId"] = 221,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006493,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["end_time"] = 1675840999,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006493,
							["last_dps"] = 98280.006493,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 98280.006493,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.006493,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840998,
							["on_hold"] = false,
							["start_time"] = 1675840998,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006348,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 98280.006348,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.006348,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840999,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.006348,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840998,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840998,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001066,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001066,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840999,
							["aID"] = "",
							["total"] = 0.001066,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 98280.001066,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840999,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DE3",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 221,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 313,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["aID"] = "4477-04D9C328",
							["totalover"] = 313.004049,
							["total_without_pet"] = 0.004049,
							["total"] = 0.004049,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.004049,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.004049,
							["healing_taken"] = 0.004049,
							["end_time"] = 1675840999,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
							},
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 313,
										},
										["n_max"] = 0,
										["targets"] = {
											["Nedro"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 313,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1675840998,
							["classe"] = "WARLOCK",
							["custom"] = 0,
							["tipo"] = 2,
							["totaldenied"] = 0.004049,
							["start_time"] = 1675840998,
							["delay"] = 0,
							["spec"] = 265,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 221,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 221,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 65,
							["last_event"] = 1675841173,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57567] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 3,
										["refreshamt"] = 0,
										["id"] = 57567,
										["uptime"] = 62,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 221,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 693440.969,
				["tempo_start"] = 1675840998,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 238,
				["totals"] = {
					98279.989904, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:23:20",
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:23:19",
				["end_time"] = 693157.214,
				["combat_id"] = 221,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 98280.006493,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 0.004049,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693156.214,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [6]
			{
				{
					["tipo"] = 2,
					["combatId"] = 220,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004723,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["end_time"] = 1675840998,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004723,
							["last_dps"] = 201600.0072589325,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 131040.004723,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.004723,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840997,
							["on_hold"] = false,
							["start_time"] = 1675840997,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005565,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 131040.005565,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 131040.005565,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840998,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 131040,
										},
										["n_dmg"] = 131040,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 131040,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.005565,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840997,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840997,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007072,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007072,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840998,
							["aID"] = "",
							["total"] = 0.007072,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 131040.007072,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840998,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DDF",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 220,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 220,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 220,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840998,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 220,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["tempo_start"] = 1675840997,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["combat_counter"] = 237,
				["overall_added"] = true,
				["totals"] = {
					131040, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:23:18",
				["end_time"] = 693156.047,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 220,
				["frags"] = {
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "08:23:19",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 131040.004723,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693155.047,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [7]
			{
				{
					["tipo"] = 2,
					["combatId"] = 219,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.007592,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["end_time"] = 1675840993,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007592,
							["last_dps"] = 65520.007592,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 65520.007592,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.007592,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840992,
							["on_hold"] = false,
							["start_time"] = 1675840992,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.00195,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 65520.00195000001,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.00195000001,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840993,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.00195,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840992,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840992,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005745,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005745,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840993,
							["aID"] = "",
							["total"] = 0.005745,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 65520.005745,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840993,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DD0",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 219,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 219,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 219,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840993,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 219,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840992,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 236,
				["totals"] = {
					65519.989414, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:23:13",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 65520.007592,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693150.814,
				["combat_id"] = 219,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:23:12",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693149.814,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [8]
			{
				{
					["tipo"] = 2,
					["combatId"] = 218,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.001281,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["end_time"] = 1675840989,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001281,
							["last_dps"] = 327600.01281,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 32760.001281,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.001281,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840988,
							["on_hold"] = false,
							["start_time"] = 1675840988,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.003506,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 32760.003506,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.003506,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840989,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.003506,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840988,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840988,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001918,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001918,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840989,
							["aID"] = "",
							["total"] = 0.001918,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 32760.001918,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840989,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000633A14",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 218,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 313,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["aID"] = "4477-04D9C328",
							["totalover"] = 313.002705,
							["total_without_pet"] = 0.002705,
							["total"] = 0.002705,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.002705,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.002705,
							["healing_taken"] = 0.002705,
							["end_time"] = 1675840989,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
							},
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 313,
										},
										["n_max"] = 0,
										["targets"] = {
											["Nedro"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 313,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1675840988,
							["classe"] = "WARLOCK",
							["custom"] = 0,
							["tipo"] = 2,
							["totaldenied"] = 0.002705,
							["start_time"] = 1675840988,
							["delay"] = 0,
							["spec"] = 265,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 218,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 218,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840989,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 218,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840988,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 235,
				["totals"] = {
					32760, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:23:09",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 32760.001281,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 0.002705,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693146.831,
				["combat_id"] = 218,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:23:08",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693145.831,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [9]
			{
				{
					["tipo"] = 2,
					["combatId"] = 217,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.003521,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["end_time"] = 1675840983,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003521,
							["last_dps"] = 358032.8062022112,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 65520.003521,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.003521,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840982,
							["on_hold"] = false,
							["start_time"] = 1675840982,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.008783,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 65520.008783,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.008783,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840983,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.008783,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840982,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840982,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001066,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001066,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840983,
							["aID"] = "",
							["total"] = 0.001066,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 65520.001066,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840983,
							["serial"] = "Vehicle-0-4457-571-176-30330-00006339EE",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 217,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 314,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["aID"] = "4477-04D9C328",
							["totalover"] = 314.003943,
							["total_without_pet"] = 0.003943,
							["total"] = 0.003943,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.003943,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.003943,
							["healing_taken"] = 0.003943,
							["end_time"] = 1675840983,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
							},
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 314,
										},
										["n_max"] = 0,
										["targets"] = {
											["Nedro"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 314,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1675840983,
							["classe"] = "WARLOCK",
							["custom"] = 0,
							["tipo"] = 2,
							["totaldenied"] = 0.003943,
							["start_time"] = 1675840983,
							["delay"] = 0,
							["spec"] = 265,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 217,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 217,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840983,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 217,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840982,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 234,
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:23:04",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 65520.003521,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 0.003943,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693141.697,
				["combat_id"] = 217,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:23:03",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693140.697,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [10]
			{
				{
					["tipo"] = 2,
					["combatId"] = 216,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005731,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["end_time"] = 1675840982,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005731,
							["last_dps"] = 106363.6456807158,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 65520.005731,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.005731,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840982,
							["on_hold"] = false,
							["start_time"] = 1675840981,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.004762,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 65520.004762,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.004762,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840982,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.004762,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840982,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840981,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005779,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005779,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840982,
							["aID"] = "",
							["total"] = 0.005779,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 65520.005779,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840982,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DCC",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 216,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 216,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 216,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840982,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 216,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840981,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 233,
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:23:03",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 65520.005731,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693140.464,
				["combat_id"] = 216,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:23:02",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693139.464,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [11]
			{
				{
					["tipo"] = 2,
					["combatId"] = 215,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008632,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["end_time"] = 1675840978,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008632,
							["last_dps"] = 65520.008632,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 65520.008632,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.008632,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840977,
							["on_hold"] = false,
							["start_time"] = 1675840977,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.001902,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 65520.001902,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.001902,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840978,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.001902,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840977,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840977,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005992,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005992,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840978,
							["aID"] = "",
							["total"] = 0.005992,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 65520.005992,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840978,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DD0",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 215,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 215,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 215,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840978,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 215,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840977,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 232,
				["totals"] = {
					65519.99139599999, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:59",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 65520.008632,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693136.197,
				["combat_id"] = 215,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:58",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693135.197,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [12]
			{
				{
					["tipo"] = 2,
					["combatId"] = 214,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006809,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["end_time"] = 1675840974,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006809,
							["last_dps"] = 65520.006809,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 65520.006809,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.006809,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840974,
							["on_hold"] = false,
							["start_time"] = 1675840973,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006317,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 65520.006317,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.006317,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840974,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.006317,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840974,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840973,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003084,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003084,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840974,
							["aID"] = "",
							["total"] = 0.003084,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 65520.003084,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840974,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DBF",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 214,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 214,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 214,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840974,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 214,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840973,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 231,
				["totals"] = {
					65519.99316300001, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:55",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 65520.006809,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693132.48,
				["combat_id"] = 214,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:54",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693131.48,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [13]
			{
				{
					["tipo"] = 2,
					["combatId"] = 213,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004704,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["end_time"] = 1675840970,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004704,
							["last_dps"] = 98181.82287646015,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 98280.00470399999,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.004704,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840969,
							["on_hold"] = false,
							["start_time"] = 1675840969,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 98280.005,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.005,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840970,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.005,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840969,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840969,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008579,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008579,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840970,
							["aID"] = "",
							["total"] = 0.008579,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 98280.008579,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840970,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DB7",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 213,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 213,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 213,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840970,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 213,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840969,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 230,
				["totals"] = {
					98279.98336700001, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:51",
				["hasTimer"] = 1.001000000047498,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 98280.00470399999,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693128.1140000001,
				["combat_id"] = 213,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:50",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693127.113,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [14]
			{
				{
					["tipo"] = 2,
					["combatId"] = 212,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008352,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["end_time"] = 1675840967,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008352,
							["last_dps"] = 327600.08352,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 32760.008352,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.008352,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840966,
							["on_hold"] = false,
							["start_time"] = 1675840966,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.0058,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 32760.0058,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.0058,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840967,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.0058,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840966,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840966,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001387,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001387,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840967,
							["aID"] = "",
							["total"] = 0.001387,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 32760.001387,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840967,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DC4",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 212,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 212,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 212,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840967,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 212,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840966,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 229,
				["totals"] = {
					32760, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:48",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 32760.008352,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693125.197,
				["combat_id"] = 212,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:47",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693124.197,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [15]
			{
				{
					["tipo"] = 2,
					["combatId"] = 211,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.00849,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["end_time"] = 1675840966,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00849,
							["last_dps"] = 140400.0121379113,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 98280.00849000001,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.00849,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840965,
							["on_hold"] = false,
							["start_time"] = 1675840965,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.008573,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 98280.008573,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.008573,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840966,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.008573,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840965,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840965,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004516,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004516,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840966,
							["aID"] = "",
							["total"] = 0.004516,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 98280.004516,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840966,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DC4",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 211,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 211,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 211,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840966,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 211,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["tempo_start"] = 1675840965,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["combat_counter"] = 228,
				["overall_added"] = true,
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:22:46",
				["end_time"] = 693124.18,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 211,
				["frags"] = {
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "08:22:47",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 98280.00849000001,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693123.18,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [16]
			{
				{
					["tipo"] = 2,
					["combatId"] = 210,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.002616,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["end_time"] = 1675840964,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002616,
							["last_dps"] = 281201.7279566733,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 65520.002616,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.002616,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840963,
							["on_hold"] = false,
							["start_time"] = 1675840963,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.00335,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 65520.00335,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.00335,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840964,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.00335,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840963,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840963,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001404,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001404,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840964,
							["aID"] = "",
							["total"] = 0.001404,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 65520.001404,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840964,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DBF",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 210,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 210,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 210,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840964,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 210,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840963,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 227,
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:45",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 65520.002616,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693122.447,
				["combat_id"] = 210,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:44",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693121.447,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [17]
			{
				{
					["tipo"] = 2,
					["combatId"] = 209,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.003104,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["end_time"] = 1675840961,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003104,
							["last_dps"] = 109200.0034460639,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 98280.003104,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.003104,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840961,
							["on_hold"] = false,
							["start_time"] = 1675840960,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006747,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 98280.006747,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.006747,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840961,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.006747,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840961,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840960,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006779,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006779,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840961,
							["aID"] = "",
							["total"] = 0.006779,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 98280.006779,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840961,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000633A14",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 209,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 209,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 209,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840961,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 209,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840960,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 226,
				["totals"] = {
					98279.984848, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:42",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 98280.003104,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693119.763,
				["combat_id"] = 209,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:41",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693118.763,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake Rider"] = 1,
				},
			}, -- [18]
			{
				{
					["tipo"] = 2,
					["combatId"] = 208,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.001079,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["end_time"] = 1675840956,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001079,
							["last_dps"] = 140400.0015507684,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 98280.00107900001,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.001079,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840956,
							["on_hold"] = false,
							["start_time"] = 1675840955,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.001465,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 98280.00146500001,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.00146500001,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840956,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.001465,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840956,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840955,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002906,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002906,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840956,
							["aID"] = "",
							["total"] = 0.002906,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 98280.00290600001,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840956,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DB3",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 208,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 208,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 208,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840956,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 208,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840955,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 225,
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:37",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 98280.00107900001,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693114.763,
				["combat_id"] = 208,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:36",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693113.763,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [19]
			{
				{
					["tipo"] = 2,
					["combatId"] = 207,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006848,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["end_time"] = 1675840954,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006848,
							["last_dps"] = 32760.006848,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 32760.006848,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.006848,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840953,
							["on_hold"] = false,
							["start_time"] = 1675840953,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005473,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 32760.005473,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.005473,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840954,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.005473,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840953,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840953,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00436,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00436,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840954,
							["aID"] = "",
							["total"] = 0.00436,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 32760.00436,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840954,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DB7",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 207,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 207,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 207,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840954,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 207,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840953,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 224,
				["totals"] = {
					32759.988671, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:35",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 32760.006848,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693112.613,
				["combat_id"] = 207,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:34",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693111.613,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [20]
			{
				{
					["tipo"] = 2,
					["combatId"] = 206,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008447,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["end_time"] = 1675840953,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008447,
							["last_dps"] = 173639.5908983311,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 98280.008447,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.008447,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840952,
							["on_hold"] = false,
							["start_time"] = 1675840952,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005896,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 98280.005896,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.005896,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840953,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.005896,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840952,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840952,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005757,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005757,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840953,
							["aID"] = "",
							["total"] = 0.005757,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 98280.005757,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840953,
							["serial"] = "Vehicle-0-4457-571-176-30330-00006339EE",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 206,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 206,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 206,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840953,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 206,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840952,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 223,
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:34",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 98280.008447,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693110.897,
				["combat_id"] = 206,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:33",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693109.897,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [21]
			{
				{
					["tipo"] = 2,
					["combatId"] = 205,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004374,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["end_time"] = 1675840948,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004374,
							["last_dps"] = 131040.004374,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 131040.004374,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.004374,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840948,
							["on_hold"] = false,
							["start_time"] = 1675840947,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.008286,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 131040.008286,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 131040.008286,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840948,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 131040,
										},
										["n_dmg"] = 131040,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 131040,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.008286,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840948,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840947,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00181,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00181,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840948,
							["aID"] = "",
							["total"] = 0.00181,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 131040.00181,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840948,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000634DB3",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 205,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 314,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["aID"] = "4477-04D9C328",
							["totalover"] = 314.005339,
							["total_without_pet"] = 0.005339,
							["total"] = 0.005339,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.005339,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.005339,
							["healing_taken"] = 0.005339,
							["end_time"] = 1675840948,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
							},
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 314,
										},
										["n_max"] = 0,
										["targets"] = {
											["Nedro"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 314,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1675840948,
							["classe"] = "WARLOCK",
							["custom"] = 0,
							["tipo"] = 2,
							["totaldenied"] = 0.005339,
							["start_time"] = 1675840948,
							["delay"] = 0,
							["spec"] = 265,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 205,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 205,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840948,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 205,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840947,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 222,
				["totals"] = {
					131039.991325, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:29",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 131040.004374,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 0.005339,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693106.68,
				["combat_id"] = 205,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:28",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693105.68,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [22]
			{
				{
					["tipo"] = 2,
					["combatId"] = 204,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.001351,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["end_time"] = 1675840944,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001351,
							["last_dps"] = 131040.001351,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 131040.001351,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.001351,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840944,
							["on_hold"] = false,
							["start_time"] = 1675840943,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002632,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 131040.002632,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 131040.002632,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840944,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 131040,
										},
										["n_dmg"] = 131040,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 131040,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.002632,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840944,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840943,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005542,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005542,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840944,
							["aID"] = "",
							["total"] = 0.005542,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 131040.005542,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840944,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000633A3D",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 204,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 204,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 204,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840944,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 204,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840943,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 221,
				["totals"] = {
					131039.985448, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:25",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 131040.001351,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693102.73,
				["combat_id"] = 204,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:24",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693101.73,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake Rider"] = 1,
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [23]
			{
				{
					["tipo"] = 2,
					["combatId"] = 203,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.001081,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["end_time"] = 1675840939,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001081,
							["last_dps"] = 327600.01081,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 32760.001081,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.001081,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840938,
							["on_hold"] = false,
							["start_time"] = 1675840938,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.00878,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 32760.00878,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.00878,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840939,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.00878,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840938,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840938,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002402,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002402,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840939,
							["aID"] = "",
							["total"] = 0.002402,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 32760.002402,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840939,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000E33A14",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 203,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 203,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 203,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840939,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 203,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["tempo_start"] = 1675840938,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["combat_counter"] = 220,
				["overall_added"] = true,
				["totals"] = {
					32760, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:22:19",
				["end_time"] = 693097.446,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 203,
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "08:22:20",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 32760.001081,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693096.446,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [24]
			{
				{
					["tipo"] = 2,
					["combatId"] = 202,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.003298,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["end_time"] = 1675840938,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003298,
							["last_dps"] = 245700.0082306984,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 98280.003298,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.003298,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840937,
							["on_hold"] = false,
							["start_time"] = 1675840937,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006915,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 98280.006915,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.006915,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840938,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.006915,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840937,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840937,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001173,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001173,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840938,
							["aID"] = "",
							["total"] = 0.001173,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 98280.001173,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840938,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000E33A14",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 202,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 202,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 202,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840938,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 202,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["tempo_start"] = 1675840937,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["combat_counter"] = 219,
				["overall_added"] = true,
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:22:17",
				["end_time"] = 693095.846,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 202,
				["frags"] = {
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "08:22:18",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 98280.003298,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693094.846,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [25]
			{
				{
					["tipo"] = 2,
					["combatId"] = 201,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005738,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["end_time"] = 1675840936,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005738,
							["last_dps"] = 179016.4091015421,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 65520.005738,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.005738,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840935,
							["on_hold"] = false,
							["start_time"] = 1675840935,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005481,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 65520.005481,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.005481,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840936,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.005481,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840935,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840935,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005902,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005902,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840936,
							["aID"] = "",
							["total"] = 0.005902,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 65520.005902,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840936,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000633A32",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 201,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 201,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 201,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840936,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 201,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840935,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 218,
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:17",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 65520.005738,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693094.28,
				["combat_id"] = 201,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:16",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693093.28,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [26]
			{
				{
					["tipo"] = 2,
					["combatId"] = 200,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.007178,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["end_time"] = 1675840933,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007178,
							["last_dps"] = 32760.007178,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 32760.007178,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.007178,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840932,
							["on_hold"] = false,
							["start_time"] = 1675840932,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002391,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 32760.002391,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.002391,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840933,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.002391,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840932,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840932,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.0074,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.0074,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840933,
							["aID"] = "",
							["total"] = 0.0074,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 32760.0074,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840933,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000E33A47",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 200,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 200,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 200,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840933,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 200,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840932,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 217,
				["totals"] = {
					32759.990162, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:13",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 32760.007178,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693090.863,
				["combat_id"] = 200,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:12",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693089.863,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [27]
			{
				{
					["tipo"] = 2,
					["combatId"] = 199,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006585,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["end_time"] = 1675840931,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006585,
							["last_dps"] = 262080.02634,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 65520.006585,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.006585,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840930,
							["on_hold"] = false,
							["start_time"] = 1675840929,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.008694,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 65520.008694,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.008694,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840931,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.008694,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840930,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840929,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004989,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004989,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840931,
							["aID"] = "",
							["total"] = 0.004989,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 65520.004989,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840931,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000633A02",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 199,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 199,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 199,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 6,
							["last_event"] = 1675840931,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 199,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["tempo_start"] = 1675840929,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 216,
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:22:11",
				["hasTimer"] = 1,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 65520.006585,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 693088.796,
				["combat_id"] = 199,
				["overall_added"] = true,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "08:22:10",
				["CombatSkillCache"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
				["start_time"] = 693087.796,
				["TimeData"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
			}, -- [28]
			{
				{
					["tipo"] = 2,
					["combatId"] = 198,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.002893,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["end_time"] = 1675840928,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002893,
							["last_dps"] = 32760.002893,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 32760.002893,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.002893,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840927,
							["on_hold"] = false,
							["start_time"] = 1675840927,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007185,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 32760.007185,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.007185,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840928,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.007185,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840927,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840927,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004662,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004662,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840928,
							["aID"] = "",
							["total"] = 0.004662,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 32760.004662,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840928,
							["serial"] = "Vehicle-0-4457-571-176-30330-0003E3197E",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 198,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 198,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 198,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840928,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 198,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["tempo_start"] = 1675840927,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["combat_counter"] = 215,
				["overall_added"] = true,
				["totals"] = {
					32759.985552, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:22:08",
				["end_time"] = 693086.263,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 198,
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "08:22:09",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 32760.002893,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693085.263,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [29]
			{
				{
					["tipo"] = 2,
					["combatId"] = 197,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006063,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["end_time"] = 1675840927,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006063,
							["last_dps"] = 98280.00606300001,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 98280.00606300001,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.006063,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840927,
							["on_hold"] = false,
							["start_time"] = 1675840926,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.003431,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 98280.003431,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.003431,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840927,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.003431,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840927,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840926,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001015,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001015,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840927,
							["aID"] = "",
							["total"] = 0.001015,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 98280.001015,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840927,
							["serial"] = "Vehicle-0-4457-571-176-30330-0003E3197E",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 197,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 197,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 197,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840927,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 197,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["tempo_start"] = 1675840926,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["combat_counter"] = 214,
				["overall_added"] = true,
				["totals"] = {
					98279.98587599999, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:22:07",
				["end_time"] = 693085.1460000001,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 197,
				["frags"] = {
					["Jotunheim Proto-Drake Rider"] = 1,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "08:22:08",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 98280.00606300001,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693084.1460000001,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [30]
			{
				{
					["tipo"] = 2,
					["combatId"] = 196,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005115,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["end_time"] = 1675840924,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005115,
							["last_dps"] = 179016.4213178255,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 32760.005115,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.005115,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840923,
							["on_hold"] = false,
							["start_time"] = 1675840923,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.004462,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 32760.004462,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.004462,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840924,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.004462,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840923,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840923,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003665,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003665,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840924,
							["aID"] = "",
							["total"] = 0.003665,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 32760.003665,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840924,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000633A38",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 196,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 196,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 196,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840924,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 196,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["tempo_start"] = 1675840923,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["combat_counter"] = 213,
				["overall_added"] = true,
				["totals"] = {
					32760, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:22:04",
				["end_time"] = 693082.463,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 196,
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "08:22:05",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 32760.005115,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693081.463,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [31]
			{
				{
					["tipo"] = 2,
					["combatId"] = 195,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004927,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["end_time"] = 1675840923,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004927,
							["last_dps"] = 368089.9059434127,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 98280.004927,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.004927,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840922,
							["on_hold"] = false,
							["start_time"] = 1675840922,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.004111,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 98280.004111,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.004111,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840923,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.004111,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840922,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840922,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008523,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008523,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840923,
							["aID"] = "",
							["total"] = 0.008523,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 98280.008523,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840923,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000633A38",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 195,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 313,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["aID"] = "4477-04D9C328",
							["totalover"] = 313.001344,
							["total_without_pet"] = 0.001344,
							["total"] = 0.001344,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.001344,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.001344,
							["healing_taken"] = 0.001344,
							["end_time"] = 1675840923,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
							},
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 313,
										},
										["n_max"] = 0,
										["targets"] = {
											["Nedro"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 313,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1675840923,
							["classe"] = "WARLOCK",
							["custom"] = 0,
							["tipo"] = 2,
							["totaldenied"] = 0.001344,
							["start_time"] = 1675840923,
							["delay"] = 0,
							["spec"] = 265,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 195,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 195,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840923,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 195,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["tempo_start"] = 1675840922,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["combat_counter"] = 212,
				["overall_added"] = true,
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:22:03",
				["end_time"] = 693081.379,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 195,
				["frags"] = {
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "08:22:04",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 98280.004927,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 0.001344,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693080.379,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [32]
			{
				{
					["tipo"] = 2,
					["combatId"] = 194,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008466,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 196560,
							},
							["end_time"] = 1675840922,
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008466,
							["last_dps"] = 357381.8335442875,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 196560.008466,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.008466,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840921,
							["on_hold"] = false,
							["start_time"] = 1675840921,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.001395,
							["damage_from"] = {
							},
							["targets"] = {
								["Jotunheim Proto-Drake"] = 196560,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 196560.001395,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 196560.001395,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840922,
							["aID"] = "",
							["ownerName"] = "Nedro",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 196560,
										},
										["n_dmg"] = 196560,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 196560,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["extra"] = {
										},
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.001395,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840921,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840921,
							["serial"] = "Vehicle-0-4457-571-176-30337-0000E31980",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008877,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008877,
							["last_dps"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1675840922,
							["aID"] = "",
							["total"] = 0.008877,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 196560.008877,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840922,
							["serial"] = "Vehicle-0-4457-571-176-30330-0000633A47",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 194,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 194,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 194,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1675840922,
							["aID"] = "4477-04D9C328",
							["classe"] = "WARLOCK",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4477-04D9C328",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 194,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["tempo_start"] = 1675840921,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["combat_counter"] = 211,
				["overall_added"] = true,
				["totals"] = {
					196560, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:22:02",
				["end_time"] = 693080.096,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 194,
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "08:22:03",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 196560.008466,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 693079.096,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [33]
			{
				{
					["tipo"] = 2,
					["combatId"] = 193,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.007876,
							["damage_from"] = {
							},
							["targets"] = {
								["Mjordin Combatant"] = 25011,
							},
							["friendlyfire_total"] = 0,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["damage_taken"] = 0.007876,
							["classe"] = "WARLOCK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 16760.007876,
							["on_hold"] = false,
							["aID"] = "4477-04D9C328",
							["dps_started"] = false,
							["total"] = 25011.007876,
							["last_event"] = 1675840855,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 2885,
										["g_amt"] = 0,
										["n_max"] = 1443,
										["targets"] = {
											["Mjordin Combatant"] = 6525,
										},
										["n_dmg"] = 3640,
										["n_min"] = 1079,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[20] = 4003,
											[17] = 4003,
											[15] = 4003,
											[11] = 1118,
											[24] = 6525,
										},
										["total"] = 6525,
										["c_max"] = 2885,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 2885,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 470,
										["targets"] = {
											["Mjordin Combatant"] = 2357,
										},
										["n_dmg"] = 2357,
										["n_min"] = 352,
										["g_dmg"] = 0,
										["counter"] = 6,
										["ChartData"] = {
											[11] = 1198,
											[17] = 1198,
											[8] = 364,
											[15] = 1198,
											[20] = 1902,
											[24] = 2357,
										},
										["total"] = 2357,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1699,
										["targets"] = {
											["Mjordin Combatant"] = 3386,
										},
										["n_dmg"] = 3386,
										["n_min"] = 1687,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[20] = 1699,
											[17] = 1699,
											[15] = 1699,
											[11] = 1699,
											[24] = 3386,
										},
										["total"] = 3386,
										["c_max"] = 0,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47857] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 843,
										["targets"] = {
											["Mjordin Combatant"] = 1596,
										},
										["n_dmg"] = 1596,
										["n_min"] = 753,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[24] = 1596,
											[15] = 753,
											[20] = 753,
											[17] = 753,
										},
										["total"] = 1596,
										["c_max"] = 0,
										["id"] = 47857,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47843] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1760,
										["g_amt"] = 0,
										["n_max"] = 1136,
										["targets"] = {
											["Mjordin Combatant"] = 2896,
										},
										["n_dmg"] = 1136,
										["n_min"] = 1136,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[20] = 1760,
											[24] = 2896,
										},
										["total"] = 2896,
										["c_max"] = 1760,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 1760,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1675840856,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840831,
							["serial"] = "Player-4477-04D9C328",
							["last_dps"] = 1030.616774186531,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007586,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 6352,
								["Mmrrggll"] = 2953,
							},
							["pets"] = {
							},
							["delay"] = 1675840873,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Nedro"] = true,
								["Mmrrggll"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 9305.007586,
							["last_dps"] = 0,
							["last_event"] = 1675840873,
							["dps_started"] = false,
							["end_time"] = 1675840921,
							["aID"] = "30037",
							["total"] = 9305.007586,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 2068,
										["g_amt"] = 0,
										["n_max"] = 362,
										["targets"] = {
											["Droomon <Nedro>"] = 5542,
											["Droomon"] = 0,
											["Mmrrggll"] = 2128,
										},
										["n_dmg"] = 5602,
										["n_min"] = 227,
										["g_dmg"] = 0,
										["counter"] = 28,
										["r_amt"] = 0,
										["total"] = 7670,
										["c_max"] = 736,
										["b_dmg"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["extra"] = {
										},
										["PARRY"] = 2,
										["c_min"] = 634,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 19,
										["MISS"] = 3,
										["DODGE"] = 1,
									}, -- [1]
									[15578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 435,
										["targets"] = {
											["Droomon <Nedro>"] = 45,
											["Droomon"] = 0,
											["Mmrrggll"] = 825,
										},
										["n_dmg"] = 870,
										["n_min"] = 45,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 870,
										["c_max"] = 0,
										["id"] = 15578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["a_dmg"] = 0,
									},
									[61227] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 55,
										["targets"] = {
											["Droomon <Nedro>"] = 109,
											["Mmrrggll"] = 0,
										},
										["n_dmg"] = 109,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 109,
										["c_max"] = 0,
										["id"] = 61227,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["DODGE"] = 1,
									},
									[61343] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 307,
										["targets"] = {
											["Droomon <Nedro>"] = 307,
										},
										["n_dmg"] = 307,
										["n_min"] = 307,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 307,
										["c_max"] = 0,
										["id"] = 61343,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[49807] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 49807,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[61344] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 349,
										["targets"] = {
											["Droomon <Nedro>"] = 349,
										},
										["n_dmg"] = 349,
										["n_min"] = 349,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 349,
										["c_max"] = 0,
										["id"] = 61344,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
									[50370] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Mmrrggll"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 50370,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["extra"] = {
										},
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 50340.007586,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840878,
							["serial"] = "Creature-0-4457-571-176-30037-00006341FC",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002057,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 8251,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 8251.002057,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 8251.002057,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840856,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 396,
										["targets"] = {
											["Mjordin Combatant"] = 4532,
										},
										["n_dmg"] = 4532,
										["n_min"] = 309,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 4532,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 13,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 454,
										["targets"] = {
											["Mjordin Combatant"] = 3719,
										},
										["n_dmg"] = 3719,
										["n_min"] = 302,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 3719,
										["c_max"] = 0,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 6352.002057,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840855,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840831,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 193,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 3555,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 3555.006301,
							["total_without_pet"] = 2124.006301,
							["total"] = 2124.006301,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.006301,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 2124,
							},
							["totalover_without_pet"] = 0.006301,
							["healing_taken"] = 2419.006301,
							["fight_component"] = true,
							["end_time"] = 1675840856,
							["healing_from"] = {
								["Mjordin Combatant"] = true,
								["Nedro"] = true,
							},
							["last_event"] = 1675840855,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 1967,
										},
										["n_max"] = 549,
										["targets"] = {
											["Nedro"] = 549,
										},
										["n_min"] = 549,
										["counter"] = 4,
										["overheal"] = 1967,
										["total"] = 549,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 549,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 835,
										},
										["n_max"] = 314,
										["targets"] = {
											["Nedro"] = 732,
										},
										["n_min"] = 313,
										["counter"] = 5,
										["overheal"] = 835,
										["total"] = 732,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 732,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47857] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 753,
										},
										["n_max"] = 843,
										["targets"] = {
											["Nedro"] = 843,
										},
										["n_min"] = 843,
										["counter"] = 2,
										["overheal"] = 753,
										["total"] = 843,
										["c_max"] = 0,
										["id"] = 47857,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 843,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.006301,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675840833,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 3109.003048,
							["total_without_pet"] = 295.003048,
							["monster"] = true,
							["total"] = 295.003048,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-30037-00006341FC",
							["totalabsorb"] = 0.003048,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 295,
							},
							["totalover_without_pet"] = 0.003048,
							["healing_taken"] = 0.003048,
							["fight_component"] = true,
							["end_time"] = 1675840856,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 3109,
										},
										["n_max"] = 295,
										["targets"] = {
											["Nedro"] = 295,
										},
										["n_min"] = 295,
										["counter"] = 2,
										["overheal"] = 3109,
										["total"] = 295,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 295,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 3109,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.003048,
							["custom"] = 0,
							["last_event"] = 1675840856,
							["classe"] = "UNKNOW",
							["start_time"] = 1675840855,
							["delay"] = 1675840844,
							["aID"] = "30037",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 193,
					["_ActorTable"] = {
						{
							["received"] = 2952.005468,
							["resource"] = 0.005468,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 2952,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 0.005468,
							["fight_component"] = true,
							["total"] = 4261.005468,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 2952,
										["id"] = 31818,
										["totalover"] = 0,
										["targets"] = {
											["Nedro"] = 2952,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.005468,
							["last_event"] = 1675840853,
							["alternatepower"] = 0.005468,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 1309.005211,
							["resource"] = 0.005211,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1309,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 3907.005211,
							["total"] = 1309.005211,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 1309,
										["id"] = 54425,
										["totalover"] = 3907,
										["targets"] = {
											["Droomon <Nedro>"] = 1309,
										},
										["counter"] = 10,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675840853,
							["passiveover"] = 0.005211,
							["alternatepower"] = 0.005211,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 193,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47836] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47836,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 118,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 63321,
										["uptime"] = 17,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 25,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 25,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 25,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[61595] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 61595,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[55637] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 55637,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57567] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57567,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 47,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[47864] = 2,
								[47813] = 2,
								[47836] = 1,
								[57946] = 1,
								[47843] = 2,
								[47857] = 2,
								[59164] = 2,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675840912,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["spell_cast"] = {
								[54053] = 10,
							},
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "Mjordin Combatant",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "30037",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[15578] = 3,
								[61227] = 3,
								[49807] = 2,
								[61343] = 1,
								[50370] = 1,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-30037-00006341FC",
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 193,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 692989.794,
				["tempo_start"] = 1675840831,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 210,
				["playing_solo"] = true,
				["totals"] = {
					34315.991126, -- [1]
					2419, -- [2]
					{
						0, -- [1]
						[0] = 4261,
						["alternatepower"] = 0,
						[6] = -0.006730000000004566,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:20:57",
				["hasTimer"] = 24.0010000000475,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 24.26800000004005,
				["CombatEndedAt"] = 693014.062,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:20:32",
				["end_time"] = 693014.062,
				["combat_id"] = 193,
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["totals_grupo"] = {
					16760, -- [1]
					2124, -- [2]
					{
						0, -- [1]
						[0] = 2952,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 25011.007876,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 2124.006301,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 692989.794,
				["contra"] = "Mjordin Combatant",
				["overall_added"] = true,
			}, -- [34]
			{
				{
					["tipo"] = 2,
					["combatId"] = 192,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.00897,
							["damage_from"] = {
							},
							["targets"] = {
								["Mjordin Combatant"] = 26839,
							},
							["friendlyfire_total"] = 0,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["damage_taken"] = 0.00897,
							["classe"] = "WARLOCK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 19513.00897,
							["on_hold"] = false,
							["aID"] = "4477-04D9C328",
							["dps_started"] = false,
							["total"] = 26839.00897,
							["last_event"] = 1675840807,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 4470,
										["g_amt"] = 0,
										["n_max"] = 1443,
										["targets"] = {
											["Mjordin Combatant"] = 8473,
										},
										["n_dmg"] = 4003,
										["n_min"] = 1118,
										["g_dmg"] = 0,
										["counter"] = 5,
										["ChartData"] = {
											[11] = 4003,
											[15] = 4003,
											[18] = 6238,
											[9] = 2561,
											[21] = 8473,
										},
										["total"] = 8473,
										["c_max"] = 2235,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 2235,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 470,
										["targets"] = {
											["Mjordin Combatant"] = 2502,
										},
										["n_dmg"] = 2502,
										["n_min"] = 364,
										["g_dmg"] = 0,
										["counter"] = 6,
										["ChartData"] = {
											[11] = 1668,
											[15] = 1668,
											[18] = 1668,
											[5] = 364,
											[9] = 1198,
											[21] = 2502,
										},
										["total"] = 2502,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1724,
										["targets"] = {
											["Mjordin Combatant"] = 3429,
										},
										["n_dmg"] = 3429,
										["n_min"] = 1705,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 1724,
											[15] = 1724,
											[18] = 1724,
											[9] = 1724,
											[21] = 3429,
										},
										["total"] = 3429,
										["c_max"] = 0,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47843] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1172,
										["targets"] = {
											["Mjordin Combatant"] = 3252,
										},
										["n_dmg"] = 3252,
										["n_min"] = 908,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[11] = 1172,
											[18] = 1172,
											[15] = 1172,
											[21] = 2080,
										},
										["total"] = 3252,
										["c_max"] = 0,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47857] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1015,
										["targets"] = {
											["Mjordin Combatant"] = 1857,
										},
										["n_dmg"] = 1857,
										["n_min"] = 842,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 842,
											[18] = 842,
											[15] = 842,
											[21] = 842,
										},
										["total"] = 1857,
										["c_max"] = 0,
										["id"] = 47857,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1675840808,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840785,
							["serial"] = "Player-4477-04D9C328",
							["last_dps"] = 1219.012988600131,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007208,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 7326,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 7326.007208,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7326.007208,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840808,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 355,
										["targets"] = {
											["Mjordin Combatant"] = 3965,
										},
										["n_dmg"] = 3965,
										["n_min"] = 306,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 3965,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 12,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 462,
										["targets"] = {
											["Mjordin Combatant"] = 3361,
										},
										["n_dmg"] = 3361,
										["n_min"] = 289,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 3361,
										["c_max"] = 0,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 4154.007208,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840807,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840785,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005172,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 4154,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Nedro"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 4154.005172,
							["last_dps"] = 0,
							["last_event"] = 1675840804,
							["dps_started"] = false,
							["end_time"] = 1675840808,
							["aID"] = "30037",
							["total"] = 4154.005172,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 372,
										["targets"] = {
											["Droomon"] = 0,
											["Droomon <Nedro>"] = 3677,
										},
										["n_dmg"] = 3677,
										["n_min"] = 282,
										["g_dmg"] = 0,
										["counter"] = 14,
										["r_amt"] = 0,
										["total"] = 3677,
										["c_max"] = 0,
										["b_dmg"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["extra"] = {
										},
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 11,
										["MISS"] = 1,
										["DODGE"] = 1,
									}, -- [1]
									[61227] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 54,
										["targets"] = {
											["Droomon <Nedro>"] = 108,
										},
										["n_dmg"] = 108,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 108,
										["c_max"] = 0,
										["id"] = 61227,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[32736] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 369,
										["targets"] = {
											["Droomon"] = 0,
											["Droomon <Nedro>"] = 369,
										},
										["n_dmg"] = 369,
										["n_min"] = 369,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 369,
										["c_max"] = 0,
										["id"] = 32736,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["MISS"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 26839.005172,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840786,
							["serial"] = "Creature-0-4457-571-176-30037-00006341E9",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 192,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 4194,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 4194.007573,
							["total_without_pet"] = 980.007573,
							["total"] = 980.007573,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.007573,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 980,
							},
							["totalover_without_pet"] = 0.007573,
							["healing_taken"] = 2056.007573,
							["fight_component"] = true,
							["end_time"] = 1675840808,
							["healing_from"] = {
								["Mjordin Combatant"] = true,
								["Nedro"] = true,
							},
							["last_event"] = 1675840808,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 2495,
										},
										["n_max"] = 894,
										["targets"] = {
											["Nedro"] = 894,
										},
										["n_min"] = 894,
										["counter"] = 5,
										["overheal"] = 2495,
										["total"] = 894,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 894,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 1511,
										},
										["n_max"] = 56,
										["targets"] = {
											["Nedro"] = 56,
										},
										["n_min"] = 0,
										["counter"] = 5,
										["overheal"] = 1511,
										["total"] = 56,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 56,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47857] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 188,
										},
										["n_max"] = 30,
										["targets"] = {
											["Nedro"] = 30,
										},
										["n_min"] = 30,
										["counter"] = 2,
										["overheal"] = 188,
										["total"] = 30,
										["c_max"] = 0,
										["id"] = 47857,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 30,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.007573,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675840788,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 2864.004865,
							["total_without_pet"] = 1076.004865,
							["monster"] = true,
							["total"] = 1076.004865,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-30037-00006341E9",
							["totalabsorb"] = 0.004865,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 1076,
							},
							["totalover_without_pet"] = 0.004865,
							["healing_taken"] = 0.004865,
							["fight_component"] = true,
							["end_time"] = 1675840808,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 2864,
										},
										["n_max"] = 1076,
										["targets"] = {
											["Nedro"] = 1076,
										},
										["n_min"] = 1076,
										["counter"] = 2,
										["overheal"] = 2864,
										["total"] = 1076,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 1076,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 2864,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.004865,
							["custom"] = 0,
							["last_event"] = 1675840807,
							["classe"] = "UNKNOW",
							["start_time"] = 1675840807,
							["delay"] = 1675840797,
							["aID"] = "30037",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 192,
					["_ActorTable"] = {
						{
							["received"] = 3247.002338,
							["resource"] = 0.002338,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 3247,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 0.002338,
							["fight_component"] = true,
							["total"] = 4425.002338,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 3247,
										["id"] = 31818,
										["totalover"] = 0,
										["targets"] = {
											["Nedro"] = 3247,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.002338,
							["last_event"] = 1675840805,
							["alternatepower"] = 0.002338,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 1178.003967,
							["resource"] = 0.003967,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1178,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 3513.003967,
							["total"] = 1178.003967,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 1178,
										["id"] = 54425,
										["totalover"] = 3513,
										["targets"] = {
											["Droomon <Nedro>"] = 1178,
										},
										["counter"] = 9,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675840805,
							["passiveover"] = 0.003967,
							["alternatepower"] = 0.003967,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 192,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47836] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47836,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 113,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 63321,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 23,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 23,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[64371] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 64371,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[61595] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 61595,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[60064] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 60064,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 23,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 47,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[47864] = 2,
								[47813] = 2,
								[47836] = 1,
								[57946] = 1,
								[47843] = 2,
								[47857] = 2,
								[59164] = 2,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675840808,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["spell_cast"] = {
								[54053] = 9,
							},
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "Mjordin Combatant",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "30037",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[61227] = 2,
								[32736] = 2,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-30037-00006341E9",
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 192,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 692943.7270000001,
				["tempo_start"] = 1675840785,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 209,
				["playing_solo"] = true,
				["totals"] = {
					30993, -- [1]
					2056, -- [2]
					{
						0, -- [1]
						[0] = 4425,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:20:09",
				["hasTimer"] = 23,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 23.0339999999851,
				["CombatEndedAt"] = 692966.761,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:19:46",
				["end_time"] = 692966.761,
				["combat_id"] = 192,
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["totals_grupo"] = {
					19513, -- [1]
					980, -- [2]
					{
						0, -- [1]
						[0] = 3247,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 26839.00897,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 980.007573,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 692943.7270000001,
				["contra"] = "Mjordin Combatant",
				["overall_added"] = true,
			}, -- [35]
			{
				{
					["tipo"] = 2,
					["combatId"] = 191,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006071,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 26964,
							},
							["friendlyfire_total"] = 0,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["damage_taken"] = 370.006071,
							["classe"] = "WARLOCK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 19533.006071,
							["on_hold"] = false,
							["aID"] = "4477-04D9C328",
							["dps_started"] = false,
							["total"] = 26964.006071,
							["last_event"] = 1675840765,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47843] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1291,
										["targets"] = {
											["Mjordin Combatant"] = 4370,
										},
										["n_dmg"] = 4370,
										["n_min"] = 907,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[6] = 907,
											[17] = 3079,
											[14] = 2080,
											[9] = 2080,
											[11] = 2080,
										},
										["total"] = 4370,
										["c_max"] = 0,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2216,
										["targets"] = {
											["Mjordin Combatant"] = 3885,
										},
										["n_dmg"] = 3885,
										["n_min"] = 1669,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 1669,
											[14] = 1669,
											[17] = 1669,
											[9] = 1669,
										},
										["total"] = 3885,
										["c_max"] = 0,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 521,
										["targets"] = {
											["Mjordin Combatant"] = 2643,
										},
										["n_dmg"] = 2643,
										["n_min"] = 363,
										["g_dmg"] = 0,
										["counter"] = 6,
										["ChartData"] = {
											[6] = 727,
											[17] = 1601,
											[14] = 1197,
											[9] = 1197,
											[11] = 1197,
										},
										["total"] = 2643,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47813] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 5451,
										["g_amt"] = 0,
										["n_max"] = 1939,
										["targets"] = {
											["Mjordin Combatant"] = 8635,
										},
										["n_dmg"] = 3184,
										["n_min"] = 1245,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[11] = 5451,
											[14] = 5451,
											[17] = 6696,
											[9] = 5451,
										},
										["total"] = 8635,
										["c_max"] = 3216,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 2235,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1675840765,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840744,
							["serial"] = "Player-4477-04D9C328",
							["last_dps"] = 1299.407550050097,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005328,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 7431,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 7431.005328,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7431.005328,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840765,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 392,
										["targets"] = {
											["Mjordin Combatant"] = 3871,
										},
										["n_dmg"] = 3871,
										["n_min"] = 320,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 3871,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 11,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 562,
										["targets"] = {
											["Mjordin Combatant"] = 3560,
										},
										["n_dmg"] = 3560,
										["n_min"] = 281,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 3560,
										["c_max"] = 0,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 2928.005328,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840764,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840744,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003596,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 2928,
								["Nedro"] = 370,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Nedro"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3298.003596,
							["last_dps"] = 0,
							["last_event"] = 1675840763,
							["dps_started"] = false,
							["end_time"] = 1675840765,
							["aID"] = "30037",
							["total"] = 3298.003596,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 370,
										["targets"] = {
											["Droomon <Nedro>"] = 2874,
											["Droomon"] = 0,
											["Nedro"] = 370,
										},
										["n_dmg"] = 3244,
										["n_min"] = 137,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 3244,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["b_dmg"] = 137,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["extra"] = {
										},
										["n_amt"] = 11,
										["a_dmg"] = 0,
										["MISS"] = 2,
									}, -- [1]
									[61227] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 54,
										["targets"] = {
											["Droomon <Nedro>"] = 54,
											["Droomon"] = 0,
										},
										["n_dmg"] = 54,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 54,
										["c_max"] = 0,
										["id"] = 61227,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 26964.003596,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840744,
							["serial"] = "Creature-0-4457-571-176-30037-00016342DD",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 191,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 1125,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 1125.004137,
							["total_without_pet"] = 2537.004137,
							["total"] = 2537.004137,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.004137,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 2537,
							},
							["totalover_without_pet"] = 0.004137,
							["healing_taken"] = 4555.004137,
							["fight_component"] = true,
							["end_time"] = 1675840765,
							["healing_from"] = {
								["Mjordin Combatant"] = true,
								["Nedro"] = true,
							},
							["last_event"] = 1675840765,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 627,
										},
										["n_max"] = 313,
										["targets"] = {
											["Nedro"] = 626,
										},
										["n_min"] = 313,
										["counter"] = 4,
										["overheal"] = 627,
										["total"] = 626,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 626,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 498,
										},
										["n_max"] = 894,
										["targets"] = {
											["Nedro"] = 1911,
										},
										["n_min"] = 287,
										["counter"] = 4,
										["overheal"] = 498,
										["total"] = 1911,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 1911,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.004137,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675840748,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 1644.005494,
							["total_without_pet"] = 2018.005494,
							["monster"] = true,
							["total"] = 2018.005494,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-30037-0000634307",
							["totalabsorb"] = 0.005494,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 2018,
							},
							["totalover_without_pet"] = 0.005494,
							["healing_taken"] = 0.005494,
							["fight_component"] = true,
							["end_time"] = 1675840765,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 1644,
										},
										["n_max"] = 1400,
										["targets"] = {
											["Nedro"] = 2018,
										},
										["n_min"] = 618,
										["counter"] = 2,
										["overheal"] = 1644,
										["total"] = 2018,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 2018,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 1644,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.005494,
							["custom"] = 0,
							["last_event"] = 1675840765,
							["classe"] = "UNKNOW",
							["start_time"] = 1675840764,
							["delay"] = 1675840752,
							["aID"] = "30037",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 191,
					["_ActorTable"] = {
						{
							["received"] = 3439.004697,
							["resource"] = 0.004697,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 3439,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 0.004697,
							["fight_component"] = true,
							["total"] = 4617.004697,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 3439,
										["id"] = 31818,
										["totalover"] = 0,
										["targets"] = {
											["Nedro"] = 3439,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.004697,
							["last_event"] = 1675840762,
							["alternatepower"] = 0.004697,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 1178.004329,
							["resource"] = 0.004329,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1178,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 3518.004329,
							["total"] = 1178.004329,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 1178,
										["id"] = 54425,
										["totalover"] = 3518,
										["targets"] = {
											["Droomon <Nedro>"] = 1178,
										},
										["counter"] = 9,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675840764,
							["passiveover"] = 0.004329,
							["alternatepower"] = 0.004329,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 191,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 113,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 1,
										["id"] = 63321,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[55637] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 55637,
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[64371] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 64371,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[60064] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 60064,
										["uptime"] = 5,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 45,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[47813] = 2,
								[47843] = 2,
								[59164] = 2,
								[47864] = 2,
								[57946] = 1,
								[47857] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675840765,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["spell_cast"] = {
								[54053] = 9,
							},
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "Mjordin Combatant",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "30037",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[61227] = 1,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-30037-0000634307",
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 191,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					30262, -- [1]
					4555, -- [2]
					{
						0, -- [1]
						[0] = 4617,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					19533, -- [1]
					2537, -- [2]
					{
						0, -- [1]
						[0] = 3439,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:19:26",
				["hasTimer"] = 20.01699999999255,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 692923.027,
				["CombatEndedAt"] = 692923.027,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 26964.006071,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 2537.004137,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 692923.027,
				["combat_id"] = 191,
				["TimeData"] = {
				},
				["tempo_start"] = 1675840744,
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["combat_counter"] = 208,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "08:19:05",
				["start_time"] = 692902.2760000001,
				["contra"] = "Mjordin Combatant",
				["spells_cast_timeline"] = {
				},
			}, -- [36]
			{
				{
					["tipo"] = 2,
					["combatId"] = 190,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004847,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 29063,
							},
							["friendlyfire_total"] = 0,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["damage_taken"] = 2691.004847,
							["classe"] = "WARLOCK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20041.004847,
							["on_hold"] = false,
							["aID"] = "4477-04D9C328",
							["dps_started"] = false,
							["total"] = 29063.004847,
							["last_event"] = 1675840713,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1393,
										["targets"] = {
											["Mjordin Combatant"] = 3679,
										},
										["n_dmg"] = 3679,
										["n_min"] = 1079,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[11] = 2600,
											[24] = 2600,
											[15] = 2600,
											[18] = 2600,
											[5] = 1207,
											[26] = 2600,
											[9] = 2600,
											[20] = 2600,
										},
										["total"] = 3679,
										["c_max"] = 0,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 506,
										["targets"] = {
											["Mjordin Combatant"] = 2498,
										},
										["n_dmg"] = 2498,
										["n_min"] = 352,
										["g_dmg"] = 0,
										["counter"] = 6,
										["ChartData"] = {
											[11] = 1794,
											[24] = 1794,
											[15] = 1794,
											[18] = 1794,
											[5] = 783,
											[26] = 2146,
											[9] = 1288,
											[20] = 1794,
										},
										["total"] = 2498,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1993,
										["targets"] = {
											["Mjordin Combatant"] = 3765,
										},
										["n_dmg"] = 3765,
										["n_min"] = 1772,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 1772,
											[24] = 1772,
											[15] = 1772,
											[18] = 1772,
											[26] = 1772,
											[9] = 1772,
											[20] = 1772,
										},
										["total"] = 3765,
										["c_max"] = 0,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47843] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1255,
										["targets"] = {
											["Mjordin Combatant"] = 3107,
										},
										["n_dmg"] = 3107,
										["n_min"] = 880,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[11] = 2227,
											[24] = 2227,
											[15] = 2227,
											[18] = 2227,
											[5] = 972,
											[26] = 3107,
											[9] = 2227,
											[20] = 2227,
										},
										["total"] = 3107,
										["c_max"] = 0,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47834] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4249,
										["targets"] = {
											["Mjordin Combatant"] = 6992,
										},
										["n_dmg"] = 6992,
										["n_min"] = 2743,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[20] = 6992,
											[24] = 6992,
											[15] = 6992,
											[18] = 6992,
											[26] = 6992,
											[11] = 6992,
										},
										["total"] = 6992,
										["c_max"] = 0,
										["id"] = 47834,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1675840713,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840684,
							["serial"] = "Player-4477-04D9C328",
							["last_dps"] = 998.7286889011427,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.001573,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 9022,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 9022.001573,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 9022.001573,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840713,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 376,
										["targets"] = {
											["Mjordin Combatant"] = 4790,
										},
										["n_dmg"] = 4790,
										["n_min"] = 313,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 4790,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 14,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 792,
										["g_amt"] = 0,
										["n_max"] = 487,
										["targets"] = {
											["Mjordin Combatant"] = 4232,
										},
										["n_dmg"] = 3440,
										["n_min"] = 269,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 4232,
										["c_max"] = 792,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 792,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 4500.001573,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840712,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840684,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005658,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 4500,
								["Nedro"] = 2691,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Nedro"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 7191.005658,
							["last_dps"] = 0,
							["last_event"] = 1675840713,
							["dps_started"] = false,
							["end_time"] = 1675840713,
							["aID"] = "30037",
							["total"] = 7191.005658,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1402,
										["g_amt"] = 0,
										["n_max"] = 435,
										["targets"] = {
											["Droomon <Nedro>"] = 3040,
											["Droomon"] = 0,
											["Nedro"] = 1942,
										},
										["n_dmg"] = 3580,
										["n_min"] = 257,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 4982,
										["c_max"] = 715,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["a_amt"] = 0,
										["c_min"] = 687,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 11,
										["spellschool"] = 1,
										["MISS"] = 1,
									}, -- [1]
									[61344] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 377,
										["targets"] = {
											["Droomon <Nedro>"] = 377,
										},
										["n_dmg"] = 377,
										["n_min"] = 377,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 377,
										["c_max"] = 0,
										["id"] = 61344,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
									[50370] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 50370,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[32736] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 350,
										["targets"] = {
											["Droomon <Nedro>"] = 643,
										},
										["n_dmg"] = 643,
										["n_min"] = 293,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 643,
										["c_max"] = 0,
										["id"] = 32736,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[61343] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 278,
										["targets"] = {
											["Droomon <Nedro>"] = 278,
										},
										["n_dmg"] = 278,
										["n_min"] = 278,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 278,
										["c_max"] = 0,
										["id"] = 61343,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[61227] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 749,
										["targets"] = {
											["Droomon <Nedro>"] = 162,
											["Nedro"] = 749,
										},
										["n_dmg"] = 911,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 911,
										["c_max"] = 0,
										["id"] = 61227,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 29063.005658,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840684,
							["serial"] = "Creature-0-4457-571-176-30037-00006342FC",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 190,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 1979,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 1979.008223,
							["total_without_pet"] = 1371.008223,
							["total"] = 1371.008223,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.008223,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 1371,
							},
							["totalover_without_pet"] = 0.008223,
							["healing_taken"] = 2255.008223,
							["fight_component"] = true,
							["end_time"] = 1675840713,
							["healing_from"] = {
								["Mjordin Combatant"] = true,
								["Nedro"] = true,
							},
							["last_event"] = 1675840713,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 939,
										},
										["n_max"] = 313,
										["targets"] = {
											["Nedro"] = 939,
										},
										["n_min"] = 313,
										["counter"] = 6,
										["overheal"] = 939,
										["total"] = 939,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 939,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 1040,
										},
										["n_max"] = 432,
										["targets"] = {
											["Nedro"] = 432,
										},
										["n_min"] = 432,
										["counter"] = 3,
										["overheal"] = 1040,
										["total"] = 432,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 432,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.008223,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675840688,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 4641.00562,
							["total_without_pet"] = 884.00562,
							["monster"] = true,
							["total"] = 884.00562,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-30037-00006342FC",
							["totalabsorb"] = 0.00562,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 884,
							},
							["totalover_without_pet"] = 0.00562,
							["healing_taken"] = 0.00562,
							["fight_component"] = true,
							["end_time"] = 1675840713,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 4641,
										},
										["n_max"] = 449,
										["targets"] = {
											["Nedro"] = 884,
										},
										["n_min"] = 0,
										["counter"] = 3,
										["overheal"] = 4641,
										["total"] = 884,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 884,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 4641,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.00562,
							["custom"] = 0,
							["last_event"] = 1675840713,
							["classe"] = "UNKNOW",
							["start_time"] = 1675840712,
							["delay"] = 1675840694,
							["aID"] = "30037",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 190,
					["_ActorTable"] = {
						{
							["received"] = 2952.005109,
							["resource"] = 0.005109,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 2952,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 0.005109,
							["fight_component"] = true,
							["total"] = 4391.005109,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 2952,
										["id"] = 31818,
										["totalover"] = 0,
										["targets"] = {
											["Nedro"] = 2952,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.005109,
							["last_event"] = 1675840733,
							["alternatepower"] = 0.005109,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 1439.005509,
							["resource"] = 0.005509,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1439,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 4297.005509000001,
							["total"] = 1439.005509,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 1439,
										["id"] = 54425,
										["totalover"] = 4297,
										["targets"] = {
											["Droomon <Nedro>"] = 1439,
										},
										["counter"] = 11,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675840712,
							["passiveover"] = 0.005509,
							["alternatepower"] = 0.005509,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 190,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47836] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47836,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 101,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 29,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 29,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[55637] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 55637,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 29,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[64371] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 64371,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 45,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[47813] = 2,
								[47843] = 2,
								[59164] = 2,
								[47864] = 2,
								[47836] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675840713,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["spell_cast"] = {
								[54053] = 11,
							},
						}, -- [2]
						{
							["flag_original"] = 2632,
							["nome"] = "Mjordin Combatant",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "30037",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[61343] = 1,
								[32736] = 2,
								[61227] = 3,
								[50370] = 1,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-30037-0000634384",
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 190,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 692901.61,
				["tempo_start"] = 1675840684,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 207,
				["playing_solo"] = true,
				["totals"] = {
					36254, -- [1]
					2255, -- [2]
					{
						0, -- [1]
						[0] = 4391,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:18:34",
				["hasTimer"] = 29,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 29.5,
				["CombatEndedAt"] = 692871.659,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:18:05",
				["end_time"] = 692871.659,
				["combat_id"] = 190,
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["totals_grupo"] = {
					20041, -- [1]
					1371, -- [2]
					{
						0, -- [1]
						[0] = 2952,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 29063.004847,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 1371.008223,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 692842.159,
				["contra"] = "Mjordin Combatant",
				["overall_added"] = true,
			}, -- [37]
			{
				{
					["tipo"] = 2,
					["combatId"] = 189,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.00464,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 30193,
							},
							["friendlyfire_total"] = 0,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["damage_taken"] = 1267.00464,
							["classe"] = "WARLOCK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 24037.00464,
							["on_hold"] = false,
							["aID"] = "4477-04D9C328",
							["dps_started"] = false,
							["total"] = 30193.00464,
							["last_event"] = 1675840642,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1443,
										["targets"] = {
											["Mjordin Combatant"] = 3678,
										},
										["n_dmg"] = 3678,
										["n_min"] = 1117,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[11] = 1117,
											[17] = 2235,
											[8] = 1117,
											[14] = 1117,
											[20] = 3678,
										},
										["total"] = 3678,
										["c_max"] = 0,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 470,
										["targets"] = {
											["Mjordin Combatant"] = 3336,
										},
										["n_dmg"] = 3336,
										["n_min"] = 364,
										["g_dmg"] = 0,
										["counter"] = 8,
										["ChartData"] = {
											[11] = 1668,
											[17] = 2866,
											[8] = 1198,
											[14] = 2032,
											[5] = 364,
											[20] = 3336,
										},
										["total"] = 3336,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1760,
										["targets"] = {
											["Mjordin Combatant"] = 3477,
										},
										["n_dmg"] = 3477,
										["n_min"] = 1717,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 1717,
											[17] = 3477,
											[8] = 1717,
											[14] = 1717,
											[20] = 3477,
										},
										["total"] = 3477,
										["c_max"] = 0,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47843] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1173,
										["targets"] = {
											["Mjordin Combatant"] = 5332,
										},
										["n_dmg"] = 5332,
										["n_min"] = 907,
										["g_dmg"] = 0,
										["counter"] = 5,
										["ChartData"] = {
											[11] = 3253,
											[17] = 5332,
											[8] = 2081,
											[14] = 4160,
											[5] = 908,
											[20] = 5332,
										},
										["total"] = 5332,
										["c_max"] = 0,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47834] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 6528,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Mjordin Combatant"] = 6528,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[14] = 6528,
											[11] = 6528,
											[20] = 6528,
											[17] = 6528,
										},
										["total"] = 6528,
										["c_max"] = 6528,
										["id"] = 47834,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 6528,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47857] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 843,
										["targets"] = {
											["Mjordin Combatant"] = 1686,
										},
										["n_dmg"] = 1686,
										["n_min"] = 843,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[20] = 1686,
										},
										["total"] = 1686,
										["c_max"] = 0,
										["id"] = 47857,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1675840643,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840622,
							["serial"] = "Player-4477-04D9C328",
							["last_dps"] = 1500.870141673516,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002394,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 6156,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 6156.002394,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6156.002394,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840643,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 3,
										["n_max"] = 375,
										["targets"] = {
											["Mjordin Combatant"] = 3057,
										},
										["n_dmg"] = 2040,
										["n_min"] = 312,
										["g_dmg"] = 1017,
										["counter"] = 9,
										["total"] = 3057,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 462,
										["targets"] = {
											["Mjordin Combatant"] = 3099,
										},
										["n_dmg"] = 3099,
										["n_min"] = 274,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 3099,
										["c_max"] = 0,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 4065.002394,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840639,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840622,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00119,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 4065,
								["Nedro"] = 1267,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Nedro"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 5332.00119,
							["last_dps"] = 0,
							["last_event"] = 1675840641,
							["dps_started"] = false,
							["end_time"] = 1675840643,
							["aID"] = "30037",
							["total"] = 5332.00119,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 601,
										["g_amt"] = 0,
										["n_max"] = 515,
										["targets"] = {
											["Droomon <Nedro>"] = 3922,
											["Droomon"] = 0,
											["Nedro"] = 515,
										},
										["n_dmg"] = 3836,
										["n_min"] = 262,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 4437,
										["c_max"] = 601,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["a_amt"] = 0,
										["c_min"] = 601,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 11,
										["spellschool"] = 1,
										["MISS"] = 1,
									}, -- [1]
									[15578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 45,
										["targets"] = {
											["Droomon <Nedro>"] = 89,
										},
										["n_dmg"] = 89,
										["n_min"] = 44,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 89,
										["c_max"] = 0,
										["id"] = 15578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[49807] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 49807,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[50370] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 50370,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[61227] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 752,
										["targets"] = {
											["Droomon <Nedro>"] = 54,
											["Nedro"] = 752,
										},
										["n_dmg"] = 806,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 806,
										["c_max"] = 0,
										["id"] = 61227,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 30193.00119,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840622,
							["serial"] = "Creature-0-4457-571-176-30037-0000634326",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 189,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 1962,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 1962.00565,
							["total_without_pet"] = 2449.00565,
							["total"] = 2449.00565,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.00565,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 2449,
							},
							["totalover_without_pet"] = 0.00565,
							["healing_taken"] = 3453.00565,
							["fight_component"] = true,
							["end_time"] = 1675840643,
							["healing_from"] = {
								["Mjordin Combatant"] = true,
								["Nedro"] = true,
							},
							["last_event"] = 1675840641,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 894,
										},
										["n_max"] = 577,
										["targets"] = {
											["Nedro"] = 577,
										},
										["n_min"] = 577,
										["counter"] = 3,
										["overheal"] = 894,
										["total"] = 577,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 577,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 1068,
										},
										["n_max"] = 186,
										["targets"] = {
											["Nedro"] = 186,
										},
										["n_min"] = 0,
										["counter"] = 4,
										["overheal"] = 1068,
										["total"] = 186,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 186,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47857] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 843,
										["targets"] = {
											["Nedro"] = 1686,
										},
										["n_min"] = 843,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 1686,
										["c_max"] = 0,
										["id"] = 47857,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 1686,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.00565,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675840623,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 2928.006792,
							["total_without_pet"] = 1004.006792,
							["monster"] = true,
							["total"] = 1004.006792,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-30037-0000634326",
							["totalabsorb"] = 0.006792,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 1004,
							},
							["totalover_without_pet"] = 0.006792,
							["healing_taken"] = 0.006792,
							["fight_component"] = true,
							["end_time"] = 1675840643,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 2928,
										},
										["n_max"] = 1004,
										["targets"] = {
											["Nedro"] = 1004,
										},
										["n_min"] = 1004,
										["counter"] = 2,
										["overheal"] = 2928,
										["total"] = 1004,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 1004,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
								["Nedro"] = 2928,
							},
							["tipo"] = 2,
							["totaldenied"] = 0.006792,
							["custom"] = 0,
							["last_event"] = 1675840642,
							["classe"] = "UNKNOW",
							["start_time"] = 1675840633,
							["delay"] = 0,
							["aID"] = "30037",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 189,
					["_ActorTable"] = {
						{
							["received"] = 2997.006012,
							["resource"] = 0.006012,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 2997,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 0.006012,
							["fight_component"] = true,
							["total"] = 4044.006012,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 2997,
										["id"] = 31818,
										["totalover"] = 0,
										["targets"] = {
											["Nedro"] = 2997,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.006012,
							["last_event"] = 1675840638,
							["alternatepower"] = 0.006012,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 1047.005001,
							["resource"] = 0.005001,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1047,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 3124.005001,
							["total"] = 1047.005001,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 1047,
										["id"] = 54425,
										["totalover"] = 3124,
										["targets"] = {
											["Droomon <Nedro>"] = 1047,
										},
										["counter"] = 8,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675840639,
							["passiveover"] = 0.005001,
							["alternatepower"] = 0.005001,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 189,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 17,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47836] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47836,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 17,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 99,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 1,
										["id"] = 63321,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[61595] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 61595,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[17941] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 17941,
										["uptime"] = 5,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 65,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[17941] = 1,
								[47864] = 2,
								[47813] = 2,
								[47857] = 1,
								[59164] = 2,
								[47836] = 1,
								[57946] = 1,
								[47843] = 2,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675840643,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["spell_cast"] = {
								[54053] = 8,
							},
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "Mjordin Combatant",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "30037",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[15578] = 2,
								[49807] = 1,
								[50370] = 1,
								[61227] = 2,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-30037-0000634326",
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 189,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 692780.074,
				["tempo_start"] = 1675840622,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 206,
				["playing_solo"] = true,
				["totals"] = {
					35525, -- [1]
					3453, -- [2]
					{
						0, -- [1]
						[0] = 4044,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:17:24",
				["hasTimer"] = 21.01699999999255,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 21.06700000003912,
				["CombatEndedAt"] = 692801.1410000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:17:03",
				["end_time"] = 692801.1410000001,
				["combat_id"] = 189,
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["totals_grupo"] = {
					24037, -- [1]
					2449, -- [2]
					{
						0, -- [1]
						[0] = 2997,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 30193.00464,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 2449.00565,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 692780.074,
				["contra"] = "Mjordin Combatant",
				["overall_added"] = true,
			}, -- [38]
			{
				{
					["tipo"] = 2,
					["combatId"] = 188,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005244,
							["damage_from"] = {
							},
							["targets"] = {
								["Mjordin Combatant"] = 27037,
							},
							["friendlyfire_total"] = 0,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["damage_taken"] = 0.005244,
							["classe"] = "WARLOCK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 19562.005244,
							["on_hold"] = false,
							["aID"] = "4477-04D9C328",
							["dps_started"] = false,
							["total"] = 27037.005244,
							["last_event"] = 1675840608,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 2235,
										["g_amt"] = 0,
										["n_max"] = 1773,
										["targets"] = {
											["Mjordin Combatant"] = 5254,
										},
										["n_dmg"] = 3019,
										["n_min"] = 1246,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[15] = 2235,
											[18] = 2235,
											[12] = 2235,
											[9] = 2235,
											[21] = 3481,
										},
										["total"] = 5254,
										["c_max"] = 2235,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 2235,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 521,
										["targets"] = {
											["Mjordin Combatant"] = 2054,
										},
										["n_dmg"] = 2054,
										["n_min"] = 363,
										["g_dmg"] = 0,
										["counter"] = 5,
										["ChartData"] = {
											[15] = 727,
											[18] = 1130,
											[12] = 727,
											[5] = 363,
											[9] = 727,
											[21] = 2054,
										},
										["total"] = 2054,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3747,
										["g_amt"] = 0,
										["n_max"] = 2215,
										["targets"] = {
											["Mjordin Combatant"] = 5962,
										},
										["n_dmg"] = 2215,
										["n_min"] = 2215,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[15] = 3747,
											[18] = 3747,
											[12] = 3747,
											[9] = 3747,
											[21] = 5962,
										},
										["total"] = 5962,
										["c_max"] = 3747,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 3747,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47843] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1815,
										["g_amt"] = 0,
										["n_max"] = 1291,
										["targets"] = {
											["Mjordin Combatant"] = 5278,
										},
										["n_dmg"] = 3463,
										["n_min"] = 1000,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[15] = 2987,
											[18] = 3987,
											[12] = 2987,
											[5] = 1815,
											[9] = 2987,
											[21] = 5278,
										},
										["total"] = 5278,
										["c_max"] = 1815,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 1815,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47857] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1014,
										["targets"] = {
											["Mjordin Combatant"] = 1014,
										},
										["n_dmg"] = 1014,
										["n_min"] = 1014,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[21] = 1014,
										},
										["total"] = 1014,
										["c_max"] = 0,
										["id"] = 47857,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1675840608,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840587,
							["serial"] = "Player-4477-04D9C328",
							["last_dps"] = 1279.373739836307,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007451,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 7475,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 7475.007451,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7475.007451,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840608,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1246,
										["g_amt"] = 0,
										["n_max"] = 402,
										["targets"] = {
											["Mjordin Combatant"] = 4451,
										},
										["n_dmg"] = 3205,
										["n_min"] = 322,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 4451,
										["c_max"] = 632,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 614,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 541,
										["targets"] = {
											["Mjordin Combatant"] = 3024,
										},
										["n_dmg"] = 3024,
										["n_min"] = 293,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 3024,
										["c_max"] = 0,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 5540.007451,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840606,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840587,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008554,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 5540,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Nedro"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 5540.008554,
							["last_dps"] = 0,
							["last_event"] = 1675840607,
							["dps_started"] = false,
							["end_time"] = 1675840608,
							["aID"] = "30037",
							["total"] = 5540.008554,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1400,
										["g_amt"] = 0,
										["n_max"] = 382,
										["targets"] = {
											["Droomon <Nedro>"] = 4813,
										},
										["n_dmg"] = 3413,
										["n_min"] = 263,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 4813,
										["c_max"] = 745,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 655,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 11,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[15578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 45,
										["targets"] = {
											["Droomon"] = 0,
											["Droomon <Nedro>"] = 45,
										},
										["n_dmg"] = 45,
										["n_min"] = 45,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 45,
										["c_max"] = 0,
										["id"] = 15578,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
									},
									[61227] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 57,
										["targets"] = {
											["Droomon <Nedro>"] = 111,
										},
										["n_dmg"] = 111,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 111,
										["c_max"] = 0,
										["id"] = 61227,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[61343] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 317,
										["targets"] = {
											["Droomon <Nedro>"] = 317,
										},
										["n_dmg"] = 317,
										["n_min"] = 317,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 317,
										["c_max"] = 0,
										["id"] = 61343,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[49807] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 49807,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
									[61344] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 254,
										["targets"] = {
											["Droomon <Nedro>"] = 254,
										},
										["n_dmg"] = 254,
										["n_min"] = 254,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 254,
										["c_max"] = 0,
										["id"] = 61344,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
									[50370] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 50370,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 27037.008554,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840587,
							["serial"] = "Creature-0-4457-571-176-30037-00006341B3",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 188,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 2425,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 2425.005205,
							["total_without_pet"] = 1717.005205,
							["total"] = 1717.005205,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.005205,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 1717,
							},
							["totalover_without_pet"] = 0.005205,
							["healing_taken"] = 3496.005205,
							["fight_component"] = true,
							["end_time"] = 1675840608,
							["healing_from"] = {
								["Mjordin Combatant"] = true,
								["Nedro"] = true,
							},
							["last_event"] = 1675840608,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 1393,
										},
										["n_max"] = 169,
										["targets"] = {
											["Nedro"] = 169,
										},
										["n_min"] = 169,
										["counter"] = 3,
										["overheal"] = 1393,
										["total"] = 169,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 169,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 1032,
										},
										["n_max"] = 313,
										["targets"] = {
											["Nedro"] = 534,
										},
										["n_min"] = 313,
										["counter"] = 5,
										["overheal"] = 1032,
										["total"] = 534,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 534,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47857] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 1014,
										["targets"] = {
											["Nedro"] = 1014,
										},
										["n_min"] = 1014,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 1014,
										["c_max"] = 0,
										["id"] = 47857,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 1014,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.005205,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675840588,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["healing_from"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.004459,
							["total_without_pet"] = 1779.004459,
							["monster"] = true,
							["total"] = 1779.004459,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4457-571-176-30037-00006341B3",
							["totalabsorb"] = 0.004459,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 1779,
							},
							["totalover_without_pet"] = 0.004459,
							["healing_taken"] = 0.004459,
							["fight_component"] = true,
							["end_time"] = 1675840608,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["_ActorTable"] = {
									[48210] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 1779,
										["targets"] = {
											["Nedro"] = 1779,
										},
										["n_min"] = 1779,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 1779,
										["c_max"] = 0,
										["id"] = 48210,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 1779,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["targets_overheal"] = {
							},
							["tipo"] = 2,
							["totaldenied"] = 0.004459,
							["custom"] = 0,
							["last_event"] = 1675840595,
							["classe"] = "UNKNOW",
							["start_time"] = 1675840607,
							["delay"] = 1675840595,
							["aID"] = "30037",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 188,
					["_ActorTable"] = {
						{
							["received"] = 3635.005938,
							["resource"] = 0.005938,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 3635,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 2948.005938,
							["fight_component"] = true,
							["total"] = 4682.005938,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 3635,
										["id"] = 31818,
										["totalover"] = 2948,
										["targets"] = {
											["Nedro"] = 3635,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.005938,
							["last_event"] = 1675840605,
							["alternatepower"] = 0.005938,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 1047.001929,
							["resource"] = 0.001929,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1047,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 3123.001929,
							["total"] = 1047.001929,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 1047,
										["id"] = 54425,
										["totalover"] = 3123,
										["targets"] = {
											["Droomon <Nedro>"] = 1047,
										},
										["counter"] = 8,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675840606,
							["passiveover"] = 0.001929,
							["alternatepower"] = 0.001929,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 188,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 105,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 2,
										["id"] = 63321,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[61595] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 61595,
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[60064] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 60064,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[55637] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 55637,
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 43,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[47813] = 2,
								[47843] = 2,
								[59164] = 2,
								[47864] = 2,
								[57946] = 2,
								[47857] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675840608,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["spell_cast"] = {
								[54053] = 8,
							},
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "Mjordin Combatant",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "30037",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[15578] = 2,
								[61227] = 2,
								[49807] = 1,
								[61343] = 1,
								[50370] = 1,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-30037-00006341B3",
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 188,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["CombatStartedAt"] = 692745.024,
				["tempo_start"] = 1675840587,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 205,
				["playing_solo"] = true,
				["totals"] = {
					32577, -- [1]
					3496, -- [2]
					{
						0, -- [1]
						[0] = 4682,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:16:49",
				["hasTimer"] = 21,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 21.31700000003912,
				["CombatEndedAt"] = 692766.341,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "08:16:28",
				["end_time"] = 692766.341,
				["combat_id"] = 188,
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["totals_grupo"] = {
					19562, -- [1]
					1717, -- [2]
					{
						0, -- [1]
						[0] = 3635,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["spells_cast_timeline"] = {
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 27037.005244,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 1717.005205,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 692745.024,
				["contra"] = "Mjordin Combatant",
				["overall_added"] = true,
			}, -- [39]
			{
				{
					["tipo"] = 2,
					["combatId"] = 187,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.002969,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Warrior"] = 12955,
							},
							["end_time"] = 1675840560,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["damage_from"] = {
							},
							["aID"] = "4477-04D9C328",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 9758.002969000001,
							["last_dps"] = 1227.962366724438,
							["classe"] = "WARLOCK",
							["dps_started"] = false,
							["total"] = 12955.002969,
							["tipo"] = 1,
							["delay"] = 0,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1773,
										["targets"] = {
											["Jotunheim Warrior"] = 2891,
										},
										["n_dmg"] = 2891,
										["n_min"] = 1118,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 1118,
											[9] = 2891,
										},
										["total"] = 2891,
										["c_max"] = 0,
										["id"] = 47813,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47864] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 470,
										["targets"] = {
											["Jotunheim Warrior"] = 1198,
										},
										["n_dmg"] = 1198,
										["n_min"] = 364,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[5] = 728,
											[9] = 1198,
										},
										["total"] = 1198,
										["c_max"] = 0,
										["id"] = 47864,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[59164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1779,
										["targets"] = {
											["Jotunheim Warrior"] = 1779,
										},
										["n_dmg"] = 1779,
										["n_min"] = 1779,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[9] = 1779,
										},
										["total"] = 1779,
										["c_max"] = 0,
										["id"] = 59164,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47843] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1172,
										["targets"] = {
											["Jotunheim Warrior"] = 2079,
										},
										["n_dmg"] = 2079,
										["n_min"] = 907,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 907,
											[9] = 2079,
										},
										["total"] = 2079,
										["c_max"] = 0,
										["id"] = 47843,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
									[47857] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 906,
										["targets"] = {
											["Jotunheim Warrior"] = 1811,
										},
										["n_dmg"] = 1811,
										["n_min"] = 905,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[9] = 905,
										},
										["total"] = 1811,
										["c_max"] = 0,
										["id"] = 47857,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 0.002969,
							["spec"] = 265,
							["custom"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1675840559,
							["on_hold"] = false,
							["start_time"] = 1675840550,
							["serial"] = "Player-4477-04D9C328",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.004531,
							["damage_from"] = {
								["Jotunheim Warrior"] = true,
							},
							["targets"] = {
								["Jotunheim Warrior"] = 3197,
							},
							["tipo"] = 1,
							["pets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["total"] = 3197.004531,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 3197.004531,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1675840560,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 378,
										["targets"] = {
											["Jotunheim Warrior"] = 1702,
										},
										["n_dmg"] = 1702,
										["n_min"] = 260,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1702,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 260,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[54053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 420,
										["targets"] = {
											["Jotunheim Warrior"] = 1495,
										},
										["n_dmg"] = 1495,
										["n_min"] = 281,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1495,
										["c_max"] = 0,
										["id"] = 54053,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 32,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1248.004531,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675840558,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840550,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007537,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 1248,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["damage_from"] = {
								["Droomon <Nedro>"] = true,
								["Nedro"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1248.007537,
							["last_dps"] = 0,
							["last_event"] = 1675840557,
							["dps_started"] = false,
							["end_time"] = 1675840560,
							["aID"] = "29880",
							["total"] = 1248.007537,
							["nome"] = "Jotunheim Warrior",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 371,
										["targets"] = {
											["Droomon <Nedro>"] = 1248,
										},
										["n_dmg"] = 1248,
										["n_min"] = 164,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1248,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 164,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["extra"] = {
										},
										["spellschool"] = 1,
									}, -- [1]
									[23262] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 23262,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["extra"] = {
										},
									},
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["damage_taken"] = 12955.007537,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1675840551,
							["serial"] = "Creature-0-4457-571-176-29880-0000634311",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 187,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Nedro"] = 1229,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "WARLOCK",
							["totalover"] = 1229.006617,
							["total_without_pet"] = 2009.006617,
							["total"] = 2009.006617,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4477-04D9C328",
							["totalabsorb"] = 0.006617,
							["last_hps"] = 0,
							["targets"] = {
								["Nedro"] = 2009,
							},
							["totalover_without_pet"] = 0.006617,
							["healing_taken"] = 2009.006617,
							["fight_component"] = true,
							["end_time"] = 1675840560,
							["healing_from"] = {
								["Nedro"] = true,
							},
							["last_event"] = 1675840559,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[63106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 447,
										},
										["n_max"] = 709,
										["targets"] = {
											["Nedro"] = 709,
										},
										["n_min"] = 709,
										["counter"] = 2,
										["overheal"] = 447,
										["total"] = 709,
										["c_max"] = 0,
										["id"] = 63106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 709,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47893] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 304,
										},
										["n_max"] = 313,
										["targets"] = {
											["Nedro"] = 322,
										},
										["n_min"] = 9,
										["counter"] = 2,
										["overheal"] = 304,
										["total"] = 322,
										["c_max"] = 0,
										["id"] = 47893,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 322,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									[47857] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Nedro"] = 478,
										},
										["n_max"] = 905,
										["targets"] = {
											["Nedro"] = 978,
										},
										["n_min"] = 73,
										["counter"] = 2,
										["overheal"] = 478,
										["total"] = 978,
										["c_max"] = 0,
										["id"] = 47857,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 978,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["totaldenied"] = 0.006617,
							["aID"] = "4477-04D9C328",
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 265,
							["start_time"] = 1675840553,
							["delay"] = 0,
							["heal_enemy_amt"] = 0,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 187,
					["_ActorTable"] = {
						{
							["received"] = 2064.006449,
							["resource"] = 0.006449,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Nedro"] = 2064,
							},
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "WARLOCK",
							["totalover"] = 932.006449,
							["fight_component"] = true,
							["total"] = 2588.006449,
							["nome"] = "Nedro",
							["spells"] = {
								["_ActorTable"] = {
									[31818] = {
										["total"] = 2064,
										["id"] = 31818,
										["totalover"] = 932,
										["targets"] = {
											["Nedro"] = 2064,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["tipo"] = 3,
							["aID"] = "4477-04D9C328",
							["passiveover"] = 0.006449,
							["last_event"] = 1675840556,
							["alternatepower"] = 0.006449,
							["flag_original"] = 1300,
							["serial"] = "Player-4477-04D9C328",
							["spec"] = 265,
						}, -- [1]
						{
							["received"] = 524.005479,
							["resource"] = 0.005479,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Droomon <Nedro>"] = 524,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["totalover"] = 1563.005479,
							["total"] = 524.005479,
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["spells"] = {
								["_ActorTable"] = {
									[54425] = {
										["total"] = 524,
										["id"] = 54425,
										["totalover"] = 1563,
										["targets"] = {
											["Droomon <Nedro>"] = 524,
										},
										["counter"] = 4,
									},
								},
								["tipo"] = 7,
							},
							["tipo"] = 3,
							["flag_original"] = 4369,
							["last_event"] = 1675840557,
							["passiveover"] = 0.005479,
							["alternatepower"] = 0.005479,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 187,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[47813] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47813,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47843] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47843,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[59164] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 59164,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47864] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47864,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 32391,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47857] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 47857,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 47,
							["aID"] = "4477-04D9C328",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[63321] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 1,
										["id"] = 63321,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57940] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57940,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[47893] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 47893,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[57821] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 57821,
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[61595] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 61595,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[60064] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 60064,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[64371] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 64371,
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 26,
							["nome"] = "Nedro",
							["spec"] = 265,
							["grupo"] = true,
							["spell_cast"] = {
								[47813] = 1,
								[47843] = 1,
								[59164] = 1,
								[47864] = 1,
								[57946] = 1,
								[47857] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675840560,
							["pets"] = {
								"Droomon <Nedro>", -- [1]
							},
							["classe"] = "WARLOCK",
							["serial"] = "Player-4477-04D9C328",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 4369,
							["aID"] = "Pet-0-4457-571-176-417-02007B88D5",
							["ownerName"] = "Nedro",
							["nome"] = "Droomon <Nedro>",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4457-571-176-417-02007B88D5",
							["spell_cast"] = {
								[54053] = 4,
							},
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "Jotunheim Warrior",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["monster"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["aID"] = "29880",
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[23262] = 1,
							},
							["fight_component"] = true,
							["serial"] = "Creature-0-4457-571-176-29880-0000634311",
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 187,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Nedro"] = "Player-4477-04D9C328",
				},
				["raid_roster_indexed"] = {
					"Nedro", -- [1]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					14203, -- [1]
					2008.994607, -- [2]
					{
						0, -- [1]
						[0] = 2588,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					9758, -- [1]
					2009, -- [2]
					{
						0, -- [1]
						[0] = 2064,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "08:16:01",
				["hasTimer"] = 10,
				["cleu_timeline"] = {
				},
				["enemy"] = "Jotunheim Warrior",
				["TotalElapsedCombatTime"] = 692718.623,
				["CombatEndedAt"] = 692718.623,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Nedro"] = 12955.002969,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Nedro"] = 2009.006617,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 692718.623,
				["combat_id"] = 187,
				["TimeData"] = {
				},
				["tempo_start"] = 1675840550,
				["frags"] = {
					["Jotunheim Warrior"] = 1,
				},
				["combat_counter"] = 204,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "08:15:51",
				["start_time"] = 692708.073,
				["contra"] = "Jotunheim Warrior",
				["spells_cast_timeline"] = {
				},
			}, -- [40]
		},
	},
	["ocd_tracker"] = {
		["enabled"] = false,
		["current_cooldowns"] = {
		},
		["lines_per_column"] = 12,
		["frames"] = {
			["defensive-raid"] = {
			},
			["main"] = {
			},
			["ofensive"] = {
			},
			["defensive-target"] = {
			},
			["utility"] = {
			},
			["defensive-personal"] = {
			},
		},
		["show_options"] = false,
		["own_frame"] = {
			["defensive-raid"] = false,
			["ofensive"] = false,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["width"] = 120,
		["cooldowns"] = {
		},
		["framme_locked"] = false,
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["height"] = 18,
		["filters"] = {
			["defensive-raid"] = false,
			["ofensive"] = true,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
	},
	["last_version"] = "3.4.1 10410",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["on_death_menu"] = false,
	["cached_talents"] = {
		["Player-4477-04D9C328"] = {
			{
				136157, -- [1]
				3, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				3, -- [7]
			}, -- [1]
			{
				136223, -- [1]
				2, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [2]
			{
				136118, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				265, -- [6]
				5, -- [7]
			}, -- [3]
			{
				136169, -- [1]
				2, -- [2]
				2, -- [3]
				4, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [4]
			{
				136230, -- [1]
				3, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				3, -- [7]
			}, -- [5]
			{
				136138, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [6]
			{
				136126, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [7]
			{
				136127, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [8]
			{
				136141, -- [1]
				0, -- [2]
				7, -- [3]
				3, -- [4]
				1, -- [5]
				265, -- [6]
				1, -- [7]
			}, -- [9]
			{
				136188, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				1, -- [7]
			}, -- [10]
			{
				136195, -- [1]
				5, -- [2]
				6, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				5, -- [7]
			}, -- [11]
			{
				136132, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				265, -- [6]
				1, -- [7]
			}, -- [12]
			{
				136162, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				1, -- [5]
				265, -- [6]
				1, -- [7]
			}, -- [13]
			{
				136163, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [14]
			{
				136139, -- [1]
				2, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [15]
			{
				136137, -- [1]
				3, -- [2]
				8, -- [3]
				3, -- [4]
				1, -- [5]
				265, -- [6]
				3, -- [7]
			}, -- [16]
			{
				136147, -- [1]
				0, -- [2]
				8, -- [3]
				1, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [17]
			{
				136180, -- [1]
				5, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				5, -- [7]
			}, -- [18]
			{
				136228, -- [1]
				1, -- [2]
				9, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				1, -- [7]
			}, -- [19]
			{
				136198, -- [1]
				5, -- [2]
				5, -- [3]
				1, -- [4]
				1, -- [5]
				265, -- [6]
				5, -- [7]
			}, -- [20]
			{
				136118, -- [1]
				3, -- [2]
				4, -- [3]
				4, -- [4]
				1, -- [5]
				265, -- [6]
				3, -- [7]
			}, -- [21]
			{
				136217, -- [1]
				2, -- [2]
				6, -- [3]
				1, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [22]
			{
				237557, -- [1]
				3, -- [2]
				9, -- [3]
				1, -- [4]
				1, -- [5]
				265, -- [6]
				3, -- [7]
			}, -- [23]
			{
				236296, -- [1]
				5, -- [2]
				10, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				5, -- [7]
			}, -- [24]
			{
				236295, -- [1]
				3, -- [2]
				7, -- [3]
				1, -- [4]
				1, -- [5]
				265, -- [6]
				3, -- [7]
			}, -- [25]
			{
				236298, -- [1]
				1, -- [2]
				11, -- [3]
				2, -- [4]
				1, -- [5]
				265, -- [6]
				1, -- [7]
			}, -- [26]
			{
				136183, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				265, -- [6]
				2, -- [7]
			}, -- [27]
			{
				136227, -- [1]
				1, -- [2]
				9, -- [3]
				3, -- [4]
				1, -- [5]
				265, -- [6]
				1, -- [7]
			}, -- [28]
			{
				135230, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
				2, -- [5]
				266, -- [6]
				2, -- [7]
			}, -- [29]
			{
				136218, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [30]
			{
				136172, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [31]
			{
				136168, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				266, -- [6]
				2, -- [7]
			}, -- [32]
			{
				136221, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [33]
			{
				136082, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				2, -- [5]
				266, -- [6]
				1, -- [7]
			}, -- [34]
			{
				136164, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				2, -- [5]
				266, -- [6]
				2, -- [7]
			}, -- [35]
			{
				135932, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [36]
			{
				136220, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [37]
			{
				136203, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				5, -- [7]
			}, -- [38]
			{
				132386, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				266, -- [6]
				2, -- [7]
			}, -- [39]
			{
				136206, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				5, -- [7]
			}, -- [40]
			{
				136165, -- [1]
				0, -- [2]
				7, -- [3]
				3, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [41]
			{
				136171, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				2, -- [5]
				266, -- [6]
				1, -- [7]
			}, -- [42]
			{
				136160, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				1, -- [7]
			}, -- [43]
			{
				236301, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [44]
			{
				136185, -- [1]
				0, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [45]
			{
				136216, -- [1]
				0, -- [2]
				9, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				1, -- [7]
			}, -- [46]
			{
				136150, -- [1]
				0, -- [2]
				8, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				5, -- [7]
			}, -- [47]
			{
				136149, -- [1]
				0, -- [2]
				7, -- [3]
				1, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [48]
			{
				236292, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				1, -- [7]
			}, -- [49]
			{
				236299, -- [1]
				0, -- [2]
				9, -- [3]
				1, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [50]
			{
				237564, -- [1]
				0, -- [2]
				1, -- [3]
				4, -- [4]
				2, -- [5]
				266, -- [6]
				2, -- [7]
			}, -- [51]
			{
				237561, -- [1]
				0, -- [2]
				9, -- [3]
				3, -- [4]
				2, -- [5]
				266, -- [6]
				3, -- [7]
			}, -- [52]
			{
				237562, -- [1]
				0, -- [2]
				10, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				5, -- [7]
			}, -- [53]
			{
				237558, -- [1]
				0, -- [2]
				11, -- [3]
				2, -- [4]
				2, -- [5]
				266, -- [6]
				1, -- [7]
			}, -- [54]
			{
				135808, -- [1]
				0, -- [2]
				8, -- [3]
				3, -- [4]
				2, -- [5]
				266, -- [6]
				2, -- [7]
			}, -- [55]
			{
				135831, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [56]
			{
				136146, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				267, -- [6]
				5, -- [7]
			}, -- [57]
			{
				136197, -- [1]
				5, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				5, -- [7]
			}, -- [58]
			{
				135817, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [59]
			{
				136191, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				1, -- [7]
			}, -- [60]
			{
				136133, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				2, -- [7]
			}, -- [61]
			{
				135827, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [62]
			{
				135826, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				267, -- [6]
				5, -- [7]
			}, -- [63]
			{
				136207, -- [1]
				5, -- [2]
				3, -- [3]
				3, -- [4]
				3, -- [5]
				267, -- [6]
				5, -- [7]
			}, -- [64]
			{
				135807, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				1, -- [7]
			}, -- [65]
			{
				135813, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				267, -- [6]
				1, -- [7]
			}, -- [66]
			{
				135805, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				267, -- [6]
				2, -- [7]
			}, -- [67]
			{
				135809, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				267, -- [6]
				2, -- [7]
			}, -- [68]
			{
				135819, -- [1]
				1, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				267, -- [6]
				2, -- [7]
			}, -- [69]
			{
				135830, -- [1]
				0, -- [2]
				7, -- [3]
				4, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [70]
			{
				136201, -- [1]
				0, -- [2]
				9, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				1, -- [7]
			}, -- [71]
			{
				136196, -- [1]
				0, -- [2]
				8, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				5, -- [7]
			}, -- [72]
			{
				136214, -- [1]
				0, -- [2]
				7, -- [3]
				3, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [73]
			{
				136178, -- [1]
				0, -- [2]
				6, -- [3]
				1, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [74]
			{
				135823, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [75]
			{
				132221, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [76]
			{
				236290, -- [1]
				0, -- [2]
				9, -- [3]
				1, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [77]
			{
				236300, -- [1]
				0, -- [2]
				8, -- [3]
				3, -- [4]
				3, -- [5]
				267, -- [6]
				2, -- [7]
			}, -- [78]
			{
				236297, -- [1]
				0, -- [2]
				10, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				5, -- [7]
			}, -- [79]
			{
				236291, -- [1]
				0, -- [2]
				11, -- [3]
				2, -- [4]
				3, -- [5]
				267, -- [6]
				1, -- [7]
			}, -- [80]
			{
				236294, -- [1]
				0, -- [2]
				9, -- [3]
				3, -- [4]
				3, -- [5]
				267, -- [6]
				3, -- [7]
			}, -- [81]
		},
	},
	["last_instance_id"] = 624,
	["data_harvest_for_charsts"] = {
		["players"] = {
			{
				["playerKey"] = "total",
				["combatObjectContainer"] = 1,
				["name"] = "Damage of Each Individual Player",
				["playerOnly"] = true,
			}, -- [1]
		},
		["totals"] = {
			{
				["combatObjectSubTableKey"] = 1,
				["name"] = "Damage of All Player Combined",
				["combatObjectSubTableName"] = "totals",
			}, -- [1]
		},
	},
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Nedro-Venoxis",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["last_realversion"] = 148,
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["verticalSnap"] = true,
			["isLocked"] = false,
			["is_open"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
				[4] = 2,
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -384.8025627136231,
					["x"] = 680.9505615234375,
					["w"] = 155.1359252929688,
					["h"] = 83.7282485961914,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["modo"] = 4,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = true,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["isLocked"] = false,
			["is_open"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
				[2] = 1,
			},
			["segment"] = 0,
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -269.2223358154297,
					["x"] = 680.9505615234375,
					["w"] = 155.1359252929688,
					["h"] = 107.4321746826172,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
	},
	["mythic_plus_log"] = {
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["combat_counter"] = 244,
	["force_font_outline"] = "",
	["last_day"] = "08",
	["last_instance_time"] = 1675342619,
	["character_data"] = {
		["logons"] = 10,
	},
	["ignore_nicktag"] = false,
	["combat_id"] = 226,
	["savedStyles"] = {
	},
	["data_harvested_for_charts"] = {
	},
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["useclasscolors"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["disable_gouge"] = false,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["last_section_selected"] = "main",
			["author"] = "Terciob",
			["window_scale"] = 1,
			["encounter_timers_dbm"] = {
			},
			["show_icon"] = 5,
			["opened"] = 0,
			["hide_on_combat"] = false,
		},
		["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
			["enabled"] = true,
			["author"] = "Terciob",
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["grow_direction"] = "right",
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["arrow_anchor_y"] = 0,
			["minimap"] = {
				["minimapPos"] = 357.8321576345522,
				["radius"] = 160,
				["hide"] = false,
			},
			["main_frame_locked"] = false,
			["arrow_anchor_x"] = 0,
			["author"] = "Details! Team",
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["font_size"] = 10,
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["use_spark"] = true,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["main_frame_strata"] = "LOW",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -1.52587890625e-05,
				["x"] = -3.0517578125e-05,
				["attribute_type"] = 1,
				["update_speed"] = 0.05,
				["size"] = 32,
			},
			["y"] = -1.52587890625e-05,
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["point"] = "CENTER",
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_height"] = 20,
			["scale"] = 1,
		},
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 263444,
					["totalabsorbed"] = 0.007868,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "PALADIN",
					["total_without_pet"] = 326191.007868,
					["dps_started"] = false,
					["total"] = 326191.007868,
					["spec"] = 66,
					["on_hold"] = false,
					["isTank"] = true,
					["serial"] = "Player-4477-04BC0BBF",
					["damage_from"] = {
						["Tempest Minion"] = true,
					},
					["targets"] = {
						["Tempest Minion"] = 322564,
						["Emalon the Storm Watcher"] = 3627,
						["Archavon the Stone Watcher"] = 0,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
						[128] = 28459,
					},
					["last_event"] = 0,
					["end_time"] = 1675343164,
					["boss_fight_component"] = true,
					["avoidance"] = {
						["overall"] = {
							["DODGE"] = 0,
							["FULL_ABSORB_AMT"] = 0,
							["BLOCKED_AMT"] = 0,
							["BLOCKED_HITS"] = 0,
							["FULL_ABSORBED"] = 0,
							["ALL"] = 0,
							["PARTIAL_ABSORBED"] = 0,
							["PARRY"] = 0,
							["PARTIAL_ABSORB_AMT"] = 0,
							["ABSORB"] = 0,
							["ABSORB_AMT"] = 0,
							["FULL_HIT"] = 0,
							["HITS"] = 0,
							["FULL_HIT_AMT"] = 0,
						},
					},
					["nome"] = "Tonyhawkings",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 5,
								["b_amt"] = 2,
								["c_dmg"] = 6783,
								["g_amt"] = 8,
								["n_max"] = 974,
								["targets"] = {
									["Tempest Minion"] = 35026,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 23221,
								["n_min"] = 0,
								["g_dmg"] = 5022,
								["counter"] = 48,
								["total"] = 35026,
								["c_max"] = 1463,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 33,
								["b_dmg"] = 1203,
								["r_amt"] = 0,
							}, -- [1]
							[48819] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 431,
								["targets"] = {
									["Tempest Minion"] = 63006,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 63006,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 196,
								["total"] = 63006,
								["c_max"] = 0,
								["id"] = 48819,
								["r_dmg"] = 15253,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 196,
								["b_dmg"] = 0,
								["r_amt"] = 53,
							},
							[48952] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 704,
								["targets"] = {
									["Tempest Minion"] = 10647,
								},
								["n_dmg"] = 10647,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 10647,
								["c_max"] = 0,
								["id"] = 48952,
								["r_dmg"] = 3607,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 16,
								["b_dmg"] = 0,
								["r_amt"] = 6,
							},
							[53595] = {
								["c_amt"] = 3,
								["b_amt"] = 1,
								["c_dmg"] = 12529,
								["g_amt"] = 0,
								["n_max"] = 2712,
								["targets"] = {
									["Tempest Minion"] = 66763,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 54234,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 30,
								["total"] = 66763,
								["c_max"] = 4609,
								["id"] = 53595,
								["r_dmg"] = 12513,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 27,
								["b_dmg"] = 1968,
								["r_amt"] = 7,
							},
							[67485] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1871,
								["targets"] = {
									["Tempest Minion"] = 3605,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 3605,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 3605,
								["c_max"] = 0,
								["id"] = 67485,
								["r_dmg"] = 1734,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[61411] = {
								["c_amt"] = 2,
								["b_amt"] = 2,
								["c_dmg"] = 12068,
								["g_amt"] = 0,
								["n_max"] = 4321,
								["targets"] = {
									["Tempest Minion"] = 42428,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 30360,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 42428,
								["c_max"] = 6123,
								["id"] = 61411,
								["r_dmg"] = 3240,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["b_dmg"] = 6848,
								["r_amt"] = 1,
							},
							[62124] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 62124,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[48827] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 3894,
								["g_amt"] = 0,
								["n_max"] = 2035,
								["targets"] = {
									["Tempest Minion"] = 14419,
									["Emalon the Storm Watcher"] = 3627,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 14152,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 18046,
								["c_max"] = 3894,
								["id"] = 48827,
								["r_dmg"] = 7240,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["b_dmg"] = 0,
								["r_amt"] = 5,
							},
							[53742] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 654,
								["targets"] = {
									["Tempest Minion"] = 27046,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 27046,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 82,
								["total"] = 27046,
								["c_max"] = 0,
								["id"] = 53742,
								["r_dmg"] = 8573,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 81,
								["b_dmg"] = 0,
								["r_amt"] = 23,
							},
							[53733] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 2489,
								["g_amt"] = 0,
								["n_max"] = 1208,
								["targets"] = {
									["Tempest Minion"] = 11978,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 9489,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 11978,
								["c_max"] = 2489,
								["id"] = 53733,
								["r_dmg"] = 3832,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["b_dmg"] = 0,
								["r_amt"] = 4,
							},
							[48806] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 4157,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Tempest Minion"] = 4157,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 4157,
								["c_max"] = 4157,
								["id"] = 48806,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[20271] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 20271,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[53307] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 207,
								["targets"] = {
									["Tempest Minion"] = 9013,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 9013,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 54,
								["total"] = 9013,
								["c_max"] = 0,
								["id"] = 53307,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["RESIST"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 53,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[54043] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 289,
								["targets"] = {
									["Tempest Minion"] = 7483,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 7483,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 31,
								["total"] = 7483,
								["c_max"] = 0,
								["id"] = 54043,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 31,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[56488] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 56488,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[63529] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Tempest Minion"] = 0,
									["Emalon the Storm Watcher"] = 0,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 63529,
								["r_dmg"] = 0,
								["IMMUNE"] = 10,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[53739] = {
								["c_amt"] = 12,
								["b_amt"] = 0,
								["c_dmg"] = 5868,
								["g_amt"] = 0,
								["n_max"] = 439,
								["targets"] = {
									["Tempest Minion"] = 26993,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 21125,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 76,
								["total"] = 26993,
								["c_max"] = 834,
								["id"] = 53739,
								["r_dmg"] = 7301,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 64,
								["b_dmg"] = 0,
								["r_amt"] = 22,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_dps"] = 0,
					["aID"] = "4477-04BC0BBF",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 205579.007868,
					["start_time"] = 1675343050,
					["delay"] = 0,
					["friendlyfire"] = {
						["Tonyhawkings"] = {
							["total"] = 0,
							["spells"] = {
								[56488] = 0,
							},
						},
					},
				}, -- [1]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 32494.013887,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Einsamen"] = 4279,
						["Ranuri"] = 35402,
						["Kreshtak"] = 25924,
						["Tonyhawkings"] = 205579,
						["Grizzmo"] = 19457,
						["Yaasi"] = 13182,
						["Greater Fire Elemental <Yaasi>"] = 14793,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4447-624-31557-33998-0000DBB316",
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Kreshtak"] = true,
						["Grizzmo"] = true,
						["Ranuri"] = true,
						["Tårtåros"] = true,
						["Nedro"] = true,
						["Mirror Image <Tårtåros>"] = true,
						["Tonyhawkings"] = true,
						["Yaasi"] = true,
						["Greater Fire Elemental <Yaasi>"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 318616.013887,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675343164,
					["aID"] = "33998",
					["dps_started"] = false,
					["nome"] = "Tempest Minion",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 29,
								["c_dmg"] = 7457,
								["g_amt"] = 0,
								["n_max"] = 5643,
								["targets"] = {
									["Kreshtak"] = 21623,
									["Ranuri"] = 26733,
									["Grizzmo"] = 15003,
									["Tonyhawkings"] = 89060,
									["Yaasi"] = 13182,
									["Greater Fire Elemental <Yaasi>"] = 9586,
								},
								["n_dmg"] = 167730,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 190,
								["a_dmg"] = 21727,
								["r_amt"] = 0,
								["c_max"] = 7457,
								["MISS"] = 18,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 49,
								["extra"] = {
								},
								["BLOCK"] = 13,
								["PARRY"] = 26,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 11,
								["n_amt"] = 83,
								["b_dmg"] = 13780,
								["total"] = 175187,
							}, -- [1]
							[64363] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7595,
								["targets"] = {
									["Kreshtak"] = 4301,
									["Ranuri"] = 8669,
									["Tonyhawkings"] = 116519,
									["Grizzmo"] = 4454,
									["Einsamen"] = 4279,
									["Greater Fire Elemental <Yaasi>"] = 5207,
								},
								["n_dmg"] = 143429,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 35,
								["total"] = 143429,
								["c_max"] = 0,
								["id"] = 64363,
								["r_dmg"] = 111211,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 22820,
								["c_min"] = 0,
								["successful_casted"] = 35,
								["a_amt"] = 5,
								["n_amt"] = 34,
								["b_dmg"] = 0,
								["r_amt"] = 27,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 318616.013887,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1078355.013887,
					["start_time"] = 1675343053,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [2]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 11030.004129,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Tårtåros"] = 9110,
						["Einsamen"] = 245781,
						["Kreshtak"] = 39075,
						["Missbläckz"] = 6931,
						["Hartarbeiter"] = 13235,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4447-624-31557-33993-00005BB316",
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Mirror Image <Tårtåros>"] = true,
						["Grizzmo"] = true,
						["Ranuri"] = true,
						["Tårtåros"] = true,
						["Nedro"] = true,
						["Kreshtak"] = true,
						["Tonyhawkings"] = true,
						["Einsamen"] = true,
						["Spirit Wolf <Yaasi>"] = true,
						["Yaasi"] = true,
						["Greater Fire Elemental <Yaasi>"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 314132.004129,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675343164,
					["aID"] = "33993",
					["dps_started"] = false,
					["nome"] = "Emalon the Storm Watcher",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 18846,
								["g_amt"] = 0,
								["n_max"] = 11753,
								["targets"] = {
									["Einsamen"] = 207922,
								},
								["n_dmg"] = 189076,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 40,
								["total"] = 207922,
								["c_max"] = 18846,
								["a_dmg"] = 112022,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 9,
								["MISS"] = 3,
								["extra"] = {
								},
								["PARRY"] = 8,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 10,
								["n_amt"] = 19,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[64216] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 20189,
								["targets"] = {
									["Grizzmo"] = 0,
									["Einsamen"] = 37859,
									["Kreshtak"] = 39075,
									["Ranuri"] = 0,
								},
								["n_dmg"] = 76934,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 76934,
								["c_max"] = 0,
								["id"] = 64216,
								["r_dmg"] = 56745,
								["MISS"] = 1,
								["IMMUNE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 57226,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 3,
								["n_amt"] = 4,
								["b_dmg"] = 0,
								["r_amt"] = 3,
							},
							[64218] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 64218,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[64213] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 6995,
								["targets"] = {
									["Tårtåros"] = 9110,
									["Missbläckz"] = 6931,
									["Hartarbeiter"] = 13235,
								},
								["n_dmg"] = 29276,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 29276,
								["c_max"] = 0,
								["id"] = 64213,
								["r_dmg"] = 18246,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 4,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 314132.004129,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 2788999.004129,
					["start_time"] = 1675343053,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [3]
				{
					["flag_original"] = 263444,
					["totalabsorbed"] = 0.008218,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "DEATHKNIGHT",
					["total_without_pet"] = 162834.008218,
					["dps_started"] = false,
					["total"] = 162834.008218,
					["spec"] = 250,
					["on_hold"] = false,
					["isTank"] = true,
					["serial"] = "Player-4477-04991245",
					["damage_from"] = {
						["Emalon the Storm Watcher"] = true,
						["Tempest Minion"] = true,
					},
					["targets"] = {
						["Emalon the Storm Watcher"] = 162834,
						["Archavon the Stone Watcher"] = 0,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["last_event"] = 0,
					["end_time"] = 1675343164,
					["boss_fight_component"] = true,
					["avoidance"] = {
						["overall"] = {
							["DODGE"] = 0,
							["FULL_ABSORB_AMT"] = 0,
							["BLOCKED_AMT"] = 0,
							["BLOCKED_HITS"] = 0,
							["FULL_ABSORBED"] = 0,
							["ALL"] = 0,
							["PARTIAL_ABSORBED"] = 0,
							["PARRY"] = 0,
							["PARTIAL_ABSORB_AMT"] = 0,
							["ABSORB"] = 0,
							["ABSORB_AMT"] = 0,
							["FULL_HIT"] = 0,
							["HITS"] = 0,
							["FULL_HIT_AMT"] = 0,
						},
					},
					["nome"] = "Einsamen",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 23,
								["b_amt"] = 7,
								["c_dmg"] = 34098,
								["g_amt"] = 31,
								["n_max"] = 962,
								["targets"] = {
									["Emalon the Storm Watcher"] = 74323,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 26054,
								["n_min"] = 0,
								["g_dmg"] = 14171,
								["counter"] = 142,
								["total"] = 74323,
								["c_max"] = 1912,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 32,
								["DODGE"] = 3,
								["extra"] = {
								},
								["PARRY"] = 12,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 41,
								["b_dmg"] = 3867,
								["r_amt"] = 0,
							}, -- [1]
							[47632] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 10463,
								["g_amt"] = 0,
								["n_max"] = 1387,
								["targets"] = {
									["Emalon the Storm Watcher"] = 20439,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 9976,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 20439,
								["c_max"] = 2754,
								["id"] = 47632,
								["r_dmg"] = 9414,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 6,
							},
							[55095] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 412,
								["targets"] = {
									["Emalon the Storm Watcher"] = 9265,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 9265,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 26,
								["total"] = 9265,
								["c_max"] = 0,
								["id"] = 55095,
								["r_dmg"] = 5436,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 26,
								["b_dmg"] = 0,
								["r_amt"] = 16,
							},
							[49921] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 1055,
								["g_amt"] = 0,
								["n_max"] = 583,
								["targets"] = {
									["Emalon the Storm Watcher"] = 6563,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 5508,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 6563,
								["c_max"] = 1055,
								["id"] = 49921,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[49930] = {
								["c_amt"] = 2,
								["b_amt"] = 2,
								["c_dmg"] = 2522,
								["g_amt"] = 0,
								["n_max"] = 725,
								["targets"] = {
									["Emalon the Storm Watcher"] = 11248,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 8726,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 17,
								["total"] = 11248,
								["c_max"] = 1333,
								["id"] = 49930,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["MISS"] = 1,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 13,
								["b_dmg"] = 1259,
								["r_amt"] = 0,
							},
							[49909] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 6148,
								["g_amt"] = 0,
								["n_max"] = 1267,
								["targets"] = {
									["Emalon the Storm Watcher"] = 21655,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 15507,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 22,
								["total"] = 21655,
								["c_max"] = 2221,
								["id"] = 49909,
								["r_dmg"] = 11746,
								["MISS"] = 4,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 15,
								["b_dmg"] = 0,
								["r_amt"] = 10,
							},
							[53307] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 167,
								["targets"] = {
									["Emalon the Storm Watcher"] = 2727,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 2727,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 2727,
								["c_max"] = 0,
								["id"] = 53307,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["RESIST"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 18,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[49895] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Emalon the Storm Watcher"] = 0,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 49895,
								["r_dmg"] = 0,
								["MISS"] = 4,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[55078] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 417,
								["targets"] = {
									["Emalon the Storm Watcher"] = 9333,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 9333,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 26,
								["total"] = 9333,
								["c_max"] = 0,
								["id"] = 55078,
								["r_dmg"] = 5391,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 26,
								["b_dmg"] = 0,
								["r_amt"] = 16,
							},
							[54043] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 199,
								["targets"] = {
									["Emalon the Storm Watcher"] = 3115,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 3115,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 18,
								["total"] = 3115,
								["c_max"] = 0,
								["id"] = 54043,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["RESIST"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 17,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[49924] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 2074,
								["g_amt"] = 0,
								["n_max"] = 1080,
								["targets"] = {
									["Emalon the Storm Watcher"] = 4166,
								},
								["n_dmg"] = 2092,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 4166,
								["c_max"] = 2074,
								["id"] = 49924,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_dps"] = 0,
					["aID"] = "4477-04991245",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 250060.008218,
					["start_time"] = 1675343051,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [4]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.015637,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Emalon the Storm Watcher"] = 426321,
						["Tempest Minion"] = 36189,
						["Archavon the Stone Watcher"] = 0,
					},
					["tipo"] = 1,
					["pets"] = {
					},
					["damage_from"] = {
						["Emalon the Storm Watcher"] = true,
						["Tempest Minion"] = true,
					},
					["total"] = 462510.015637,
					["aID"] = "4477-02C03342",
					["raid_targets"] = {
					},
					["total_without_pet"] = 462510.015637,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 13,
								["b_amt"] = 0,
								["c_dmg"] = 54454,
								["g_amt"] = 12,
								["n_max"] = 2232,
								["targets"] = {
									["Emalon the Storm Watcher"] = 90719,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 20135,
								["n_min"] = 0,
								["g_dmg"] = 16130,
								["counter"] = 37,
								["total"] = 90719,
								["c_max"] = 5216,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 11,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[50782] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 5584,
								["g_amt"] = 0,
								["n_max"] = 2485,
								["targets"] = {
									["Emalon the Storm Watcher"] = 12379,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 6795,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 12379,
								["c_max"] = 5584,
								["id"] = 50782,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[47520] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 25899,
								["g_amt"] = 0,
								["n_max"] = 1865,
								["targets"] = {
									["Emalon the Storm Watcher"] = 21461,
									["Tempest Minion"] = 13265,
								},
								["n_dmg"] = 8827,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 34726,
								["c_max"] = 4747,
								["id"] = 47520,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[7384] = {
								["c_amt"] = 11,
								["b_amt"] = 0,
								["c_dmg"] = 56944,
								["g_amt"] = 0,
								["n_max"] = 2525,
								["targets"] = {
									["Emalon the Storm Watcher"] = 59469,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 2525,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 59469,
								["c_max"] = 5968,
								["id"] = 7384,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[7922] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Emalon the Storm Watcher"] = 0,
									["Archavon the Stone Watcher"] = 0,
									["Tempest Warder"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 7922,
								["r_dmg"] = 0,
								["IMMUNE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[7386] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 7386,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[47465] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1138,
								["targets"] = {
									["Emalon the Storm Watcher"] = 25057,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 25057,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 28,
								["total"] = 25057,
								["c_max"] = 0,
								["id"] = 47465,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 28,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[50622] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 19837,
								["g_amt"] = 0,
								["n_max"] = 2043,
								["targets"] = {
									["Emalon the Storm Watcher"] = 25553,
								},
								["n_dmg"] = 5716,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 25553,
								["c_max"] = 5604,
								["id"] = 50622,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[12721] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1926,
								["targets"] = {
									["Emalon the Storm Watcher"] = 69027,
									["Tempest Minion"] = 3030,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 72057,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 80,
								["total"] = 72057,
								["c_max"] = 0,
								["id"] = 12721,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 80,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[47486] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 37831,
								["g_amt"] = 0,
								["n_max"] = 3080,
								["targets"] = {
									["Emalon the Storm Watcher"] = 50330,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 12499,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 50330,
								["c_max"] = 7658,
								["id"] = 47486,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[57755] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 57755,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[53307] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 148,
								["targets"] = {
									["Tempest Minion"] = 740,
								},
								["n_dmg"] = 740,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 740,
								["c_max"] = 0,
								["id"] = 53307,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[47450] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 5302,
								["g_amt"] = 0,
								["n_max"] = 2332,
								["targets"] = {
									["Emalon the Storm Watcher"] = 9879,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 4577,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 9879,
								["c_max"] = 5302,
								["id"] = 47450,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[54043] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 174,
								["targets"] = {
									["Tempest Minion"] = 849,
								},
								["n_dmg"] = 849,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 849,
								["c_max"] = 0,
								["id"] = 54043,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[20647] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 38858,
								["g_amt"] = 0,
								["n_max"] = 3661,
								["targets"] = {
									["Emalon the Storm Watcher"] = 62447,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 23589,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 62447,
								["c_max"] = 8691,
								["id"] = 20647,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[12723] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 4497,
								["targets"] = {
									["Tempest Minion"] = 18305,
								},
								["n_dmg"] = 18305,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 18305,
								["c_max"] = 0,
								["id"] = 12723,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["last_dps"] = 0,
					["serial"] = "Player-4477-02C03342",
					["nome"] = "Kreshtak",
					["spec"] = 71,
					["grupo"] = true,
					["classe"] = "WARRIOR",
					["friendlyfire"] = {
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 64999.015637,
					["start_time"] = 1675343052,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [5]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.016999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Emalon the Storm Watcher"] = 657284,
						["Tempest Minion"] = 72596,
						["Archavon the Stone Watcher"] = 0,
					},
					["tipo"] = 1,
					["pets"] = {
					},
					["damage_from"] = {
						["Tempest Minion"] = true,
					},
					["total"] = 729880.0169990001,
					["aID"] = "4477-044DA6CD",
					["raid_targets"] = {
						[128] = 20618,
					},
					["total_without_pet"] = 729880.0169990001,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 106,
								["b_amt"] = 2,
								["c_dmg"] = 191337,
								["g_amt"] = 59,
								["n_max"] = 1608,
								["targets"] = {
									["Emalon the Storm Watcher"] = 252815,
									["Tempest Minion"] = 17858,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 43598,
								["n_min"] = 0,
								["g_dmg"] = 35738,
								["counter"] = 250,
								["total"] = 270673,
								["c_max"] = 3628,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 29,
								["DODGE"] = 4,
								["extra"] = {
									["extra_attack"] = 15,
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 52,
								["b_dmg"] = 2295,
								["r_amt"] = 0,
							}, -- [1]
							[52874] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 5529,
								["g_amt"] = 0,
								["n_max"] = 376,
								["targets"] = {
									["Tempest Minion"] = 6357,
									["Emalon the Storm Watcher"] = 2329,
								},
								["n_dmg"] = 3157,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 15,
								["total"] = 8686,
								["c_max"] = 980,
								["id"] = 52874,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[51585] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Emalon the Storm Watcher"] = 0,
									["Tempest Minion"] = 0,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 35,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 51585,
								["r_dmg"] = 0,
								["IMMUNE"] = 35,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[48638] = {
								["c_amt"] = 16,
								["b_amt"] = 0,
								["c_dmg"] = 81762,
								["g_amt"] = 0,
								["n_max"] = 1998,
								["targets"] = {
									["Emalon the Storm Watcher"] = 110766,
									["Tempest Minion"] = 10201,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 39205,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 39,
								["total"] = 120967,
								["c_max"] = 5725,
								["id"] = 48638,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 23,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[57841] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 11248,
								["g_amt"] = 0,
								["n_max"] = 1646,
								["targets"] = {
									["Emalon the Storm Watcher"] = 14486,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 3238,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 14486,
								["c_max"] = 4008,
								["id"] = 57841,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[57842] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 7315,
								["g_amt"] = 0,
								["n_max"] = 1013,
								["targets"] = {
									["Emalon the Storm Watcher"] = 9277,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 1962,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 9277,
								["c_max"] = 2522,
								["id"] = 57842,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[57970] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1836,
								["targets"] = {
									["Emalon the Storm Watcher"] = 43909,
									["Tempest Minion"] = 8508,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 52417,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 53,
								["total"] = 52417,
								["c_max"] = 0,
								["id"] = 57970,
								["r_dmg"] = 22500,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 53,
								["b_dmg"] = 0,
								["r_amt"] = 24,
							},
							[51723] = {
								["c_amt"] = 7,
								["b_amt"] = 2,
								["c_dmg"] = 16383,
								["g_amt"] = 0,
								["n_max"] = 1002,
								["targets"] = {
									["Tempest Minion"] = 17683,
									["Emalon the Storm Watcher"] = 6080,
								},
								["n_dmg"] = 7380,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 15,
								["total"] = 23763,
								["c_max"] = 2620,
								["id"] = 51723,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 1669,
								["r_amt"] = 0,
							},
							[1330] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Emalon the Storm Watcher"] = 0,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1330,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[48672] = {
								["c_amt"] = 13,
								["b_amt"] = 0,
								["c_dmg"] = 30523,
								["g_amt"] = 0,
								["n_max"] = 1031,
								["targets"] = {
									["Emalon the Storm Watcher"] = 53716,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 23193,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 37,
								["total"] = 53716,
								["c_max"] = 2548,
								["id"] = 48672,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 24,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[57965] = {
								["c_amt"] = 25,
								["b_amt"] = 0,
								["c_dmg"] = 50899,
								["g_amt"] = 0,
								["n_max"] = 1560,
								["targets"] = {
									["Emalon the Storm Watcher"] = 157734,
									["Tempest Minion"] = 11506,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 118341,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 132,
								["total"] = 169240,
								["c_max"] = 2485,
								["id"] = 57965,
								["r_dmg"] = 62180,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 107,
								["b_dmg"] = 0,
								["r_amt"] = 51,
							},
							[54043] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 173,
								["targets"] = {
									["Tempest Minion"] = 483,
								},
								["n_dmg"] = 483,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 483,
								["c_max"] = 0,
								["id"] = 54043,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[48676] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1029,
								["targets"] = {
									["Emalon the Storm Watcher"] = 6172,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 6172,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 6172,
								["c_max"] = 0,
								["id"] = 48676,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[48668] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 48668,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["last_dps"] = 0,
					["serial"] = "Player-4477-044DA6CD",
					["nome"] = "Grizzmo",
					["spec"] = 260,
					["grupo"] = true,
					["classe"] = "ROGUE",
					["friendlyfire"] = {
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 19457.016999,
					["start_time"] = 1675343052,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [6]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.014612,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Emalon the Storm Watcher"] = 404589,
						["Tempest Minion"] = 98065,
						["Archavon the Stone Watcher"] = 0,
					},
					["tipo"] = 1,
					["pets"] = {
					},
					["damage_from"] = {
						["Tempest Minion"] = true,
					},
					["total"] = 502654.014612,
					["aID"] = "4477-04546F6D",
					["raid_targets"] = {
						[128] = 20002,
					},
					["total_without_pet"] = 502654.014612,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 17,
								["b_amt"] = 0,
								["c_dmg"] = 56770,
								["g_amt"] = 16,
								["n_max"] = 2163,
								["targets"] = {
									["Emalon the Storm Watcher"] = 92315,
									["Tempest Minion"] = 6672,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 21232,
								["n_min"] = 0,
								["g_dmg"] = 20985,
								["counter"] = 45,
								["total"] = 98987,
								["c_max"] = 4399,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[53385] = {
								["c_amt"] = 8,
								["b_amt"] = 0,
								["c_dmg"] = 34534,
								["g_amt"] = 0,
								["n_max"] = 2901,
								["targets"] = {
									["Tempest Minion"] = 30374,
									["Emalon the Storm Watcher"] = 29031,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 24871,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 59405,
								["c_max"] = 5230,
								["id"] = 53385,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[67890] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Emalon the Storm Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 67890,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[53739] = {
								["c_amt"] = 27,
								["b_amt"] = 0,
								["c_dmg"] = 48268,
								["g_amt"] = 0,
								["n_max"] = 1458,
								["targets"] = {
									["Emalon the Storm Watcher"] = 86891,
									["Tempest Minion"] = 1854,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 40477,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 75,
								["total"] = 88745,
								["c_max"] = 2868,
								["id"] = 53739,
								["r_dmg"] = 42592,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 48,
								["b_dmg"] = 0,
								["r_amt"] = 37,
							},
							[28730] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Emalon the Storm Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 28730,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[61840] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 745,
								["targets"] = {
									["Emalon the Storm Watcher"] = 15067,
									["Tempest Minion"] = 7880,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 22947,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 60,
								["total"] = 22947,
								["c_max"] = 0,
								["id"] = 61840,
								["r_dmg"] = 9072,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 60,
								["b_dmg"] = 0,
								["r_amt"] = 26,
							},
							[53733] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 18267,
								["g_amt"] = 0,
								["n_max"] = 4006,
								["targets"] = {
									["Emalon the Storm Watcher"] = 34074,
									["Tempest Minion"] = 7915,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 23722,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 41989,
								["c_max"] = 5179,
								["id"] = 53733,
								["r_dmg"] = 23865,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["b_dmg"] = 0,
								["r_amt"] = 8,
							},
							[32747] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Emalon the Storm Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 32747,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[35395] = {
								["c_amt"] = 9,
								["b_amt"] = 0,
								["c_dmg"] = 29517,
								["g_amt"] = 0,
								["n_max"] = 1963,
								["targets"] = {
									["Emalon the Storm Watcher"] = 41120,
									["Tempest Minion"] = 4530,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 16133,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 45650,
								["c_max"] = 3919,
								["id"] = 35395,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[53742] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1519,
								["targets"] = {
									["Emalon the Storm Watcher"] = 36476,
									["Tempest Minion"] = 1608,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 38084,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 41,
								["total"] = 38084,
								["c_max"] = 0,
								["id"] = 53742,
								["r_dmg"] = 13642,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 41,
								["b_dmg"] = 0,
								["r_amt"] = 16,
							},
							[48819] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 653,
								["targets"] = {
									["Emalon the Storm Watcher"] = 32829,
									["Tempest Minion"] = 25331,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 58160,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 140,
								["total"] = 58160,
								["c_max"] = 0,
								["id"] = 48819,
								["r_dmg"] = 23217,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 140,
								["b_dmg"] = 0,
								["r_amt"] = 60,
							},
							[54043] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 276,
								["targets"] = {
									["Tempest Minion"] = 1526,
								},
								["n_dmg"] = 1526,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 1526,
								["c_max"] = 0,
								["id"] = 54043,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[48801] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 7230,
								["g_amt"] = 0,
								["n_max"] = 3682,
								["targets"] = {
									["Emalon the Storm Watcher"] = 14574,
									["Tempest Minion"] = 3122,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 10466,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 17696,
								["c_max"] = 4599,
								["id"] = 48801,
								["r_dmg"] = 8281,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							},
							[48806] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 29465,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Tempest Minion"] = 7253,
									["Emalon the Storm Watcher"] = 22212,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 29465,
								["c_max"] = 7253,
								["id"] = 48806,
								["r_dmg"] = 18818,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 3,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["last_dps"] = 0,
					["serial"] = "Player-4477-04546F6D",
					["nome"] = "Ranuri",
					["spec"] = 70,
					["grupo"] = true,
					["classe"] = "PALADIN",
					["friendlyfire"] = {
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 35402.014612,
					["start_time"] = 1675343052,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [7]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.004804,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Emalon the Storm Watcher"] = 250549,
						["Tempest Minion"] = 370086,
						["Archavon the Stone Watcher"] = 0,
					},
					["tipo"] = 1,
					["pets"] = {
						"Mirror Image <Tårtåros>", -- [1]
					},
					["damage_from"] = {
						["Emalon the Storm Watcher"] = true,
					},
					["total"] = 620635.004804,
					["aID"] = "4477-04D7DA76",
					["raid_targets"] = {
						[128] = 101779,
					},
					["total_without_pet"] = 605931.004804,
					["spells"] = {
						["_ActorTable"] = {
							[47610] = {
								["c_amt"] = 11,
								["b_amt"] = 0,
								["c_dmg"] = 101700,
								["g_amt"] = 0,
								["n_max"] = 4828,
								["targets"] = {
									["Emalon the Storm Watcher"] = 102017,
									["Tempest Minion"] = 29888,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 30205,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 39,
								["total"] = 131905,
								["c_max"] = 11996,
								["id"] = 47610,
								["r_dmg"] = 27286,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 28,
								["b_dmg"] = 0,
								["r_amt"] = 14,
							},
							[60203] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 3285,
								["g_amt"] = 0,
								["n_max"] = 2561,
								["targets"] = {
									["Tempest Minion"] = 5473,
									["Emalon the Storm Watcher"] = 2561,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 4749,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 8034,
								["c_max"] = 3285,
								["id"] = 60203,
								["r_dmg"] = 3285,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[42950] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2240,
								["targets"] = {
									["Tempest Minion"] = 8194,
								},
								["n_dmg"] = 8194,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 8194,
								["c_max"] = 0,
								["id"] = 42950,
								["r_dmg"] = 1628,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[12494] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 12494,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[42873] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 2659,
								["g_amt"] = 0,
								["n_max"] = 2430,
								["targets"] = {
									["Emalon the Storm Watcher"] = 4688,
									["Tempest Minion"] = 2659,
								},
								["n_dmg"] = 4688,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 7347,
								["c_max"] = 2659,
								["id"] = 42873,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[42926] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 10689,
								["g_amt"] = 0,
								["n_max"] = 2253,
								["targets"] = {
									["Tempest Minion"] = 25426,
								},
								["n_dmg"] = 14737,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 25426,
								["c_max"] = 4031,
								["id"] = 42926,
								["r_dmg"] = 5938,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 13,
								["b_dmg"] = 0,
								["r_amt"] = 4,
							},
							[42859] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 2834,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Tempest Minion"] = 2834,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 2834,
								["c_max"] = 2834,
								["id"] = 42859,
								["r_dmg"] = 2834,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[55362] = {
								["c_amt"] = 25,
								["b_amt"] = 0,
								["c_dmg"] = 78474,
								["g_amt"] = 0,
								["n_max"] = 2450,
								["targets"] = {
									["Emalon the Storm Watcher"] = 13649,
									["Tempest Minion"] = 122866,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 58041,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 60,
								["total"] = 136515,
								["c_max"] = 4035,
								["id"] = 55362,
								["r_dmg"] = 33759,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 35,
								["b_dmg"] = 0,
								["r_amt"] = 17,
							},
							[12654] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7168,
								["targets"] = {
									["Emalon the Storm Watcher"] = 52402,
									["Tempest Minion"] = 57588,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 109990,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 102,
								["total"] = 109990,
								["c_max"] = 0,
								["id"] = 12654,
								["r_dmg"] = 26160,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 102,
								["b_dmg"] = 0,
								["r_amt"] = 28,
							},
							[42945] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 3125,
								["g_amt"] = 0,
								["n_max"] = 2441,
								["targets"] = {
									["Tempest Minion"] = 9821,
								},
								["n_dmg"] = 6696,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 9821,
								["c_max"] = 3125,
								["id"] = 42945,
								["r_dmg"] = 5168,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							},
							[42891] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 41957,
								["g_amt"] = 0,
								["n_max"] = 6062,
								["targets"] = {
									["Emalon the Storm Watcher"] = 38282,
									["Tempest Minion"] = 23574,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 19899,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 61856,
								["c_max"] = 11552,
								["id"] = 42891,
								["r_dmg"] = 29352,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 19,
								["b_dmg"] = 0,
								["r_amt"] = 13,
							},
							[55360] = {
								["c_amt"] = 43,
								["b_amt"] = 0,
								["c_dmg"] = 65192,
								["g_amt"] = 0,
								["n_max"] = 968,
								["targets"] = {
									["Emalon the Storm Watcher"] = 25312,
									["Tempest Minion"] = 78697,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 38817,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 91,
								["total"] = 104009,
								["c_max"] = 2049,
								["id"] = 55360,
								["r_dmg"] = 28143,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 48,
								["b_dmg"] = 0,
								["r_amt"] = 27,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["last_dps"] = 0,
					["serial"] = "Player-4477-04D7DA76",
					["nome"] = "Tårtåros",
					["spec"] = 63,
					["grupo"] = true,
					["classe"] = "MAGE",
					["friendlyfire"] = {
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 9110.004804,
					["start_time"] = 1675343053,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [8]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 1.142529000000001,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ravenous Jormungar"] = 215097,
						["Seething Revenant"] = 51645,
						["Emalon the Storm Watcher"] = 400351,
						["Jotunheim Warrior"] = 77392,
						["Onslaught Gryphon Rider"] = 268484,
						["Stoic Mammoth"] = 22684,
						["Tempest Minion"] = 33965,
						["Roaming Jormungar"] = 215033,
						["Viscous Oil"] = 262600,
						["Restless Frostborn Warrior"] = 128135,
						["Disembodied Jormungar"] = 175348,
						["Stormforged Infiltrator"] = 154760,
						["Mjordin Combatant"] = 333800,
						["Brittle Revenant"] = 322113,
						["Restless Frostborn Ghost"] = 151120,
						["Archavon the Stone Watcher"] = 0,
						["Niffelem Forefather"] = 302714,
						["Jotunheim Proto-Drake"] = 4520880,
					},
					["tipo"] = 1,
					["pets"] = {
						"Droomon <Nedro>", -- [1]
						"Jotunheim Rapid-Fire Harpoon <Nedro>", -- [2]
						"Unknown <Nedro>", -- [3]
					},
					["damage_from"] = {
						["Viscous Oil"] = true,
						["Disembodied Jormungar"] = true,
						["Jotunheim Warrior"] = true,
						["Onslaught Gryphon Rider"] = true,
						["Stormforged Infiltrator"] = true,
						["Brittle Revenant"] = true,
						["Mjordin Combatant"] = true,
						["Onslaught Harbor Guard"] = true,
						["Ravenous Jormungar"] = true,
						["Restless Frostborn Ghost"] = true,
						["Niffelem Forefather"] = true,
						["Roaming Jormungar"] = true,
					},
					["end_time"] = 1675343164,
					["classe"] = "WARLOCK",
					["raid_targets"] = {
						[128] = 33965,
					},
					["total_without_pet"] = 2309216.142528997,
					["aID"] = "4477-04D9C328",
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["total"] = 7636122.142529003,
					["damage_taken"] = 97591.14252899993,
					["serial"] = "Player-4477-04D9C328",
					["boss_fight_component"] = true,
					["spec"] = 265,
					["grupo"] = true,
					["friendlyfire"] = {
					},
					["nome"] = "Nedro",
					["spells"] = {
						["_ActorTable"] = {
							[47864] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 623,
								["targets"] = {
									["Restless Frostborn Ghost"] = 14655,
									["Seething Revenant"] = 4571,
									["Restless Frostborn Warrior"] = 11941,
									["Disembodied Jormungar"] = 17274,
									["Jotunheim Warrior"] = 7630,
									["Onslaught Gryphon Rider"] = 24642,
									["Stormforged Infiltrator"] = 14033,
									["Brittle Revenant"] = 32527,
									["Mjordin Combatant"] = 32603,
									["Viscous Oil"] = 20835,
									["Ravenous Jormungar"] = 17866,
									["Stoic Mammoth"] = 2526,
									["Niffelem Forefather"] = 28360,
									["Roaming Jormungar"] = 19504,
								},
								["n_dmg"] = 248967,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 610,
								["total"] = 248967,
								["c_max"] = 0,
								["id"] = 47864,
								["r_dmg"] = 0,
								["EVADE"] = 3,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 607,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[47857] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1101,
								["targets"] = {
									["Ravenous Jormungar"] = 11265,
									["Seething Revenant"] = 2873,
									["Restless Frostborn Warrior"] = 4384,
									["Disembodied Jormungar"] = 761,
									["Jotunheim Warrior"] = 6196,
									["Onslaught Gryphon Rider"] = 9852,
									["Stormforged Infiltrator"] = 5215,
									["Brittle Revenant"] = 8307,
									["Mjordin Combatant"] = 9782,
									["Restless Frostborn Ghost"] = 3781,
									["Viscous Oil"] = 11798,
									["Niffelem Forefather"] = 13623,
									["Roaming Jormungar"] = 6102,
								},
								["n_dmg"] = 93939,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 111,
								["total"] = 93939,
								["c_max"] = 0,
								["id"] = 47857,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 111,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[47843] = {
								["c_amt"] = 95,
								["b_amt"] = 0,
								["c_dmg"] = 206587,
								["g_amt"] = 0,
								["n_max"] = 1936,
								["targets"] = {
									["Ravenous Jormungar"] = 34089,
									["Seething Revenant"] = 11645,
									["Emalon the Storm Watcher"] = 55826,
									["Jotunheim Warrior"] = 15258,
									["Onslaught Gryphon Rider"] = 38321,
									["Stoic Mammoth"] = 4370,
									["Tempest Minion"] = 7319,
									["Roaming Jormungar"] = 39330,
									["Viscous Oil"] = 36101,
									["Restless Frostborn Warrior"] = 26944,
									["Disembodied Jormungar"] = 34930,
									["Stormforged Infiltrator"] = 30927,
									["Mjordin Combatant"] = 60845,
									["Restless Frostborn Ghost"] = 26005,
									["Archavon the Stone Watcher"] = 0,
									["Niffelem Forefather"] = 43503,
									["Brittle Revenant"] = 62654,
								},
								["n_dmg"] = 321480,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 394,
								["total"] = 528067,
								["c_max"] = 3751,
								["id"] = 47843,
								["r_dmg"] = 21508,
								["EVADE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 298,
								["b_dmg"] = 0,
								["r_amt"] = 11,
							},
							[47836] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 939,
								["targets"] = {
									["Viscous Oil"] = 1877,
									["Ravenous Jormungar"] = 2816,
									["Onslaught Gryphon Rider"] = 939,
								},
								["n_dmg"] = 5632,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 5632,
								["c_max"] = 0,
								["id"] = 47836,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[47860] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1795,
								["targets"] = {
									["Viscous Oil"] = 1795,
									["Brittle Revenant"] = 3255,
									["Niffelem Forefather"] = 1453,
								},
								["n_dmg"] = 6503,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 6503,
								["c_max"] = 0,
								["id"] = 47860,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[59164] = {
								["c_amt"] = 33,
								["b_amt"] = 0,
								["c_dmg"] = 122113,
								["g_amt"] = 0,
								["n_max"] = 2489,
								["targets"] = {
									["Ravenous Jormungar"] = 32919,
									["Seething Revenant"] = 7426,
									["Emalon the Storm Watcher"] = 17479,
									["Jotunheim Warrior"] = 10718,
									["Onslaught Gryphon Rider"] = 43463,
									["Stoic Mammoth"] = 3808,
									["Tempest Minion"] = 6213,
									["Roaming Jormungar"] = 33920,
									["Viscous Oil"] = 36321,
									["Restless Frostborn Warrior"] = 21299,
									["Disembodied Jormungar"] = 31446,
									["Stormforged Infiltrator"] = 24861,
									["Mjordin Combatant"] = 45823,
									["Restless Frostborn Ghost"] = 30088,
									["Archavon the Stone Watcher"] = 0,
									["Niffelem Forefather"] = 39053,
									["Brittle Revenant"] = 50068,
								},
								["n_dmg"] = 312792,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 201,
								["total"] = 434905,
								["c_max"] = 4499,
								["id"] = 59164,
								["r_dmg"] = 12770,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 168,
								["b_dmg"] = 0,
								["r_amt"] = 4,
							},
							[47855] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 10801,
								["targets"] = {
									["Emalon the Storm Watcher"] = 46133,
									["Brittle Revenant"] = 2019,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 48152,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 48152,
								["c_max"] = 0,
								["id"] = 47855,
								["r_dmg"] = 8631,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[47813] = {
								["c_amt"] = 114,
								["b_amt"] = 0,
								["c_dmg"] = 307992,
								["g_amt"] = 0,
								["n_max"] = 2454,
								["targets"] = {
									["Ravenous Jormungar"] = 40588,
									["Seething Revenant"] = 11229,
									["Emalon the Storm Watcher"] = 105025,
									["Jotunheim Warrior"] = 16336,
									["Onslaught Gryphon Rider"] = 61111,
									["Stoic Mammoth"] = 2364,
									["Tempest Minion"] = 10848,
									["Roaming Jormungar"] = 37981,
									["Viscous Oil"] = 67850,
									["Restless Frostborn Warrior"] = 25561,
									["Disembodied Jormungar"] = 33428,
									["Stormforged Infiltrator"] = 31093,
									["Mjordin Combatant"] = 68604,
									["Restless Frostborn Ghost"] = 28845,
									["Archavon the Stone Watcher"] = 0,
									["Niffelem Forefather"] = 83720,
									["Brittle Revenant"] = 77540,
								},
								["n_dmg"] = 394131,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 404,
								["total"] = 702123,
								["c_max"] = 4601,
								["id"] = 47813,
								["r_dmg"] = 61802,
								["EVADE"] = 3,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 287,
								["b_dmg"] = 0,
								["r_amt"] = 27,
							},
							[47809] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 42357,
								["g_amt"] = 0,
								["n_max"] = 4823,
								["targets"] = {
									["Tempest Minion"] = 5950,
									["Archavon the Stone Watcher"] = 0,
									["Emalon the Storm Watcher"] = 125523,
									["Niffelem Forefather"] = 3034,
									["Onslaught Gryphon Rider"] = 3382,
								},
								["n_dmg"] = 95532,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 30,
								["total"] = 137889,
								["c_max"] = 9541,
								["id"] = 47809,
								["r_dmg"] = 58032,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 25,
								["b_dmg"] = 0,
								["r_amt"] = 14,
							},
							[47834] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 23730,
								["g_amt"] = 0,
								["n_max"] = 4820,
								["targets"] = {
									["Restless Frostborn Ghost"] = 2924,
									["Mjordin Combatant"] = 24826,
									["Onslaught Gryphon Rider"] = 21114,
									["Viscous Oil"] = 20359,
									["Ravenous Jormungar"] = 20519,
									["Niffelem Forefather"] = 9194,
									["Roaming Jormungar"] = 4102,
								},
								["n_dmg"] = 79308,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 28,
								["total"] = 103038,
								["c_max"] = 6528,
								["id"] = 47834,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 23,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675340749,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [9]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.8445589999999997,
					["on_hold"] = false,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ravenous Jormungar"] = 55035,
						["Seething Revenant"] = 13901,
						["Emalon the Storm Watcher"] = 50365,
						["Jotunheim Warrior"] = 21254,
						["Onslaught Gryphon Rider"] = 55132,
						["Stoic Mammoth"] = 9616,
						["Tempest Minion"] = 3635,
						["Roaming Jormungar"] = 74094,
						["Viscous Oil"] = 65664,
						["Restless Frostborn Warrior"] = 38006,
						["Disembodied Jormungar"] = 57509,
						["Stormforged Infiltrator"] = 48631,
						["Mjordin Combatant"] = 91317,
						["Restless Frostborn Ghost"] = 44822,
						["Archavon the Stone Watcher"] = 0,
						["Niffelem Forefather"] = 80774,
						["Brittle Revenant"] = 85743,
					},
					["pets"] = {
					},
					["serial"] = "Pet-0-4446-571-12108-417-01007B88D5",
					["damage_from"] = {
						["Restless Frostborn Ghost"] = true,
						["Seething Revenant"] = true,
						["Restless Frostborn Warrior"] = true,
						["Disembodied Jormungar"] = true,
						["Onslaught Harbor Guard"] = true,
						["Jotunheim Warrior"] = true,
						["Onslaught Gryphon Rider"] = true,
						["Stormforged Infiltrator"] = true,
						["Brittle Revenant"] = true,
						["Mjordin Combatant"] = true,
						["Viscous Oil"] = true,
						["Ravenous Jormungar"] = true,
						["Stoic Mammoth"] = true,
						["Niffelem Forefather"] = true,
						["Roaming Jormungar"] = true,
					},
					["aID"] = "Pet-0-4446-571-12108-417-01007B88D5",
					["raid_targets"] = {
						[128] = 3635,
					},
					["total_without_pet"] = 795498.8445590006,
					["total"] = 795498.8445590006,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["classe"] = "PET",
					["ownerName"] = "Nedro",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 62,
								["b_amt"] = 35,
								["c_dmg"] = 44779,
								["g_amt"] = 48,
								["n_max"] = 512,
								["targets"] = {
									["Ravenous Jormungar"] = 28368,
									["Seething Revenant"] = 7227,
									["Emalon the Storm Watcher"] = 28497,
									["Jotunheim Warrior"] = 10703,
									["Onslaught Gryphon Rider"] = 28596,
									["Stoic Mammoth"] = 5424,
									["Tempest Minion"] = 2287,
									["Roaming Jormungar"] = 39886,
									["Viscous Oil"] = 33237,
									["Restless Frostborn Warrior"] = 20558,
									["Disembodied Jormungar"] = 29800,
									["Stormforged Infiltrator"] = 25488,
									["Mjordin Combatant"] = 47941,
									["Restless Frostborn Ghost"] = 24484,
									["Archavon the Stone Watcher"] = 0,
									["Niffelem Forefather"] = 44022,
									["Brittle Revenant"] = 46031,
								},
								["n_dmg"] = 362014,
								["n_min"] = 0,
								["g_dmg"] = 15756,
								["counter"] = 1147,
								["total"] = 422549,
								["c_max"] = 998,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1035,
								["b_dmg"] = 9815,
								["r_amt"] = 0,
							}, -- [1]
							[54053] = {
								["c_amt"] = 58,
								["b_amt"] = 0,
								["c_dmg"] = 45339,
								["g_amt"] = 0,
								["n_max"] = 614,
								["targets"] = {
									["Ravenous Jormungar"] = 26667,
									["Seething Revenant"] = 6674,
									["Emalon the Storm Watcher"] = 21868,
									["Jotunheim Warrior"] = 10551,
									["Onslaught Gryphon Rider"] = 26536,
									["Stoic Mammoth"] = 4192,
									["Tempest Minion"] = 1348,
									["Roaming Jormungar"] = 34208,
									["Viscous Oil"] = 32427,
									["Restless Frostborn Warrior"] = 17448,
									["Disembodied Jormungar"] = 27709,
									["Stormforged Infiltrator"] = 23143,
									["Mjordin Combatant"] = 43376,
									["Restless Frostborn Ghost"] = 20338,
									["Archavon the Stone Watcher"] = 0,
									["Niffelem Forefather"] = 36752,
									["Brittle Revenant"] = 39712,
								},
								["n_dmg"] = 327610,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 910,
								["total"] = 372949,
								["c_max"] = 1056,
								["id"] = 54053,
								["r_dmg"] = 12031,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 852,
								["b_dmg"] = 0,
								["r_amt"] = 22,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["nome"] = "Droomon <Nedro>",
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 278275.844559,
					["start_time"] = 1675340892,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [10]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.012675,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Emalon the Storm Watcher"] = 483444,
						["Tempest Minion"] = 144890,
						["Archavon the Stone Watcher"] = 0,
					},
					["tipo"] = 1,
					["pets"] = {
						"Greater Fire Elemental <Yaasi>", -- [1]
						"Spirit Wolf <Yaasi>", -- [2]
					},
					["damage_from"] = {
						["Tempest Minion"] = true,
					},
					["total"] = 628334.0126749999,
					["aID"] = "4477-03B262D2",
					["raid_targets"] = {
						[128] = 78277,
					},
					["total_without_pet"] = 467036.012675,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 51,
								["b_amt"] = 0,
								["c_dmg"] = 76902,
								["g_amt"] = 37,
								["n_max"] = 1120,
								["targets"] = {
									["Emalon the Storm Watcher"] = 104751,
									["Tempest Minion"] = 21198,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 26883,
								["n_min"] = 0,
								["g_dmg"] = 22164,
								["counter"] = 138,
								["total"] = 125949,
								["c_max"] = 2334,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["MISS"] = 12,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 37,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[32175] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 9118,
								["g_amt"] = 0,
								["n_max"] = 1342,
								["targets"] = {
									["Emalon the Storm Watcher"] = 14839,
									["Tempest Minion"] = 3101,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 8822,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 17940,
								["c_max"] = 2620,
								["id"] = 32175,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[10444] = {
								["c_amt"] = 39,
								["b_amt"] = 0,
								["c_dmg"] = 40458,
								["g_amt"] = 0,
								["n_max"] = 549,
								["targets"] = {
									["Emalon the Storm Watcher"] = 73549,
									["Tempest Minion"] = 18642,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 51733,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 155,
								["total"] = 92191,
								["c_max"] = 1130,
								["id"] = 10444,
								["r_dmg"] = 29261,
								["MISS"] = 10,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 106,
								["b_dmg"] = 0,
								["r_amt"] = 53,
							},
							[49238] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 22758,
								["g_amt"] = 0,
								["n_max"] = 3918,
								["targets"] = {
									["Emalon the Storm Watcher"] = 40210,
									["Tempest Minion"] = 10373,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 27825,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 50583,
								["c_max"] = 8118,
								["id"] = 49238,
								["r_dmg"] = 23656,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 6,
							},
							[49231] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 17241,
								["g_amt"] = 0,
								["n_max"] = 2865,
								["targets"] = {
									["Emalon the Storm Watcher"] = 22080,
									["Tempest Minion"] = 7652,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 12491,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 29732,
								["c_max"] = 5970,
								["id"] = 49231,
								["r_dmg"] = 9575,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 3,
							},
							[32176] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 6542,
								["g_amt"] = 0,
								["n_max"] = 726,
								["targets"] = {
									["Emalon the Storm Watcher"] = 9182,
									["Tempest Minion"] = 1763,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 4403,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 10945,
								["c_max"] = 1395,
								["id"] = 32176,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[49233] = {
								["c_amt"] = 11,
								["b_amt"] = 0,
								["c_dmg"] = 12847,
								["g_amt"] = 0,
								["n_max"] = 1378,
								["targets"] = {
									["Emalon the Storm Watcher"] = 26134,
									["Tempest Minion"] = 4264,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 17551,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 39,
								["total"] = 30398,
								["c_max"] = 2733,
								["id"] = 49233,
								["r_dmg"] = 9857,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 28,
								["b_dmg"] = 0,
								["r_amt"] = 15,
							},
							[49271] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 7599,
								["g_amt"] = 0,
								["n_max"] = 1807,
								["targets"] = {
									["Tempest Minion"] = 4894,
									["Emalon the Storm Watcher"] = 7599,
								},
								["n_dmg"] = 4894,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 12493,
								["c_max"] = 7599,
								["id"] = 49271,
								["r_dmg"] = 12493,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 4,
							},
							[61654] = {
								["c_amt"] = 8,
								["b_amt"] = 0,
								["c_dmg"] = 36586,
								["g_amt"] = 0,
								["n_max"] = 2450,
								["targets"] = {
									["Emalon the Storm Watcher"] = 32288,
									["Tempest Minion"] = 33460,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 29162,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 23,
								["total"] = 65748,
								["c_max"] = 5306,
								["id"] = 61654,
								["r_dmg"] = 23318,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 14,
								["b_dmg"] = 0,
								["r_amt"] = 10,
							},
							[60103] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 2475,
								["g_amt"] = 0,
								["n_max"] = 1484,
								["targets"] = {
									["Emalon the Storm Watcher"] = 9013,
									["Tempest Minion"] = 4936,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 11474,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 13949,
								["c_max"] = 2475,
								["id"] = 60103,
								["r_dmg"] = 8328,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["b_dmg"] = 0,
								["r_amt"] = 6,
							},
							[49279] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1598,
								["targets"] = {
									["Emalon the Storm Watcher"] = 8914,
									["Tempest Minion"] = 7419,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 16333,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 16333,
								["c_max"] = 0,
								["id"] = 49279,
								["r_dmg"] = 3947,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 3,
							},
							[54043] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 261,
								["targets"] = {
									["Tempest Minion"] = 775,
								},
								["n_dmg"] = 775,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 775,
								["c_max"] = 0,
								["id"] = 54043,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["last_dps"] = 0,
					["serial"] = "Player-4477-03B262D2",
					["nome"] = "Yaasi",
					["spec"] = 263,
					["grupo"] = true,
					["classe"] = "SHAMAN",
					["friendlyfire"] = {
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 13182.012675,
					["start_time"] = 1675343054,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [11]
				{
					["flag_original"] = 8466,
					["totalabsorbed"] = 0.012885,
					["friendlyfire"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Emalon the Storm Watcher"] = 107165,
						["Tempest Minion"] = 26413,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4447-624-31557-15438-00005BB4D8",
					["damage_from"] = {
						["Tempest Minion"] = true,
					},
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 133578.012885,
					["total"] = 133578.012885,
					["damage_taken"] = 14793.012885,
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["friendlyfire_total"] = 0,
					["ownerName"] = "Yaasi",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 10,
								["n_max"] = 1971,
								["targets"] = {
									["Emalon the Storm Watcher"] = 48767,
								},
								["n_dmg"] = 34251,
								["n_min"] = 0,
								["g_dmg"] = 14516,
								["counter"] = 29,
								["total"] = 48767,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 15954,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 19,
								["b_dmg"] = 0,
								["r_amt"] = 11,
							}, -- [1]
							[13376] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 415,
								["g_amt"] = 0,
								["n_max"] = 154,
								["targets"] = {
									["Emalon the Storm Watcher"] = 4969,
									["Tempest Minion"] = 2425,
								},
								["n_dmg"] = 6979,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 51,
								["total"] = 7394,
								["c_max"] = 231,
								["id"] = 13376,
								["r_dmg"] = 1748,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 49,
								["b_dmg"] = 0,
								["r_amt"] = 13,
							},
							[57984] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 6283,
								["g_amt"] = 0,
								["n_max"] = 1539,
								["targets"] = {
									["Emalon the Storm Watcher"] = 19241,
								},
								["n_dmg"] = 12958,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 19241,
								["c_max"] = 2233,
								["id"] = 57984,
								["r_dmg"] = 5805,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["b_dmg"] = 0,
								["r_amt"] = 4,
							},
							[12470] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 14399,
								["g_amt"] = 0,
								["n_max"] = 2611,
								["targets"] = {
									["Emalon the Storm Watcher"] = 34188,
									["Tempest Minion"] = 23988,
								},
								["n_dmg"] = 43777,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 23,
								["total"] = 58176,
								["c_max"] = 3992,
								["id"] = 12470,
								["r_dmg"] = 26213,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 19,
								["b_dmg"] = 0,
								["r_amt"] = 11,
							},
						},
						["tipo"] = 2,
					},
					["aID"] = "15438",
					["nome"] = "Greater Fire Elemental <Yaasi>",
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675343059,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [12]
				{
					["flag_original"] = 8466,
					["totalabsorbed"] = 0.007401,
					["friendlyfire"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Emalon the Storm Watcher"] = 11638,
						["Tempest Minion"] = 3066,
						["Archavon the Stone Watcher"] = 0,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4447-624-31557-31216-00015BB4D8",
					["damage_from"] = {
					},
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 14704.007401,
					["total"] = 14704.007401,
					["damage_taken"] = 0.007401,
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["friendlyfire_total"] = 0,
					["ownerName"] = "Tårtåros",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[59637] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 2531,
								["g_amt"] = 0,
								["n_max"] = 271,
								["targets"] = {
									["Emalon the Storm Watcher"] = 4301,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 1770,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 4301,
								["c_max"] = 666,
								["id"] = 59637,
								["r_dmg"] = 2576,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 6,
							},
							[59638] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1305,
								["g_amt"] = 0,
								["n_max"] = 463,
								["targets"] = {
									["Emalon the Storm Watcher"] = 7337,
									["Tempest Minion"] = 3066,
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 9098,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 10403,
								["c_max"] = 687,
								["id"] = 59638,
								["r_dmg"] = 4906,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 22,
								["b_dmg"] = 0,
								["r_amt"] = 12,
							},
						},
						["tipo"] = 2,
					},
					["aID"] = "31216",
					["nome"] = "Mirror Image <Tårtåros>",
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675343131,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [13]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.012253,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["tipo"] = 1,
					["pets"] = {
					},
					["damage_from"] = {
						["Emalon the Storm Watcher"] = true,
					},
					["total"] = 0.012253,
					["classe"] = "PRIEST",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.012253,
					["spec"] = 256,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["last_dps"] = 0,
					["serial"] = "Player-4477-044E7D32",
					["nome"] = "Missbläckz",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["aID"] = "4477-044E7D32",
					["friendlyfire"] = {
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 6931.012253,
					["start_time"] = 1675343161,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [14]
				{
					["flag_original"] = 4370,
					["totalabsorbed"] = 0.008895,
					["damage_from"] = {
					},
					["targets"] = {
						["Emalon the Storm Watcher"] = 27720,
					},
					["serial"] = "Creature-0-4447-624-31557-29264-0000DBB4D9",
					["pets"] = {
					},
					["damage_taken"] = 0.008895,
					["classe"] = "PET",
					["aID"] = "29264",
					["raid_targets"] = {
					},
					["total_without_pet"] = 27720.008895,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["total"] = 27720.008895,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 6,
								["b_amt"] = 1,
								["c_dmg"] = 5043,
								["g_amt"] = 13,
								["n_max"] = 482,
								["targets"] = {
									["Emalon the Storm Watcher"] = 27720,
								},
								["n_dmg"] = 18453,
								["n_min"] = 0,
								["g_dmg"] = 4224,
								["counter"] = 62,
								["total"] = 27720,
								["c_max"] = 862,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 43,
								["b_dmg"] = 385,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675343164,
					["on_hold"] = false,
					["nome"] = "Spirit Wolf <Yaasi>",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675343130,
					["delay"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [15]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.010279,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Archavon the Stone Watcher"] = 0,
					},
					["tipo"] = 1,
					["pets"] = {
					},
					["damage_from"] = {
						["Emalon the Storm Watcher"] = true,
					},
					["total"] = 0.010279,
					["aID"] = "4477-03B26A55",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.010279,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675343164,
					["last_dps"] = 0,
					["serial"] = "Player-4477-03B26A55",
					["nome"] = "Hartarbeiter",
					["spec"] = 105,
					["grupo"] = true,
					["classe"] = "DRUID",
					["friendlyfire"] = {
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 13235.010279,
					["start_time"] = 1675343161,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [16]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.001075,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 0,
						["Kreshtak"] = 0,
						["Grizzmo"] = 0,
						["Ranuri"] = 0,
						["Missbläckz"] = 0,
						["Hartarbeiter"] = 0,
						["Tårtåros"] = 0,
						["Tonyhawkings"] = 0,
						["Einsamen"] = 0,
						["Spirit Wolf <Yaasi>"] = 0,
						["Yaasi"] = 0,
						["Nedro"] = 0,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
					},
					["aID"] = "",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001075,
					["damage_taken"] = 0.001075,
					["last_dps"] = 0,
					["dps_started"] = false,
					["total"] = 0.001075,
					["friendlyfire_total"] = 0,
					["classe"] = "UNKNOW",
					["nome"] = "Archavon the Stone Watcher",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Tonyhawkings"] = 0,
									["Einsamen"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
							[58960] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58960,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[58696] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Missbläckz"] = 0,
									["Kreshtak"] = 0,
									["Grizzmo"] = 0,
									["Tonyhawkings"] = 0,
									["Yaasi"] = 0,
									["Ranuri"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58696,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[58663] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Droomon <Nedro>"] = 0,
									["Kreshtak"] = 0,
									["Grizzmo"] = 0,
									["Hartarbeiter"] = 0,
									["Missbläckz"] = 0,
									["Ranuri"] = 0,
									["Einsamen"] = 0,
									["Spirit Wolf <Yaasi>"] = 0,
									["Tårtåros"] = 0,
									["Tonyhawkings"] = 0,
									["Yaasi"] = 0,
									["Nedro"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58663,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[58678] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58678,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[58695] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Missbläckz"] = 0,
									["Kreshtak"] = 0,
									["Grizzmo"] = 0,
									["Tonyhawkings"] = 0,
									["Yaasi"] = 0,
									["Ranuri"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58695,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[58963] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Nedro"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58963,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[58965] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Droomon <Nedro>"] = 0,
									["Kreshtak"] = 0,
									["Spirit Wolf <Yaasi>"] = 0,
									["Grizzmo"] = 0,
									["Yaasi"] = 0,
									["Ranuri"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58965,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[58666] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Tonyhawkings"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58666,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675494156,
					["on_hold"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675494153,
					["serial"] = "Vehicle-0-4447-624-31557-31125-00005BB316",
					["boss_fight_component"] = true,
				}, -- [17]
				{
					["flag_original"] = 8466,
					["totalabsorbed"] = 0.008197,
					["damage_from"] = {
					},
					["targets"] = {
						["Archavon the Stone Watcher"] = 0,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["classe"] = "PET",
					["aID"] = "31167",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008197,
					["on_hold"] = false,
					["dps_started"] = false,
					["end_time"] = 1675494156,
					["last_dps"] = 0,
					["tipo"] = 1,
					["nome"] = "Magma Totem VII <Yaasi>",
					["spells"] = {
						["_ActorTable"] = {
							[58735] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Archavon the Stone Watcher"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58735,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["total"] = 0.008197,
					["boss_fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 0.008197,
					["start_time"] = 1675494153,
					["serial"] = "Creature-0-4447-624-31557-31167-00005BB3E0",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [18]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.110868,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 28166,
						["Irgat"] = 1082,
						["Nedro"] = 1881,
						["Rotándroll"] = 881,
						["Ferallus"] = 210,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Irgat"] = true,
						["Nedro"] = true,
						["Kunkz"] = true,
						["Rotándroll"] = true,
						["Ferallus"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 32220.110868,
					["end_time"] = 1675494520,
					["damage_taken"] = 378593.1108680002,
					["monster"] = true,
					["total"] = 32220.110868,
					["delay"] = 0,
					["aID"] = "30160",
					["nome"] = "Brittle Revenant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 8,
								["b_amt"] = 6,
								["c_dmg"] = 5307,
								["g_amt"] = 0,
								["n_max"] = 464,
								["targets"] = {
									["Droomon <Nedro>"] = 28093,
									["Droomon"] = 0,
									["Nedro"] = 1881,
									["Irgat"] = 1082,
									["Rotándroll"] = 881,
									["Ferallus"] = 210,
								},
								["n_dmg"] = 26840,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 110,
								["total"] = 32147,
								["c_max"] = 984,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 1136,
								["MISS"] = 6,
								["a_amt"] = 0,
								["PARRY"] = 6,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 87,
								["a_dmg"] = 0,
								["DODGE"] = 3,
							}, -- [1]
							[50731] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 37,
								["targets"] = {
									["Droomon <Nedro>"] = 73,
									["Droomon"] = 0,
									["Rotándroll"] = 0,
								},
								["n_dmg"] = 73,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 73,
								["c_max"] = 0,
								["id"] = 50731,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["extra"] = {
								},
								["MISS"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["fight_component"] = true,
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1675494267,
					["serial"] = "Creature-0-4448-571-6723-30160-00005E0414",
					["friendlyfire_total"] = 0,
				}, -- [19]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.053537,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 18186,
						["Wíldlífe"] = 664,
						["Nedro"] = 541,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Wíldlífe"] = true,
						["Nedro"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 19391.053537,
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["monster"] = true,
					["end_time"] = 1675494843,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["nome"] = "Restless Frostborn Ghost",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 2,
								["c_dmg"] = 683,
								["g_amt"] = 0,
								["n_max"] = 445,
								["targets"] = {
									["Droomon <Nedro>"] = 15766,
									["Droomon"] = 0,
									["Wíldlífe"] = 616,
									["Nedro"] = 445,
								},
								["n_dmg"] = 16144,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 64,
								["total"] = 16827,
								["c_max"] = 683,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 331,
								["MISS"] = 3,
								["a_amt"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 55,
								["a_dmg"] = 0,
								["DODGE"] = 3,
							}, -- [1]
							[57456] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 175,
								["targets"] = {
									["Droomon <Nedro>"] = 2420,
									["Wíldlífe"] = 48,
									["Nedro"] = 96,
								},
								["n_dmg"] = 2564,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 44,
								["total"] = 2564,
								["c_max"] = 0,
								["id"] = 57456,
								["r_dmg"] = 2420,
								["r_amt"] = 41,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 44,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["total"] = 19391.053537,
					["damage_taken"] = 155499.053537,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675494675,
					["serial"] = "Creature-0-4448-571-6723-30144-00005DF0C4",
					["aID"] = "30144",
				}, -- [20]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.139161,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 33387,
						["Azzitay"] = 3583,
						["Nedro"] = 23573,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Azzitay"] = true,
						["Nedro"] = true,
						["Searing Totem X"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 60543.13916099999,
					["monster"] = true,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675494843,
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["nome"] = "Niffelem Forefather",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 6,
								["b_amt"] = 5,
								["c_dmg"] = 5421,
								["g_amt"] = 0,
								["n_max"] = 610,
								["targets"] = {
									["Droomon <Nedro>"] = 18870,
									["Azzitay"] = 3583,
									["Droomon"] = 0,
									["Nedro"] = 15198,
								},
								["n_dmg"] = 32230,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 98,
								["total"] = 37651,
								["c_max"] = 1116,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 1117,
								["DODGE"] = 4,
								["a_amt"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 80,
								["MISS"] = 6,
								["a_dmg"] = 0,
							}, -- [1]
							[57454] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1470,
								["targets"] = {
									["Droomon <Nedro>"] = 14517,
									["Azzitay"] = 0,
									["Nedro"] = 8375,
								},
								["n_dmg"] = 22892,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 21,
								["total"] = 22892,
								["c_max"] = 0,
								["id"] = 57454,
								["r_dmg"] = 14517,
								["r_amt"] = 14,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 21,
								["a_amt"] = 0,
								["n_amt"] = 20,
								["extra"] = {
								},
								["MISS"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 60543.13916099999,
					["damage_taken"] = 327091.139161,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675494582,
					["serial"] = "Creature-0-4448-571-6723-29974-00005DF175",
					["aID"] = "29974",
				}, -- [21]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.065956,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 17633,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Wíldlífe"] = true,
						["Nedro"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 17633.065956,
					["damage_taken"] = 128907.065956,
					["friendlyfire"] = {
					},
					["monster"] = true,
					["end_time"] = 1675494894,
					["classe"] = "UNKNOW",
					["total"] = 17633.065956,
					["nome"] = "Restless Frostborn Warrior",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 4,
								["c_dmg"] = 1108,
								["g_amt"] = 0,
								["n_max"] = 353,
								["targets"] = {
									["Droomon <Nedro>"] = 14852,
									["Droomon"] = 0,
								},
								["n_dmg"] = 13744,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 58,
								["total"] = 14852,
								["c_max"] = 604,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 543,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 48,
								["DODGE"] = 3,
								["MISS"] = 2,
							}, -- [1]
							[57456] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 200,
								["targets"] = {
									["Droomon <Nedro>"] = 2781,
								},
								["n_dmg"] = 2781,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 35,
								["total"] = 2781,
								["c_max"] = 0,
								["id"] = 57456,
								["r_dmg"] = 2781,
								["r_amt"] = 35,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 35,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["last_dps"] = 0,
					["last_event"] = 0,
					["fight_component"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675494766,
					["serial"] = "Creature-0-4448-571-6723-30135-00005DF127",
					["aID"] = "30135",
				}, -- [22]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.07526799999999999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 15804,
						["Ethereal Frostworg"] = 553,
						["Nedro"] = 3686,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Ethereal Frostworg"] = true,
						["Nedro"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 20043.075268,
					["monster"] = true,
					["serial"] = "Creature-0-4448-571-6723-30422-00005DA1A5",
					["fight_component"] = true,
					["total"] = 20043.075268,
					["aID"] = "30422",
					["friendlyfire_total"] = 0,
					["nome"] = "Disembodied Jormungar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 2,
								["c_dmg"] = 1296,
								["g_amt"] = 0,
								["n_max"] = 517,
								["targets"] = {
									["Droomon <Nedro>"] = 15804,
									["Ethereal Frostworg"] = 553,
									["Droomon"] = 0,
									["Nedro"] = 3686,
								},
								["n_dmg"] = 18747,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 65,
								["total"] = 20043,
								["c_max"] = 743,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 295,
								["MISS"] = 3,
								["a_amt"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 56,
								["DODGE"] = 3,
								["a_dmg"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675495375,
					["on_hold"] = false,
					["tipo"] = 1,
					["last_dps"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 155078.075268,
					["start_time"] = 1675495225,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [23]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.108036,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 28271,
						["Ethereal Frostworg"] = 3259,
						["Rumo"] = 2064,
						["Nedro"] = 5160,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Ethereal Frostworg"] = true,
						["Turihunt"] = true,
						["Rumo"] = true,
						["Nedro"] = true,
					},
					["aID"] = "30422",
					["raid_targets"] = {
					},
					["total_without_pet"] = 38754.108036,
					["monster"] = true,
					["damage_taken"] = 263126.108036,
					["dps_started"] = false,
					["total"] = 38754.108036,
					["classe"] = "UNKNOW",
					["friendlyfire_total"] = 0,
					["nome"] = "Roaming Jormungar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 5,
								["b_amt"] = 6,
								["c_dmg"] = 3588,
								["g_amt"] = 0,
								["n_max"] = 482,
								["targets"] = {
									["Droomon <Nedro>"] = 28271,
									["Ethereal Frostworg"] = 3259,
									["Droomon"] = 0,
									["Rumo"] = 2064,
									["Nedro"] = 5160,
								},
								["n_dmg"] = 35166,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 131,
								["total"] = 38754,
								["c_max"] = 965,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 1132,
								["DODGE"] = 2,
								["a_amt"] = 0,
								["PARRY"] = 7,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 113,
								["a_dmg"] = 0,
								["MISS"] = 4,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["end_time"] = 1675495394,
					["on_hold"] = false,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1675495096,
					["serial"] = "Creature-0-4448-571-6723-30422-00005DA44C",
					["last_dps"] = 0,
				}, -- [24]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.09219800000000002,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 12313,
						["Ethereal Frostworg"] = 4012,
						["Nedro"] = 1121,
					},
					["pets"] = {
					},
					["monster"] = true,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Ethereal Frostworg"] = true,
						["Nedro"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 17446.092198,
					["friendlyfire"] = {
					},
					["damage_taken"] = 161084.092198,
					["fight_component"] = true,
					["total"] = 17446.092198,
					["delay"] = 0,
					["aID"] = "30222",
					["nome"] = "Stormforged Infiltrator",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 7,
								["c_dmg"] = 1224,
								["g_amt"] = 0,
								["n_max"] = 384,
								["targets"] = {
									["Droomon <Nedro>"] = 12313,
									["Ethereal Frostworg"] = 4012,
									["Droomon"] = 0,
									["Nedro"] = 1121,
								},
								["n_dmg"] = 16222,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 75,
								["total"] = 17446,
								["c_max"] = 635,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 1059,
								["MISS"] = 4,
								["a_amt"] = 0,
								["PARRY"] = 7,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 57,
								["a_dmg"] = 0,
								["DODGE"] = 5,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675495555,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675495394,
					["serial"] = "Creature-0-4448-571-6723-30222-00005E0877",
					["friendlyfire_total"] = 0,
				}, -- [25]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.077545,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Ethereal Frostworg"] = true,
						["Turihunt"] = true,
						["Rumo"] = true,
						["Spr"] = true,
						["Nedro"] = true,
					},
					["targets"] = {
						["Rumo"] = 3761,
						["Spr"] = 10358,
						["Droomon <Nedro>"] = 2818,
						["Turihunt"] = 563,
					},
					["friendlyfire"] = {
					},
					["pets"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["total"] = 17500.077545,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 17500.077545,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675495869,
					["classe"] = "UNKNOW",
					["damage_taken"] = 197479.077545,
					["nome"] = "Stoic Mammoth",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 2,
								["c_dmg"] = 757,
								["g_amt"] = 0,
								["n_max"] = 327,
								["targets"] = {
									["Droomon <Nedro>"] = 2818,
									["Droomon"] = 0,
									["Turihunt"] = 563,
									["Rumo"] = 3761,
									["Spr"] = 10358,
								},
								["n_dmg"] = 16743,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 92,
								["total"] = 17500,
								["c_max"] = 385,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 239,
								["DODGE"] = 5,
								["a_amt"] = 0,
								["PARRY"] = 4,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 72,
								["MISS"] = 9,
								["a_dmg"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["aID"] = "30260",
					["last_dps"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675495761,
					["serial"] = "Creature-0-4448-571-6723-30260-00005DED38",
					["fight_component"] = true,
				}, -- [26]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.07675000000000001,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 22300,
						["Nedro"] = 6445,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Mowzi"] = true,
						["Cîlin"] = true,
						["Nedro"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 28745.07675,
					["damage_taken"] = 215828.07675,
					["tipo"] = 1,
					["dps_started"] = false,
					["total"] = 28745.07675,
					["aID"] = "30291",
					["fight_component"] = true,
					["nome"] = "Ravenous Jormungar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 4,
								["b_amt"] = 7,
								["c_dmg"] = 2468,
								["g_amt"] = 0,
								["n_max"] = 486,
								["targets"] = {
									["Droomon <Nedro>"] = 22300,
									["Droomon"] = 0,
									["Nedro"] = 6445,
								},
								["n_dmg"] = 26277,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 96,
								["total"] = 28745,
								["c_max"] = 701,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 1161,
								["DODGE"] = 5,
								["a_amt"] = 0,
								["PARRY"] = 4,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 80,
								["a_dmg"] = 0,
								["MISS"] = 3,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675495907,
					["friendlyfire"] = {
					},
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1675495695,
					["serial"] = "Creature-0-4448-571-6723-30291-00005DF376",
					["on_hold"] = false,
				}, -- [27]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.090609,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Nedro"] = true,
					},
					["targets"] = {
						["Droomon <Nedro>"] = 18413,
						["Nedro"] = 10275,
					},
					["damage_taken"] = 262600.090609,
					["pets"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["end_time"] = 1675495945,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 28688.090609,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 28688.090609,
					["aID"] = "30325",
					["on_hold"] = false,
					["nome"] = "Viscous Oil",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 3,
								["b_amt"] = 7,
								["c_dmg"] = 2196,
								["g_amt"] = 0,
								["n_max"] = 505,
								["targets"] = {
									["Droomon <Nedro>"] = 18413,
									["Droomon"] = 0,
									["Nedro"] = 10275,
								},
								["n_dmg"] = 26492,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 92,
								["total"] = 28688,
								["c_max"] = 997,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 1152,
								["MISS"] = 5,
								["a_amt"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 79,
								["DODGE"] = 4,
								["a_dmg"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675495751,
					["serial"] = "Creature-0-4448-571-6723-30325-00005DF403",
					["fight_component"] = true,
				}, -- [28]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.031874,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 3585,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Nedro"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 3585.031874,
					["classe"] = "UNKNOW",
					["last_dps"] = 0,
					["fight_component"] = true,
					["end_time"] = 1675594200,
					["delay"] = 0,
					["aID"] = "30387",
					["nome"] = "Seething Revenant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 1,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 358,
								["targets"] = {
									["Droomon <Nedro>"] = 3500,
									["Droomon"] = 0,
								},
								["n_dmg"] = 3500,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 3500,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 216,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 11,
								["MISS"] = 1,
								["a_dmg"] = 0,
							}, -- [1]
							[56620] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 56620,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[56657] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 20,
								["targets"] = {
									["Droomon <Nedro>"] = 85,
								},
								["n_dmg"] = 85,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 85,
								["c_max"] = 0,
								["id"] = 56657,
								["r_dmg"] = 85,
								["r_amt"] = 5,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 3585.031874,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675594164,
					["serial"] = "Creature-0-5563-571-10-30387-00005F8300",
					["damage_taken"] = 51645.03187400001,
				}, -- [29]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.032157,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 6750,
						["Nedro"] = 2157,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Nedro"] = true,
					},
					["aID"] = "29880",
					["raid_targets"] = {
					},
					["total_without_pet"] = 8907.032157,
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["fight_component"] = true,
					["total"] = 8907.032157,
					["serial"] = "Creature-0-5563-571-5-29880-00006214B4",
					["friendlyfire_total"] = 0,
					["nome"] = "Jotunheim Warrior",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 2,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 470,
								["targets"] = {
									["Droomon <Nedro>"] = 6750,
									["Droomon"] = 0,
									["Nedro"] = 1304,
								},
								["n_dmg"] = 8054,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 8054,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["b_dmg"] = 367,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 25,
								["r_amt"] = 0,
								["MISS"] = 1,
							}, -- [1]
							[23262] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 23262,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[43410] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 853,
								["targets"] = {
									["Nedro"] = 853,
								},
								["n_dmg"] = 853,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 853,
								["c_max"] = 0,
								["id"] = 43410,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["monster"] = true,
					["end_time"] = 1675764281,
					["damage_taken"] = 77392.032157,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675764214,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [30]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.06686700000000001,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 51004,
						["Nedro"] = 7262,
						["Mmrrggll"] = 435,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-30037-0000622243",
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Nedro"] = true,
						["Mmrrggll"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 58701.066867,
					["last_dps"] = 0,
					["last_event"] = 0,
					["dps_started"] = false,
					["total"] = 58701.066867,
					["aID"] = "30037",
					["friendlyfire_total"] = 0,
					["nome"] = "Mjordin Combatant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 13,
								["b_amt"] = 5,
								["c_dmg"] = 8867,
								["g_amt"] = 0,
								["n_max"] = 515,
								["targets"] = {
									["Droomon <Nedro>"] = 45419,
									["Nedro"] = 5369,
									["Droomon"] = 0,
									["Mmrrggll"] = 0,
								},
								["n_dmg"] = 41921,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 167,
								["total"] = 50788,
								["c_max"] = 750,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 4,
								["MISS"] = 10,
								["extra"] = {
								},
								["PARRY"] = 9,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 131,
								["b_dmg"] = 826,
								["r_amt"] = 0,
							}, -- [1]
							[49807] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 49807,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 7,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[15578] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 435,
								["targets"] = {
									["Droomon <Nedro>"] = 281,
									["Droomon"] = 0,
									["Mmrrggll"] = 435,
								},
								["n_dmg"] = 716,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 716,
								["c_max"] = 0,
								["id"] = 15578,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 11,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[50370] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Droomon"] = 0,
									["Mmrrggll"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 50370,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 7,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[32736] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 369,
								["targets"] = {
									["Droomon <Nedro>"] = 1012,
									["Droomon"] = 0,
								},
								["n_dmg"] = 1012,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 1012,
								["c_max"] = 0,
								["id"] = 32736,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["extra"] = {
								},
								["MISS"] = 1,
							},
							[61343] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 392,
								["targets"] = {
									["Droomon <Nedro>"] = 1558,
									["Nedro"] = 392,
								},
								["n_dmg"] = 1950,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 1950,
								["c_max"] = 0,
								["id"] = 61343,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 6,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[61344] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 377,
								["targets"] = {
									["Droomon <Nedro>"] = 1592,
								},
								["n_dmg"] = 1592,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 1592,
								["c_max"] = 0,
								["id"] = 61344,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[61227] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 752,
								["targets"] = {
									["Droomon <Nedro>"] = 1142,
									["Nedro"] = 1501,
									["Droomon"] = 0,
									["Mmrrggll"] = 0,
								},
								["n_dmg"] = 2643,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 26,
								["total"] = 2643,
								["c_max"] = 0,
								["id"] = 61227,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["extra"] = {
								},
								["b_dmg"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 24,
								["a_amt"] = 0,
								["n_amt"] = 23,
								["r_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675764350,
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675764077,
					["delay"] = 0,
					["damage_taken"] = 339457.066867,
				}, -- [31]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.2978110000000001,
					["damage_from"] = {
					},
					["targets"] = {
						["Jotunheim Proto-Drake"] = 4520880,
					},
					["serial"] = "Vehicle-0-5563-571-5-30337-00006214BE",
					["pets"] = {
					},
					["aID"] = "",
					["friendlyfire"] = {
					},
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 4520880.297811,
					["total"] = 4520880.297811,
					["dps_started"] = false,
					["end_time"] = 1675764624,
					["on_hold"] = false,
					["ownerName"] = "Nedro",
					["nome"] = "Jotunheim Rapid-Fire Harpoon <Nedro>",
					["spells"] = {
						["_ActorTable"] = {
							[56578] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 32760,
								["targets"] = {
									["Jotunheim Proto-Drake"] = 4520880,
								},
								["n_dmg"] = 4520880,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 138,
								["total"] = 4520880,
								["c_max"] = 0,
								["id"] = 56578,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 138,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.2978110000000001,
					["start_time"] = 1675764563,
					["delay"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [32]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.2844789999999999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["damage_from"] = {
						["Jotunheim Rapid-Fire Harpoon <Nedro>"] = true,
					},
					["aID"] = "",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.2844789999999999,
					["classe"] = "UNKNOW",
					["tipo"] = 1,
					["monster"] = true,
					["end_time"] = 1675764624,
					["serial"] = "Vehicle-0-5563-571-5-30330-00006221A7",
					["friendlyfire_total"] = 0,
					["nome"] = "Jotunheim Proto-Drake",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["total"] = 0.2844789999999999,
					["damage_taken"] = 4520880.284479,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675764621,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [33]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.06448499999999999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 22605,
						["Unknown <Nedro>"] = 298,
						["Corrupted Scarlet Onslaught"] = 89,
						["Nedro"] = 34419,
						["Roghaye"] = 676,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-29333-00006223F1",
					["damage_from"] = {
						["Droomon <Nedro>"] = true,
						["Unknown <Nedro>"] = true,
						["Corrupted Scarlet Onslaught"] = true,
						["Nedro"] = true,
						["Roghaye"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 58087.064485,
					["last_dps"] = 0,
					["last_event"] = 0,
					["dps_started"] = false,
					["total"] = 58087.064485,
					["aID"] = "29333",
					["friendlyfire_total"] = 0,
					["nome"] = "Onslaught Gryphon Rider",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 5,
								["b_amt"] = 2,
								["c_dmg"] = 3860,
								["g_amt"] = 0,
								["n_max"] = 499,
								["targets"] = {
									["Droomon <Nedro>"] = 14809,
									["Unknown <Nedro>"] = 298,
									["Droomon"] = 0,
									["Nedro"] = 22296,
									["Roghaye"] = 676,
								},
								["n_dmg"] = 34219,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 113,
								["total"] = 38079,
								["c_max"] = 1013,
								["DODGE"] = 4,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["MISS"] = 5,
								["extra"] = {
								},
								["PARRY"] = 4,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 95,
								["b_dmg"] = 302,
								["r_amt"] = 0,
							}, -- [1]
							[40652] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 94,
								["targets"] = {
									["Droomon <Nedro>"] = 123,
									["Corrupted Scarlet Onslaught"] = 89,
									["Nedro"] = 919,
									["Roghaye"] = 0,
								},
								["n_dmg"] = 1131,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 1131,
								["c_max"] = 0,
								["id"] = 40652,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["r_amt"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 16,
								["a_amt"] = 0,
								["n_amt"] = 14,
								["MISS"] = 1,
								["b_dmg"] = 0,
							},
							[54617] = {
								["c_amt"] = 0,
								["b_amt"] = 2,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1223,
								["targets"] = {
									["Droomon <Nedro>"] = 7673,
									["Nedro"] = 11204,
								},
								["n_dmg"] = 18877,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 21,
								["total"] = 18877,
								["c_max"] = 0,
								["id"] = 54617,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 23,
								["a_amt"] = 0,
								["n_amt"] = 21,
								["b_dmg"] = 1456,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675764968,
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675764736,
					["delay"] = 0,
					["damage_taken"] = 280561.064485,
				}, -- [34]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.027818,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 443,
						["Corrupted Scarlet Onslaught"] = 12425,
						["Nedro"] = 1070,
						["Roghaye"] = 2674,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["damage_from"] = {
						["Corrupted Scarlet Onslaught"] = true,
						["Roghaye"] = true,
					},
					["aID"] = "29330",
					["raid_targets"] = {
					},
					["total_without_pet"] = 16612.027818,
					["damage_taken"] = 8186.027818000001,
					["last_event"] = 0,
					["dps_started"] = false,
					["total"] = 16612.027818,
					["serial"] = "Creature-0-5563-571-5-29330-0000622416",
					["friendlyfire_total"] = 0,
					["nome"] = "Onslaught Harbor Guard",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 1,
								["c_dmg"] = 812,
								["g_amt"] = 0,
								["n_max"] = 504,
								["targets"] = {
									["Corrupted Scarlet Onslaught"] = 12425,
									["Roghaye"] = 1171,
								},
								["n_dmg"] = 12784,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 49,
								["extra"] = {
								},
								["total"] = 13596,
								["c_max"] = 812,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 6,
								["a_amt"] = 0,
								["c_min"] = 0,
								["PARRY"] = 3,
								["BLOCK"] = 2,
								["successful_casted"] = 0,
								["r_amt"] = 0,
								["n_amt"] = 35,
								["DODGE"] = 2,
								["b_dmg"] = 384,
							}, -- [1]
							[6660] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 574,
								["targets"] = {
									["Droomon <Nedro>"] = 443,
									["Nedro"] = 1070,
									["Roghaye"] = 1126,
								},
								["n_dmg"] = 2639,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 2639,
								["c_max"] = 0,
								["id"] = 6660,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["BLOCK"] = 3,
								["successful_casted"] = 11,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[18802] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 377,
								["targets"] = {
									["Roghaye"] = 377,
								},
								["n_dmg"] = 377,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 377,
								["c_max"] = 0,
								["id"] = 18802,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["end_time"] = 1675765044,
					["monster"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675764965,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [35]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.015112,
					["damage_from"] = {
						["Onslaught Gryphon Rider"] = true,
					},
					["targets"] = {
						["Onslaught Gryphon Rider"] = 10528,
					},
					["on_hold"] = false,
					["pets"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 10528.015112,
					["serial"] = "Pet-0-5563-571-5-417-0A007B88D5",
					["dps_started"] = false,
					["end_time"] = 1675765080,
					["aID"] = "Pet-0-5563-571-5-417-0A007B88D5",
					["ownerName"] = "Nedro",
					["nome"] = "Unknown <Nedro>",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1257,
								["g_amt"] = 1,
								["n_max"] = 370,
								["targets"] = {
									["Onslaught Gryphon Rider"] = 5627,
								},
								["n_dmg"] = 4074,
								["n_min"] = 0,
								["g_dmg"] = 296,
								["counter"] = 15,
								["total"] = 5627,
								["c_max"] = 645,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[54053] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 548,
								["g_amt"] = 0,
								["n_max"] = 461,
								["targets"] = {
									["Onslaught Gryphon Rider"] = 4901,
								},
								["n_dmg"] = 4353,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 4901,
								["c_max"] = 548,
								["id"] = 54053,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["total"] = 10528.015112,
					["damage_taken"] = 3701.015112,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675765049,
					["delay"] = 0,
					["classe"] = "PET",
				}, -- [36]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1300,
					["targets_overheal"] = {
						["Einsamen"] = 0,
						["Grizzmo"] = 0,
						["Ranuri"] = 0,
						["Missbläckz"] = 0,
						["Hartarbeiter"] = 0,
						["Kreshtak"] = 0,
						["Tårtåros"] = 0,
						["Tonyhawkings"] = 0,
						["Yaasi"] = 0,
						["Nedro"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "PRIEST",
					["totalover"] = 94401.00554999999,
					["total_without_pet"] = 253785.00555,
					["total"] = 253785.00555,
					["targets_absorbs"] = {
						["Kreshtak"] = 0,
						["Grizzmo"] = 0,
						["Hartarbeiter"] = 0,
						["Tårtåros"] = 0,
						["Ranuri"] = 0,
						["Missbläckz"] = 0,
						["Einsamen"] = 0,
						["Tonyhawkings"] = 0,
						["Yaasi"] = 0,
						["Nedro"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-044E7D32",
					["totalabsorb"] = 105617.00555,
					["last_hps"] = 0,
					["targets"] = {
						["Einsamen"] = 0,
						["Grizzmo"] = 0,
						["Ranuri"] = 0,
						["Missbläckz"] = 0,
						["Hartarbeiter"] = 0,
						["Kreshtak"] = 0,
						["Tårtåros"] = 0,
						["Tonyhawkings"] = 0,
						["Yaasi"] = 0,
						["Nedro"] = 0,
					},
					["totalover_without_pet"] = 0.00555,
					["healing_taken"] = 6931.00555,
					["start_time"] = 1675343053,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-044E7D32",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[56160] = {
								["c_amt"] = 8,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Einsamen"] = 1932,
									["Grizzmo"] = 3455,
									["Ranuri"] = 158,
									["Missbläckz"] = 445,
									["Hartarbeiter"] = 2073,
									["Kreshtak"] = 1382,
									["Tårtåros"] = 2764,
									["Tonyhawkings"] = 1696,
									["Yaasi"] = 1382,
									["Nedro"] = 2088,
								},
								["n_max"] = 1865,
								["targets"] = {
									["Kreshtak"] = 1288,
									["Grizzmo"] = 1288,
									["Ranuri"] = 3705,
									["Missbläckz"] = 2225,
									["Hartarbeiter"] = 1932,
									["Einsamen"] = 3153,
									["Tårtåros"] = 1287,
									["Tonyhawkings"] = 5480,
									["Yaasi"] = 1932,
									["Nedro"] = 1963,
								},
								["n_min"] = 0,
								["counter"] = 27,
								["overheal"] = 17375,
								["total"] = 24253,
								["c_max"] = 1932,
								["id"] = 56160,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 7804,
								["n_curado"] = 16449,
								["totaldenied"] = 0,
								["n_amt"] = 19,
								["absorbed"] = 0,
							},
							[48063] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Tonyhawkings"] = 6059,
								},
								["n_max"] = 2578,
								["targets"] = {
									["Tonyhawkings"] = 2578,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 6059,
								["total"] = 2578,
								["c_max"] = 0,
								["id"] = 48063,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 2578,
								["totaldenied"] = 0,
								["n_amt"] = 1,
								["absorbed"] = 0,
							},
							[47753] = {
								["c_amt"] = 0,
								["totalabsorb"] = 23270,
								["targets_overheal"] = {
								},
								["n_max"] = 3661,
								["targets"] = {
									["Tårtåros"] = 0,
									["Kreshtak"] = 1479,
									["Einsamen"] = 18139,
									["Tonyhawkings"] = 2494,
									["Yaasi"] = 579,
									["Ranuri"] = 579,
								},
								["n_min"] = 0,
								["counter"] = 15,
								["overheal"] = 0,
								["total"] = 23270,
								["c_max"] = 0,
								["id"] = 47753,
								["targets_absorbs"] = {
									["Tårtåros"] = 0,
									["Kreshtak"] = 1479,
									["Einsamen"] = 18139,
									["Tonyhawkings"] = 2494,
									["Yaasi"] = 579,
									["Ranuri"] = 579,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 23270,
								["totaldenied"] = 0,
								["n_amt"] = 15,
								["absorbed"] = 0,
							},
							[33110] = {
								["c_amt"] = 2,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Kreshtak"] = 701,
									["Einsamen"] = 65,
									["Tonyhawkings"] = 3479,
								},
								["n_max"] = 3541,
								["targets"] = {
									["Einsamen"] = 21337,
									["Tonyhawkings"] = 151,
									["Kreshtak"] = 2645,
									["Ranuri"] = 3248,
								},
								["n_min"] = 0,
								["counter"] = 8,
								["overheal"] = 4245,
								["total"] = 27381,
								["c_max"] = 5697,
								["id"] = 33110,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 11008,
								["n_curado"] = 16373,
								["totaldenied"] = 0,
								["n_amt"] = 6,
								["absorbed"] = 0,
							},
							[52985] = {
								["c_amt"] = 8,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Einsamen"] = 48660,
									["Kreshtak"] = 3332,
									["Tonyhawkings"] = 0,
									["Ranuri"] = 0,
								},
								["n_max"] = 4447,
								["targets"] = {
									["Einsamen"] = 53206,
									["Kreshtak"] = 8073,
									["Tonyhawkings"] = 0,
									["Ranuri"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 29,
								["overheal"] = 51992,
								["total"] = 61279,
								["c_max"] = 5170,
								["id"] = 52985,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 26106,
								["n_curado"] = 35173,
								["totaldenied"] = 0,
								["n_amt"] = 21,
								["absorbed"] = 0,
							},
							[48066] = {
								["c_amt"] = 0,
								["totalabsorb"] = 82347,
								["targets_overheal"] = {
								},
								["n_max"] = 6547,
								["targets"] = {
									["Kreshtak"] = 6547,
									["Grizzmo"] = 6101,
									["Hartarbeiter"] = 6240,
									["Tårtåros"] = 4790,
									["Ranuri"] = 6101,
									["Missbläckz"] = 0,
									["Einsamen"] = 18749,
									["Tonyhawkings"] = 30951,
									["Yaasi"] = 2868,
									["Nedro"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 25,
								["overheal"] = 0,
								["total"] = 82347,
								["c_max"] = 0,
								["id"] = 48066,
								["targets_absorbs"] = {
									["Kreshtak"] = 6547,
									["Grizzmo"] = 6101,
									["Hartarbeiter"] = 6240,
									["Tårtåros"] = 4790,
									["Ranuri"] = 6101,
									["Missbläckz"] = 0,
									["Einsamen"] = 18749,
									["Tonyhawkings"] = 30951,
									["Yaasi"] = 2868,
									["Nedro"] = 0,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 82347,
								["totaldenied"] = 0,
								["n_amt"] = 25,
								["absorbed"] = 0,
							},
							[48071] = {
								["c_amt"] = 4,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Tonyhawkings"] = 6962,
									["Einsamen"] = 7069,
									["Ranuri"] = 699,
								},
								["n_max"] = 4334,
								["targets"] = {
									["Tonyhawkings"] = 16707,
									["Kreshtak"] = 4216,
									["Einsamen"] = 6115,
									["Ranuri"] = 5639,
								},
								["n_min"] = 0,
								["counter"] = 9,
								["overheal"] = 14730,
								["total"] = 32677,
								["c_max"] = 6385,
								["id"] = 48071,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 18139,
								["n_curado"] = 14538,
								["totaldenied"] = 0,
								["n_amt"] = 5,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Missbläckz",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 256,
					["totaldenied"] = 0.00555,
					["delay"] = 0,
					["healing_from"] = {
						["Missbläckz"] = true,
						["Hartarbeiter"] = true,
					},
				}, -- [1]
				{
					["flag_original"] = 263444,
					["targets_overheal"] = {
						["Einsamen"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "DEATHKNIGHT",
					["totalover"] = 8409.010046999998,
					["total_without_pet"] = 38631.010047,
					["total"] = 38631.010047,
					["targets_absorbs"] = {
						["Einsamen"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["isTank"] = true,
					["serial"] = "Player-4477-04991245",
					["totalabsorb"] = 30458.010047,
					["last_hps"] = 0,
					["targets"] = {
						["Einsamen"] = 0,
					},
					["totalover_without_pet"] = 0.010047,
					["healing_taken"] = 247605.010047,
					["start_time"] = 1675343141,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-04991245",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[60218] = {
								["c_amt"] = 0,
								["totalabsorb"] = 140,
								["targets_overheal"] = {
								},
								["n_max"] = 140,
								["targets"] = {
									["Einsamen"] = 140,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 0,
								["total"] = 140,
								["c_max"] = 0,
								["id"] = 60218,
								["targets_absorbs"] = {
									["Einsamen"] = 140,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 140,
								["totaldenied"] = 0,
								["n_amt"] = 1,
								["absorbed"] = 0,
							},
							[45470] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Einsamen"] = 8409,
								},
								["n_max"] = 5432,
								["targets"] = {
									["Einsamen"] = 8173,
								},
								["n_min"] = 0,
								["counter"] = 3,
								["overheal"] = 8409,
								["total"] = 8173,
								["c_max"] = 0,
								["id"] = 45470,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 8173,
								["totaldenied"] = 0,
								["n_amt"] = 3,
								["absorbed"] = 0,
							},
							[49497] = {
								["c_amt"] = 0,
								["totalabsorb"] = 1925,
								["targets_overheal"] = {
								},
								["n_max"] = 1925,
								["targets"] = {
									["Einsamen"] = 1925,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 0,
								["total"] = 1925,
								["c_max"] = 0,
								["id"] = 49497,
								["targets_absorbs"] = {
									["Einsamen"] = 1925,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 1925,
								["totaldenied"] = 0,
								["n_amt"] = 1,
								["absorbed"] = 0,
							},
							[48707] = {
								["c_amt"] = 0,
								["totalabsorb"] = 28393,
								["targets_overheal"] = {
								},
								["n_max"] = 15141,
								["targets"] = {
									["Einsamen"] = 28393,
								},
								["n_min"] = 0,
								["counter"] = 2,
								["overheal"] = 0,
								["total"] = 28393,
								["c_max"] = 0,
								["id"] = 48707,
								["targets_absorbs"] = {
									["Einsamen"] = 28393,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 28393,
								["totaldenied"] = 0,
								["n_amt"] = 2,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Einsamen",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 250,
					["totaldenied"] = 0.010047,
					["delay"] = 0,
					["healing_from"] = {
						["Missbläckz"] = true,
						["Einsamen"] = true,
						["Hartarbeiter"] = true,
						["Ranuri"] = true,
					},
				}, -- [2]
				{
					["flag_original"] = 1297,
					["targets_overheal"] = {
						["Droomon <Nedro>"] = 4837,
						["Nedro"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
						"Droomon <Nedro>", -- [1]
					},
					["iniciar_hps"] = false,
					["classe"] = "WARLOCK",
					["totalover"] = 277577.8823290001,
					["total_without_pet"] = 267552.8823290001,
					["total"] = 267552.8823290001,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-04D9C328",
					["totalabsorb"] = 0.8823289999999998,
					["last_hps"] = 0,
					["targets"] = {
						["Droomon <Nedro>"] = 3489,
						["Nedro"] = 0,
					},
					["totalover_without_pet"] = 0.8823289999999998,
					["healing_taken"] = 386489.882329,
					["start_time"] = 1675340990,
					["fight_component"] = true,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-04D9C328",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[47893] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 100358,
								},
								["n_max"] = 412,
								["targets"] = {
									["Nedro"] = 66587,
								},
								["n_min"] = 0,
								["counter"] = 526,
								["overheal"] = 100358,
								["total"] = 66587,
								["c_max"] = 0,
								["id"] = 47893,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 66587,
								["totaldenied"] = 0,
								["n_amt"] = 526,
								["absorbed"] = 0,
							},
							[47860] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 9349,
								},
								["n_max"] = 1687,
								["targets"] = {
									["Nedro"] = 3416,
								},
								["n_min"] = 0,
								["counter"] = 4,
								["overheal"] = 9349,
								["total"] = 3416,
								["c_max"] = 0,
								["id"] = 47860,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 4,
								["n_curado"] = 3416,
								["absorbed"] = 0,
							},
							[47857] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 10245,
								},
								["n_max"] = 1101,
								["targets"] = {
									["Nedro"] = 72595,
								},
								["n_min"] = 0,
								["counter"] = 111,
								["overheal"] = 10245,
								["total"] = 72595,
								["c_max"] = 0,
								["id"] = 47857,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 111,
								["n_curado"] = 72595,
								["absorbed"] = 0,
							},
							[47856] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Droomon <Nedro>"] = 7875,
								},
								["n_max"] = 1535,
								["targets"] = {
									["Droomon <Nedro>"] = 24893,
								},
								["n_min"] = 0,
								["counter"] = 23,
								["overheal"] = 7875,
								["total"] = 24893,
								["c_max"] = 0,
								["id"] = 47856,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 23,
								["n_curado"] = 24893,
								["absorbed"] = 0,
							},
							[63106] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 149750,
								},
								["n_max"] = 1418,
								["targets"] = {
									["Nedro"] = 100061,
								},
								["n_min"] = 0,
								["counter"] = 401,
								["overheal"] = 149750,
								["total"] = 100061,
								["c_max"] = 0,
								["id"] = 63106,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 100061,
								["totaldenied"] = 0,
								["n_amt"] = 401,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Nedro",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 265,
					["totaldenied"] = 0.8823289999999998,
					["delay"] = 0,
					["healing_from"] = {
						["Ravenous Jormungar"] = true,
						["Seething Revenant"] = true,
						["Emalon the Storm Watcher"] = true,
						["Jotunheim Warrior"] = true,
						["Onslaught Gryphon Rider"] = true,
						["Missbläckz"] = true,
						["Brittle Revenant"] = true,
						["Yaasi"] = true,
						["Roaming Jormungar"] = true,
						["Viscous Oil"] = true,
						["Restless Frostborn Warrior"] = true,
						["Disembodied Jormungar"] = true,
						["Stormforged Infiltrator"] = true,
						["Mjordin Combatant"] = true,
						["Stoic Mammoth"] = true,
						["Restless Frostborn Ghost"] = true,
						["Niffelem Forefather"] = true,
						["Nedro"] = true,
					},
				}, -- [3]
				{
					["flag_original"] = 263444,
					["targets_overheal"] = {
						["Droomon <Nedro>"] = 0,
						["Kreshtak"] = 0,
						["Grizzmo"] = 0,
						["Ranuri"] = 0,
						["Tårtåros"] = 0,
						["Einsamen"] = 0,
						["Mirror Image <Tårtåros>"] = 0,
						["Hartarbeiter"] = 0,
						["Tonyhawkings"] = 0,
						["Yaasi"] = 0,
						["Nedro"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "PALADIN",
					["totalover"] = 39905.01553400001,
					["total_without_pet"] = 17908.015534,
					["total"] = 17908.015534,
					["targets_absorbs"] = {
						["Tonyhawkings"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["isTank"] = true,
					["serial"] = "Player-4477-04BC0BBF",
					["totalabsorb"] = 840.015534,
					["last_hps"] = 0,
					["targets"] = {
						["Droomon <Nedro>"] = 0,
						["Kreshtak"] = 0,
						["Einsamen"] = 0,
						["Grizzmo"] = 0,
						["Yaasi"] = 0,
						["Tonyhawkings"] = 0,
					},
					["totalover_without_pet"] = 0.015534,
					["healing_taken"] = 205579.015534,
					["start_time"] = 1675343058,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-04BC0BBF",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[20267] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Droomon <Nedro>"] = 1121,
									["Kreshtak"] = 0,
									["Grizzmo"] = 2913,
									["Ranuri"] = 2578,
									["Tårtåros"] = 4593,
									["Einsamen"] = 0,
									["Mirror Image <Tårtåros>"] = 0,
									["Hartarbeiter"] = 0,
									["Tonyhawkings"] = 18198,
									["Yaasi"] = 9265,
									["Nedro"] = 1237,
								},
								["n_max"] = 952,
								["targets"] = {
									["Droomon <Nedro>"] = 0,
									["Kreshtak"] = 0,
									["Grizzmo"] = 0,
									["Ranuri"] = 0,
									["Tårtåros"] = 0,
									["Einsamen"] = 0,
									["Mirror Image <Tårtåros>"] = 0,
									["Hartarbeiter"] = 0,
									["Tonyhawkings"] = 17068,
									["Yaasi"] = 0,
									["Nedro"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 93,
								["overheal"] = 39905,
								["total"] = 17068,
								["c_max"] = 0,
								["id"] = 20267,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 17068,
								["totaldenied"] = 0,
								["n_amt"] = 93,
								["absorbed"] = 0,
							},
							[60218] = {
								["c_amt"] = 0,
								["totalabsorb"] = 840,
								["targets_overheal"] = {
								},
								["n_max"] = 140,
								["targets"] = {
									["Tonyhawkings"] = 840,
								},
								["n_min"] = 0,
								["counter"] = 6,
								["overheal"] = 0,
								["total"] = 840,
								["c_max"] = 0,
								["id"] = 60218,
								["targets_absorbs"] = {
									["Tonyhawkings"] = 840,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 840,
								["totaldenied"] = 0,
								["n_amt"] = 6,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Tonyhawkings",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 66,
					["totaldenied"] = 0.015534,
					["delay"] = 0,
					["healing_from"] = {
						["Missbläckz"] = true,
						["Tonyhawkings"] = true,
						["Hartarbeiter"] = true,
						["Ranuri"] = true,
					},
				}, -- [4]
				{
					["flag_original"] = 1300,
					["targets_overheal"] = {
						["Missbläckz"] = 0,
						["Kreshtak"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "PALADIN",
					["totalover"] = 0.010632,
					["total_without_pet"] = 15955.010632,
					["total"] = 15955.010632,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-04546F6D",
					["totalabsorb"] = 0.010632,
					["last_hps"] = 0,
					["targets"] = {
						["Missbläckz"] = 0,
						["Kreshtak"] = 0,
						["Tonyhawkings"] = 0,
						["Grizzmo"] = 0,
						["Einsamen"] = 0,
						["Ranuri"] = 0,
					},
					["totalover_without_pet"] = 0.010632,
					["healing_taken"] = 35402.010632,
					["start_time"] = 1675343155,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-04546F6D",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[54172] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Missbläckz"] = 0,
									["Kreshtak"] = 0,
								},
								["n_max"] = 3432,
								["targets"] = {
									["Missbläckz"] = 0,
									["Kreshtak"] = 5678,
									["Tonyhawkings"] = 613,
									["Grizzmo"] = 0,
									["Einsamen"] = 7249,
									["Ranuri"] = 2415,
								},
								["n_min"] = 0,
								["counter"] = 9,
								["overheal"] = 0,
								["total"] = 15955,
								["c_max"] = 0,
								["id"] = 54172,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 15955,
								["totaldenied"] = 0,
								["n_amt"] = 9,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Ranuri",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 70,
					["totaldenied"] = 0.010632,
					["delay"] = 0,
					["healing_from"] = {
						["Missbläckz"] = true,
						["Ranuri"] = true,
						["Hartarbeiter"] = true,
					},
				}, -- [5]
				{
					["flag_original"] = 1300,
					["targets_overheal"] = {
						["Droomon <Nedro>"] = 0,
						["Einsamen"] = 0,
						["Grizzmo"] = 0,
						["Nedro"] = 0,
						["Hartarbeiter"] = 0,
						["Missbläckz"] = 0,
						["Tårtåros"] = 0,
						["Tonyhawkings"] = 0,
						["Ranuri"] = 0,
						["Kreshtak"] = 0,
						["Spirit Wolf <Yaasi>"] = 0,
						["Yaasi"] = 0,
						["Greater Fire Elemental <Yaasi>"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "DRUID",
					["totalover"] = 413399.006554,
					["total_without_pet"] = 275442.006554,
					["total"] = 275442.006554,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-03B26A55",
					["totalabsorb"] = 0.006554,
					["last_hps"] = 0,
					["targets"] = {
						["Droomon <Nedro>"] = 0,
						["Kreshtak"] = 0,
						["Grizzmo"] = 0,
						["Ranuri"] = 0,
						["Missbläckz"] = 0,
						["Hartarbeiter"] = 0,
						["Tårtåros"] = 0,
						["Tonyhawkings"] = 0,
						["Yaasi"] = 0,
						["Einsamen"] = 0,
					},
					["totalover_without_pet"] = 0.006554,
					["healing_taken"] = 13235.006554,
					["start_time"] = 1675343057,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-03B26A55",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[48441] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Kreshtak"] = 22266,
									["Grizzmo"] = 10548,
									["Ranuri"] = 15297,
									["Missbläckz"] = 29667,
									["Hartarbeiter"] = 28532,
									["Einsamen"] = 26645,
									["Tårtåros"] = 15705,
									["Tonyhawkings"] = 26967,
									["Yaasi"] = 5334,
									["Nedro"] = 11856,
								},
								["n_max"] = 2668,
								["targets"] = {
									["Kreshtak"] = 5401,
									["Grizzmo"] = 9213,
									["Ranuri"] = 8419,
									["Missbläckz"] = 3929,
									["Hartarbeiter"] = 5063,
									["Einsamen"] = 29576,
									["Tårtåros"] = 2080,
									["Tonyhawkings"] = 32316,
									["Yaasi"] = 6523,
									["Nedro"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 147,
								["overheal"] = 192817,
								["total"] = 102520,
								["c_max"] = 0,
								["id"] = 48441,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 102520,
								["totaldenied"] = 0,
								["n_amt"] = 147,
								["absorbed"] = 0,
							},
							[48443] = {
								["c_amt"] = 3,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Einsamen"] = 27169,
									["Tonyhawkings"] = 15709,
								},
								["n_max"] = 4825,
								["targets"] = {
									["Tonyhawkings"] = 44622,
									["Einsamen"] = 33806,
								},
								["n_min"] = 0,
								["counter"] = 69,
								["overheal"] = 42878,
								["total"] = 78428,
								["c_max"] = 7212,
								["id"] = 48443,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 21311,
								["n_curado"] = 57117,
								["totaldenied"] = 0,
								["n_amt"] = 66,
								["absorbed"] = 0,
							},
							[50464] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Tonyhawkings"] = 29913,
									["Einsamen"] = 29851,
									["Kreshtak"] = 4484,
								},
								["n_max"] = 6085,
								["targets"] = {
									["Tonyhawkings"] = 11762,
									["Einsamen"] = 1820,
									["Kreshtak"] = 7491,
								},
								["n_min"] = 0,
								["counter"] = 14,
								["overheal"] = 64248,
								["total"] = 21073,
								["c_max"] = 0,
								["id"] = 50464,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 21073,
								["totaldenied"] = 0,
								["n_amt"] = 14,
								["absorbed"] = 0,
							},
							[48503] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Tonyhawkings"] = 5850,
								},
								["n_max"] = 2972,
								["targets"] = {
									["Tonyhawkings"] = 4728,
									["Einsamen"] = 2972,
								},
								["n_min"] = 0,
								["counter"] = 4,
								["overheal"] = 5850,
								["total"] = 7700,
								["c_max"] = 0,
								["id"] = 48503,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 7700,
								["totaldenied"] = 0,
								["n_amt"] = 4,
								["absorbed"] = 0,
							},
							[18562] = {
								["c_amt"] = 2,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Tonyhawkings"] = 4201,
									["Einsamen"] = 2,
								},
								["n_max"] = 8695,
								["targets"] = {
									["Tonyhawkings"] = 30579,
									["Einsamen"] = 8693,
									["Kreshtak"] = 8695,
								},
								["n_min"] = 0,
								["counter"] = 5,
								["overheal"] = 4203,
								["total"] = 47967,
								["c_max"] = 11780,
								["id"] = 18562,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 21884,
								["n_curado"] = 26083,
								["totaldenied"] = 0,
								["n_amt"] = 3,
								["absorbed"] = 0,
							},
							[60526] = {
								["c_amt"] = 1,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Ranuri"] = 2068,
								},
								["n_max"] = 0,
								["targets"] = {
									["Ranuri"] = 2413,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 2068,
								["total"] = 2413,
								["c_max"] = 2413,
								["id"] = 60526,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 2413,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 0,
								["absorbed"] = 0,
							},
							[53251] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Droomon <Nedro>"] = 13960,
									["Einsamen"] = 5147,
									["Grizzmo"] = 3591,
									["Nedro"] = 13966,
									["Ranuri"] = 1770,
									["Missbläckz"] = 13183,
									["Hartarbeiter"] = 6872,
									["Tonyhawkings"] = 6834,
									["Tårtåros"] = 6872,
									["Kreshtak"] = 6396,
									["Spirit Wolf <Yaasi>"] = 9308,
									["Yaasi"] = 4655,
									["Greater Fire Elemental <Yaasi>"] = 8781,
								},
								["n_max"] = 777,
								["targets"] = {
									["Droomon <Nedro>"] = 0,
									["Einsamen"] = 4159,
									["Grizzmo"] = 1063,
									["Nedro"] = 0,
									["Ranuri"] = 2883,
									["Missbläckz"] = 777,
									["Hartarbeiter"] = 0,
									["Tonyhawkings"] = 4690,
									["Tårtåros"] = 0,
									["Kreshtak"] = 1769,
									["Spirit Wolf <Yaasi>"] = 0,
									["Yaasi"] = 0,
									["Greater Fire Elemental <Yaasi>"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 175,
								["overheal"] = 101335,
								["total"] = 15341,
								["c_max"] = 0,
								["id"] = 53251,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 15341,
								["totaldenied"] = 0,
								["n_amt"] = 175,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Hartarbeiter",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 105,
					["totaldenied"] = 0.006554,
					["delay"] = 0,
					["healing_from"] = {
						["Missbläckz"] = true,
						["Hartarbeiter"] = true,
					},
				}, -- [6]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
						["Droomon <Nedro>"] = 0,
						["Kreshtak"] = 0,
						["Tårtåros"] = 0,
						["Grizzmo"] = 0,
						["Spirit Wolf <Yaasi>"] = 0,
						["Yaasi"] = 0,
						["Nedro"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
						"Spirit Wolf <Yaasi>", -- [1]
						"Greater Fire Elemental <Yaasi>", -- [2]
					},
					["iniciar_hps"] = false,
					["classe"] = "SHAMAN",
					["totalover"] = 150529.011996,
					["total_without_pet"] = 6804.011996,
					["total"] = 6804.011996,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-03B262D2",
					["totalabsorb"] = 0.011996,
					["last_hps"] = 0,
					["targets"] = {
						["Tårtåros"] = 0,
						["Kreshtak"] = 0,
						["Droomon <Nedro>"] = 0,
						["Grizzmo"] = 0,
						["Spirit Wolf <Yaasi>"] = 0,
						["Yaasi"] = 0,
						["Nedro"] = 0,
					},
					["totalover_without_pet"] = 0.011996,
					["healing_taken"] = 13160.011996,
					["start_time"] = 1675343060,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-03B262D2",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[52042] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Droomon <Nedro>"] = 11105,
									["Kreshtak"] = 8013,
									["Tårtåros"] = 5011,
									["Grizzmo"] = 8516,
									["Spirit Wolf <Yaasi>"] = 9718,
									["Yaasi"] = 9435,
									["Nedro"] = 10582,
								},
								["n_max"] = 239,
								["targets"] = {
									["Droomon <Nedro>"] = 0,
									["Kreshtak"] = 2277,
									["Tårtåros"] = 953,
									["Grizzmo"] = 1792,
									["Spirit Wolf <Yaasi>"] = 0,
									["Yaasi"] = 1258,
									["Nedro"] = 524,
								},
								["n_min"] = 0,
								["counter"] = 316,
								["overheal"] = 62380,
								["total"] = 6804,
								["c_max"] = 0,
								["id"] = 52042,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 6804,
								["totaldenied"] = 0,
								["n_amt"] = 316,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Yaasi",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 263,
					["totaldenied"] = 0.011996,
					["delay"] = 0,
					["healing_from"] = {
						["Missbläckz"] = true,
						["Yaasi"] = true,
						["Hartarbeiter"] = true,
					},
				}, -- [7]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "WARRIOR",
					["totalover"] = 0.012256,
					["total_without_pet"] = 0.012256,
					["total"] = 0.012256,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-02C03342",
					["totalabsorb"] = 0.012256,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.012256,
					["healing_taken"] = 55559.012256,
					["start_time"] = 1675343161,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-02C03342",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Kreshtak",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 71,
					["totaldenied"] = 0.012256,
					["delay"] = 0,
					["healing_from"] = {
						["Missbläckz"] = true,
						["Ranuri"] = true,
						["Yaasi"] = true,
						["Hartarbeiter"] = true,
					},
				}, -- [8]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "MAGE",
					["totalover"] = 0.007147000000000001,
					["total_without_pet"] = 0.007147000000000001,
					["total"] = 0.007147000000000001,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-04D7DA76",
					["totalabsorb"] = 0.007147000000000001,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.007147000000000001,
					["healing_taken"] = 9110.007146999998,
					["start_time"] = 1675343161,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-04D7DA76",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Tårtåros",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 63,
					["totaldenied"] = 0.007147000000000001,
					["delay"] = 0,
					["healing_from"] = {
						["Missbläckz"] = true,
						["Yaasi"] = true,
						["Hartarbeiter"] = true,
					},
				}, -- [9]
				{
					["flag_original"] = 4369,
					["targets_overheal"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "PET",
					["totalover"] = 0.043567,
					["total_without_pet"] = 0.043567,
					["total"] = 0.043567,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Pet-0-4446-571-12108-417-01007B88D5",
					["totalabsorb"] = 0.043567,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.043567,
					["healing_taken"] = 24893.043567,
					["fight_component"] = true,
					["end_time"] = 1675343164,
					["boss_fight_component"] = true,
					["ownerName"] = "Nedro",
					["nome"] = "Droomon <Nedro>",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["aID"] = "Pet-0-4446-571-12108-417-01007B88D5",
					["start_time"] = 1675343161,
					["heal_enemy_amt"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.043567,
					["delay"] = 0,
					["healing_from"] = {
						["Nedro"] = true,
					},
				}, -- [10]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "ROGUE",
					["totalover"] = 0.006791,
					["total_without_pet"] = 0.006791,
					["total"] = 0.006791,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-044DA6CD",
					["totalabsorb"] = 0.006791,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.006791,
					["healing_taken"] = 19457.006791,
					["start_time"] = 1675343161,
					["end_time"] = 1675343164,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-044DA6CD",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Grizzmo",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 260,
					["totaldenied"] = 0.006791,
					["delay"] = 0,
					["healing_from"] = {
						["Missbläckz"] = true,
						["Yaasi"] = true,
						["Hartarbeiter"] = true,
					},
				}, -- [11]
				{
					["flag_original"] = 4370,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 88149.008439,
					["total_without_pet"] = 0.008439,
					["total"] = 0.008439,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4447-624-31557-29264-00005BB4D9",
					["totalabsorb"] = 0.008439,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.008439,
					["healing_taken"] = 0.008439,
					["end_time"] = 1675343164,
					["aID"] = "29264",
					["ownerName"] = "Yaasi",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[58879] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Yaasi"] = 44074,
									["Spirit Wolf <Yaasi>"] = 44075,
								},
								["n_max"] = 0,
								["targets"] = {
									["Yaasi"] = 0,
									["Spirit Wolf <Yaasi>"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 124,
								["overheal"] = 88149,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58879,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 124,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Yaasi"] = 0,
						["Spirit Wolf <Yaasi>"] = 0,
					},
					["nome"] = "Spirit Wolf <Yaasi>",
					["classe"] = "PET",
					["custom"] = 0,
					["tipo"] = 2,
					["start_time"] = 1675343130,
					["totaldenied"] = 0.008439,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [12]
				{
					["flag_original"] = 68168,
					["targets_overheal"] = {
						["Nedro"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 189641,
					["totalover"] = 17909.00976,
					["total_without_pet"] = 618.0097599999999,
					["monster"] = true,
					["total"] = 618.0097599999999,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
						[64218] = 189641,
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4447-624-31557-33993-00005BB316",
					["totalabsorb"] = 0.00976,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 0,
					},
					["totalover_without_pet"] = 0.00976,
					["healing_taken"] = 0.00976,
					["end_time"] = 1675343164,
					["healing_from"] = {
					},
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 17909,
								},
								["n_max"] = 618,
								["targets"] = {
									["Nedro"] = 618,
								},
								["n_min"] = 0,
								["counter"] = 6,
								["overheal"] = 17909,
								["total"] = 618,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 618,
								["totaldenied"] = 0,
								["n_amt"] = 6,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["tipo"] = 2,
					["aID"] = "33993",
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["last_event"] = 0,
					["start_time"] = 1675343139,
					["totaldenied"] = 0.00976,
					["delay"] = 0,
					["nome"] = "Emalon the Storm Watcher",
				}, -- [13]
				{
					["flag_original"] = 8466,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.007041,
					["total_without_pet"] = 0.007041,
					["total"] = 0.007041,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4447-624-31557-15438-00005BB4D8",
					["totalabsorb"] = 0.007041,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.007041,
					["healing_taken"] = 0.007041,
					["end_time"] = 1675343164,
					["aID"] = "15438",
					["ownerName"] = "Yaasi",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
					},
					["nome"] = "Greater Fire Elemental <Yaasi>",
					["classe"] = "PET",
					["custom"] = 0,
					["tipo"] = 2,
					["start_time"] = 1675343161,
					["totaldenied"] = 0.007041,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [14]
				{
					["flag_original"] = 2632,
					["targets_overheal"] = {
						["Nedro"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 6586.009590000001,
					["total_without_pet"] = 0.009590000000000001,
					["monster"] = true,
					["total"] = 0.009590000000000001,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4447-624-31557-33998-00015BB316",
					["totalabsorb"] = 0.009590000000000001,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.009590000000000001,
					["healing_taken"] = 0.009590000000000001,
					["end_time"] = 1675343164,
					["healing_from"] = {
					},
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 6586,
								},
								["n_max"] = 0,
								["targets"] = {
									["Nedro"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 2,
								["overheal"] = 6586,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 2,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["tipo"] = 2,
					["aID"] = "33998",
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["last_event"] = 0,
					["start_time"] = 1675343157,
					["totaldenied"] = 0.009590000000000001,
					["delay"] = 0,
					["nome"] = "Tempest Minion",
				}, -- [15]
				{
					["flag_original"] = 8466,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.005296,
					["total_without_pet"] = 0.005296,
					["total"] = 0.005296,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4447-624-31557-31216-0000DBB3E3",
					["totalabsorb"] = 0.005296,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.005296,
					["healing_taken"] = 0.005296,
					["end_time"] = 1675494156,
					["targets_overheal"] = {
					},
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["classe"] = "PET",
					["last_event"] = 0,
					["aID"] = "31216",
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.005296,
					["start_time"] = 1675494153,
					["delay"] = 0,
					["nome"] = "Mirror Image <Tårtåros>",
				}, -- [16]
				{
					["flag_original"] = 68168,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.00395,
					["total_without_pet"] = 0.00395,
					["monster"] = true,
					["total"] = 0.00395,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Vehicle-0-4447-624-31557-31125-00005BB316",
					["totalabsorb"] = 0.00395,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.00395,
					["healing_taken"] = 0.00395,
					["end_time"] = 1675494156,
					["targets_overheal"] = {
						["Nedro"] = 0,
					},
					["nome"] = "Archavon the Stone Watcher",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Nedro"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["boss_fight_component"] = true,
					["classe"] = "UNKNOW",
					["start_time"] = 1675494153,
					["custom"] = 0,
					["tipo"] = 2,
					["aID"] = "",
					["totaldenied"] = 0.00395,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [17]
				{
					["flag_original"] = 2632,
					["targets_overheal"] = {
						["Nedro"] = 8757,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 21905.108421,
					["total_without_pet"] = 15122.108421,
					["monster"] = true,
					["total"] = 15122.108421,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4448-571-6723-30160-00005E0414",
					["totalabsorb"] = 0.108421,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 10026,
					},
					["totalover_without_pet"] = 0.108421,
					["healing_taken"] = 0.108421,
					["fight_component"] = true,
					["end_time"] = 1675494520,
					["nome"] = "Brittle Revenant",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 21905,
								},
								["n_max"] = 1810,
								["targets"] = {
									["Nedro"] = 15122,
								},
								["n_min"] = 0,
								["counter"] = 18,
								["overheal"] = 21905,
								["total"] = 15122,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 18,
								["n_curado"] = 15122,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["healing_from"] = {
					},
					["aID"] = "30160",
					["heal_enemy_amt"] = 0,
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.108421,
					["start_time"] = 1675494505,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [18]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 23253.086815,
					["total_without_pet"] = 13060.086815,
					["monster"] = true,
					["total"] = 13060.086815,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4448-571-6723-29974-00005DF175",
					["totalabsorb"] = 0.086815,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 7606,
					},
					["totalover_without_pet"] = 0.086815,
					["healing_taken"] = 0.086815,
					["fight_component"] = true,
					["end_time"] = 1675494843,
					["nome"] = "Niffelem Forefather",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 23253,
								},
								["n_max"] = 2000,
								["targets"] = {
									["Nedro"] = 13060,
								},
								["n_min"] = 0,
								["counter"] = 17,
								["overheal"] = 23253,
								["total"] = 13060,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 17,
								["n_curado"] = 13060,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 8268,
					},
					["classe"] = "UNKNOW",
					["aID"] = "29974",
					["custom"] = 0,
					["last_event"] = 0,
					["start_time"] = 1675494827,
					["totaldenied"] = 0.086815,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [19]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 6619.034108,
					["total_without_pet"] = 7715.034108000001,
					["monster"] = true,
					["total"] = 7715.034108000001,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4448-571-6723-30135-00005DF127",
					["totalabsorb"] = 0.034108,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 1649,
					},
					["totalover_without_pet"] = 0.034108,
					["healing_taken"] = 0.034108,
					["fight_component"] = true,
					["end_time"] = 1675494894,
					["nome"] = "Restless Frostborn Warrior",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 6619,
								},
								["n_max"] = 1933,
								["targets"] = {
									["Nedro"] = 7715,
								},
								["n_min"] = 0,
								["counter"] = 8,
								["overheal"] = 6619,
								["total"] = 7715,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 8,
								["n_curado"] = 7715,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 3513,
					},
					["classe"] = "UNKNOW",
					["aID"] = "30135",
					["custom"] = 0,
					["last_event"] = 0,
					["start_time"] = 1675494879,
					["totaldenied"] = 0.034108,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [20]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 15420.050009,
					["total_without_pet"] = 9442.050008999999,
					["monster"] = true,
					["total"] = 9442.050008999999,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4448-571-6723-30422-00005DF36B",
					["totalabsorb"] = 0.05000899999999999,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 2000,
					},
					["totalover_without_pet"] = 0.05000899999999999,
					["healing_taken"] = 0.05000899999999999,
					["fight_component"] = true,
					["end_time"] = 1675495522,
					["nome"] = "Roaming Jormungar",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 15420,
								},
								["n_max"] = 2000,
								["targets"] = {
									["Nedro"] = 9442,
								},
								["n_min"] = 0,
								["counter"] = 12,
								["overheal"] = 15420,
								["total"] = 9442,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 12,
								["n_curado"] = 9442,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 1936,
					},
					["classe"] = "UNKNOW",
					["aID"] = "30422",
					["custom"] = 0,
					["last_event"] = 0,
					["start_time"] = 1675495505,
					["totaldenied"] = 0.05000899999999999,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [21]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 8815.054878,
					["total_without_pet"] = 11472.054878,
					["monster"] = true,
					["total"] = 11472.054878,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4448-571-6723-30222-00005E0877",
					["totalabsorb"] = 0.054878,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 5924,
					},
					["totalover_without_pet"] = 0.054878,
					["healing_taken"] = 0.054878,
					["fight_component"] = true,
					["end_time"] = 1675495555,
					["nome"] = "Stormforged Infiltrator",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 8815,
								},
								["n_max"] = 2000,
								["targets"] = {
									["Nedro"] = 11472,
								},
								["n_min"] = 0,
								["counter"] = 10,
								["overheal"] = 8815,
								["total"] = 11472,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 10,
								["n_curado"] = 11472,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 3205,
					},
					["classe"] = "UNKNOW",
					["aID"] = "30222",
					["custom"] = 0,
					["last_event"] = 0,
					["start_time"] = 1675495545,
					["totaldenied"] = 0.054878,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [22]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 23383.068102,
					["total_without_pet"] = 13387.068102,
					["monster"] = true,
					["total"] = 13387.068102,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4448-571-6723-30291-00005DF376",
					["totalabsorb"] = 0.068102,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 4433,
					},
					["totalover_without_pet"] = 0.068102,
					["healing_taken"] = 0.068102,
					["fight_component"] = true,
					["end_time"] = 1675495907,
					["nome"] = "Ravenous Jormungar",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 23383,
								},
								["n_max"] = 2000,
								["targets"] = {
									["Nedro"] = 13387,
								},
								["n_min"] = 0,
								["counter"] = 15,
								["overheal"] = 23383,
								["total"] = 13387,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 15,
								["n_curado"] = 13387,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 9165,
					},
					["classe"] = "UNKNOW",
					["aID"] = "30291",
					["custom"] = 0,
					["last_event"] = 0,
					["start_time"] = 1675495876,
					["totaldenied"] = 0.068102,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [23]
				{
					["flag_original"] = 2600,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 30024.085431,
					["total_without_pet"] = 5484.085431000001,
					["total"] = 5484.085431000001,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4448-571-6723-30325-00005DF43D",
					["totalabsorb"] = 0.085431,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 2725,
					},
					["totalover_without_pet"] = 0.085431,
					["healing_taken"] = 0.085431,
					["fight_component"] = true,
					["end_time"] = 1675495958,
					["nome"] = "Viscous Oil",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 30024,
								},
								["n_max"] = 1728,
								["targets"] = {
									["Nedro"] = 5484,
								},
								["n_min"] = 0,
								["counter"] = 17,
								["overheal"] = 30024,
								["total"] = 5484,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 17,
								["n_curado"] = 5484,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["totaldenied"] = 0.085431,
					["targets_overheal"] = {
						["Nedro"] = 12400,
					},
					["aID"] = "30325",
					["custom"] = 0,
					["last_event"] = 0,
					["heal_enemy_amt"] = 0,
					["start_time"] = 1675495930,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [24]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 11322.049944,
					["total_without_pet"] = 9421.049944,
					["monster"] = true,
					["total"] = 9421.049944,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-5563-571-10-30144-00005F7E12",
					["totalabsorb"] = 0.049944,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 8811,
					},
					["totalover_without_pet"] = 0.049944,
					["healing_taken"] = 0.049944,
					["fight_component"] = true,
					["end_time"] = 1675594316,
					["nome"] = "Restless Frostborn Ghost",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 11322,
								},
								["n_max"] = 2000,
								["targets"] = {
									["Nedro"] = 9421,
								},
								["n_min"] = 0,
								["counter"] = 9,
								["overheal"] = 11322,
								["total"] = 9421,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 9421,
								["totaldenied"] = 0,
								["n_amt"] = 9,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 7800,
					},
					["heal_enemy_amt"] = 0,
					["start_time"] = 1675594305,
					["custom"] = 0,
					["tipo"] = 2,
					["aID"] = "30144",
					["totaldenied"] = 0.049944,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [25]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 2279.0153,
					["total_without_pet"] = 4791.0153,
					["monster"] = true,
					["total"] = 4791.0153,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-5563-571-10-30422-00005F84ED",
					["totalabsorb"] = 0.0153,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 1686,
					},
					["totalover_without_pet"] = 0.0153,
					["healing_taken"] = 0.0153,
					["fight_component"] = true,
					["end_time"] = 1675594694,
					["nome"] = "Disembodied Jormungar",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 2279,
								},
								["n_max"] = 1687,
								["targets"] = {
									["Nedro"] = 4791,
								},
								["n_min"] = 0,
								["counter"] = 3,
								["overheal"] = 2279,
								["total"] = 4791,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 4791,
								["totaldenied"] = 0,
								["n_amt"] = 3,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 245,
					},
					["heal_enemy_amt"] = 0,
					["start_time"] = 1675594691,
					["custom"] = 0,
					["tipo"] = 2,
					["aID"] = "30422",
					["totaldenied"] = 0.0153,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [26]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 4153.024171999999,
					["total_without_pet"] = 4766.024172,
					["monster"] = true,
					["total"] = 4766.024172,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-5563-571-5-29880-00006214B4",
					["totalabsorb"] = 0.024172,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 4766,
					},
					["totalover_without_pet"] = 0.024172,
					["healing_taken"] = 0.024172,
					["fight_component"] = true,
					["end_time"] = 1675764281,
					["nome"] = "Jotunheim Warrior",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 4153,
								},
								["n_max"] = 1706,
								["targets"] = {
									["Nedro"] = 4766,
								},
								["n_min"] = 0,
								["counter"] = 5,
								["overheal"] = 4153,
								["total"] = 4766,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 5,
								["n_curado"] = 4766,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 4153,
					},
					["tipo"] = 2,
					["aID"] = "29880",
					["custom"] = 0,
					["last_event"] = 0,
					["totaldenied"] = 0.024172,
					["start_time"] = 1675764273,
					["delay"] = 0,
					["heal_enemy_amt"] = 0,
				}, -- [27]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 23986.073537,
					["total_without_pet"] = 20175.073537,
					["monster"] = true,
					["total"] = 20175.073537,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-5563-571-5-30037-0000622243",
					["totalabsorb"] = 0.07353699999999999,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 0,
					},
					["totalover_without_pet"] = 0.07353699999999999,
					["healing_taken"] = 0.07353699999999999,
					["fight_component"] = true,
					["end_time"] = 1675764350,
					["nome"] = "Mjordin Combatant",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 23986,
								},
								["n_max"] = 1913,
								["targets"] = {
									["Nedro"] = 20175,
								},
								["n_min"] = 0,
								["counter"] = 23,
								["overheal"] = 23986,
								["total"] = 20175,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 23,
								["n_curado"] = 20175,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 0,
					},
					["tipo"] = 2,
					["aID"] = "30037",
					["custom"] = 0,
					["last_event"] = 0,
					["totaldenied"] = 0.07353699999999999,
					["start_time"] = 1675764311,
					["delay"] = 0,
					["heal_enemy_amt"] = 0,
				}, -- [28]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 19930.070072,
					["total_without_pet"] = 21950.070072,
					["monster"] = true,
					["total"] = 21950.070072,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-5563-571-5-29333-00006223F1",
					["totalabsorb"] = 0.07007200000000001,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 0,
					},
					["totalover_without_pet"] = 0.07007200000000001,
					["healing_taken"] = 0.07007200000000001,
					["fight_component"] = true,
					["end_time"] = 1675764968,
					["nome"] = "Onslaught Gryphon Rider",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 19930,
								},
								["n_max"] = 3212,
								["targets"] = {
									["Nedro"] = 21950,
								},
								["n_min"] = 0,
								["counter"] = 18,
								["overheal"] = 19930,
								["total"] = 21950,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 18,
								["n_curado"] = 21950,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 0,
					},
					["tipo"] = 2,
					["aID"] = "29333",
					["custom"] = 0,
					["last_event"] = 0,
					["totaldenied"] = 0.07007200000000001,
					["start_time"] = 1675764941,
					["delay"] = 0,
					["heal_enemy_amt"] = 0,
				}, -- [29]
				{
					["flag_original"] = 2632,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["aID"] = "30387",
					["totalover"] = 7613.021148,
					["total_without_pet"] = 2253.021148,
					["monster"] = true,
					["total"] = 2253.021148,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4457-571-183-30387-000063417B",
					["totalabsorb"] = 0.021148,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 2253,
					},
					["totalover_without_pet"] = 0.021148,
					["healing_taken"] = 0.021148,
					["fight_component"] = true,
					["end_time"] = 1675838805,
					["nome"] = "Seething Revenant",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 7613,
								},
								["n_max"] = 2000,
								["targets"] = {
									["Nedro"] = 2253,
								},
								["n_min"] = 0,
								["counter"] = 3,
								["overheal"] = 7613,
								["total"] = 2253,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 3,
								["n_curado"] = 2253,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 7613,
					},
					["start_time"] = 1675838801,
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["last_event"] = 0,
					["heal_enemy_amt"] = 0,
					["totaldenied"] = 0.021148,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [30]
				{
					["flag_original"] = 2600,
					["healing_from"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 463.00681,
					["total_without_pet"] = 1687.00681,
					["total"] = 1687.00681,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4457-571-183-30260-0000E348AE",
					["totalabsorb"] = 0.00681,
					["last_hps"] = 0,
					["targets"] = {
						["Nedro"] = 1687,
					},
					["totalover_without_pet"] = 0.00681,
					["healing_taken"] = 0.00681,
					["fight_component"] = true,
					["end_time"] = 1675839701,
					["nome"] = "Stoic Mammoth",
					["spells"] = {
						["_ActorTable"] = {
							[48210] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Nedro"] = 463,
								},
								["n_max"] = 1687,
								["targets"] = {
									["Nedro"] = 1687,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 463,
								["total"] = 1687,
								["c_max"] = 0,
								["id"] = 48210,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 1,
								["n_curado"] = 1687,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["targets_overheal"] = {
						["Nedro"] = 463,
					},
					["start_time"] = 1675839697,
					["aID"] = "30260",
					["custom"] = 0,
					["last_event"] = 0,
					["heal_enemy_amt"] = 0,
					["totaldenied"] = 0.00681,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [31]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["received"] = 756.0049319999999,
					["resource"] = 0.037326,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Einsamen"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 6,
					["classe"] = "DEATHKNIGHT",
					["totalover"] = 0.002527,
					["total"] = 756.0049319999999,
					["spells"] = {
						["_ActorTable"] = {
							[50422] = {
								["total"] = 30,
								["id"] = 50422,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 3,
							},
							[49088] = {
								["total"] = 120,
								["id"] = 49088,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 2,
							},
							[49921] = {
								["total"] = 100,
								["id"] = 49921,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 11,
							},
							[49930] = {
								["total"] = 150,
								["id"] = 49930,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 15,
							},
							[48543] = {
								["total"] = 32,
								["id"] = 48543,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 3,
							},
							[49924] = {
								["total"] = 45,
								["id"] = 49924,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 3,
							},
							[47568] = {
								["total"] = 25,
								["id"] = 47568,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 1,
							},
							[49909] = {
								["total"] = 170,
								["id"] = 49909,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 18,
							},
							[63652] = {
								["total"] = 64,
								["id"] = 63652,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 2,
							},
							[55233] = {
								["total"] = 20,
								["id"] = 55233,
								["totalover"] = 0,
								["targets"] = {
									["Einsamen"] = 0,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["passiveover"] = 0.002527,
					["nome"] = "Einsamen",
					["spec"] = 250,
					["grupo"] = true,
					["alternatepower"] = 0.004932000000000001,
					["aID"] = "4477-04991245",
					["tipo"] = 3,
					["last_event"] = 0,
					["flag_original"] = 263444,
					["isTank"] = true,
					["serial"] = "Player-4477-04991245",
					["boss_fight_component"] = true,
				}, -- [1]
				{
					["received"] = 22636.007144,
					["resource"] = 0.035704,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Tonyhawkings"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "PALADIN",
					["totalover"] = 0.001118,
					["total"] = 21709.007144,
					["spells"] = {
						["_ActorTable"] = {
							[67490] = {
								["total"] = 0,
								["id"] = 67490,
								["totalover"] = 0,
								["targets"] = {
									["Tonyhawkings"] = 0,
								},
								["counter"] = 0,
							},
							[63654] = {
								["total"] = 52,
								["id"] = 63654,
								["totalover"] = 0,
								["targets"] = {
									["Tonyhawkings"] = 0,
								},
								["counter"] = 1,
							},
							[57319] = {
								["total"] = 10213,
								["id"] = 57319,
								["totalover"] = 0,
								["targets"] = {
									["Tonyhawkings"] = 0,
								},
								["counter"] = 117,
							},
							[48542] = {
								["total"] = 152,
								["id"] = 48542,
								["totalover"] = 0,
								["targets"] = {
									["Tonyhawkings"] = 0,
								},
								["counter"] = 5,
							},
							[31786] = {
								["total"] = 8045,
								["id"] = 31786,
								["totalover"] = 0,
								["targets"] = {
									["Tonyhawkings"] = 0,
								},
								["counter"] = 71,
							},
							[54428] = {
								["total"] = 3247,
								["id"] = 54428,
								["totalover"] = 0,
								["targets"] = {
									["Tonyhawkings"] = 0,
								},
								["counter"] = 12,
							},
						},
						["tipo"] = 7,
					},
					["passiveover"] = 0.001118,
					["nome"] = "Tonyhawkings",
					["spec"] = 66,
					["grupo"] = true,
					["alternatepower"] = 0.007144,
					["aID"] = "4477-04BC0BBF",
					["tipo"] = 3,
					["last_event"] = 0,
					["flag_original"] = 263444,
					["isTank"] = true,
					["serial"] = "Player-4477-04BC0BBF",
					["boss_fight_component"] = true,
				}, -- [2]
				{
					["received"] = 20323.009705,
					["resource"] = 0.037122,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 0,
						["Mirror Image <Tårtåros>"] = 0,
						["Ranuri"] = 0,
						["Tårtåros"] = 0,
						["Nedro"] = 0,
						["Hartarbeiter"] = 0,
						["Missbläckz"] = 0,
						["Tonyhawkings"] = 0,
						["Yaasi"] = 0,
						["Greater Fire Elemental <Yaasi>"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "PALADIN",
					["totalover"] = 0.001837,
					["total"] = 52874.009705,
					["passiveover"] = 0.001837,
					["nome"] = "Ranuri",
					["spells"] = {
						["_ActorTable"] = {
							[57669] = {
								["total"] = 22836,
								["id"] = 57669,
								["totalover"] = 0,
								["targets"] = {
									["Missbläckz"] = 0,
									["Ranuri"] = 0,
									["Nedro"] = 0,
									["Droomon <Nedro>"] = 0,
									["Tårtåros"] = 0,
									["Tonyhawkings"] = 0,
									["Yaasi"] = 0,
									["Hartarbeiter"] = 0,
								},
								["counter"] = 676,
							},
							[31930] = {
								["total"] = 13487,
								["id"] = 31930,
								["totalover"] = 0,
								["targets"] = {
									["Ranuri"] = 0,
								},
								["counter"] = 13,
							},
							[20268] = {
								["total"] = 15687,
								["id"] = 20268,
								["totalover"] = 0,
								["targets"] = {
									["Droomon <Nedro>"] = 0,
									["Mirror Image <Tårtåros>"] = 0,
									["Ranuri"] = 0,
									["Tårtåros"] = 0,
									["Greater Fire Elemental <Yaasi>"] = 0,
									["Hartarbeiter"] = 0,
									["Tonyhawkings"] = 0,
									["Yaasi"] = 0,
									["Nedro"] = 0,
								},
								["counter"] = 240,
							},
							[28730] = {
								["total"] = 472,
								["id"] = 28730,
								["totalover"] = 0,
								["targets"] = {
									["Ranuri"] = 0,
								},
								["counter"] = 1,
							},
							[48542] = {
								["total"] = 235,
								["id"] = 48542,
								["totalover"] = 0,
								["targets"] = {
									["Ranuri"] = 0,
								},
								["counter"] = 3,
							},
							[63654] = {
								["total"] = 157,
								["id"] = 63654,
								["totalover"] = 0,
								["targets"] = {
									["Ranuri"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["alternatepower"] = 0.009705,
					["spec"] = 70,
					["aID"] = "4477-04546F6D",
					["last_event"] = 0,
					["tipo"] = 3,
					["flag_original"] = 1300,
					["serial"] = "Player-4477-04546F6D",
					["boss_fight_component"] = true,
				}, -- [3]
				{
					["received"] = 9879.015002,
					["resource"] = 0.050819,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Missbläckz"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "PRIEST",
					["totalover"] = 0.008703,
					["total"] = 4922.015002000001,
					["passiveover"] = 0.008703,
					["nome"] = "Missbläckz",
					["spells"] = {
						["_ActorTable"] = {
							[55382] = {
								["total"] = 1200,
								["id"] = 55382,
								["totalover"] = 0,
								["targets"] = {
									["Missbläckz"] = 0,
								},
								["counter"] = 2,
							},
							[47755] = {
								["total"] = 3001,
								["id"] = 47755,
								["totalover"] = 0,
								["targets"] = {
									["Missbläckz"] = 0,
								},
								["counter"] = 5,
							},
							[48542] = {
								["total"] = 721,
								["id"] = 48542,
								["totalover"] = 0,
								["targets"] = {
									["Missbläckz"] = 0,
								},
								["counter"] = 3,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["alternatepower"] = 0.015002,
					["spec"] = 256,
					["aID"] = "4477-044E7D32",
					["last_event"] = 0,
					["tipo"] = 3,
					["flag_original"] = 1300,
					["serial"] = "Player-4477-044E7D32",
					["boss_fight_component"] = true,
				}, -- [4]
				{
					["received"] = 23223.012007,
					["resource"] = 0.03979,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Tårtåros"] = 0,
					},
					["pets"] = {
						"Mirror Image <Tårtåros>", -- [1]
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["totalover"] = 0.008048,
					["total"] = 17927.012007,
					["passiveover"] = 0.008048,
					["nome"] = "Tårtåros",
					["spells"] = {
						["_ActorTable"] = {
							[67545] = {
								["total"] = 6675,
								["id"] = 67545,
								["totalover"] = 0,
								["targets"] = {
									["Tårtåros"] = 0,
								},
								["counter"] = 102,
							},
							[48542] = {
								["total"] = 612,
								["id"] = 48542,
								["totalover"] = 0,
								["targets"] = {
									["Tårtåros"] = 0,
								},
								["counter"] = 3,
							},
							[29077] = {
								["total"] = 6265,
								["id"] = 29077,
								["totalover"] = 0,
								["targets"] = {
									["Tårtåros"] = 0,
								},
								["counter"] = 34,
							},
							[42987] = {
								["total"] = 4375,
								["id"] = 42987,
								["totalover"] = 0,
								["targets"] = {
									["Tårtåros"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["alternatepower"] = 0.012007,
					["spec"] = 63,
					["aID"] = "4477-04D7DA76",
					["last_event"] = 0,
					["tipo"] = 3,
					["flag_original"] = 1298,
					["serial"] = "Player-4477-04D7DA76",
					["boss_fight_component"] = true,
				}, -- [5]
				{
					["received"] = 36009.00963,
					["resource"] = 0.03266400000000001,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Yaasi"] = 0,
					},
					["pets"] = {
						"Greater Fire Elemental <Yaasi>", -- [1]
					},
					["powertype"] = 0,
					["classe"] = "SHAMAN",
					["totalover"] = 0.003321,
					["total"] = 27316.00963,
					["passiveover"] = 0.003321,
					["nome"] = "Yaasi",
					["spells"] = {
						["_ActorTable"] = {
							[30824] = {
								["total"] = 16941,
								["id"] = 30824,
								["totalover"] = 0,
								["targets"] = {
									["Yaasi"] = 0,
								},
								["counter"] = 25,
							},
							[63375] = {
								["total"] = 9999,
								["id"] = 63375,
								["totalover"] = 0,
								["targets"] = {
									["Yaasi"] = 0,
								},
								["counter"] = 12,
							},
							[48542] = {
								["total"] = 154,
								["id"] = 48542,
								["totalover"] = 0,
								["targets"] = {
									["Yaasi"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["alternatepower"] = 0.00963,
					["spec"] = 263,
					["aID"] = "4477-03B262D2",
					["last_event"] = 0,
					["tipo"] = 3,
					["flag_original"] = 1298,
					["serial"] = "Player-4477-03B262D2",
					["boss_fight_component"] = true,
				}, -- [6]
				{
					["flag_original"] = 1300,
					["resource"] = 1.587364000000001,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Nedro"] = 0,
					},
					["pets"] = {
						"Droomon <Nedro>", -- [1]
						"Unknown <Nedro>", -- [2]
					},
					["powertype"] = 0,
					["aID"] = "4477-04D9C328",
					["passiveover"] = 0.004477,
					["fight_component"] = true,
					["alternatepower"] = 0.8600620000000001,
					["tipo"] = 3,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[31818] = {
								["total"] = 353674,
								["id"] = 31818,
								["totalover"] = 0,
								["targets"] = {
									["Nedro"] = 0,
								},
								["counter"] = 161,
							},
							[48542] = {
								["total"] = 1088,
								["id"] = 48542,
								["totalover"] = 0,
								["targets"] = {
									["Nedro"] = 0,
								},
								["counter"] = 6,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["classe"] = "WARLOCK",
					["spec"] = 265,
					["nome"] = "Nedro",
					["last_event"] = 0,
					["total"] = 477942.8600620003,
					["totalover"] = 0.004477,
					["serial"] = "Player-4477-04D9C328",
					["received"] = 360037.8600620001,
				}, -- [7]
				{
					["flag_original"] = 4369,
					["resource"] = 1.501291000000003,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Droomon <Nedro>"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["aID"] = "Pet-0-4446-571-12108-417-01007B88D5",
					["totalover"] = 0.007931,
					["fight_component"] = true,
					["alternatepower"] = 0.8176580000000003,
					["ownerName"] = "Nedro",
					["nome"] = "Droomon <Nedro>",
					["spells"] = {
						["_ActorTable"] = {
							[54425] = {
								["total"] = 122918,
								["id"] = 54425,
								["totalover"] = 0,
								["targets"] = {
									["Droomon <Nedro>"] = 0,
								},
								["counter"] = 921,
							},
							[48542] = {
								["total"] = 0,
								["id"] = 48542,
								["totalover"] = 0,
								["targets"] = {
									["Droomon <Nedro>"] = 0,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["tipo"] = 3,
					["classe"] = "PET",
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["total"] = 122918.817658,
					["passiveover"] = 0.007931,
					["serial"] = "Pet-0-4446-571-12108-417-01007B88D5",
					["received"] = 122967.817658,
				}, -- [8]
				{
					["received"] = 7105.006416,
					["resource"] = 0.024185,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Hartarbeiter"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "DRUID",
					["totalover"] = 0.005374,
					["total"] = 2792.006416,
					["passiveover"] = 0.005374,
					["nome"] = "Hartarbeiter",
					["spells"] = {
						["_ActorTable"] = {
							[55382] = {
								["total"] = 1200,
								["id"] = 55382,
								["totalover"] = 0,
								["targets"] = {
									["Hartarbeiter"] = 0,
								},
								["counter"] = 2,
							},
							[55767] = {
								["total"] = 1170,
								["id"] = 55767,
								["totalover"] = 0,
								["targets"] = {
									["Hartarbeiter"] = 0,
								},
								["counter"] = 3,
							},
							[48542] = {
								["total"] = 422,
								["id"] = 48542,
								["totalover"] = 0,
								["targets"] = {
									["Hartarbeiter"] = 0,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["alternatepower"] = 0.006416,
					["spec"] = 105,
					["aID"] = "4477-03B26A55",
					["last_event"] = 0,
					["tipo"] = 3,
					["flag_original"] = 1300,
					["serial"] = "Player-4477-03B26A55",
					["boss_fight_component"] = true,
				}, -- [9]
				{
					["received"] = 541.01603,
					["resource"] = 0.042265,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Grizzmo"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 3,
					["classe"] = "ROGUE",
					["totalover"] = 0.008729,
					["total"] = 541.01603,
					["passiveover"] = 0.008729,
					["nome"] = "Grizzmo",
					["spells"] = {
						["_ActorTable"] = {
							[64913] = {
								["total"] = 52,
								["id"] = 64913,
								["totalover"] = 0,
								["targets"] = {
									["Grizzmo"] = 0,
								},
								["counter"] = 53,
							},
							[35548] = {
								["total"] = 465,
								["id"] = 35548,
								["totalover"] = 0,
								["targets"] = {
									["Grizzmo"] = 0,
								},
								["counter"] = 31,
							},
							[48540] = {
								["total"] = 24,
								["id"] = 48540,
								["totalover"] = 0,
								["targets"] = {
									["Grizzmo"] = 0,
								},
								["counter"] = 3,
							},
							[63655] = {
								["total"] = 0,
								["id"] = 63655,
								["totalover"] = 0,
								["targets"] = {
									["Grizzmo"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["alternatepower"] = 0.01603,
					["spec"] = 260,
					["aID"] = "4477-044DA6CD",
					["last_event"] = 0,
					["tipo"] = 3,
					["flag_original"] = 1298,
					["serial"] = "Player-4477-044DA6CD",
					["boss_fight_component"] = true,
				}, -- [10]
				{
					["received"] = 915.012856,
					["resource"] = 0.0457,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "PET",
					["totalover"] = 0.005772,
					["total"] = 0.012856,
					["ownerName"] = "Tårtåros",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 7,
					},
					["passiveover"] = 0.005772,
					["alternatepower"] = 0.012856,
					["aID"] = "31216",
					["last_event"] = 0,
					["flag_original"] = 8466,
					["tipo"] = 3,
					["serial"] = "Creature-0-4447-624-31557-31216-00015BB4D8",
					["nome"] = "Mirror Image <Tårtåros>",
				}, -- [11]
				{
					["received"] = 2126.010227,
					["resource"] = 0.020241,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Greater Fire Elemental <Yaasi>"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "PET",
					["totalover"] = 0.006889,
					["total"] = 222.010227,
					["ownerName"] = "Yaasi",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[48542] = {
								["total"] = 222,
								["id"] = 48542,
								["totalover"] = 0,
								["targets"] = {
									["Greater Fire Elemental <Yaasi>"] = 0,
								},
								["counter"] = 3,
							},
						},
						["tipo"] = 7,
					},
					["passiveover"] = 0.006889,
					["alternatepower"] = 0.010227,
					["aID"] = "15438",
					["last_event"] = 0,
					["flag_original"] = 8466,
					["tipo"] = 3,
					["serial"] = "Creature-0-4447-624-31557-15438-00005BB4D8",
					["nome"] = "Greater Fire Elemental <Yaasi>",
				}, -- [12]
				{
					["received"] = 46.009815,
					["resource"] = 0.050867,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Kreshtak"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "WARRIOR",
					["totalover"] = 0.004664,
					["total"] = 46.009815,
					["passiveover"] = 0.004664,
					["nome"] = "Kreshtak",
					["spells"] = {
						["_ActorTable"] = {
							[63653] = {
								["total"] = 0,
								["id"] = 63653,
								["totalover"] = 0,
								["targets"] = {
									["Kreshtak"] = 0,
								},
								["counter"] = 1,
							},
							[48541] = {
								["total"] = 4,
								["id"] = 48541,
								["totalover"] = 0,
								["targets"] = {
									["Kreshtak"] = 0,
								},
								["counter"] = 1,
							},
							[2687] = {
								["total"] = 30,
								["id"] = 2687,
								["totalover"] = 0,
								["targets"] = {
									["Kreshtak"] = 0,
								},
								["counter"] = 1,
							},
							[29131] = {
								["total"] = 12,
								["id"] = 29131,
								["totalover"] = 0,
								["targets"] = {
									["Kreshtak"] = 0,
								},
								["counter"] = 8,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["alternatepower"] = 0.009815,
					["spec"] = 71,
					["aID"] = "4477-02C03342",
					["last_event"] = 0,
					["tipo"] = 3,
					["flag_original"] = 1298,
					["serial"] = "Player-4477-02C03342",
					["boss_fight_component"] = true,
				}, -- [13]
				{
					["received"] = 262.01105,
					["resource"] = 0.01999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Unknown <Nedro>"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "PET",
					["passiveover"] = 0.00211,
					["total"] = 262.01105,
					["ownerName"] = "Nedro",
					["nome"] = "Unknown <Nedro>",
					["spells"] = {
						["_ActorTable"] = {
							[54425] = {
								["total"] = 262,
								["id"] = 54425,
								["totalover"] = 0,
								["targets"] = {
									["Unknown <Nedro>"] = 0,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["totalover"] = 0.00211,
					["alternatepower"] = 0.01105,
					["tipo"] = 3,
					["flag_original"] = 4369,
					["last_event"] = 0,
					["serial"] = "Pet-0-5563-571-5-417-0A007B88D5",
					["aID"] = "Pet-0-5563-571-5-417-0A007B88D5",
				}, -- [14]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[56222] = {
								["id"] = 56222,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[55078] = {
								["refreshamt"] = 9,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = 55078,
								["uptime"] = 96,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[55095] = {
								["refreshamt"] = 17,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = 55095,
								["uptime"] = 110,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["cooldowns_defensive"] = 5.009543,
					["pets"] = {
					},
					["aID"] = "4477-04991245",
					["cooldowns_defensive_targets"] = {
						["Einsamen"] = 5,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[64859] = {
								["refreshamt"] = 32,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 64859,
								["uptime"] = 88,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48263] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 48263,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[58578] = {
								["refreshamt"] = 17,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 58578,
								["uptime"] = 110,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57819] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57819,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48707] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 48707,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20572] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 20572,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[55233] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 55233,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[51911] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 51911,
								["uptime"] = 1,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[50449] = {
								["refreshamt"] = 35,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 50449,
								["uptime"] = 104,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48792] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 48792,
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53138] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 53138,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60218] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 60218,
								["uptime"] = 17,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[50421] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 50421,
								["uptime"] = 2,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57623] = {
								["id"] = 57623,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_targets"] = {
					},
					["debuff_uptime"] = 306,
					["classe"] = "DEATHKNIGHT",
					["cooldowns_defensive_spells"] = {
						["_ActorTable"] = {
							[48707] = {
								["id"] = 48707,
								["targets"] = {
									["Einsamen"] = 2,
								},
								["counter"] = 2,
							},
							[55233] = {
								["id"] = 55233,
								["targets"] = {
									["Einsamen"] = 2,
								},
								["counter"] = 2,
							},
							[48792] = {
								["id"] = 48792,
								["targets"] = {
									["Einsamen"] = 1,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 9,
					},
					["nome"] = "Einsamen",
					["spec"] = 250,
					["grupo"] = true,
					["spell_cast"] = {
						[49921] = 12,
						[48707] = 2,
						[49930] = 17,
						[55233] = 2,
						[47568] = 1,
						[49924] = 4,
						[48792] = 1,
						[49895] = 17,
						[49909] = 22,
						[20572] = 1,
						[56222] = 0,
					},
					["buff_uptime"] = 712,
					["last_event"] = 0,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["isTank"] = true,
					["serial"] = "Player-4477-04991245",
					["debuff_uptime_targets"] = {
					},
				}, -- [1]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[62124] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 3,
								["id"] = 62124,
								["uptime"] = 9,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48819] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 31,
								["id"] = 48819,
								["uptime"] = 64,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53742] = {
								["refreshamt"] = 84,
								["activedamt"] = 2,
								["appliedamt"] = 11,
								["id"] = 53742,
								["uptime"] = 102,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[31790] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = 31790,
								["uptime"] = 6,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20185] = {
								["refreshamt"] = 4,
								["activedamt"] = 1,
								["appliedamt"] = 6,
								["id"] = 20185,
								["uptime"] = 93,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54499] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 10,
								["id"] = 54499,
								["uptime"] = 88,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["aID"] = "4477-04BC0BBF",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[348704] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 348704,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60795] = {
								["refreshamt"] = 15,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 60795,
								["uptime"] = 88,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54428] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 54428,
								["uptime"] = 72,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57399] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57399,
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[25899] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 25899,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[28093] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 28093,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20132] = {
								["refreshamt"] = 3,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 20132,
								["uptime"] = 25,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57820] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57820,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[25780] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 25780,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48942] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 48942,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[31884] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 31884,
								["uptime"] = 17,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48952] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 48952,
								["uptime"] = 18,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60218] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 60218,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 462,
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 812,
					["nome"] = "Tonyhawkings",
					["spec"] = 66,
					["grupo"] = true,
					["spell_cast"] = {
						[48952] = 2,
						[53595] = 12,
						[54428] = 1,
						[61411] = 11,
						[48819] = 8,
						[48827] = 3,
						[67490] = 0,
						[48806] = 1,
						[20271] = 10,
						[56488] = 0,
						[31789] = 2,
						[62124] = 3,
					},
					["classe"] = "PALADIN",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["last_event"] = 0,
					["isTank"] = true,
					["serial"] = "Player-4477-04BC0BBF",
					["debuff_uptime_targets"] = {
					},
				}, -- [2]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[6788] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 27,
								["id"] = 6788,
								["uptime"] = 99,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "PRIEST",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[48074] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 48074,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47753] = {
								["id"] = 47753,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[55637] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 55637,
								["uptime"] = 30,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48168] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 48168,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57821] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57821,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48162] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 48162,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[63944] = {
								["refreshamt"] = 6,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 63944,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59891] = {
								["refreshamt"] = 21,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 59891,
								["uptime"] = 55,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48066] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 48066,
								["uptime"] = 51,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60062] = {
								["id"] = 60062,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 199,
					["nome"] = "Missbläckz",
					["debuff_uptime_targets"] = {
					},
					["spec"] = 256,
					["grupo"] = true,
					["spell_cast"] = {
						[48068] = 1,
						[48063] = 1,
						[48113] = 4,
						[48071] = 9,
						[48066] = 27,
						[52985] = 29,
					},
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 691,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["serial"] = "Player-4477-044E7D32",
					["aID"] = "4477-044E7D32",
				}, -- [3]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["ress_targets"] = {
						["Kreshtak"] = 1,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "DRUID",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[53251] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 53251,
								["uptime"] = 11,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57399] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57399,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48422] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 48422,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60520] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 60520,
								["uptime"] = 30,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57820] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57820,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[16870] = {
								["refreshamt"] = 0,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = 16870,
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48470] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 48470,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[34123] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 34123,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[33891] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 33891,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48441] = {
								["refreshamt"] = 1,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 48441,
								["uptime"] = 53,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["boss_fight_component"] = true,
					["debuff_uptime"] = 100,
					["buff_uptime"] = 772,
					["ress"] = 1.005197,
					["nome"] = "Hartarbeiter",
					["spec"] = 105,
					["grupo"] = true,
					["spell_cast"] = {
						[50464] = 14,
						[48441] = 28,
						[48443] = 10,
						[53251] = 8,
						[18562] = 5,
						[48477] = 1,
						[60526] = 1,
						[48469] = 1,
					},
					["buff_uptime_targets"] = {
					},
					["ress_spells"] = {
						["_ActorTable"] = {
							[48477] = {
								["id"] = 48477,
								["ress"] = 1,
								["targets"] = {
									["Kreshtak"] = 1,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["debuff_uptime_targets"] = {
					},
					["serial"] = "Player-4477-03B26A55",
					["aID"] = "4477-03B26A55",
				}, -- [4]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[48819] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 20,
								["id"] = 48819,
								["uptime"] = 86,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53742] = {
								["refreshamt"] = 50,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = 53742,
								["uptime"] = 108,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20186] = {
								["refreshamt"] = 9,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = 20186,
								["uptime"] = 109,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[25771] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 25771,
								["uptime"] = 34,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54499] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 13,
								["id"] = 54499,
								["uptime"] = 109,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[61840] = {
								["refreshamt"] = 8,
								["activedamt"] = 0,
								["appliedamt"] = 13,
								["id"] = 61840,
								["uptime"] = 89,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["cooldowns_defensive"] = 1.015367,
					["pets"] = {
					},
					["classe"] = "PALADIN",
					["cooldowns_defensive_targets"] = {
						["Ranuri"] = 1,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[60547] = {
								["refreshamt"] = 11,
								["activedamt"] = 8,
								["appliedamt"] = 8,
								["id"] = 60547,
								["uptime"] = 92,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[642] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 642,
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[25898] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 25898,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54758] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 54758,
								["uptime"] = 24,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57669] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = 57669,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53768] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 53768,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[31884] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 31884,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20053] = {
								["refreshamt"] = 61,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 20053,
								["uptime"] = 107,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54043] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 54043,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60229] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 60229,
								["uptime"] = 45,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59620] = {
								["refreshamt"] = 4,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 59620,
								["uptime"] = 35,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[64790] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 64790,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59578] = {
								["refreshamt"] = 31,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = 59578,
								["uptime"] = 92,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54861] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 54861,
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[348704] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 348704,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 635,
					["cooldowns_defensive_spells"] = {
						["_ActorTable"] = {
							[642] = {
								["id"] = 642,
								["targets"] = {
									["Ranuri"] = 1,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_targets"] = {
					},
					["debuff_uptime_targets"] = {
					},
					["spec"] = 70,
					["grupo"] = true,
					["spell_cast"] = {
						[53385] = 10,
						[54758] = 2,
						[48819] = 9,
						[28730] = 1,
						[31884] = 1,
						[48806] = 5,
						[53408] = 13,
						[642] = 1,
						[35395] = 20,
						[48801] = 6,
						[67890] = 1,
					},
					["buff_uptime"] = 886,
					["nome"] = "Ranuri",
					["last_event"] = 0,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["serial"] = "Player-4477-04546F6D",
					["aID"] = "4477-04546F6D",
				}, -- [5]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[12721] = {
								["refreshamt"] = 41,
								["activedamt"] = 0,
								["appliedamt"] = 5,
								["id"] = 12721,
								["uptime"] = 91,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[58567] = {
								["refreshamt"] = 18,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = 58567,
								["uptime"] = 106,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[46857] = {
								["refreshamt"] = 44,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = 46857,
								["uptime"] = 101,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47465] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = 47465,
								["uptime"] = 84,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47486] = {
								["refreshamt"] = 9,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = 47486,
								["uptime"] = 74,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "WARRIOR",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[57522] = {
								["refreshamt"] = 45,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 57522,
								["uptime"] = 86,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60437] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 60437,
								["uptime"] = 30,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[12328] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 12328,
								["uptime"] = 4,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[46924] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 46924,
								["uptime"] = 6,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60503] = {
								["refreshamt"] = 3,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = 60503,
								["uptime"] = 46,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[65156] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 65156,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60229] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 60229,
								["uptime"] = 44,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57100] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57100,
								["uptime"] = 80,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57819] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57819,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[61571] = {
								["refreshamt"] = 0,
								["activedamt"] = 9,
								["appliedamt"] = 9,
								["id"] = 61571,
								["uptime"] = 8,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20572] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 20572,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59620] = {
								["refreshamt"] = 1,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 59620,
								["uptime"] = 31,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54758] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 54758,
								["uptime"] = 24,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53748] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 53748,
								["uptime"] = 80,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[18499] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 18499,
								["uptime"] = 3,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[28507] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 28507,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[52437] = {
								["refreshamt"] = 0,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = 52437,
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[29131] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 29131,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 556,
					["nome"] = "Kreshtak",
					["debuff_uptime_targets"] = {
					},
					["spec"] = 71,
					["grupo"] = true,
					["spell_cast"] = {
						[11578] = 2,
						[20572] = 1,
						[18499] = 1,
						[54758] = 2,
						[7384] = 12,
						[7386] = 12,
						[47465] = 4,
						[28507] = 1,
						[47520] = 6,
						[47486] = 11,
						[46924] = 1,
						[50622] = 7,
						[47450] = 3,
						[2687] = 1,
						[12328] = 1,
						[47475] = 4,
					},
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 625,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["serial"] = "Player-4477-02C03342",
					["aID"] = "4477-02C03342",
				}, -- [6]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[42891] = {
								["refreshamt"] = 2,
								["activedamt"] = 0,
								["appliedamt"] = 5,
								["id"] = 42891,
								["uptime"] = 57,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47610] = {
								["refreshamt"] = 14,
								["activedamt"] = 0,
								["appliedamt"] = 5,
								["id"] = 47610,
								["uptime"] = 87,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[12654] = {
								["refreshamt"] = 49,
								["activedamt"] = 0,
								["appliedamt"] = 39,
								["id"] = 12654,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[42926] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 8,
								["id"] = 42926,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[22959] = {
								["id"] = 22959,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[55360] = {
								["refreshamt"] = 4,
								["activedamt"] = 2,
								["appliedamt"] = 24,
								["id"] = 55360,
								["uptime"] = 108,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
						"Mirror Image <Tårtåros>", -- [1]
					},
					["classe"] = "MAGE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[60494] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 60494,
								["uptime"] = 30,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[55342] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 55342,
								["uptime"] = 30,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[62215] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 62215,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48108] = {
								["refreshamt"] = 3,
								["activedamt"] = 8,
								["appliedamt"] = 8,
								["id"] = 48108,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[28682] = {
								["refreshamt"] = 2,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 28682,
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[12472] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 12472,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[43046] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 43046,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54741] = {
								["refreshamt"] = 6,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 54741,
								["uptime"] = 3,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[43002] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 43002,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 462,
					["nome"] = "Tårtåros",
					["debuff_uptime_targets"] = {
					},
					["spec"] = 63,
					["grupo"] = true,
					["spell_cast"] = {
						[55342] = 1,
						[42945] = 1,
						[42873] = 3,
						[55360] = 28,
						[48108] = 11,
						[42926] = 2,
						[42859] = 1,
						[12472] = 1,
						[42950] = 1,
						[42987] = 1,
						[42891] = 7,
						[47610] = 19,
					},
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 345,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["serial"] = "Player-4477-04D7DA76",
					["aID"] = "4477-04D7DA76",
				}, -- [7]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[47864] = {
								["counter"] = 0,
								["refreshamt"] = 1,
								["activedamt"] = -3,
								["uptime"] = 1388,
								["id"] = 47864,
								["appliedamt"] = 195,
								["targets"] = {
								},
								["actived_at"] = 6702449420,
							},
							[47857] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 117,
								["id"] = 47857,
								["uptime"] = 136,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							[47865] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 5,
								["id"] = 47865,
								["uptime"] = 110,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47843] = {
								["refreshamt"] = 1,
								["counter"] = 0,
								["activedamt"] = -1,
								["uptime"] = 1412,
								["id"] = 47843,
								["appliedamt"] = 201,
								["targets"] = {
								},
								["actived_at"] = 1675595354,
							},
							[47836] = {
								["counter"] = 0,
								["refreshamt"] = 1,
								["activedamt"] = -1,
								["uptime"] = 41,
								["id"] = 47836,
								["appliedamt"] = 21,
								["targets"] = {
								},
								["actived_at"] = 1675841458,
							},
							[47860] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = 47860,
								["uptime"] = 3,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							[47820] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = 47820,
								["uptime"] = 1,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[32391] = {
								["refreshamt"] = 37,
								["activedamt"] = 0,
								["appliedamt"] = 185,
								["id"] = 32391,
								["uptime"] = 526,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[17800] = {
								["refreshamt"] = 25,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = 17800,
								["uptime"] = 107,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47855] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 6,
								["id"] = 47855,
								["uptime"] = 22,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59164] = {
								["refreshamt"] = 0,
								["activedamt"] = -1,
								["appliedamt"] = 193,
								["id"] = 59164,
								["uptime"] = 502,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47813] = {
								["refreshamt"] = 0,
								["counter"] = 0,
								["activedamt"] = -14,
								["uptime"] = 1168,
								["id"] = 47813,
								["appliedamt"] = 188,
								["targets"] = {
								},
								["actived_at"] = 16756744542,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
						"Droomon <Nedro>", -- [1]
						"Unknown <Nedro>", -- [2]
					},
					["classe"] = "WARLOCK",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[60480] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 60480,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[64371] = {
								["refreshamt"] = 3,
								["activedamt"] = 34,
								["appliedamt"] = 34,
								["id"] = 64371,
								["uptime"] = 182,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47820] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 47820,
								["uptime"] = 1,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[33702] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 33702,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[61595] = {
								["refreshamt"] = 3,
								["activedamt"] = 62,
								["appliedamt"] = 62,
								["id"] = 61595,
								["uptime"] = 282,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[17941] = {
								["refreshamt"] = 0,
								["activedamt"] = 22,
								["appliedamt"] = 22,
								["id"] = 17941,
								["uptime"] = 109,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[55637] = {
								["refreshamt"] = 0,
								["activedamt"] = 96,
								["appliedamt"] = 96,
								["id"] = 55637,
								["uptime"] = 650,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57940] = {
								["counter"] = 0,
								["activedamt"] = 202,
								["appliedamt"] = 202,
								["id"] = 57940,
								["uptime"] = 2279,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							[32245] = {
								["refreshamt"] = 0,
								["appliedamt"] = 7,
								["activedamt"] = 7,
								["uptime"] = 10,
								["id"] = 32245,
								["actived_at"] = 10054742742,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57821] = {
								["refreshamt"] = 0,
								["activedamt"] = 221,
								["appliedamt"] = 221,
								["id"] = 57821,
								["uptime"] = 2610,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60064] = {
								["refreshamt"] = 0,
								["activedamt"] = 66,
								["appliedamt"] = 66,
								["id"] = 60064,
								["uptime"] = 393,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57567] = {
								["refreshamt"] = 0,
								["appliedamt"] = 6,
								["activedamt"] = 6,
								["uptime"] = 0,
								["id"] = 57567,
								["actived_at"] = 10054742756,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47855] = {
								["refreshamt"] = 0,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 47855,
								["uptime"] = 21,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47893] = {
								["refreshamt"] = 0,
								["activedamt"] = 221,
								["appliedamt"] = 221,
								["id"] = 47893,
								["uptime"] = 2610,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47856] = {
								["counter"] = 0,
								["activedamt"] = 10,
								["appliedamt"] = 10,
								["id"] = 47856,
								["uptime"] = 23,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							[63321] = {
								["refreshamt"] = 109,
								["activedamt"] = 175,
								["appliedamt"] = 175,
								["id"] = 63321,
								["uptime"] = 1895,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 5516,
					["nome"] = "Nedro",
					["debuff_uptime_targets"] = {
					},
					["spec"] = 265,
					["grupo"] = true,
					["spell_cast"] = {
						[47864] = 199,
						[47857] = 117,
						[60480] = 1,
						[47843] = 203,
						[57946] = 161,
						[17941] = 20,
						[47820] = 1,
						[47860] = 4,
						[47836] = 25,
						[47809] = 31,
						[59164] = 200,
						[33702] = 1,
						[47855] = 6,
						[47865] = 5,
						[47856] = 7,
						[47813] = 191,
					},
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 11100,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["serial"] = "Player-4477-04D9C328",
					["aID"] = "4477-04D9C328",
				}, -- [8]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[17364] = {
								["refreshamt"] = 10,
								["activedamt"] = 0,
								["appliedamt"] = 7,
								["id"] = 17364,
								["uptime"] = 92,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[49233] = {
								["refreshamt"] = 1,
								["activedamt"] = 0,
								["appliedamt"] = 6,
								["id"] = 49233,
								["uptime"] = 77,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[49231] = {
								["refreshamt"] = 1,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = 49231,
								["uptime"] = 13,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
						"Fire Elemental Totem <Yaasi>", -- [1]
						"Greater Fire Elemental <Yaasi>", -- [2]
						"Spirit Wolf <Yaasi>", -- [3]
					},
					["classe"] = "SHAMAN",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[26297] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 26297,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[16280] = {
								["refreshamt"] = 93,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = 16280,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[30809] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 30809,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[49281] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 49281,
								["uptime"] = 106,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[58646] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 58646,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[2825] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 2825,
								["uptime"] = 40,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53817] = {
								["refreshamt"] = 103,
								["activedamt"] = 14,
								["appliedamt"] = 14,
								["id"] = 53817,
								["uptime"] = 81,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57820] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57820,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60766] = {
								["refreshamt"] = 24,
								["activedamt"] = 12,
								["appliedamt"] = 12,
								["id"] = 60766,
								["uptime"] = 69,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60302] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 60302,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57079] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57079,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60065] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 60065,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53760] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 53760,
								["uptime"] = 58,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[29178] = {
								["refreshamt"] = 9,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 29178,
								["uptime"] = 77,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[30823] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 30823,
								["uptime"] = 30,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[58875] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 58875,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59620] = {
								["refreshamt"] = 4,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 59620,
								["uptime"] = 52,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[8515] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = 8515,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 282,
					["nome"] = "Yaasi",
					["debuff_uptime_targets"] = {
					},
					["spec"] = 263,
					["grupo"] = true,
					["spell_cast"] = {
						[2894] = 1,
						[58734] = 1,
						[49281] = 1,
						[60103] = 10,
						[2825] = 1,
						[49231] = 8,
						[66842] = 1,
						[49233] = 7,
						[17364] = 12,
						[8512] = 1,
						[49238] = 11,
						[51533] = 1,
						[49271] = 2,
						[26297] = 1,
						[61657] = 12,
						[30823] = 2,
						[58643] = 1,
						[58757] = 1,
					},
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 1122,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["serial"] = "Player-4477-03B262D2",
					["aID"] = "4477-03B262D2",
				}, -- [9]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[48672] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 5,
								["id"] = 48672,
								["uptime"] = 76,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57970] = {
								["refreshamt"] = 71,
								["activedamt"] = 0,
								["appliedamt"] = 8,
								["id"] = 57970,
								["uptime"] = 108,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48676] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = 48676,
								["uptime"] = 18,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57724] = {
								["refreshamt"] = 1,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57724,
								["uptime"] = 100,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[58683] = {
								["refreshamt"] = 37,
								["activedamt"] = 0,
								["appliedamt"] = 31,
								["id"] = 58683,
								["uptime"] = 69,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["cooldowns_defensive"] = 2.012029,
					["pets"] = {
					},
					["classe"] = "ROGUE",
					["cooldowns_defensive_targets"] = {
						["Grizzmo"] = 2,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[48659] = {
								["id"] = 48659,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[13877] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 13877,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53760] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 53760,
								["uptime"] = 111,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54758] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 54758,
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60233] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 60233,
								["uptime"] = 45,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[11305] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 11305,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[1784] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 1784,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59620] = {
								["refreshamt"] = 10,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 59620,
								["uptime"] = 74,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[6774] = {
								["refreshamt"] = 4,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 6774,
								["uptime"] = 107,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59628] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 59628,
								["uptime"] = 6,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57934] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 57934,
								["uptime"] = 2,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[51690] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 51690,
								["uptime"] = 2,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[398488] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 398488,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[31224] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 31224,
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54861] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 54861,
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[13750] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 13750,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 371,
					["cooldowns_defensive_spells"] = {
						["_ActorTable"] = {
							[31224] = {
								["id"] = 31224,
								["targets"] = {
									["Grizzmo"] = 1,
								},
								["counter"] = 1,
							},
							[26889] = {
								["id"] = 26889,
								["targets"] = {
									["Grizzmo"] = 1,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_targets"] = {
					},
					["debuff_uptime_targets"] = {
					},
					["spec"] = 260,
					["grupo"] = true,
					["spell_cast"] = {
						[48659] = 0,
						[13877] = 1,
						[51690] = 1,
						[54758] = 1,
						[48676] = 1,
						[11305] = 1,
						[48638] = 39,
						[31224] = 1,
						[6774] = 6,
						[26889] = 1,
						[57934] = 0,
						[48672] = 5,
						[398488] = 1,
						[51723] = 5,
						[13750] = 1,
						[48668] = 0,
					},
					["buff_uptime"] = 439,
					["nome"] = "Grizzmo",
					["last_event"] = 0,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["serial"] = "Player-4477-044DA6CD",
					["aID"] = "4477-044DA6CD",
				}, -- [10]
				{
					["fight_component"] = true,
					["classe"] = "PET",
					["ownerName"] = "Nedro",
					["nome"] = "Droomon <Nedro>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 4369,
					["aID"] = "Pet-0-4446-571-12108-417-01007B88D5",
					["spell_cast"] = {
						[54053] = 895,
					},
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["pets"] = {
					},
					["serial"] = "Pet-0-4446-571-12108-417-01007B88D5",
					["tipo"] = 4,
				}, -- [11]
				{
					["flag_original"] = 2632,
					["boss_fight_component"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["nome"] = "Tempest Minion",
					["classe"] = "UNKNOW",
					["aID"] = "33998",
					["spell_cast"] = {
						[64363] = 35,
					},
					["serial"] = "Creature-0-4447-624-31557-33998-00005BB316",
					["tipo"] = 4,
				}, -- [12]
				{
					["flag_original"] = 8466,
					["classe"] = "PET",
					["ownerName"] = "Yaasi",
					["nome"] = "Fire Elemental Totem <Yaasi>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["tipo"] = 4,
					["spell_cast"] = {
						[32982] = 1,
					},
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["pets"] = {
					},
					["serial"] = "Creature-0-4447-624-31557-15439-00005BB4D8",
					["aID"] = "15439",
				}, -- [13]
				{
					["flag_original"] = 8466,
					["classe"] = "PET",
					["ownerName"] = "Tårtåros",
					["nome"] = "Mirror Image <Tårtåros>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["tipo"] = 4,
					["spell_cast"] = {
						[59637] = 11,
						[59638] = 24,
					},
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["pets"] = {
					},
					["serial"] = "Creature-0-4447-624-31557-31216-00015BB4D8",
					["aID"] = "31216",
				}, -- [14]
				{
					["flag_original"] = 8466,
					["classe"] = "PET",
					["ownerName"] = "Yaasi",
					["nome"] = "Greater Fire Elemental <Yaasi>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["tipo"] = 4,
					["spell_cast"] = {
						[57984] = 12,
						[12470] = 12,
					},
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["pets"] = {
					},
					["serial"] = "Creature-0-4447-624-31557-15438-00005BB4D8",
					["aID"] = "15438",
				}, -- [15]
				{
					["flag_original"] = 68168,
					["boss_fight_component"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["nome"] = "Emalon the Storm Watcher",
					["classe"] = "UNKNOW",
					["aID"] = "33993",
					["spell_cast"] = {
						[64216] = 2,
						[64218] = 2,
						[64213] = 4,
					},
					["serial"] = "Creature-0-4447-624-31557-33993-00005BB316",
					["tipo"] = 4,
				}, -- [16]
				{
					["flag_original"] = 4370,
					["classe"] = "PET",
					["ownerName"] = "Yaasi",
					["nome"] = "Spirit Wolf <Yaasi>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["tipo"] = 4,
					["spell_cast"] = {
						[58875] = 2,
					},
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["pets"] = {
					},
					["serial"] = "Creature-0-4447-624-31557-29264-00005BB4D9",
					["aID"] = "29264",
				}, -- [17]
				{
					["flag_original"] = 2632,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 8,
					["spellschool"] = 1,
					["nome"] = "Dazed",
					["aID"] = "34049",
					["damage_spellid"] = 1604,
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "Tempest Minion",
					["last_event"] = 0,
					["serial"] = "Creature-0-4447-624-31557-34049-00005BB50B",
					["debuff_uptime_targets"] = {
						["Nedro"] = {
							["uptime"] = 4,
							["appliedamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Kreshtak"] = {
							["uptime"] = 4,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [18]
				{
					["monster"] = true,
					["nome"] = "Archavon the Stone Watcher",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[58678] = 0,
						[58960] = 0,
						[58663] = 0,
					},
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["serial"] = "Vehicle-0-4447-624-31557-31125-00005BB316",
					["aID"] = "",
				}, -- [19]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 1,
					["nome"] = "Rock Shards",
					["debuff_uptime_targets"] = {
					},
					["serial"] = "Vehicle-0-4447-624-31557-31125-00005BB316",
					["tipo"] = 4,
					["last_event"] = 0,
					["damage_twin"] = "Archavon the Stone Watcher",
					["boss_fight_component"] = true,
					["damage_spellid"] = 58678,
					["aID"] = "",
				}, -- [20]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 8,
					["nome"] = "Choking Cloud",
					["debuff_uptime_targets"] = {
					},
					["serial"] = "Vehicle-0-4447-624-31557-31125-00005BB316",
					["tipo"] = 4,
					["last_event"] = 0,
					["damage_twin"] = "Archavon the Stone Watcher",
					["boss_fight_component"] = true,
					["damage_spellid"] = 58965,
					["aID"] = "",
				}, -- [21]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 1,
					["nome"] = "Stomp",
					["debuff_uptime_targets"] = {
					},
					["serial"] = "Vehicle-0-4447-624-31557-31125-00005BB316",
					["tipo"] = 4,
					["last_event"] = 0,
					["damage_twin"] = "Archavon the Stone Watcher",
					["boss_fight_component"] = true,
					["damage_spellid"] = 58663,
					["aID"] = "",
				}, -- [22]
				{
					["flag_original"] = 68168,
					["nome"] = "Brittle Revenant",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["aID"] = "30160",
					["spell_cast"] = {
						[50731] = 3,
					},
					["tipo"] = 4,
					["serial"] = "Creature-0-4448-571-6723-30160-00005E0414",
					["monster"] = true,
				}, -- [23]
				{
					["flag_original"] = 68168,
					["nome"] = "Niffelem Forefather",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["spell_cast"] = {
						[57454] = 21,
					},
					["last_event"] = 0,
					["aID"] = "29974",
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["tipo"] = 4,
					["serial"] = "Creature-0-4448-571-6723-29974-00005DF175",
					["monster"] = true,
				}, -- [24]
				{
					["monster"] = true,
					["nome"] = "Seething Revenant",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["pets"] = {
					},
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["spell_cast"] = {
						[56620] = 3,
					},
					["aID"] = "30387",
					["serial"] = "Creature-0-5563-571-10-30387-00005F8300",
					["fight_component"] = true,
				}, -- [25]
				{
					["flag_original"] = 68168,
					["nome"] = "Jotunheim Warrior",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["aID"] = "29880",
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["spell_cast"] = {
						[23262] = 4,
						[43410] = 1,
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-5563-571-5-29880-00006214B4",
					["fight_component"] = true,
				}, -- [26]
				{
					["flag_original"] = 68168,
					["nome"] = "Mjordin Combatant",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["last_event"] = 0,
					["spell_cast"] = {
						[15578] = 11,
						[61227] = 24,
						[32736] = 4,
						[49807] = 7,
						[61343] = 6,
						[50370] = 7,
					},
					["aID"] = "30037",
					["serial"] = "Creature-0-5563-571-5-30037-0000622243",
					["fight_component"] = true,
				}, -- [27]
				{
					["flag_original"] = 68168,
					["nome"] = "Onslaught Gryphon Rider",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["last_event"] = 0,
					["spell_cast"] = {
						[40652] = 16,
						[54617] = 23,
					},
					["aID"] = "29333",
					["serial"] = "Creature-0-5563-571-5-29333-00006223F1",
					["fight_component"] = true,
				}, -- [28]
				{
					["flag_original"] = 4369,
					["last_event"] = 0,
					["ownerName"] = "Nedro",
					["nome"] = "Unknown <Nedro>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["aID"] = "Pet-0-5563-571-5-417-08007B88D5",
					["tipo"] = 4,
					["classe"] = "PET",
					["serial"] = "Pet-0-5563-571-5-417-08007B88D5",
					["spell_cast"] = {
						[23832] = 6,
						[54053] = 22,
					},
				}, -- [29]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["spells_cast_timeline"] = {
		},
		["tempo_start"] = 1675343164,
		["cleu_timeline"] = {
		},
		["alternate_power"] = {
		},
		["combat_counter"] = 18,
		["totals"] = {
			17631673.52731001, -- [1]
			1017421.627098001, -- [2]
			{
				46.005151, -- [1]
				[0] = 728885.670664,
				["alternatepower"] = 0,
				[3] = 541.007301,
				[6] = 755.9953709999999,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 1.005197,
				["cooldowns_defensive"] = 8.013814,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "14:04:14",
		["end_time"] = 693709.057,
		["cleu_events"] = {
			["n"] = 1,
		},
		["totals_grupo"] = {
			11069160.189925, -- [1]
			876077.9319850006, -- [2]
			{
				46.005151, -- [1]
				[0] = 605482.8870880001,
				["alternatepower"] = 0,
				[3] = 541.007301,
				[6] = 756.002405,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 1.005197,
				["cooldowns_defensive"] = 8.013814,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["frags"] = {
		},
		["hasSaved"] = true,
		["segments_added"] = {
			{
				["elapsed"] = 21.86699999996927,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "08:32:10",
			}, -- [1]
			{
				["elapsed"] = 22.88300000003073,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "08:31:29",
			}, -- [2]
			{
				["elapsed"] = 14.55000000004657,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "08:30:58",
			}, -- [3]
			{
				["elapsed"] = 115.1519999998855,
				["type"] = 0,
				["name"] = "Onslaught Harbor Guard",
				["clock"] = "08:28:28",
			}, -- [4]
			{
				["elapsed"] = 11.33299999998417,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "08:28:05",
			}, -- [5]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:23:19",
			}, -- [6]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:23:18",
			}, -- [7]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:23:12",
			}, -- [8]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:23:08",
			}, -- [9]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:23:03",
			}, -- [10]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:23:02",
			}, -- [11]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:58",
			}, -- [12]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:54",
			}, -- [13]
			{
				["elapsed"] = 1.001000000047498,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:50",
			}, -- [14]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:47",
			}, -- [15]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:46",
			}, -- [16]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:44",
			}, -- [17]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:41",
			}, -- [18]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:36",
			}, -- [19]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:34",
			}, -- [20]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:33",
			}, -- [21]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:28",
			}, -- [22]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:24",
			}, -- [23]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:19",
			}, -- [24]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:17",
			}, -- [25]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:16",
			}, -- [26]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:12",
			}, -- [27]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:10",
			}, -- [28]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:08",
			}, -- [29]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:07",
			}, -- [30]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:04",
			}, -- [31]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:03",
			}, -- [32]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "08:22:02",
			}, -- [33]
			{
				["elapsed"] = 24.26800000004005,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "08:20:32",
			}, -- [34]
			{
				["elapsed"] = 23.0339999999851,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "08:19:46",
			}, -- [35]
			{
				["elapsed"] = 20.75099999993108,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "08:19:05",
			}, -- [36]
			{
				["elapsed"] = 29.5,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "08:18:05",
			}, -- [37]
			{
				["elapsed"] = 21.06700000003912,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "08:17:03",
			}, -- [38]
			{
				["elapsed"] = 21.31700000003912,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "08:16:28",
			}, -- [39]
			{
				["elapsed"] = 10.55000000004657,
				["type"] = 0,
				["name"] = "Jotunheim Warrior",
				["clock"] = "08:15:51",
			}, -- [40]
		},
		["data_fim"] = "08:32:32",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage_section"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage"] = {
			},
		},
		["start_time"] = 691103.004999999,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["last_events_tables"] = {
		},
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["last_encounter"] = "Emalon the Storm Watcher",
	["nick_tag_cache"] = {
		["nextreset"] = 1676620187,
		["last_version"] = 15,
	},
	["announce_cooldowns"] = {
		["ignored_cooldowns"] = {
		},
		["enabled"] = false,
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["cached_roles"] = {
		["Player-4477-03B26A55"] = "HEALER",
		["Player-4477-044DA6CD"] = "DAMAGER",
		["Player-4477-02C03342"] = "DAMAGER",
		["Player-4477-04D7DA76"] = "DAMAGER",
		["Player-4477-0430029B"] = "DAMAGER",
		["Player-4477-04991245"] = "TANK",
		["Player-4477-03B262D2"] = "DAMAGER",
		["Player-4477-04BC0BBF"] = "TANK",
		["Player-4477-044E7D32"] = "HEALER",
		["Player-4477-04D9C328"] = "DAMAGER",
	},
	["cached_specs"] = {
		["Player-4477-04D9C328"] = 265,
	},
}
