
ThreatPlatesDB = {
	["char"] = {
		["Nedro - Ashbringer"] = {
			["welcome"] = true,
		},
		["Resonatorr - Venoxis"] = {
			["welcome"] = true,
		},
		["Stoc - Everlook"] = {
			["welcome"] = true,
		},
		["Postorc - Ashbringer"] = {
			["welcome"] = true,
		},
		["Hoddl - Ewige Warte"] = {
			["welcome"] = true,
		},
		["Gdgfgfdh - Venoxis"] = {
			["welcome"] = true,
		},
		["Teststsws - Venoxis"] = {
			["welcome"] = true,
		},
		["Knallus - Ewige Warte"] = {
			["welcome"] = true,
		},
		["Schwerlast - Everlook"] = {
			["welcome"] = true,
		},
		["Neilyoung - Everlook"] = {
			["welcome"] = true,
		},
		["Postorc - Everlook"] = {
			["welcome"] = true,
		},
		["Restset - Razorfen"] = {
			["welcome"] = true,
		},
		["Resonator - Ewige Warte"] = {
			["welcome"] = true,
		},
		["Felton - Lakeshire"] = {
			["welcome"] = true,
		},
		["Radorn - Venoxis"] = {
			["welcome"] = true,
		},
		["Resonatorr - Transcendence"] = {
			["welcome"] = true,
		},
		["Drushnak - Lakeshire"] = {
			["welcome"] = true,
		},
		["Crimora - Venoxis"] = {
			["welcome"] = true,
		},
		["Nedro - Transcendence"] = {
			["welcome"] = true,
		},
		["Fearleader - Lucifron"] = {
			["welcome"] = true,
		},
		["Hoddl - Everlook"] = {
			["welcome"] = true,
		},
		["Saucier - Everlook"] = {
			["welcome"] = true,
		},
		["Skatron - Ashbringer"] = {
			["welcome"] = true,
		},
		["Dfsgdsgds - Venoxis"] = {
			["welcome"] = true,
		},
		["Giselheer - Everlook"] = {
			["welcome"] = true,
		},
		["Neilyoung - Ashbringer"] = {
			["welcome"] = true,
		},
		["Crimora - Everlook"] = {
			["welcome"] = true,
		},
		["Biologe - Everlook"] = {
			["welcome"] = true,
		},
		["Drushnak - Mograine"] = {
			["welcome"] = true,
		},
		["Explorerr - Venoxis"] = {
			["welcome"] = true,
		},
		["Postbotee - Everlook"] = {
			["welcome"] = true,
		},
		["Akuhstiker - Transcendence"] = {
			["welcome"] = true,
		},
		["Privee - Everlook"] = {
			["welcome"] = true,
		},
		["Drushnak - Transcendence"] = {
			["welcome"] = true,
		},
		["Sparbier - Ashbringer"] = {
			["welcome"] = true,
		},
		["Pädagoge - Everlook"] = {
			["welcome"] = true,
		},
		["Testdgfz - Venoxis"] = {
			["welcome"] = true,
		},
		["Ragoûtfin - Everlook"] = {
			["welcome"] = true,
		},
		["Schwerlast - Ashbringer"] = {
			["welcome"] = true,
		},
		["Tinyevil - Lakeshire"] = {
			["welcome"] = true,
		},
		["Postbotee - Ashbringer"] = {
			["welcome"] = true,
		},
		["Skatron - Everlook"] = {
			["welcome"] = true,
		},
		["Drushnak - Ashbringer"] = {
			["welcome"] = true,
		},
		["Sibo - Lakeshire"] = {
			["welcome"] = true,
		},
		["Resonator - Everlook"] = {
			["welcome"] = true,
		},
		["Knallus - Everlook"] = {
			["welcome"] = true,
		},
		["Drushnak - Venoxis"] = {
			["welcome"] = true,
		},
		["Sparbier - Everlook"] = {
			["welcome"] = true,
		},
		["Testtata - Venoxis"] = {
			["welcome"] = true,
		},
		["Nedro - Venoxis"] = {
			["welcome"] = true,
		},
		["Clintfastfud - Everlook"] = {
			["welcome"] = true,
		},
		["Lastenasd - Everlook"] = {
			["welcome"] = true,
		},
	},
	["profileKeys"] = {
		["Nedro - Ashbringer"] = "Default",
		["Resonatorr - Venoxis"] = "Default",
		["Stoc - Everlook"] = "Default",
		["Postorc - Ashbringer"] = "Default",
		["Hoddl - Ewige Warte"] = "Default",
		["Gdgfgfdh - Venoxis"] = "Default",
		["Teststsws - Venoxis"] = "Default",
		["Knallus - Ewige Warte"] = "Default",
		["Schwerlast - Everlook"] = "Default",
		["Neilyoung - Everlook"] = "Default",
		["Postorc - Everlook"] = "Default",
		["Restset - Razorfen"] = "Default",
		["Resonator - Ewige Warte"] = "Default",
		["Felton - Lakeshire"] = "Default",
		["Radorn - Venoxis"] = "Default",
		["Resonatorr - Transcendence"] = "Default",
		["Drushnak - Lakeshire"] = "Default",
		["Crimora - Venoxis"] = "Default",
		["Nedro - Transcendence"] = "Default",
		["Fearleader - Lucifron"] = "Default",
		["Hoddl - Everlook"] = "Default",
		["Saucier - Everlook"] = "Default",
		["Skatron - Ashbringer"] = "Default",
		["Dfsgdsgds - Venoxis"] = "Default",
		["Giselheer - Everlook"] = "Default",
		["Neilyoung - Ashbringer"] = "Default",
		["Crimora - Everlook"] = "Default",
		["Biologe - Everlook"] = "Default",
		["Drushnak - Mograine"] = "Default",
		["Explorerr - Venoxis"] = "Default",
		["Postbotee - Everlook"] = "Default",
		["Akuhstiker - Transcendence"] = "Default",
		["Privee - Everlook"] = "Default",
		["Drushnak - Transcendence"] = "Default",
		["Sparbier - Ashbringer"] = "Default",
		["Pädagoge - Everlook"] = "Default",
		["Testdgfz - Venoxis"] = "Default",
		["Ragoûtfin - Everlook"] = "Default",
		["Schwerlast - Ashbringer"] = "Default",
		["Tinyevil - Lakeshire"] = "Default",
		["Postbotee - Ashbringer"] = "Default",
		["Skatron - Everlook"] = "Default",
		["Drushnak - Ashbringer"] = "Default",
		["Sibo - Lakeshire"] = "Default",
		["Resonator - Everlook"] = "Default",
		["Knallus - Everlook"] = "Default",
		["Drushnak - Venoxis"] = "Default",
		["Sparbier - Everlook"] = "Default",
		["Testtata - Venoxis"] = "Default",
		["Nedro - Venoxis"] = "Default",
		["Clintfastfud - Everlook"] = "Default",
		["Lastenasd - Everlook"] = "Default",
	},
	["global"] = {
		["version"] = "11.1.13",
	},
	["profiles"] = {
		["Default"] = {
			["AuraWidget"] = {
				["Debuffs"] = {
					["FilterBySpell"] = {
						"", -- [1]
						"", -- [2]
					},
					["FilterMode"] = "None",
				},
				["ShowOmniCC"] = false,
				["ShowCooldownSpiral"] = true,
				["ShowInHeadlineView"] = true,
			},
			["settings"] = {
				["frame"] = {
					["height"] = 52.875,
					["width"] = 154,
				},
			},
		},
	},
}
