
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 3,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004229,
							["on_hold"] = false,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 55,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 55.004229,
							["aID"] = "4477-04C42F48",
							["dps_started"] = false,
							["total"] = 55.004229,
							["classe"] = "ROGUE",
							["serial"] = "Player-4477-04C42F48",
							["nome"] = "Dfsgdsgds",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 10,
										["g_amt"] = 1,
										["n_max"] = 6,
										["targets"] = {
											["Scheckiger Eber"] = 39,
										},
										["n_dmg"] = 24,
										["n_min"] = 2,
										["g_dmg"] = 5,
										["counter"] = 10,
										["total"] = 39,
										["c_max"] = 10,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 10,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 7,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Scheckiger Eber"] = 8,
										},
										["n_dmg"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Scheckiger Eber"] = 8,
										},
										["n_dmg"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["end_time"] = 1669212481,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 8.004229,
							["start_time"] = 1669212473,
							["delay"] = 0,
							["last_event"] = 1669212480,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.007959,
							["damage_from"] = {
								["Dfsgdsgds"] = true,
							},
							["targets"] = {
								["Dfsgdsgds"] = 8,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 8.007959,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212481,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["Dfsgdsgds"] = 8,
										},
										["n_dmg"] = 8,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "3098",
							["total"] = 8.007959,
							["serial"] = "Creature-0-4479-1-117-3098-00007E1213",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212479,
							["damage_taken"] = 55.007959,
							["start_time"] = 1669212473,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 3,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 3,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 3,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Dfsgdsgds",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["spell_cast"] = {
								[1752] = 1,
								[2098] = 1,
							},
							["tipo"] = 4,
							["aID"] = "4477-04C42F48",
							["serial"] = "Player-4477-04C42F48",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 3,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Dfsgdsgds"] = true,
				},
				["raid_roster_indexed"] = {
					"Dfsgdsgds", -- [1]
				},
				["CombatStartedAt"] = 1021366.366,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 6,
				["playing_solo"] = true,
				["totals"] = {
					63, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:08:02",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 8.099999999976717,
				["CombatEndedAt"] = 1021374.466,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:07:54",
				["end_time"] = 1021374.466,
				["combat_id"] = 3,
				["tempo_start"] = 1669212473,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					55, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Dfsgdsgds"] = 55.004229,
						}, -- [1]
					},
				},
				["start_time"] = 1021366.366,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [1]
			{
				{
					["combatId"] = 2,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.00864,
							["damage_from"] = {
								["Dfsgdsgds"] = true,
							},
							["targets"] = {
								["Dfsgdsgds"] = 3,
							},
							["pets"] = {
							},
							["total"] = 3.00864,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 3.00864,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212470,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1,
										["targets"] = {
											["Dfsgdsgds"] = 3,
										},
										["n_dmg"] = 3,
										["n_min"] = 1,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 3,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "3098",
							["serial"] = "Creature-0-4479-1-117-3098-00007E1208",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212468,
							["damage_taken"] = 58.00864,
							["start_time"] = 1669212464,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00219,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 58,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 58.00219,
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1669212470,
							["friendlyfire_total"] = 0,
							["aID"] = "4477-04C42F48",
							["nome"] = "Dfsgdsgds",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 18,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 25,
										},
										["n_dmg"] = 7,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 25,
										["c_max"] = 9,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 4,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Scheckiger Eber"] = 16,
										},
										["n_dmg"] = 16,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Scheckiger Eber"] = 17,
										},
										["n_dmg"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["total"] = 58.00219,
							["serial"] = "Player-4477-04C42F48",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212469,
							["damage_taken"] = 3.00219,
							["start_time"] = 1669212464,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 2,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 2,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 2,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Dfsgdsgds",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["spell_cast"] = {
								[1752] = 1,
								[2098] = 1,
							},
							["tipo"] = 4,
							["aID"] = "4477-04C42F48",
							["serial"] = "Player-4477-04C42F48",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 2,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Dfsgdsgds"] = true,
				},
				["raid_roster_indexed"] = {
					"Dfsgdsgds", -- [1]
				},
				["tempo_start"] = 1669212464,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 5,
				["playing_solo"] = true,
				["totals"] = {
					61, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					58, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:07:51",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 1021363.516,
				["CombatEndedAt"] = 1021363.516,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Dfsgdsgds"] = 58.00219,
						}, -- [1]
					},
				},
				["end_time"] = 1021363.516,
				["combat_id"] = 2,
				["cleu_events"] = {
					["n"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["overall_added"] = true,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "15:07:44",
				["start_time"] = 1021357.032,
				["TimeData"] = {
				},
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
			}, -- [2]
			{
				{
					["combatId"] = 1,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004326,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 57,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 57.004326,
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1669212459,
							["friendlyfire_total"] = 0,
							["aID"] = "4477-04C42F48",
							["nome"] = "Dfsgdsgds",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 10,
										["g_amt"] = 1,
										["n_max"] = 4,
										["targets"] = {
											["Scheckiger Eber"] = 26,
										},
										["n_dmg"] = 11,
										["n_min"] = 2,
										["g_dmg"] = 5,
										["counter"] = 7,
										["total"] = 26,
										["c_max"] = 10,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 10,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Scheckiger Eber"] = 16,
										},
										["n_dmg"] = 16,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Scheckiger Eber"] = 15,
										},
										["n_dmg"] = 15,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["total"] = 57.004326,
							["serial"] = "Player-4477-04C42F48",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212458,
							["damage_taken"] = 6.004326,
							["start_time"] = 1669212454,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.006469,
							["damage_from"] = {
								["Dfsgdsgds"] = true,
							},
							["targets"] = {
								["Dfsgdsgds"] = 6,
							},
							["pets"] = {
							},
							["total"] = 6.006469,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6.006469,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212459,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["Dfsgdsgds"] = 6,
										},
										["n_dmg"] = 6,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 6,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "3098",
							["serial"] = "Creature-0-4479-1-117-3098-00007E2913",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212458,
							["damage_taken"] = 57.006469,
							["start_time"] = 1669212454,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 1,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 1,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 1,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "Dfsgdsgds",
							["buff_uptime"] = 5,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["last_event"] = 1669212459,
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[26297] = {
										["activedamt"] = 1,
										["id"] = 26297,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04C42F48",
							["aID"] = "4477-04C42F48",
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 1,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Dfsgdsgds"] = true,
				},
				["raid_roster_indexed"] = {
					"Dfsgdsgds", -- [1]
				},
				["CombatStartedAt"] = 1021357.032,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 4,
				["playing_solo"] = true,
				["totals"] = {
					63, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:07:39",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 4.850000000093132,
				["CombatEndedAt"] = 1021351.749,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:07:34",
				["end_time"] = 1021351.749,
				["combat_id"] = 1,
				["tempo_start"] = 1669212454,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					57, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Dfsgdsgds"] = 57.004326,
						}, -- [1]
					},
				},
				["start_time"] = 1021346.899,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [3]
		},
	},
	["ocd_tracker"] = {
		["enabled"] = false,
		["current_cooldowns"] = {
		},
		["lines_per_column"] = 12,
		["show_options"] = false,
		["filters"] = {
			["defensive-raid"] = false,
			["ofensive"] = true,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["width"] = 120,
		["height"] = 18,
		["framme_locked"] = false,
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["cooldowns"] = {
		},
		["pos"] = {
		},
	},
	["last_version"] = "3.4.0 10259",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["on_death_menu"] = false,
	["cached_talents"] = {
	},
	["last_instance_id"] = 0,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Dfsgdsgds-Venoxis",
	["last_realversion"] = 146,
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["disable_gouge"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["useclasscolors"] = false,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["last_section_selected"] = "main",
			["author"] = "Terciob",
			["window_scale"] = 1,
			["hide_on_combat"] = false,
			["show_icon"] = 5,
			["opened"] = 0,
			["encounter_timers_dbm"] = {
			},
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["grow_direction"] = "right",
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["scale"] = 1,
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 338.4489600712638,
				["radius"] = 160,
				["hide"] = false,
			},
			["point"] = "CENTER",
			["arrow_anchor_x"] = 0,
			["y"] = -1.52587890625e-05,
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_height"] = 20,
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["use_spark"] = true,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["main_frame_strata"] = "LOW",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -1.52587890625e-05,
				["x"] = -3.0517578125e-05,
				["update_speed"] = 0.05,
				["size"] = 32,
				["attribute_type"] = 1,
			},
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["arrow_anchor_y"] = 0,
			["font_size"] = 10,
			["main_frame_locked"] = false,
			["author"] = "Details! Team",
		},
	},
	["last_day"] = "23",
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = false,
			["isLocked"] = false,
			["snap"] = {
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 0,
					["x"] = 0,
					["w"] = 310.0000610351563,
					["h"] = 157.9999847412109,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["last_instance_time"] = 0,
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["cached_roles"] = {
	},
	["ignore_nicktag"] = false,
	["combat_id"] = 3,
	["savedStyles"] = {
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1670508430,
		["last_version"] = 15,
	},
	["combat_counter"] = 6,
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.017776,
					["aID"] = "4477-04C42F48",
					["damage_from"] = {
						["Scheckiger Eber"] = true,
					},
					["targets"] = {
						["Scheckiger Eber"] = 170,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 170.017776,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1669212459,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "Dfsgdsgds",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 38,
								["g_amt"] = 2,
								["n_max"] = 6,
								["targets"] = {
									["Scheckiger Eber"] = 90,
								},
								["n_dmg"] = 42,
								["n_min"] = 0,
								["g_dmg"] = 10,
								["counter"] = 23,
								["total"] = 90,
								["c_max"] = 10,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 3,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 13,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[1752] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["Scheckiger Eber"] = 40,
								},
								["n_dmg"] = 40,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 40,
								["c_max"] = 0,
								["id"] = 1752,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[2098] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 17,
								["targets"] = {
									["Scheckiger Eber"] = 40,
								},
								["n_dmg"] = 40,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 40,
								["c_max"] = 0,
								["id"] = 2098,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["grupo"] = true,
					["total"] = 170.017776,
					["serial"] = "Player-4477-04C42F48",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 17.017776,
					["start_time"] = 1669212437,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [1]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.026244,
					["aID"] = "3098",
					["damage_from"] = {
						["Dfsgdsgds"] = true,
					},
					["targets"] = {
						["Dfsgdsgds"] = 17,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 17.026244,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1669212459,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["nome"] = "Scheckiger Eber",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["Dfsgdsgds"] = 17,
								},
								["n_dmg"] = 17,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 17,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire"] = {
					},
					["total"] = 17.026244,
					["serial"] = "Creature-0-4479-1-117-3098-00007E2913",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 170.026244,
					["start_time"] = 1669212437,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [2]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["buff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["nome"] = "Dfsgdsgds",
					["grupo"] = true,
					["buff_uptime"] = 5,
					["spell_cast"] = {
						[1752] = 4,
						[2098] = 3,
					},
					["pets"] = {
					},
					["classe"] = "ROGUE",
					["tipo"] = 4,
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[26297] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 26297,
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["serial"] = "Player-4477-04C42F48",
					["aID"] = "4477-04C42F48",
				}, -- [1]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["tempo_start"] = 1669212454,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["combat_counter"] = 3,
		["spells_cast_timeline"] = {
		},
		["totals"] = {
			187.033813, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "15:07:34",
		["end_time"] = 1021374.466,
		["cleu_events"] = {
			["n"] = 1,
		},
		["segments_added"] = {
			{
				["elapsed"] = 8.099999999976717,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:07:54",
			}, -- [1]
			{
				["elapsed"] = 6.484000000054948,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:07:44",
			}, -- [2]
			{
				["elapsed"] = 4.850000000093132,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:07:34",
			}, -- [3]
		},
		["totals_grupo"] = {
			170.010745, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["frags"] = {
		},
		["data_fim"] = "15:08:02",
		["overall_enemy_name"] = "Scheckiger Eber",
		["CombatSkillCache"] = {
		},
		["cleu_timeline"] = {
		},
		["start_time"] = 1021355.032,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
			["damage"] = {
			},
		},
	},
	["character_data"] = {
		["logons"] = 1,
	},
	["force_font_outline"] = "",
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
	},
}
