
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 2,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007117,
							["on_hold"] = false,
							["damage_from"] = {
							},
							["targets"] = {
								["Katze"] = 8,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 8.007117,
							["aID"] = "4477-04C42ECA",
							["dps_started"] = false,
							["total"] = 8.007117,
							["classe"] = "ROGUE",
							["serial"] = "Player-4477-04C42ECA",
							["nome"] = "Teststsws",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Katze"] = 8,
										},
										["n_dmg"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["end_time"] = 1669212136,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.007117,
							["start_time"] = 1669212134,
							["delay"] = 0,
							["last_event"] = 1669212134,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.006396,
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Teststsws"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006396,
							["aID"] = "6368",
							["dps_started"] = false,
							["total"] = 0.006396,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-4479-530-129-6368-00027D853C",
							["nome"] = "Katze",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["end_time"] = 1669212136,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 8.006396,
							["start_time"] = 1669212136,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 2,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 2,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 2,
					["tipo"] = 9,
					["_ActorTable"] = {
					},
				}, -- [4]
				{
					["combatId"] = 2,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Teststsws"] = true,
				},
				["raid_roster_indexed"] = {
					"Teststsws", -- [1]
				},
				["tempo_start"] = 1669212134,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 5,
				["playing_solo"] = true,
				["totals"] = {
					8, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					8, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:02:16",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Katze",
				["TotalElapsedCombatTime"] = 1021028.927,
				["CombatEndedAt"] = 1021028.927,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Teststsws"] = 8.007117,
						}, -- [1]
					},
				},
				["end_time"] = 1021028.927,
				["combat_id"] = 2,
				["cleu_events"] = {
					["n"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["overall_added"] = true,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "15:02:14",
				["start_time"] = 1021026.894,
				["TimeData"] = {
				},
				["frags"] = {
					["Katze"] = 1,
				},
			}, -- [1]
			{
				{
					["combatId"] = 1,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.001107,
							["damage_from"] = {
								["Teststsws"] = true,
							},
							["targets"] = {
								["Teststsws"] = 4,
							},
							["pets"] = {
							},
							["total"] = 4.001107,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4.001107,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212130,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Manawyrm",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["Teststsws"] = 4,
										},
										["n_dmg"] = 4,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 4,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "15274",
							["serial"] = "Creature-0-4479-530-129-15274-00007E15B9",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212127,
							["damage_taken"] = 42.001107,
							["start_time"] = 1669212125,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001598,
							["damage_from"] = {
								["Manawyrm"] = true,
							},
							["targets"] = {
								["Manawyrm"] = 42,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 42.001598,
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1669212130,
							["friendlyfire_total"] = 0,
							["aID"] = "4477-04C42ECA",
							["nome"] = "Teststsws",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 2,
										["n_max"] = 4,
										["targets"] = {
											["Manawyrm"] = 9,
										},
										["n_dmg"] = 6,
										["n_min"] = 2,
										["g_dmg"] = 3,
										["counter"] = 6,
										["total"] = 9,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Manawyrm"] = 16,
										},
										["n_dmg"] = 16,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Manawyrm"] = 17,
										},
										["n_dmg"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["total"] = 42.001598,
							["serial"] = "Player-4477-04C42ECA",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212129,
							["damage_taken"] = 4.001598,
							["start_time"] = 1669212125,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 1,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 1,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 1,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Teststsws",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["spell_cast"] = {
								[1752] = 1,
								[2098] = 1,
							},
							["tipo"] = 4,
							["aID"] = "4477-04C42ECA",
							["serial"] = "Player-4477-04C42ECA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 1,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Teststsws"] = true,
				},
				["raid_roster_indexed"] = {
					"Teststsws", -- [1]
				},
				["CombatStartedAt"] = 1021026.894,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 4,
				["playing_solo"] = true,
				["totals"] = {
					46, -- [1]
					-0.00717, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:02:10",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Manawyrm",
				["TotalElapsedCombatTime"] = 1021022.444,
				["CombatEndedAt"] = 1021022.444,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:02:05",
				["end_time"] = 1021022.444,
				["combat_id"] = 1,
				["tempo_start"] = 1669212125,
				["frags"] = {
					["Manawyrm"] = 1,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					42, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Teststsws"] = 42.001598,
						}, -- [1]
					},
				},
				["start_time"] = 1021017.96,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [2]
		},
	},
	["ocd_tracker"] = {
		["enabled"] = false,
		["current_cooldowns"] = {
		},
		["lines_per_column"] = 12,
		["show_options"] = false,
		["filters"] = {
			["defensive-raid"] = false,
			["ofensive"] = true,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["width"] = 120,
		["height"] = 18,
		["framme_locked"] = false,
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["cooldowns"] = {
		},
		["pos"] = {
		},
	},
	["last_version"] = "3.4.0 10259",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["on_death_menu"] = false,
	["cached_talents"] = {
	},
	["last_instance_id"] = 0,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Teststsws-Venoxis",
	["last_realversion"] = 146,
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["disable_gouge"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["useclasscolors"] = false,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["last_section_selected"] = "main",
			["author"] = "Terciob",
			["window_scale"] = 1,
			["hide_on_combat"] = false,
			["show_icon"] = 5,
			["opened"] = 0,
			["encounter_timers_dbm"] = {
			},
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["grow_direction"] = "right",
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["scale"] = 1,
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 338.4489600712638,
				["radius"] = 160,
				["hide"] = false,
			},
			["point"] = "CENTER",
			["arrow_anchor_x"] = 0,
			["y"] = -1.52587890625e-05,
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_height"] = 20,
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["use_spark"] = true,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["main_frame_strata"] = "LOW",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -1.52587890625e-05,
				["x"] = -3.0517578125e-05,
				["update_speed"] = 0.05,
				["size"] = 32,
				["attribute_type"] = 1,
			},
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["arrow_anchor_y"] = 0,
			["font_size"] = 10,
			["main_frame_locked"] = false,
			["author"] = "Details! Team",
		},
	},
	["last_day"] = "23",
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = false,
			["isLocked"] = false,
			["snap"] = {
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 0,
					["x"] = 0,
					["w"] = 310.0000610351563,
					["h"] = 157.9999847412109,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["last_instance_time"] = 0,
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["cached_roles"] = {
	},
	["ignore_nicktag"] = false,
	["combat_id"] = 2,
	["savedStyles"] = {
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1670508108,
		["last_version"] = 15,
	},
	["combat_counter"] = 5,
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.010087,
					["aID"] = "15274",
					["damage_from"] = {
						["Teststsws"] = true,
					},
					["targets"] = {
						["Teststsws"] = 4,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 4.010087,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1669212130,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["nome"] = "Manawyrm",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["Teststsws"] = 4,
								},
								["n_dmg"] = 4,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 4,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire"] = {
					},
					["total"] = 4.010087,
					["serial"] = "Creature-0-4479-530-129-15274-00007E15B9",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 42.010087,
					["start_time"] = 1669212122,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [1]
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.010005,
					["aID"] = "4477-04C42ECA",
					["damage_from"] = {
						["Manawyrm"] = true,
					},
					["targets"] = {
						["Manawyrm"] = 42,
						["Katze"] = 8,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 50.010005,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1669212130,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "Teststsws",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 2,
								["n_max"] = 4,
								["targets"] = {
									["Manawyrm"] = 9,
								},
								["n_dmg"] = 6,
								["n_min"] = 0,
								["g_dmg"] = 3,
								["counter"] = 6,
								["total"] = 9,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[1752] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["Manawyrm"] = 16,
									["Katze"] = 8,
								},
								["n_dmg"] = 24,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 24,
								["c_max"] = 0,
								["id"] = 1752,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[2098] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 17,
								["targets"] = {
									["Manawyrm"] = 17,
								},
								["n_dmg"] = 17,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 17,
								["c_max"] = 0,
								["id"] = 2098,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["grupo"] = true,
					["total"] = 50.010005,
					["serial"] = "Player-4477-04C42ECA",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 4.010005,
					["start_time"] = 1669212120,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [2]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.01445,
					["aID"] = "6368",
					["damage_from"] = {
						["Teststsws"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.01445,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1669212136,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["nome"] = "Katze",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["friendlyfire"] = {
					},
					["total"] = 0.01445,
					["serial"] = "Creature-0-4479-530-129-6368-00027D853C",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 8.01445,
					["start_time"] = 1669212133,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [3]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["last_event"] = 0,
					["nome"] = "Teststsws",
					["grupo"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						[1752] = 1,
						[2098] = 1,
					},
					["aID"] = "4477-04C42ECA",
					["classe"] = "ROGUE",
					["serial"] = "Player-4477-04C42ECA",
					["tipo"] = 4,
				}, -- [1]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["tempo_start"] = 1669212125,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["combat_counter"] = 3,
		["spells_cast_timeline"] = {
		},
		["totals"] = {
			54.016218, -- [1]
			0.00717, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "15:02:05",
		["end_time"] = 1021028.927,
		["cleu_events"] = {
			["n"] = 1,
		},
		["segments_added"] = {
			{
				["elapsed"] = 2.033000000054017,
				["type"] = 0,
				["name"] = "Katze",
				["clock"] = "15:02:14",
			}, -- [1]
			{
				["elapsed"] = 4.483999999938533,
				["type"] = 0,
				["name"] = "Manawyrm",
				["clock"] = "15:02:05",
			}, -- [2]
		},
		["totals_grupo"] = {
			50.008715, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["frags"] = {
		},
		["data_fim"] = "15:02:16",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["cleu_timeline"] = {
		},
		["start_time"] = 1021022.41,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
			["damage"] = {
			},
		},
	},
	["character_data"] = {
		["logons"] = 1,
	},
	["force_font_outline"] = "",
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
	},
}
