
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 6,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008607,
							["on_hold"] = false,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 64,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 64.008607,
							["aID"] = "4477-04C42EBB",
							["dps_started"] = false,
							["total"] = 64.008607,
							["classe"] = "ROGUE",
							["serial"] = "Player-4477-04C42EBB",
							["nome"] = "Testtata",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 1,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 25,
										},
										["n_dmg"] = 21,
										["n_min"] = 2,
										["g_dmg"] = 4,
										["counter"] = 10,
										["total"] = 25,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Scheckiger Eber"] = 16,
										},
										["n_dmg"] = 16,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Scheckiger Eber"] = 23,
										},
										["n_dmg"] = 23,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 23,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["end_time"] = 1669212561,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 5.008607,
							["start_time"] = 1669212551,
							["delay"] = 0,
							["last_event"] = 1669212561,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.007163,
							["damage_from"] = {
								["Testtata"] = true,
							},
							["targets"] = {
								["Testtata"] = 5,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5.007163,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212561,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3,
										["targets"] = {
											["Testtata"] = 5,
										},
										["n_dmg"] = 5,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 5,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "3098",
							["total"] = 5.007163,
							["serial"] = "Creature-0-4479-1-117-3098-00067D853A",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212559,
							["damage_taken"] = 64.00716299999999,
							["start_time"] = 1669212551,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 6,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 6,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 6,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 2,
							},
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "Testtata",
							["buff_uptime"] = 1,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["last_event"] = 1669212552,
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[26297] = {
										["activedamt"] = 1,
										["id"] = 26297,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04C42EBB",
							["aID"] = "4477-04C42EBB",
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 6,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Testtata"] = true,
				},
				["raid_roster_indexed"] = {
					"Testtata", -- [1]
				},
				["CombatStartedAt"] = 1021444.5,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 10,
				["playing_solo"] = true,
				["totals"] = {
					69, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:09:22",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 9.751000000047497,
				["CombatEndedAt"] = 1021454.251,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:09:12",
				["end_time"] = 1021454.251,
				["combat_id"] = 6,
				["tempo_start"] = 1669212551,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					64, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Testtata"] = 64.008607,
						}, -- [1]
					},
				},
				["start_time"] = 1021444.5,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [1]
			{
				{
					["combatId"] = 5,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007158,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 44,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 44.007158,
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1669212545,
							["friendlyfire_total"] = 0,
							["aID"] = "4477-04C42EBB",
							["nome"] = "Testtata",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 18,
										},
										["n_dmg"] = 18,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 18,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Scheckiger Eber"] = 26,
										},
										["n_dmg"] = 26,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 26,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["total"] = 44.007158,
							["serial"] = "Player-4477-04C42EBB",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212544,
							["damage_taken"] = 1.007158,
							["start_time"] = 1669212540,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.008301,
							["damage_from"] = {
								["Testtata"] = true,
							},
							["targets"] = {
								["Testtata"] = 1,
							},
							["pets"] = {
							},
							["total"] = 1.008301,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1.008301,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212545,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1,
										["targets"] = {
											["Testtata"] = 1,
										},
										["n_dmg"] = 1,
										["n_min"] = 1,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "3098",
							["serial"] = "Creature-0-4479-1-117-3098-00007E291B",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212544,
							["damage_taken"] = 44.008301,
							["start_time"] = 1669212542,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 5,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 5,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 5,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["buff_uptime_targets"] = {
							},
							["nome"] = "Testtata",
							["grupo"] = true,
							["classe"] = "ROGUE",
							["spell_cast"] = {
								[1752] = 3,
								[26297] = 1,
							},
							["pets"] = {
							},
							["buff_uptime"] = 3,
							["last_event"] = 1669212545,
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[26297] = {
										["activedamt"] = 1,
										["id"] = 26297,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04C42EBB",
							["aID"] = "4477-04C42EBB",
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 5,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Testtata"] = true,
				},
				["raid_roster_indexed"] = {
					"Testtata", -- [1]
				},
				["CombatStartedAt"] = 1021433.3,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 9,
				["playing_solo"] = true,
				["totals"] = {
					45, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:09:05",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 4.699999999953434,
				["CombatEndedAt"] = 1021438,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:09:01",
				["end_time"] = 1021438,
				["combat_id"] = 5,
				["tempo_start"] = 1669212540,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					44, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Testtata"] = 44.007158,
						}, -- [1]
					},
				},
				["start_time"] = 1021433.3,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [2]
			{
				{
					["combatId"] = 4,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003094,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 55,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 55.003094,
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1669212533,
							["friendlyfire_total"] = 0,
							["aID"] = "4477-04C42EBB",
							["nome"] = "Testtata",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 9,
										["g_amt"] = 1,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 22,
										},
										["n_dmg"] = 11,
										["n_min"] = 2,
										["g_dmg"] = 2,
										["counter"] = 7,
										["total"] = 22,
										["c_max"] = 9,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 9,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Scheckiger Eber"] = 17,
										},
										["n_dmg"] = 17,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Scheckiger Eber"] = 16,
										},
										["n_dmg"] = 16,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["total"] = 55.003094,
							["serial"] = "Player-4477-04C42EBB",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212532,
							["damage_taken"] = 4.003094,
							["start_time"] = 1669212527,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.003615,
							["damage_from"] = {
								["Testtata"] = true,
							},
							["targets"] = {
								["Testtata"] = 4,
							},
							["pets"] = {
							},
							["total"] = 4.003615,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4.003615,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212533,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["Testtata"] = 4,
										},
										["n_dmg"] = 4,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 4,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "3098",
							["serial"] = "Creature-0-4479-1-117-3098-00007E292D",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212531,
							["damage_taken"] = 55.003615,
							["start_time"] = 1669212529,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 4,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 4,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 4,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Testtata",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
							["tipo"] = 4,
							["aID"] = "4477-04C42EBB",
							["serial"] = "Player-4477-04C42EBB",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 4,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Testtata"] = true,
				},
				["raid_roster_indexed"] = {
					"Testtata", -- [1]
				},
				["CombatStartedAt"] = 1021420.283,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 8,
				["playing_solo"] = true,
				["totals"] = {
					59, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:08:54",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 6.366999999969266,
				["CombatEndedAt"] = 1021426.65,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:08:48",
				["end_time"] = 1021426.65,
				["combat_id"] = 4,
				["tempo_start"] = 1669212527,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					55, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Testtata"] = 55.003094,
						}, -- [1]
					},
				},
				["start_time"] = 1021420.283,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001127,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 66,
							},
							["pets"] = {
							},
							["last_event"] = 1669212064,
							["aID"] = "4477-04C42EBB",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 66.001127,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 66.001127,
							["classe"] = "ROGUE",
							["damage_taken"] = 2.001127,
							["nome"] = "Testtata",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 21,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 30,
										},
										["n_dmg"] = 9,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 30,
										["c_max"] = 11,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["a_amt"] = 0,
										["c_min"] = 10,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["MISS"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Scheckiger Eber"] = 16,
										},
										["n_dmg"] = 16,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["Scheckiger Eber"] = 20,
										},
										["n_dmg"] = 20,
										["n_min"] = 20,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1669212065,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1669212060,
							["serial"] = "Player-4477-04C42EBB",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.00228,
							["damage_from"] = {
								["Testtata"] = true,
							},
							["targets"] = {
								["Testtata"] = 2,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 2.00228,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2.00228,
							["delay"] = 0,
							["fight_component"] = true,
							["end_time"] = 1669212065,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 66.00228,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["Testtata"] = 2,
										},
										["n_dmg"] = 2,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["aID"] = "3098",
							["last_dps"] = 0,
							["on_hold"] = false,
							["custom"] = 0,
							["last_event"] = 1669212064,
							["friendlyfire"] = {
							},
							["start_time"] = 1669212064,
							["serial"] = "Creature-0-4468-1-274-3098-0000FDE187",
							["dps_started"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 3,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["aID"] = "4477-04C42EBB",
							["nome"] = "Testtata",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["serial"] = "Player-4477-04C42EBB",
							["spell_cast"] = {
								[1752] = 1,
								[2098] = 1,
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 3,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Testtata"] = true,
				},
				["raid_roster_indexed"] = {
					"Testtata", -- [1]
				},
				["CombatStartedAt"] = 1020953.809,
				["tempo_start"] = 1669212060,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					68, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					66, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "15:01:06",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 4.717000000062399,
				["CombatEndedAt"] = 1020958.526,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Testtata"] = 66.001127,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1020958.526,
				["combat_id"] = 3,
				["overall_added"] = true,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 6,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 1020953.809,
				["TimeData"] = {
				},
				["data_inicio"] = "15:01:01",
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008962,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 58,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 58.008962,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 58.008962,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1669212054,
							["aID"] = "4477-04C42EBB",
							["damage_taken"] = 4.008962,
							["nome"] = "Testtata",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 1,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 25,
										},
										["n_dmg"] = 20,
										["n_min"] = 3,
										["g_dmg"] = 5,
										["counter"] = 8,
										["total"] = 25,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 5,
										["spellschool"] = 1,
										["MISS"] = 2,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Scheckiger Eber"] = 16,
										},
										["n_dmg"] = 16,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Scheckiger Eber"] = 17,
										},
										["n_dmg"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212054,
							["on_hold"] = false,
							["start_time"] = 1669212049,
							["serial"] = "Player-4477-04C42EBB",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.007701,
							["damage_from"] = {
								["Testtata"] = true,
							},
							["targets"] = {
								["Testtata"] = 4,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["aID"] = "3098",
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4.007701,
							["delay"] = 0,
							["fight_component"] = true,
							["total"] = 4.007701,
							["on_hold"] = false,
							["damage_taken"] = 58.007701,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["Testtata"] = 4,
										},
										["n_dmg"] = 4,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 4,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 2,
										["spellschool"] = 1,
										["DODGE"] = 2,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["end_time"] = 1669212060,
							["custom"] = 0,
							["last_event"] = 1669212060,
							["friendlyfire"] = {
							},
							["start_time"] = 1669212051,
							["serial"] = "Creature-0-4468-1-274-3098-00007DE766",
							["dps_started"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 2,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 2,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["aID"] = "4477-04C42EBB",
							["nome"] = "Testtata",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["serial"] = "Player-4477-04C42EBB",
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Testtata"] = true,
				},
				["raid_roster_indexed"] = {
					"Testtata", -- [1]
				},
				["CombatStartedAt"] = 1020942.876,
				["tempo_start"] = 1669212049,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					62, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					58, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "15:00:55",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 5.133000000030734,
				["CombatEndedAt"] = 1020948.009,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Testtata"] = 58.008962,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1020948.009,
				["combat_id"] = 2,
				["overall_added"] = true,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 5,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
					["Testtata"] = {
						{
							true, -- [1]
							1, -- [2]
							2, -- [3]
							1669212060.608, -- [4]
							55, -- [5]
							"Scheckiger Eber", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["start_time"] = 1020942.876,
				["TimeData"] = {
				},
				["data_inicio"] = "15:00:50",
			}, -- [5]
			{
				{
					["tipo"] = 2,
					["combatId"] = 1,
					["_ActorTable"] = {
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.008133,
							["damage_from"] = {
								["Testtata"] = true,
							},
							["targets"] = {
								["Testtata"] = 6,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["aID"] = "3098",
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6.008133,
							["delay"] = 0,
							["fight_component"] = true,
							["total"] = 6.008133,
							["on_hold"] = false,
							["damage_taken"] = 58.008133,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["Testtata"] = 6,
										},
										["n_dmg"] = 6,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 6,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["extra"] = {
										},
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["end_time"] = 1669212044,
							["custom"] = 0,
							["last_event"] = 1669212042,
							["friendlyfire"] = {
							},
							["start_time"] = 1669212036,
							["serial"] = "Creature-0-4468-1-274-3098-00007E1A90",
							["dps_started"] = false,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006569,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 58,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 58.006569,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 58.006569,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1669212044,
							["aID"] = "4477-04C42EBB",
							["damage_taken"] = 6.006569,
							["nome"] = "Testtata",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 1,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 21,
										},
										["n_dmg"] = 19,
										["n_min"] = 1,
										["g_dmg"] = 2,
										["counter"] = 9,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 1,
										["extra"] = {
										},
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 6,
										["spellschool"] = 1,
										["MISS"] = 2,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Scheckiger Eber"] = 18,
										},
										["n_dmg"] = 18,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 18,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["Scheckiger Eber"] = 19,
										},
										["n_dmg"] = 19,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 19,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["extra"] = {
										},
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212043,
							["on_hold"] = false,
							["start_time"] = 1669212036,
							["serial"] = "Player-4477-04C42EBB",
							["friendlyfire"] = {
							},
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 1,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["aID"] = "4477-04C42EBB",
							["nome"] = "Testtata",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["serial"] = "Player-4477-04C42EBB",
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Testtata"] = true,
				},
				["raid_roster_indexed"] = {
					"Testtata", -- [1]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					64, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					58, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "15:00:45",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 1020937.509,
				["CombatEndedAt"] = 1020937.509,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:00:37",
				["end_time"] = 1020937.509,
				["combat_id"] = 1,
				["player_last_events"] = {
				},
				["spells_cast_timeline"] = {
				},
				["tempo_start"] = 1669212036,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["combat_counter"] = 4,
				["start_time"] = 1020929.275,
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Testtata"] = 58.006569,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
			}, -- [6]
		},
	},
	["ocd_tracker"] = {
		["enabled"] = false,
		["current_cooldowns"] = {
		},
		["lines_per_column"] = 12,
		["show_options"] = false,
		["filters"] = {
			["defensive-raid"] = false,
			["ofensive"] = true,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["width"] = 120,
		["height"] = 18,
		["cooldowns"] = {
		},
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["framme_locked"] = false,
		["pos"] = {
		},
	},
	["last_version"] = "3.4.0 10259",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["on_death_menu"] = false,
	["cached_talents"] = {
	},
	["last_instance_id"] = 0,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Testtata-Venoxis",
	["last_realversion"] = 146,
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["useclasscolors"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["disable_gouge"] = false,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["last_section_selected"] = "main",
			["author"] = "Terciob",
			["window_scale"] = 1,
			["encounter_timers_dbm"] = {
			},
			["show_icon"] = 5,
			["opened"] = 0,
			["hide_on_combat"] = false,
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["grow_direction"] = "right",
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["author"] = "Details! Team",
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 338.4489600712638,
				["radius"] = 160,
				["hide"] = false,
			},
			["main_frame_locked"] = false,
			["arrow_anchor_x"] = 0,
			["font_size"] = 10,
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["arrow_anchor_y"] = 0,
			["use_spark"] = true,
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["main_frame_strata"] = "LOW",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -1.52587890625e-05,
				["x"] = -3.0517578125e-05,
				["attribute_type"] = 1,
				["update_speed"] = 0.05,
				["size"] = 32,
			},
			["y"] = -1.52587890625e-05,
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["point"] = "CENTER",
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_height"] = 20,
			["scale"] = 1,
		},
	},
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["last_day"] = "23",
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["last_instance_time"] = 0,
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["force_font_outline"] = "",
	["combat_id"] = 6,
	["savedStyles"] = {
	},
	["character_data"] = {
		["logons"] = 2,
	},
	["combat_counter"] = 10,
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.045999,
					["damage_from"] = {
						["Testtata"] = true,
					},
					["targets"] = {
						["Testtata"] = 20,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 20.045999,
					["tipo"] = 1,
					["last_dps"] = 0,
					["dps_started"] = false,
					["total"] = 20.045999,
					["friendlyfire"] = {
					},
					["aID"] = "3098",
					["nome"] = "Scheckiger Eber",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3,
								["targets"] = {
									["Testtata"] = 20,
								},
								["n_dmg"] = 20,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 20,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["extra"] = {
								},
								["DODGE"] = 10,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["delay"] = 0,
					["fight_component"] = true,
					["end_time"] = 1669212045,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1669212013,
					["serial"] = "Creature-0-4468-1-274-3098-00007E1A90",
					["damage_taken"] = 345.045999,
				}, -- [1]
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.04206500000000001,
					["damage_from"] = {
						["Scheckiger Eber"] = true,
					},
					["targets"] = {
						["Scheckiger Eber"] = 345,
					},
					["pets"] = {
					},
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 345.042065,
					["last_dps"] = 0,
					["tipo"] = 1,
					["dps_started"] = false,
					["total"] = 345.042065,
					["aID"] = "4477-04C42EBB",
					["delay"] = 0,
					["nome"] = "Testtata",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 3,
								["b_amt"] = 1,
								["c_dmg"] = 30,
								["g_amt"] = 4,
								["n_max"] = 5,
								["targets"] = {
									["Scheckiger Eber"] = 141,
								},
								["n_dmg"] = 98,
								["n_min"] = 0,
								["g_dmg"] = 13,
								["counter"] = 46,
								["total"] = 141,
								["c_max"] = 11,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 1,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 29,
								["extra"] = {
								},
								["MISS"] = 10,
							}, -- [1]
							[1752] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9,
								["targets"] = {
									["Scheckiger Eber"] = 109,
								},
								["n_dmg"] = 109,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 109,
								["c_max"] = 0,
								["id"] = 1752,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 13,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[2098] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 20,
								["targets"] = {
									["Scheckiger Eber"] = 95,
								},
								["n_dmg"] = 95,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 95,
								["c_max"] = 0,
								["id"] = 2098,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["end_time"] = 1669212045,
					["on_hold"] = false,
					["damage_taken"] = 20.042065,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1669212003,
					["serial"] = "Player-4477-04C42EBB",
					["friendlyfire_total"] = 0,
				}, -- [2]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["last_event"] = 0,
					["nome"] = "Testtata",
					["buff_uptime_targets"] = {
					},
					["grupo"] = true,
					["pets"] = {
					},
					["buff_uptime"] = 4,
					["spell_cast"] = {
						[2098] = 6,
						[26297] = 1,
						[1752] = 12,
					},
					["tipo"] = 4,
					["aID"] = "4477-04C42EBB",
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[26297] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 26297,
								["uptime"] = 4,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["serial"] = "Player-4477-04C42EBB",
					["classe"] = "ROGUE",
				}, -- [1]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["cleu_timeline"] = {
		},
		["tempo_start"] = 1669212036,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["combat_counter"] = 3,
		["totals"] = {
			365.07271, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["dispell"] = 0,
				["cooldowns_defensive"] = 0,
			}, -- [4]
			["voidzone_damage"] = 0,
			["frags_total"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "15:00:37",
		["end_time"] = 1021454.251,
		["totals_grupo"] = {
			345.035517, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["dispell"] = 0,
				["cooldowns_defensive"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
		},
		["segments_added"] = {
			{
				["elapsed"] = 9.751000000047497,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:09:12",
			}, -- [1]
			{
				["elapsed"] = 4.699999999953434,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:09:01",
			}, -- [2]
			{
				["elapsed"] = 6.366999999969266,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:08:48",
			}, -- [3]
			{
				["elapsed"] = 4.717000000062399,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:01:01",
			}, -- [4]
			{
				["elapsed"] = 5.133000000030734,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:00:50",
			}, -- [5]
			{
				["elapsed"] = 8.234000000054948,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:00:37",
			}, -- [6]
		},
		["hasSaved"] = true,
		["spells_cast_timeline"] = {
		},
		["data_fim"] = "15:09:22",
		["overall_enemy_name"] = "Scheckiger Eber",
		["CombatSkillCache"] = {
		},
		["frags"] = {
		},
		["start_time"] = 1021415.349,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["cleu_events"] = {
			["n"] = 1,
		},
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1670508007,
		["last_version"] = 15,
	},
	["ignore_nicktag"] = false,
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["isLocked"] = false,
			["is_open"] = false,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 0,
					["x"] = 6.103515625e-05,
					["w"] = 310.0000610351563,
					["h"] = 157.9999847412109,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["announce_cooldowns"] = {
		["ignored_cooldowns"] = {
		},
		["enabled"] = false,
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["cached_roles"] = {
	},
	["cached_specs"] = {
	},
}
