
Prio3DB = {
	["profileKeys"] = {
		["Biologe - Ewige Warte"] = "Biologe - Ewige Warte",
		["Saucier - Ewige Warte"] = "Saucier - Ewige Warte",
		["Sortis - Lakeshire"] = "Sortis - Lakeshire",
		["Hoddl - Ewige Warte"] = "Hoddl - Ewige Warte",
		["Pinkfear - Lakeshire"] = "Pinkfear - Lakeshire",
		["Resonator - Everlook"] = "Resonator - Everlook",
		["Nedro - Everlook"] = "Nedro - Everlook",
		["Privee - Ewige Warte"] = "Privee - Ewige Warte",
		["Cadix - Lakeshire"] = "Cadix - Lakeshire",
		["Resonator - Ewige Warte"] = "Resonator - Ewige Warte",
		["Felton - Lakeshire"] = "Felton - Lakeshire",
		["Deramahsteht - Lucifron"] = "Deramahsteht - Lucifron",
		["Sibo - Lakeshire"] = "Sibo - Lakeshire",
		["Stoc - Ewige Warte"] = "Stoc - Ewige Warte",
		["Pädagoge - Everlook"] = "Pädagoge - Everlook",
		["Saucier - Everlook"] = "Saucier - Everlook",
		["Felton - Seenhain"] = "Felton - Seenhain",
		["Giselheer - Everlook"] = "Giselheer - Everlook",
		["Containerd - Lakeshire"] = "Containerd - Lakeshire",
		["Biologe - Everlook"] = "Biologe - Everlook",
		["Raidbankk - Lakeshire"] = "Raidbankk - Lakeshire",
		["Akuhstiker - Transcendence"] = "Akuhstiker - Transcendence",
		["Privee - Everlook"] = "Privee - Everlook",
		["Refractor - Everlook"] = "Refractor - Everlook",
		["Hoddl - Everlook"] = "Hoddl - Everlook",
		["Cretax - Everlook"] = "Cretax - Everlook",
		["Knallus - Everlook"] = "Knallus - Everlook",
		["Nedro - Ewige Warte"] = "Nedro - Ewige Warte",
		["Pädagoge - Ewige Warte"] = "Pädagoge - Ewige Warte",
		["Stoc - Everlook"] = "Stoc - Everlook",
		["Cretax - Ewige Warte"] = "Cretax - Ewige Warte",
		["Nedro - Lakeshire"] = "Nedro - Lakeshire",
		["Drushnak - Lakeshire"] = "Drushnak - Lakeshire",
	},
	["profiles"] = {
		["Biologe - Ewige Warte"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Saucier - Ewige Warte"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Sortis - Lakeshire"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Hoddl - Ewige Warte"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Pinkfear - Lakeshire"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Resonator - Everlook"] = {
			["enabled"] = false,
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Nedro - Everlook"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Privee - Ewige Warte"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Cadix - Lakeshire"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Resonator - Ewige Warte"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Felton - Lakeshire"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Deramahsteht - Lucifron"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Sibo - Lakeshire"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Stoc - Ewige Warte"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Pädagoge - Everlook"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Saucier - Everlook"] = {
			["enabled"] = false,
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Felton - Seenhain"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Giselheer - Everlook"] = {
			["enabled"] = false,
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Containerd - Lakeshire"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Biologe - Everlook"] = {
			["enabled"] = false,
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Raidbankk - Lakeshire"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Akuhstiker - Transcendence"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Privee - Everlook"] = {
			["enabled"] = false,
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Refractor - Everlook"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Hoddl - Everlook"] = {
			["lootlastopened"] = {
			},
			["enabled"] = false,
			["receivedPriorities"] = 0,
			["priorities"] = {
			},
		},
		["Cretax - Everlook"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Knallus - Everlook"] = {
			["enabled"] = false,
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Nedro - Ewige Warte"] = {
			["priorities"] = {
			},
			["lootlastopened"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Pädagoge - Ewige Warte"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Stoc - Everlook"] = {
			["enabled"] = false,
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Cretax - Ewige Warte"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Nedro - Lakeshire"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
		["Drushnak - Lakeshire"] = {
			["lootlastopened"] = {
			},
			["priorities"] = {
			},
			["receivedPriorities"] = 0,
		},
	},
}
