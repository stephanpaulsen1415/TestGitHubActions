
BisTooltipDB = {
	["profileKeys"] = {
		["Crimora - Venoxis"] = "Default",
		["Knallus - Everlook"] = "Default",
		["Drushnak - Venoxis"] = "Default",
		["Resonatorr - Venoxis"] = "Default",
		["Nedro - Venoxis"] = "Default",
		["Radorn - Venoxis"] = "Default",
		["Saucier - Everlook"] = "Default",
	},
	["char"] = {
		["Crimora - Venoxis"] = {
			["minimapPos"] = 312.6763613863728,
			["data_source"] = "wowtbc",
			["version"] = 6.1,
		},
		["Knallus - Everlook"] = {
			["version"] = 6.1,
			["data_source"] = "wowtbc",
		},
		["Drushnak - Venoxis"] = {
			["minimapPos"] = 309.2950042757474,
			["version"] = 6.1,
			["phase_index"] = 3,
			["data_source"] = "wh",
			["class_index"] = 7,
		},
		["Resonatorr - Venoxis"] = {
			["minimapPos"] = 186.8321751031018,
			["data_source"] = "wowtbc",
			["version"] = 6.1,
		},
		["Nedro - Venoxis"] = {
			["minimapPos"] = 313.8060062043479,
			["data_source"] = "wh",
			["version"] = 6.1,
		},
		["Radorn - Venoxis"] = {
			["minimapPos"] = 321.9983868980082,
			["class_index"] = 6,
			["data_source"] = "wowtbc",
			["version"] = 6.1,
		},
		["Saucier - Everlook"] = {
			["version"] = 6.1,
			["data_source"] = "wowtbc",
		},
	},
}
