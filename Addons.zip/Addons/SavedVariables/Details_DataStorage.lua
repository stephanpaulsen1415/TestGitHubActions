
DetailsDataStorage = {
	["saved_encounters"] = {
	},
	[15] = {
	},
	["VERSION"] = 5,
	[16] = {
	},
	[14] = {
	},
	["mythic_plus"] = {
	},
	["Data"] = {
	},
}
