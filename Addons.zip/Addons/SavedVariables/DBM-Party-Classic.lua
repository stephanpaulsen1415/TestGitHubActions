
DBMPartyClassic_AllSavedVars = {
	["Biologe-Everlook"] = {
		["452"] = {
			[2] = {
				["announceother6016target2"] = false,
				["Timer6016ai2"] = false,
				["Timer17235ai"] = true,
				["Timer17235aiCVoice"] = 0,
				["announce17235spell"] = true,
				["Timer17235aiTColor"] = 1,
				["Timer6016ai2TColor"] = 5,
				["Enabled"] = true,
				["Timer6016ai2CVoice"] = 0,
			},
		},
		["RasFrostwhisper"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Tutenkash"] = {
			[2] = {
				["Enabled"] = true,
				["Timer12255aiTColor"] = 3,
				["Timer12252aiTColor"] = 5,
				["announceother12255target"] = false,
				["Timer12255ai"] = true,
				["Timer12252aiCVoice"] = 0,
				["announce12252spell"] = true,
				["Timer12252ai"] = true,
				["Timer12255aiCVoice"] = 0,
			},
		},
		["454"] = {
			[2] = {
				["Enabled"] = true,
				["Timer14099ai2"] = false,
				["Timer10887aiTColor"] = 2,
				["Timer14099ai2TColor"] = 5,
				["Timer10887ai"] = true,
				["Timer10887aiCVoice"] = 0,
				["announce14099spell"] = true,
				["Timer14099ai2CVoice"] = 0,
				["announce10887spell"] = true,
			},
		},
		["WolfMasterNandos"] = {
			[2] = {
				["Enabled"] = true,
				["announce7488spell"] = true,
				["Timer7487ai"] = true,
				["Timer7487aiTColor"] = 1,
				["Timer7489aiTColor"] = 1,
				["Timer7489aiCVoice"] = 0,
				["Timer7489ai"] = true,
				["Timer7487aiCVoice"] = 0,
				["announce7487spell"] = true,
				["Timer7488ai"] = true,
				["Timer7488aiTColor"] = 1,
				["announce7489spell"] = true,
				["Timer7488aiCVoice"] = 0,
			},
		},
		["430"] = {
			[2] = {
				["Timer16495aiTColor"] = 5,
				["Timer16495ai"] = true,
				["Timer16495aiCVoice"] = 0,
				["announce16495spell"] = true,
				["Enabled"] = true,
			},
		},
		["Fairbanks"] = {
			[2] = {
				["Enabled"] = true,
				["announceother8282target"] = false,
			},
		},
		["BloodmageThalnos"] = {
			[2] = {
				["Enabled"] = true,
				["announce8814spell"] = true,
				["Timer8814ai"] = true,
				["announce12470spell"] = true,
				["Timer8814aiTColor"] = 3,
				["Timer8814aiCVoice"] = 0,
			},
		},
		["451"] = {
			[2] = {
				["Enabled"] = true,
				["SpecWarn17244targetchangeSWNote"] = true,
				["announceother18327target"] = false,
				["announceother16867target"] = false,
				["SpecWarn17244targetchange"] = true,
				["SpecWarn17244targetchangeSWSound"] = 1,
			},
		},
		["DextrenWard"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Gilnid"] = {
			[2] = {
				["Enabled"] = true,
				["Timer5213aiTColor"] = 3,
				["Timer5213ai"] = true,
				["announceother5213target"] = true,
				["Timer5213aiCVoice"] = 0,
			},
		},
		["446"] = {
			[2] = {
				["Enabled"] = true,
				["Timer17279ai"] = true,
				["announce17279spell"] = false,
				["Timer17279aiCVoice"] = 0,
				["Timer17279aiTColor"] = 1,
			},
		},
		["Akumai"] = {
			[2] = {
				["Timer3815aiTColor"] = 3,
				["Timer3490aiTColor"] = 5,
				["announce3490spell"] = true,
				["Timer3490ai"] = true,
				["Timer3815ai"] = true,
				["Timer3490aiCVoice"] = 0,
				["announce3815spell"] = true,
				["Timer3815aiCVoice"] = 0,
				["Enabled"] = true,
			},
		},
		["PlaguemawtheRotting"] = {
			[2] = {
				["Enabled"] = true,
				["announceother11442target"] = false,
				["SpecWarn12946dispel"] = false,
				["Timer12946ai"] = true,
				["Timer12946aiTColor"] = 5,
				["SpecWarn12946dispelSWSound"] = 1,
				["SpecWarn12946dispelSWNote"] = true,
				["Timer12946aiCVoice"] = 0,
			},
		},
		["422"] = {
			[2] = {
				["announce11518spell"] = true,
				["Timer10101aiCVoice"] = 0,
				["announce10101spell"] = true,
				["Timer10101ai"] = true,
				["Timer10101aiTColor"] = 2,
				["Enabled"] = true,
			},
		},
		["443"] = {
			[2] = {
				["Enabled"] = true,
				["SpecWarn16798interruptSWSound"] = 1,
				["Timer16798ai"] = true,
				["SpecWarn16798interruptSWNote"] = true,
				["SpecWarn16798interrupt"] = false,
				["announceother16798target"] = true,
				["Timer16798aiTColor"] = 4,
				["Timer16798aiCVoice"] = 0,
			},
		},
		["421"] = {
			[2] = {
				["Timer11082aiCVoice"] = 0,
				["SpecWarn11082interruptSWNote"] = true,
				["Timer11082aiTColor"] = 4,
				["Timer11084ai2CVoice"] = 0,
				["SpecWarn11082interrupt"] = false,
				["SpecWarn11085interruptSWSound"] = 1,
				["Timer11085aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer11084ai2TColor"] = 5,
				["Timer11085ai"] = true,
				["Timer11085aiTColor"] = 4,
				["Timer11084ai2"] = false,
				["Timer11082ai"] = true,
				["SpecWarn11085interruptSWNote"] = true,
				["SpecWarn11085interrupt"] = false,
				["SpecWarn11082interruptSWSound"] = 1,
				["announce11084spell"] = false,
			},
		},
		["ArcanistDoan"] = {
			[2] = {
				["Enabled"] = true,
				["announceother13323target"] = true,
				["SpecWarn9435run"] = true,
				["SpecWarn9435runSWNote"] = true,
				["announce9433spell2"] = false,
				["announce8988cast"] = true,
				["Timer8988cdTColor"] = 3,
				["Timer8988cd"] = true,
				["SpecWarn9435runSWSound"] = 4,
				["Timer8988cdCVoice"] = 0,
			},
		},
		["429"] = {
			[2] = {
				["Enabled"] = true,
				["Timer5568cd"] = true,
				["Timer21808aiTColor"] = 0,
				["announce5568spell"] = true,
				["SpecWarn21807interruptSWNote"] = true,
				["SpecWarn21807interruptSWSound"] = 1,
				["SpecWarn21807interrupt"] = false,
				["Timer21808ai"] = true,
				["Timer11130cd"] = true,
				["announce11130spell"] = true,
				["Timer11130cdTColor"] = 2,
				["Timer21808aiCVoice"] = 0,
				["announce21808spell"] = true,
				["Timer11130cdCVoice"] = 0,
				["Timer5568cdTColor"] = 2,
				["Timer5568cdCVoice"] = 0,
			},
		},
		["DoctorTheolenKrastinov"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["InterrogatorVishas"] = {
			[2] = {
				["Enabled"] = true,
				["Timer9034aiCVoice"] = 0,
				["Timer9034ai"] = true,
				["announceother9034target"] = true,
				["Timer9034aiTColor"] = 3,
			},
		},
		["Hazzas"] = {
			[2] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["448"] = {
			[2] = {
				["Enabled"] = true,
				["Timer17293aiCVoice"] = 0,
				["Timer17293ai"] = true,
				["Timer17366ai"] = true,
				["announceother17293target"] = true,
				["Timer17293aiTColor"] = 3,
				["announce17366spell"] = true,
				["Timer17366aiTColor"] = 2,
				["Timer17366aiCVoice"] = 0,
			},
		},
		["EdwinVanCleef"] = {
			[2] = {
				["announce5200spell"] = true,
				["Timer3391aiTColor"] = 5,
				["Timer3391aiCVoice"] = 0,
				["Timer3391ai"] = true,
				["Enabled"] = true,
				["announce3391spell"] = true,
			},
		},
		["Jergosh"] = {
			[2] = {
				["Enabled"] = true,
				["Timer18267aiTColor"] = 3,
				["Timer20800aiCVoice"] = 0,
				["Timer18267aiCVoice"] = 0,
				["announceother18267target"] = true,
				["announceother20800target"] = false,
				["Timer20800aiTColor"] = 5,
				["Timer18267ai"] = true,
				["Timer20800ai"] = false,
			},
		},
		["413"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["417"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["BaronSilverlaine"] = {
			[2] = {
				["Timer7068aiTColor"] = 3,
				["announceother7068target"] = true,
				["Timer7068ai"] = true,
				["Enabled"] = true,
				["Timer7068aiCVoice"] = 0,
			},
		},
		["393"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Vectus"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["416"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["390"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["talent2"] = "SHAMAN2",
		["EarthcallerHalmgar"] = {
			[2] = {
				["Enabled"] = true,
				["announce8270spell"] = true,
			},
		},
		["418"] = {
			[2] = {
				["Enabled"] = true,
				["SpecWarn10887spell"] = true,
				["Timer8374ai2"] = false,
				["SpecWarn10887spellSWNote"] = true,
				["Timer10887aiTColor"] = 2,
				["SpecWarn10887spellSWSound"] = 2,
				["Timer10887ai"] = true,
				["Timer8374ai2CVoice"] = 0,
				["Timer10887aiCVoice"] = 0,
				["Timer8374ai2TColor"] = 5,
			},
		},
		["AggemThorncurse"] = {
			[2] = {
				["Enabled"] = true,
				["announce8286spell"] = true,
				["SpecWarn14900interruptSWSound"] = 1,
				["Timer14900aiCVoice"] = 0,
				["Timer8286aiTColor"] = 1,
				["SpecWarn14900interruptSWNote"] = true,
				["Timer8286aiCVoice"] = 0,
				["Timer14900ai"] = true,
				["Timer8286ai"] = true,
				["SpecWarn14900interrupt"] = false,
				["Timer14900aiTColor"] = 4,
			},
		},
		["Hamhock"] = {
			[2] = {
				["Enabled"] = true,
				["announceother6742target"] = true,
				["RangeFrame"] = true,
			},
		},
		["GeneralDrakkisath"] = {
			[2] = {
				["Enabled"] = true,
				["Timer16805target"] = true,
				["announceother16805target"] = true,
				["Timer16805targetTColor"] = 3,
				["Timer16805targetCVoice"] = 0,
			},
		},
		["HoundmasterLoksey"] = {
			[2] = {
				["Enabled"] = true,
				["announceother6742target"] = true,
			},
		},
		["410"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["AgathelostheRaging"] = {
			[2] = {
				["Enabled"] = true,
				["announceother8269target"] = true,
			},
		},
		["DeathswornCaptain"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["423"] = {
			[2] = {
				["Enabled"] = true,
				["Timer21707aiTColor"] = 1,
				["Timer10966ai"] = true,
				["Timer10966aiCVoice"] = 0,
				["Timer10966aiTColor"] = 5,
				["Timer21707aiCVoice"] = 0,
				["announce21707spell"] = true,
				["announce10966spell"] = true,
				["Timer21707ai"] = true,
			},
		},
		["427"] = {
			[2] = {
				["Enabled"] = true,
				["Timer7964cd"] = true,
				["announce7964spell"] = true,
				["Timer7964cdTColor"] = 3,
				["Timer7964cdCVoice"] = 0,
			},
		},
		["GhamooRa"] = {
			[2] = {
				["Timer5568aiTColor"] = 3,
				["Timer5568aiCVoice"] = 0,
				["announce5568spell"] = true,
				["Timer5568ai"] = true,
				["Enabled"] = true,
			},
		},
		["RhahkZor"] = {
			[2] = {
				["Enabled"] = true,
				["Timer6304ai"] = true,
				["Timer6304aiTColor"] = 5,
				["announceother6304target"] = true,
				["Timer6304aiCVoice"] = 0,
			},
		},
		["ArchmageArugal"] = {
			[2] = {
				["Enabled"] = true,
				["announce7587spell"] = true,
				["Timer7621aiCVoice"] = 0,
				["Timer7621aiTColor"] = 3,
				["Timer7587aiCVoice"] = 0,
				["Timer7587ai"] = true,
				["announceother7621target"] = true,
				["Timer7587aiTColor"] = 6,
				["Timer7621ai"] = true,
			},
		},
		["389"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["489"] = {
			[2] = {
				["Enabled"] = true,
				["announceother8269target"] = true,
			},
		},
		["Rethilgore"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["TheRavenian"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Glutton"] = {
			[2] = {
				["Enabled"] = true,
				["announce12795spell"] = true,
			},
		},
		["381"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["481"] = {
			[2] = {
				["Enabled"] = true,
				["SpecWarn7967interruptSWSound"] = 1,
				["announceother7967target"] = true,
				["Timer7967ai"] = true,
				["SpecWarn7967interrupt"] = false,
				["Timer8150aiCVoice"] = 0,
				["SpecWarn7967interruptSWNote"] = true,
				["announceother7399target"] = true,
				["Timer7967aiCVoice"] = 0,
				["Timer7967aiTColor"] = 4,
				["Timer7399aiTColor"] = 3,
				["Timer8150ai"] = true,
				["Timer7399aiCVoice"] = 0,
				["Timer8150aiTColor"] = 2,
				["Timer7399ai"] = true,
			},
		},
		["409"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Bazzalan"] = {
			[2] = {
				["Enabled"] = true,
				["Timer744ai"] = false,
				["Timer744aiTColor"] = 5,
				["Timer744aiCVoice"] = 0,
				["announceother744target"] = false,
			},
		},
		["Herod"] = {
			[2] = {
				["Enabled"] = true,
				["SpecWarn8989runSWSound"] = 4,
				["SpecWarn8989run"] = true,
				["announceother8269target"] = true,
				["Timer8989cdCVoice"] = 0,
				["Timer8989cdTColor"] = 4,
				["Timer8989cd"] = true,
				["SpecWarn8989runSWNote"] = true,
			},
		},
		["GoralukAnvilcrack"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["428"] = {
			[2] = {
				["Enabled"] = true,
				["announceother12747target"] = true,
				["announce21968spell"] = false,
				["SpecWarn21807interruptSWNote"] = true,
				["SpecWarn21807interrupt"] = false,
				["SpecWarn21807interruptSWSound"] = 1,
			},
		},
		["LadySerevess"] = {
			[2] = {
				["Timer246ai"] = true,
				["announceother246target"] = true,
				["Timer246aiTColor"] = 3,
				["Enabled"] = true,
				["Timer246aiCVoice"] = 0,
			},
		},
		["392"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["LorekeeperPolkelt"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["376"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["476"] = {
			[2] = {
				["Enabled"] = true,
				["announce23381cast"] = true,
				["SpecWarn8040interruptSWSound"] = 1,
				["SpecWarn8040interrupt"] = false,
				["SpecWarn8040interruptSWNote"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiCVoice"] = 0,
				["Timer23381ai"] = true,
				["Timer23381aiTColor"] = 4,
			},
		},
		["412"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["CharlgaRazorflank"] = {
			[2] = {
				["Enabled"] = true,
				["announceother8361target"] = true,
				["SpecWarn8292interruptSWNote"] = true,
				["announce8358spell"] = true,
				["SpecWarn8292interrupt"] = false,
				["SpecWarn8292interruptSWSound"] = 1,
			},
		},
		["JedRunewatcher"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["377"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["373"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Taragaman"] = {
			[2] = {
				["Timer18072ai2TColor"] = 5,
				["Timer11970ai"] = true,
				["Timer18072ai2CVoice"] = 0,
				["announce18072spell2"] = false,
				["Enabled"] = true,
				["Timer18072ai2"] = false,
				["Timer11970aiCVoice"] = 0,
				["announce11970spell"] = true,
				["Timer11970aiTColor"] = 2,
			},
		},
		["MinerJohnson"] = {
			[2] = {
				["Timer12097aiTColor"] = 5,
				["Timer12097aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12097ai"] = true,
				["announceother12097target"] = true,
			},
		},
		["411"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["LordAlexeiBarov"] = {
			[2] = {
				["Enabled"] = true,
				["announceother17820target"] = false,
			},
		},
		["415"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["370"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["InstructorMalicia"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["391"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["419"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["478"] = {
			[2] = {
				["Enabled"] = true,
				["Timer6254ai"] = true,
				["Timer6254aiCVoice"] = 0,
				["Timer6254aiTColor"] = 3,
				["RangeFrame"] = true,
			},
		},
		["Rattlegore"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["403"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["420"] = {
			[2] = {
				["Timer21687ai"] = true,
				["announce21687spell"] = false,
				["Timer21687aiCVoice"] = 0,
				["Timer21687aiTColor"] = 3,
				["Enabled"] = true,
			},
		},
		["385"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Gelihast"] = {
			[2] = {
				["Timer6533aiTColor"] = 5,
				["Timer6533aiCVoice"] = 0,
				["announceother6533target"] = true,
				["Timer6533ai"] = true,
				["Enabled"] = true,
			},
		},
		["386"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["486"] = {
			[2] = {
				["Timer12491aiCVoice"] = 0,
				["Timer12491ai"] = true,
				["announce11086spell"] = true,
				["Timer12491aiTColor"] = 4,
				["SpecWarn15245interruptSWNote"] = true,
				["Timer11086aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer15245ai"] = true,
				["SpecWarn15245interruptSWSound"] = 1,
				["SpecWarn15245interrupt"] = false,
				["Timer15245aiCVoice"] = 0,
				["SpecWarn12491interruptSWSound"] = 1,
				["SpecWarn12491interruptSWNote"] = true,
				["Timer11086ai"] = true,
				["Timer11086aiTColor"] = 1,
				["Timer15245aiTColor"] = 4,
				["SpecWarn12491interrupt"] = false,
			},
		},
		["402"] = {
			[2] = {
				["Enabled"] = true,
				["Yell22651"] = true,
				["announceother22651target"] = true,
			},
		},
		["473"] = {
			[2] = {
				["Enabled"] = true,
				["Timer6524aiCVoice"] = 0,
				["Timer10252aiTColor"] = 1,
				["announce10258spell"] = true,
				["Timer6524ai"] = true,
				["Timer10252aiCVoice"] = 0,
				["announce10252spell"] = true,
				["announce6524spell"] = true,
				["Timer10252ai"] = true,
				["Timer6524aiTColor"] = 2,
			},
		},
		["748"] = {
			[2] = {
				["Enabled"] = true,
				["announceother9941target"] = true,
				["announce10072spell"] = true,
			},
		},
		["383"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["483"] = {
			[2] = {
				["Enabled"] = true,
				["Timer11836ai"] = true,
				["Timer11836aiCVoice"] = 0,
				["announceother11836target"] = true,
				["Timer11902ai"] = true,
				["Timer11902aiCVoice"] = 0,
				["announce11902spell"] = true,
				["Timer11902aiTColor"] = 2,
				["Timer11836aiTColor"] = 3,
			},
		},
		["406"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["DeviateFaerie"] = {
			[2] = {
				["Enabled"] = true,
				["SpecWarn8040interruptSWSound"] = 1,
				["SpecWarn8040interrupt"] = false,
				["SpecWarn8040interruptSWNote"] = true,
				["announceother8040target"] = true,
			},
		},
		["405"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["487"] = {
			[2] = {
				["Timer8362aiCVoice"] = 0,
				["Timer13704aiTColor"] = 2,
				["SpecWarn12039interrupt"] = false,
				["Timer8362ai"] = true,
				["announceother8600target"] = false,
				["Enabled"] = true,
				["SpecWarn8362interruptSWSound"] = 1,
				["SpecWarn8362interrupt"] = false,
				["Timer12039aiTColor"] = 4,
				["Timer8362aiTColor"] = 4,
				["Timer13704ai"] = true,
				["SpecWarn12039interruptSWNote"] = true,
				["SpecWarn12039interruptSWSound"] = 1,
				["SpecWarn8362interruptSWNote"] = true,
				["Timer12039aiCVoice"] = 0,
				["Timer12039ai"] = true,
				["Timer13704aiCVoice"] = 0,
			},
		},
		["480"] = {
			[2] = {
				["Timer8142ai"] = true,
				["announce8142spell"] = true,
				["Timer8142aiTColor"] = 4,
				["Enabled"] = true,
				["Timer8142aiCVoice"] = 0,
			},
		},
		["380"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["408"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["OverlordRamtusk"] = {
			[2] = {
				["Enabled"] = true,
				["announce8259cast"] = true,
			},
		},
		["LadyIlluciaBarov"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["425"] = {
			[2] = {
				["Timer21833cdTColor"] = 3,
				["Timer21833cdCVoice"] = 0,
				["announce21833spell"] = true,
				["Timer21833cd"] = true,
				["Enabled"] = true,
			},
		},
		["749"] = {
			[2] = {
				["Enabled"] = true,
				["Timer15245aiCVoice"] = 0,
				["SpecWarn15245interruptSWSound"] = 1,
				["SpecWarn15245interrupt"] = false,
				["Timer15245ai"] = true,
				["Timer12734aiCVoice"] = 0,
				["SpecWarn15245interruptSWNote"] = true,
				["Timer15245aiTColor"] = 4,
				["Timer12734ai"] = true,
				["announce12734spell"] = true,
				["Timer12734aiTColor"] = 2,
			},
		},
		["396"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["HydromancerVelrath"] = {
			[2] = {
				["Enabled"] = true,
				["Timer12491aiCVoice"] = 0,
				["SpecWarn12491interruptSWNote"] = true,
				["Timer12491aiTColor"] = 4,
				["Timer12491ai"] = true,
				["SpecWarn12491interruptSWSound"] = 1,
				["SpecWarn12491interrupt"] = false,
			},
		},
		["388"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["MordreshFireEye"] = {
			[2] = {
				["Timer12466ai"] = true,
				["SpecWarn12466interruptSWNote"] = true,
				["Timer12470aiCVoice"] = 0,
				["SpecWarn12466interruptSWSound"] = 1,
				["Timer12466aiCVoice"] = 0,
				["Timer12466aiTColor"] = 4,
				["Timer12470aiTColor"] = 5,
				["announce12470spell"] = true,
				["Enabled"] = true,
				["SpecWarn12466interrupt"] = false,
				["Timer12470ai"] = true,
			},
		},
		["449"] = {
			[2] = {
				["announceother17405target"] = true,
				["Timer17405aiTColor"] = 3,
				["announce13704spell"] = true,
				["Timer17405aiCVoice"] = 0,
				["Timer13704ai"] = true,
				["Timer13704aiTColor"] = 2,
				["Timer17405ai"] = true,
				["Enabled"] = true,
				["Timer13704aiCVoice"] = 0,
			},
		},
		["424"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["JandiceBarov"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["369"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["387"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["456"] = {
			[2] = {
				["Timer17473ai"] = true,
				["Timer17473aiCVoice"] = 0,
				["Timer17471next"] = true,
				["Timer17471nextTColor"] = 5,
				["Timer17471nextCVoice"] = 0,
				["Timer17473aiTColor"] = 1,
				["Enabled"] = true,
				["announce17473spell"] = true,
			},
		},
		["KirtonostheHerald"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["378"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["407"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["472"] = {
			[2] = {
				["announceother9906target"] = true,
				["Timer6742aiTColor"] = 5,
				["SpecWarn12167interruptSWNote"] = true,
				["Timer12167aiCVoice"] = 0,
				["announceother3636target"] = false,
				["Timer6742aiCVoice"] = 0,
				["Timer8292ai"] = true,
				["SpecWarn8292interruptSWNote"] = true,
				["Timer8292aiTColor"] = 4,
				["SpecWarn8292interruptSWSound"] = 1,
				["SpecWarn12167interrupt"] = false,
				["Timer8292aiCVoice"] = 0,
				["Enabled"] = true,
				["SpecWarn12167interruptSWSound"] = 1,
				["Timer12167ai"] = true,
				["SpecWarn8292interrupt"] = false,
				["Timer12167aiTColor"] = 4,
				["announceother6742target"] = true,
				["Timer6742ai"] = true,
			},
		},
		["Morphaz"] = {
			[2] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["414"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["372"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["FenrustheDevourer"] = {
			[2] = {
				["Enabled"] = true,
				["Timer7125aiTColor"] = 3,
				["Timer7125aiCVoice"] = 0,
				["Timer7125ai"] = true,
				["announceother7125target"] = false,
			},
		},
		["457"] = {
			[2] = {
				["Timer12889aiTColor"] = 3,
				["Timer12889ai"] = true,
				["Timer12888aiTColor"] = 3,
				["Timer12889aiCVoice"] = 0,
				["Timer12888ai"] = true,
				["Timer12888aiCVoice"] = 0,
				["announceother12889target"] = false,
				["announceother12888target"] = true,
				["Enabled"] = true,
			},
		},
		["CommanderSpringvale"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["AmnennartheColdbringer"] = {
			[2] = {
				["SpecWarn12675interruptSWSound"] = 1,
				["Timer13009aiTColor"] = 2,
				["SpecWarn12675interruptSWNote"] = true,
				["announce13009spell"] = true,
				["Enabled"] = true,
				["SpecWarn13322switchSWNote"] = true,
				["SpecWarn13322switchSWSound"] = 1,
				["Timer13322aiTColor"] = 1,
				["SpecWarn13322switch"] = true,
				["Timer13009ai"] = true,
				["Timer12675ai"] = true,
				["Timer12675aiTColor"] = 4,
				["Timer13322aiCVoice"] = 0,
				["Timer13009aiCVoice"] = 0,
				["Timer13322ai"] = true,
				["Timer12675aiCVoice"] = 0,
				["SpecWarn12675interrupt"] = false,
			},
		},
		["395"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["479"] = {
			[2] = {
				["Enabled"] = true,
				["announce23381cast"] = true,
				["SpecWarn8040interruptSWSound"] = 1,
				["SpecWarn8040interrupt"] = false,
				["SpecWarn8040interruptSWNote"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiCVoice"] = 0,
				["Timer23381ai"] = true,
				["Timer23381aiTColor"] = 4,
			},
		},
		["474"] = {
			[2] = {
				["Enabled"] = true,
				["announce23381cast"] = true,
				["SpecWarn8040interruptSWSound"] = 1,
				["SpecWarn8040interrupt"] = false,
				["SpecWarn8040interruptSWNote"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiCVoice"] = 0,
				["Timer23381ai"] = true,
				["Timer23381aiTColor"] = 4,
			},
		},
		["453"] = {
			[2] = {
				["Enabled"] = true,
				["Timer16869aiTColor"] = 3,
				["Timer16869ai"] = true,
				["Timer16869aiCVoice"] = 0,
				["announceother16869target"] = true,
			},
		},
		["374"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["394"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["PyroguardEmberseer"] = {
			[2] = {
				["Enabled"] = true,
				["timer_combatCVoice"] = 1,
				["timer_combat"] = true,
				["timer_combatTColor"] = 0,
			},
		},
		["379"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["450"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["CaptainGreenskin"] = {
			[2] = {
				["Enabled"] = true,
				["Timer5208ai"] = false,
				["announceother5208target"] = false,
				["Timer5208aiTColor"] = 5,
				["Timer5208aiCVoice"] = 0,
			},
		},
		["Weaver"] = {
			[2] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["OdotheBlindwatcher"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["MrSmite"] = {
			[2] = {
				["Enabled"] = true,
				["announceother6435target"] = true,
				["announceother6264target"] = true,
				["Timer6432fadesTColor"] = 2,
				["Timer6432fadesCVoice"] = 0,
				["Timer6432fades"] = true,
			},
		},
		["458"] = {
			[2] = {
				["Yell12479"] = true,
				["announce12492cast"] = true,
				["Timer12479ai"] = true,
				["SpecWarn12471interruptSWSound"] = 1,
				["announce8376spell"] = true,
				["announce12468cast"] = true,
				["Timer8376ai"] = true,
				["SpecWarn12471interruptSWNote"] = true,
				["Timer8376aiTColor"] = 1,
				["announceother12493target"] = false,
				["Timer12479aiCVoice"] = 0,
				["announceother11639target"] = false,
				["SpecWarn12479you"] = true,
				["Enabled"] = true,
				["announceother12479target"] = true,
				["SpecWarn12471interrupt"] = false,
				["SpecWarn12479youSWNote"] = true,
				["Timer8376aiCVoice"] = 0,
				["Timer12479aiTColor"] = 4,
				["SpecWarn12479youSWSound"] = 1,
			},
		},
		["KamDeepfury"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Dreamscythe"] = {
			[2] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["475"] = {
			[2] = {
				["announceother17330target"] = false,
				["announce23381cast"] = true,
				["SpecWarn8040interruptSWSound"] = 1,
				["SpecWarn8040interrupt"] = false,
				["SpecWarn8040interruptSWNote"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer23381aiCVoice"] = 0,
				["Timer23381ai"] = false,
				["Timer23381aiTColor"] = 5,
			},
		},
		["TheBeast"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Roogug"] = {
			[2] = {
				["Enabled"] = true,
				["announce8270spell"] = true,
			},
		},
		["375"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["SolakarFlamewreath"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["RazorclawtheButcher"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["DeathSpeakerJargba"] = {
			[2] = {
				["Enabled"] = true,
				["announceother14515target2"] = false,
				["announce14515cast"] = true,
				["Timer14515ai"] = true,
				["Timer14515aiCVoice"] = 0,
				["Timer14515aiTColor"] = 3,
			},
		},
		["Ragglesnout"] = {
			[2] = {
				["Enabled"] = true,
				["announceother7645target"] = true,
				["SpecWarn12039interruptSWSound"] = 1,
				["Timer7645ai"] = true,
				["Timer12039ai"] = true,
				["Timer7645aiTColor"] = 3,
				["SpecWarn12039interrupt"] = false,
				["Timer12039aiCVoice"] = 0,
				["SpecWarn12039interruptSWNote"] = true,
				["Timer12039aiTColor"] = 4,
				["Timer7645aiCVoice"] = 0,
			},
		},
		["WarchiefRendBlackhand"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["BlindHunter"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["371"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["471"] = {
			[2] = {
				["SpecWarn6725interruptSWSound"] = 1,
				["Timer11969ai"] = true,
				["announce11969spell"] = true,
				["SpecWarn3356interruptSWNote"] = true,
				["SpecWarn6725interrupt"] = false,
				["Timer11969aiTColor"] = 2,
				["SpecWarn3356interrupt"] = false,
				["SpecWarn3356interruptSWSound"] = 1,
				["Enabled"] = true,
				["Timer11969aiCVoice"] = 0,
				["SpecWarn6725interruptSWNote"] = true,
			},
		},
		["467"] = {
			[2] = {
				["Enabled"] = true,
				["SpecWarn15801interrupt"] = false,
				["Timer16006aiCVoice"] = 0,
				["SpecWarn16006interrupt"] = false,
				["SpecWarn15801interruptSWNote"] = true,
				["Timer15801ai"] = true,
				["SpecWarn16006interruptSWSound"] = 1,
				["Timer15801aiTColor"] = 4,
				["SpecWarn16006interruptSWNote"] = true,
				["Timer16006aiTColor"] = 4,
				["Timer16006ai"] = true,
				["SpecWarn15801interruptSWSound"] = 1,
				["Timer15801aiCVoice"] = 0,
			},
		},
		["DarkmasterGandling"] = {
			[2] = {
				["Enabled"] = true,
				["announce17950spell"] = true,
			},
		},
		["BazilThredd"] = {
			[2] = {
				["Enabled"] = true,
				["Timer7964cd"] = true,
				["announce7964spell"] = true,
				["Timer7964cdTColor"] = 3,
				["Timer7964cdCVoice"] = 0,
			},
		},
		["Cookie"] = {
			[2] = {
				["Enabled"] = true,
				["SpecWarn5174interruptSWSound"] = 1,
				["SpecWarn5174interruptSWNote"] = true,
				["SpecWarn5174interrupt"] = false,
				["Timer5174ai"] = true,
				["Timer5174aiTColor"] = 4,
				["Timer5174aiCVoice"] = 0,
			},
		},
		["463"] = {
			[2] = {
				["Enabled"] = true,
				["Timer12533ai"] = true,
				["announceother12890target"] = true,
				["Timer24375ai"] = true,
				["announce12533spell"] = true,
				["Timer12890aiTColor"] = 3,
				["Timer24375aiCVoice"] = 0,
				["Timer24375aiTColor"] = 2,
				["Timer12533aiTColor"] = 5,
				["announce24375spell"] = true,
				["Timer12890ai"] = true,
				["Timer12890aiCVoice"] = 0,
				["Timer12533aiCVoice"] = 0,
			},
		},
		["445"] = {
			[2] = {
				["Enabled"] = true,
				["announceother8599target"] = true,
			},
		},
		["TwilightLordKelris"] = {
			[2] = {
				["Enabled"] = true,
				["Timer8399aiTColor"] = 3,
				["Timer8399ai"] = true,
				["announceother8399target"] = true,
				["Timer8399aiCVoice"] = 0,
			},
		},
		["469"] = {
			[2] = {
				["Enabled"] = true,
				["Timer8374ai2"] = false,
				["announce11876spell"] = true,
				["Timer11876aiCVoice"] = 0,
				["Timer11876aiTColor"] = 2,
				["announce8374spell"] = true,
				["Timer8374ai2TColor"] = 5,
				["Timer8374ai2CVoice"] = 0,
				["Timer11876ai"] = true,
			},
		},
		["BruegalIronknuckle"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Mograine_and_Whitemane"] = {
			[2] = {
				["Enabled"] = true,
				["Timer9256fades"] = true,
				["SpecWarn12039interrupt"] = false,
				["Timer9256fadesTColor"] = 6,
				["announce9256spell"] = true,
				["SpecWarn12039interruptSWNote"] = true,
				["SpecWarn12039interruptSWSound"] = 1,
				["Timer9256fadesCVoice"] = 0,
			},
		},
		["455"] = {
			[2] = {
				["Timer5568aiTColor"] = 2,
				["Timer5568aiCVoice"] = 0,
				["Timer5568ai"] = true,
				["Timer17307aiTColor"] = 5,
				["Timer17307ai"] = true,
				["announce5568spell"] = true,
				["Timer17307aiCVoice"] = 0,
				["Enabled"] = true,
				["announce17307spell"] = true,
				["TimerGuards"] = true,
				["TimerGuardsTColor"] = 1,
				["TimerGuardsCVoice"] = 0,
			},
		},
		["431"] = {
			[2] = {
				["announce21909spell"] = true,
				["Timer21869cdTColor"] = 3,
				["SpecWarn21909runSWSound"] = 4,
				["SpecWarn21909run"] = true,
				["Timer21869cdCVoice"] = 0,
				["Timer21909cdTColor"] = 2,
				["announce21832spell"] = true,
				["announce21869spell"] = true,
				["SpecWarn21909runSWNote"] = true,
				["Timer21909cdCVoice"] = 0,
				["Timer21909cd"] = true,
				["Timer21869cd"] = true,
				["Enabled"] = true,
			},
		},
		["484"] = {
			[2] = {
				["SpecWarn15982interruptSWNote"] = true,
				["Timer11894aiCVoice"] = 0,
				["announce4971spell"] = true,
				["SpecWarn11894switchSWSound"] = 1,
				["announce8376spell"] = true,
				["Enabled"] = true,
				["SpecWarn11894switch"] = true,
				["Timer15982aiCVoice"] = 0,
				["SpecWarn11895interrupt"] = false,
				["SpecWarn11895interruptSWNote"] = true,
				["SpecWarn15982interrupt"] = false,
				["Timer11895aiCVoice"] = 0,
				["SpecWarn11894switchSWNote"] = true,
				["Timer15982ai"] = true,
				["Timer11895ai"] = true,
				["SpecWarn15982interruptSWSound"] = 1,
				["Timer11894ai"] = true,
				["Timer11895aiTColor"] = 4,
				["SpecWarn11895interruptSWSound"] = 1,
				["Timer11894aiTColor"] = 1,
				["Timer15982aiTColor"] = 4,
			},
		},
		["SneedsShredder"] = {
			[2] = {
				["Enabled"] = true,
				["announceother7399target"] = true,
				["Timer6713aiCVoice"] = 0,
				["Timer7399aiCVoice"] = 0,
				["announceother6713target"] = true,
				["Timer7399aiTColor"] = 3,
				["announce5141spell"] = true,
				["Timer6713aiTColor"] = 5,
				["Timer6713ai"] = true,
				["Timer7399ai"] = true,
			},
		},
		["OldSerrakis"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["384"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Targorr"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["Oggleflint"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["468"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["470"] = {
			[2] = {
				["Timer10132ai"] = true,
				["Timer10132aiCVoice"] = 0,
				["announce10132spell"] = true,
				["Timer10132aiTColor"] = 3,
				["Enabled"] = true,
			},
		},
		["MardukBlackpool"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["485"] = {
			[2] = {
				["Enabled"] = true,
				["announceother8600target"] = false,
				["announce11089spell"] = true,
			},
		},
		["404"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
		["477"] = {
			[2] = {
				["Enabled"] = true,
			},
		},
	},
	["Crimora-Everlook"] = {
		["452"] = {
			[3] = {
				["announceother6016target2"] = true,
				["Timer6016ai2"] = true,
				["Timer17235ai"] = true,
				["Timer17235aiCVoice"] = 0,
				["announce17235spell"] = true,
				["Timer17235aiTColor"] = 1,
				["Timer6016ai2CVoice"] = 0,
				["Enabled"] = true,
				["Timer6016ai2TColor"] = 5,
			},
		},
		["RasFrostwhisper"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["Tutenkash"] = {
			[3] = {
				["Enabled"] = true,
				["Timer12255aiTColor"] = 3,
				["Timer12252aiTColor"] = 5,
				["announceother12255target"] = false,
				["Timer12255ai"] = true,
				["Timer12252aiCVoice"] = 0,
				["announce12252spell"] = true,
				["Timer12252ai"] = true,
				["Timer12255aiCVoice"] = 0,
			},
		},
		["454"] = {
			[3] = {
				["Enabled"] = true,
				["Timer14099ai2"] = true,
				["Timer10887aiTColor"] = 2,
				["Timer14099ai2TColor"] = 5,
				["Timer10887ai"] = true,
				["Timer10887aiCVoice"] = 0,
				["announce14099spell"] = true,
				["Timer14099ai2CVoice"] = 0,
				["announce10887spell"] = true,
			},
		},
		["WolfMasterNandos"] = {
			[3] = {
				["Enabled"] = true,
				["announce7488spell"] = true,
				["Timer7487ai"] = true,
				["Timer7487aiTColor"] = 1,
				["Timer7489aiTColor"] = 1,
				["Timer7489aiCVoice"] = 0,
				["Timer7489ai"] = true,
				["Timer7487aiCVoice"] = 0,
				["Timer7488aiCVoice"] = 0,
				["Timer7488aiTColor"] = 1,
				["announce7489spell"] = true,
				["Timer7488ai"] = true,
				["announce7487spell"] = true,
			},
		},
		["430"] = {
			[3] = {
				["Timer16495aiTColor"] = 5,
				["Timer16495ai"] = true,
				["Timer16495aiCVoice"] = 0,
				["announce16495spell"] = true,
				["Enabled"] = true,
			},
		},
		["Fairbanks"] = {
			[3] = {
				["Enabled"] = true,
				["announceother8282target"] = false,
			},
		},
		["BloodmageThalnos"] = {
			[3] = {
				["Enabled"] = true,
				["announce8814spell"] = true,
				["Timer8814ai"] = true,
				["announce12470spell"] = true,
				["Timer8814aiCVoice"] = 0,
				["Timer8814aiTColor"] = 3,
			},
		},
		["451"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn17244targetchangeSWNote"] = true,
				["announceother18327target"] = true,
				["SpecWarn17244targetchangeSWSound"] = 1,
				["SpecWarn17244targetchange"] = true,
				["announceother16867target"] = false,
			},
		},
		["DextrenWard"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["Gilnid"] = {
			[3] = {
				["Enabled"] = true,
				["Timer5213aiTColor"] = 3,
				["Timer5213ai"] = true,
				["Timer5213aiCVoice"] = 0,
				["announceother5213target"] = true,
			},
		},
		["446"] = {
			[3] = {
				["Enabled"] = true,
				["Timer17279ai"] = true,
				["announce17279spell"] = false,
				["Timer17279aiCVoice"] = 0,
				["Timer17279aiTColor"] = 1,
			},
		},
		["Akumai"] = {
			[3] = {
				["Timer3815aiTColor"] = 3,
				["Timer3490aiTColor"] = 5,
				["announce3490spell"] = true,
				["Timer3490ai"] = true,
				["Timer3815ai"] = true,
				["Timer3490aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer3815aiCVoice"] = 0,
				["announce3815spell"] = true,
			},
		},
		["PlaguemawtheRotting"] = {
			[3] = {
				["Enabled"] = true,
				["Timer12946aiCVoice"] = 0,
				["SpecWarn12946dispelSWNote"] = true,
				["Timer12946ai"] = true,
				["Timer12946aiTColor"] = 5,
				["SpecWarn12946dispelSWSound"] = 1,
				["SpecWarn12946dispel"] = true,
				["announceother11442target"] = true,
			},
		},
		["422"] = {
			[3] = {
				["announce11518spell"] = true,
				["Timer10101aiCVoice"] = 0,
				["announce10101spell"] = true,
				["Enabled"] = true,
				["Timer10101aiTColor"] = 2,
				["Timer10101ai"] = true,
			},
		},
		["443"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn16798interruptSWSound"] = 1,
				["Timer16798ai"] = true,
				["SpecWarn16798interruptSWNote"] = true,
				["SpecWarn16798interrupt"] = false,
				["announceother16798target"] = true,
				["Timer16798aiCVoice"] = 0,
				["Timer16798aiTColor"] = 4,
			},
		},
		["421"] = {
			[3] = {
				["Timer11082aiCVoice"] = 0,
				["SpecWarn11082interruptSWNote"] = true,
				["Timer11082aiTColor"] = 4,
				["Timer11084ai2CVoice"] = 0,
				["SpecWarn11082interrupt"] = false,
				["SpecWarn11085interruptSWSound"] = 1,
				["Timer11085aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer11084ai2TColor"] = 5,
				["Timer11085ai"] = true,
				["Timer11085aiTColor"] = 4,
				["Timer11084ai2"] = true,
				["Timer11082ai"] = true,
				["SpecWarn11085interruptSWNote"] = true,
				["SpecWarn11085interrupt"] = false,
				["SpecWarn11082interruptSWSound"] = 1,
				["announce11084spell"] = true,
			},
		},
		["ArcanistDoan"] = {
			[3] = {
				["Enabled"] = true,
				["announceother13323target"] = true,
				["SpecWarn9435run"] = true,
				["Timer8988cdCVoice"] = 0,
				["SpecWarn9435runSWSound"] = 4,
				["announce8988cast"] = true,
				["Timer8988cd"] = true,
				["Timer8988cdTColor"] = 3,
				["announce9433spell2"] = false,
				["SpecWarn9435runSWNote"] = true,
			},
		},
		["429"] = {
			[3] = {
				["Enabled"] = true,
				["Timer5568cd"] = true,
				["Timer21808aiTColor"] = 0,
				["announce5568spell"] = true,
				["Timer5568cdCVoice"] = 0,
				["Timer11130cd"] = true,
				["Timer5568cdTColor"] = 2,
				["announce11130spell"] = true,
				["Timer21808aiCVoice"] = 0,
				["announce21808spell"] = true,
				["Timer11130cdCVoice"] = 0,
				["Timer21808ai"] = true,
				["Timer11130cdTColor"] = 2,
			},
		},
		["DoctorTheolenKrastinov"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["InterrogatorVishas"] = {
			[3] = {
				["Enabled"] = true,
				["Timer9034aiCVoice"] = 0,
				["announceother9034target"] = true,
				["Timer9034aiTColor"] = 3,
				["Timer9034ai"] = true,
			},
		},
		["Hazzas"] = {
			[3] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["448"] = {
			[3] = {
				["Enabled"] = true,
				["Timer17293aiCVoice"] = 0,
				["Timer17293ai"] = true,
				["Timer17366ai"] = true,
				["announceother17293target"] = true,
				["Timer17293aiTColor"] = 3,
				["announce17366spell"] = true,
				["Timer17366aiCVoice"] = 0,
				["Timer17366aiTColor"] = 2,
			},
		},
		["EdwinVanCleef"] = {
			[3] = {
				["announce5200spell"] = true,
				["Timer3391aiTColor"] = 5,
				["Timer3391aiCVoice"] = 0,
				["Timer3391ai"] = true,
				["Enabled"] = true,
				["announce3391spell"] = true,
			},
		},
		["Jergosh"] = {
			[3] = {
				["Enabled"] = true,
				["Timer18267aiTColor"] = 3,
				["Timer20800aiCVoice"] = 0,
				["Timer18267aiCVoice"] = 0,
				["announceother18267target"] = true,
				["announceother20800target"] = true,
				["Timer20800aiTColor"] = 5,
				["Timer18267ai"] = true,
				["Timer20800ai"] = true,
			},
		},
		["413"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["417"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["BaronSilverlaine"] = {
			[3] = {
				["Timer7068aiTColor"] = 3,
				["announceother7068target"] = true,
				["Timer7068ai"] = true,
				["Timer7068aiCVoice"] = 0,
				["Enabled"] = true,
			},
		},
		["393"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["Vectus"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["416"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["390"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["EarthcallerHalmgar"] = {
			[3] = {
				["Enabled"] = true,
				["announce8270spell"] = true,
			},
		},
		["418"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn10887spell"] = true,
				["Timer8374ai2"] = true,
				["SpecWarn10887spellSWNote"] = true,
				["Timer10887aiTColor"] = 2,
				["SpecWarn10887spellSWSound"] = 2,
				["Timer10887ai"] = true,
				["Timer8374ai2CVoice"] = 0,
				["Timer10887aiCVoice"] = 0,
				["Timer8374ai2TColor"] = 5,
			},
		},
		["AggemThorncurse"] = {
			[3] = {
				["Enabled"] = true,
				["announce8286spell"] = true,
				["Timer14900aiCVoice"] = 0,
				["Timer14900aiTColor"] = 4,
				["Timer8286aiTColor"] = 1,
				["SpecWarn14900interrupt"] = false,
				["Timer14900ai"] = true,
				["Timer8286ai"] = true,
				["Timer8286aiCVoice"] = 0,
				["SpecWarn14900interruptSWNote"] = true,
				["SpecWarn14900interruptSWSound"] = 1,
			},
		},
		["Hamhock"] = {
			[3] = {
				["Enabled"] = true,
				["announceother6742target"] = true,
				["RangeFrame"] = true,
			},
		},
		["GeneralDrakkisath"] = {
			[3] = {
				["Enabled"] = true,
				["Timer16805target"] = true,
				["announceother16805target"] = true,
				["Timer16805targetTColor"] = 3,
				["Timer16805targetCVoice"] = 0,
			},
		},
		["HoundmasterLoksey"] = {
			[3] = {
				["Enabled"] = true,
				["announceother6742target"] = true,
			},
		},
		["410"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["AgathelostheRaging"] = {
			[3] = {
				["Enabled"] = true,
				["announceother8269target"] = true,
			},
		},
		["DeathswornCaptain"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["423"] = {
			[3] = {
				["Enabled"] = true,
				["Timer21707aiTColor"] = 1,
				["Timer10966ai"] = true,
				["Timer10966aiCVoice"] = 0,
				["Timer10966aiTColor"] = 5,
				["Timer21707aiCVoice"] = 0,
				["Timer21707ai"] = true,
				["announce10966spell"] = true,
				["announce21707spell"] = true,
			},
		},
		["427"] = {
			[3] = {
				["Enabled"] = true,
				["Timer7964cd"] = true,
				["announce7964spell"] = true,
				["Timer7964cdTColor"] = 3,
				["Timer7964cdCVoice"] = 0,
			},
		},
		["GhamooRa"] = {
			[3] = {
				["Timer5568aiTColor"] = 3,
				["Timer5568aiCVoice"] = 0,
				["announce5568spell"] = true,
				["Enabled"] = true,
				["Timer5568ai"] = true,
			},
		},
		["RhahkZor"] = {
			[3] = {
				["Enabled"] = true,
				["Timer6304ai"] = true,
				["Timer6304aiTColor"] = 5,
				["Timer6304aiCVoice"] = 0,
				["announceother6304target"] = true,
			},
		},
		["ArchmageArugal"] = {
			[3] = {
				["Enabled"] = true,
				["announce7587spell"] = true,
				["Timer7621aiCVoice"] = 0,
				["Timer7621aiTColor"] = 3,
				["Timer7587aiCVoice"] = 0,
				["Timer7621ai"] = true,
				["announceother7621target"] = true,
				["Timer7587aiTColor"] = 6,
				["Timer7587ai"] = true,
			},
		},
		["389"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["489"] = {
			[3] = {
				["Enabled"] = true,
				["announceother8269target"] = true,
			},
		},
		["Rethilgore"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["TheRavenian"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["Glutton"] = {
			[3] = {
				["Enabled"] = true,
				["announce12795spell"] = true,
			},
		},
		["381"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["481"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn7967interruptSWSound"] = 1,
				["announceother7967target"] = true,
				["Timer7399ai"] = true,
				["SpecWarn7967interrupt"] = false,
				["Timer8150aiCVoice"] = 0,
				["SpecWarn7967interruptSWNote"] = true,
				["Timer8150aiTColor"] = 2,
				["Timer7399aiCVoice"] = 0,
				["Timer7399aiTColor"] = 3,
				["Timer7967aiTColor"] = 4,
				["Timer8150ai"] = true,
				["Timer7967aiCVoice"] = 0,
				["announceother7399target"] = true,
				["Timer7967ai"] = true,
			},
		},
		["talent3"] = "PALADIN3",
		["409"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["Bazzalan"] = {
			[3] = {
				["Enabled"] = true,
				["Timer744ai"] = true,
				["Timer744aiTColor"] = 5,
				["Timer744aiCVoice"] = 0,
				["announceother744target"] = true,
			},
		},
		["Herod"] = {
			[3] = {
				["Enabled"] = true,
				["announceother8269target"] = true,
				["SpecWarn8989run2SWSound"] = 4,
				["announce8989spell"] = true,
				["SpecWarn8989run2SWNote"] = true,
				["Timer8989cdCVoice"] = 0,
				["Timer8989cdTColor"] = 4,
				["Timer8989cd"] = true,
				["SpecWarn8989run2"] = false,
			},
		},
		["GoralukAnvilcrack"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["428"] = {
			[3] = {
				["Enabled"] = true,
				["announceother12747target"] = true,
				["announce21968spell"] = false,
				["SpecWarn21807interruptSWNote"] = true,
				["SpecWarn21807interrupt"] = false,
				["SpecWarn21807interruptSWSound"] = 1,
			},
		},
		["LadySerevess"] = {
			[3] = {
				["Timer246ai"] = true,
				["announceother246target"] = true,
				["Timer246aiTColor"] = 3,
				["Enabled"] = true,
				["Timer246aiCVoice"] = 0,
			},
		},
		["392"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["LorekeeperPolkelt"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["376"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["476"] = {
			[3] = {
				["Enabled"] = true,
				["announce23381cast"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiCVoice"] = 0,
				["Timer23381aiTColor"] = 4,
				["Timer23381ai"] = true,
			},
		},
		["412"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["CharlgaRazorflank"] = {
			[3] = {
				["Enabled"] = true,
				["announceother8361target"] = true,
				["SpecWarn8292interruptSWNote"] = true,
				["announce8358spell"] = true,
				["SpecWarn8292interrupt"] = false,
				["SpecWarn8292interruptSWSound"] = 1,
			},
		},
		["JedRunewatcher"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["377"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["373"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["Taragaman"] = {
			[3] = {
				["Timer18072ai2TColor"] = 5,
				["Timer11970ai"] = true,
				["Timer18072ai2CVoice"] = 0,
				["announce18072spell2"] = true,
				["Enabled"] = true,
				["Timer18072ai2"] = true,
				["Timer11970aiCVoice"] = 0,
				["announce11970spell"] = true,
				["Timer11970aiTColor"] = 2,
			},
		},
		["MinerJohnson"] = {
			[3] = {
				["Timer12097aiTColor"] = 5,
				["Timer12097aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12097ai"] = true,
				["announceother12097target"] = true,
			},
		},
		["411"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["LordAlexeiBarov"] = {
			[3] = {
				["Enabled"] = true,
				["announceother17820target"] = false,
			},
		},
		["415"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["370"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["InstructorMalicia"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["391"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["419"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["478"] = {
			[3] = {
				["Enabled"] = true,
				["Timer6254ai"] = true,
				["Timer6254aiCVoice"] = 0,
				["RangeFrame"] = true,
				["Timer6254aiTColor"] = 3,
			},
		},
		["Rattlegore"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["403"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["477"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["404"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["485"] = {
			[3] = {
				["Enabled"] = true,
				["announce11089spell"] = true,
				["announceother8600target"] = true,
			},
		},
		["386"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["486"] = {
			[3] = {
				["Enabled"] = true,
				["Timer15245ai"] = true,
				["Timer12491aiCVoice"] = 0,
				["Timer11086ai"] = true,
				["announce11086spell"] = true,
				["Timer15245aiCVoice"] = 0,
				["Timer12491aiTColor"] = 4,
				["Timer15245aiTColor"] = 4,
				["Timer12491ai"] = true,
				["SpecWarn12491interruptSWNote"] = true,
				["Timer11086aiCVoice"] = 0,
				["Timer11086aiTColor"] = 1,
				["SpecWarn12491interruptSWSound"] = 1,
				["SpecWarn12491interrupt"] = false,
			},
		},
		["MardukBlackpool"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["470"] = {
			[3] = {
				["Timer10132ai"] = true,
				["Timer10132aiCVoice"] = 0,
				["announce10132spell"] = true,
				["Timer10132aiTColor"] = 3,
				["Enabled"] = true,
			},
		},
		["748"] = {
			[3] = {
				["Enabled"] = true,
				["announceother9941target"] = true,
				["announce10072spell"] = true,
			},
		},
		["383"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["483"] = {
			[3] = {
				["Enabled"] = true,
				["Timer11836ai"] = true,
				["Timer11836aiCVoice"] = 0,
				["announceother11836target"] = true,
				["Timer11902ai"] = true,
				["Timer11902aiCVoice"] = 0,
				["announce11902spell"] = true,
				["Timer11902aiTColor"] = 2,
				["Timer11836aiTColor"] = 3,
			},
		},
		["406"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["425"] = {
			[3] = {
				["Timer21833cdTColor"] = 3,
				["Timer21833cdCVoice"] = 0,
				["announce21833spell"] = true,
				["Timer21833cd"] = true,
				["Enabled"] = true,
			},
		},
		["384"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["487"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn8362interruptSWSound"] = 1,
				["SpecWarn8362interrupt"] = false,
				["Timer13704aiCVoice"] = 0,
				["Timer12039aiTColor"] = 4,
				["Timer8362aiTColor"] = 4,
				["Timer12039ai"] = true,
				["Timer13704ai"] = true,
				["Timer13704aiTColor"] = 2,
				["Timer12039aiCVoice"] = 0,
				["SpecWarn8362interruptSWNote"] = true,
				["Timer8362ai"] = true,
				["Timer8362aiCVoice"] = 0,
				["announceother8600target"] = true,
			},
		},
		["480"] = {
			[3] = {
				["Timer8142ai"] = true,
				["announce8142spell"] = true,
				["Timer8142aiTColor"] = 4,
				["Timer8142aiCVoice"] = 0,
				["Enabled"] = true,
			},
		},
		["380"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["408"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["OverlordRamtusk"] = {
			[3] = {
				["Enabled"] = true,
				["announce8259cast"] = true,
			},
		},
		["LadyIlluciaBarov"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["DeviateFaerie"] = {
			[3] = {
				["Enabled"] = true,
				["announceother8040target"] = true,
			},
		},
		["405"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["OldSerrakis"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["SneedsShredder"] = {
			[3] = {
				["Enabled"] = true,
				["announceother7399target"] = true,
				["Timer6713aiCVoice"] = 0,
				["Timer7399aiCVoice"] = 0,
				["announceother6713target"] = true,
				["Timer7399aiTColor"] = 3,
				["announce5141spell"] = true,
				["Timer6713aiTColor"] = 5,
				["Timer6713ai"] = true,
				["Timer7399ai"] = true,
			},
		},
		["388"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["MordreshFireEye"] = {
			[3] = {
				["Timer12466ai"] = true,
				["SpecWarn12466interruptSWNote"] = true,
				["Timer12470aiCVoice"] = 0,
				["SpecWarn12466interruptSWSound"] = 1,
				["Timer12466aiCVoice"] = 0,
				["Timer12470ai"] = true,
				["Timer12470aiTColor"] = 5,
				["Enabled"] = true,
				["announce12470spell"] = true,
				["SpecWarn12466interrupt"] = false,
				["Timer12466aiTColor"] = 4,
			},
		},
		["484"] = {
			[3] = {
				["SpecWarn15982interruptSWNote"] = true,
				["Timer11894aiCVoice"] = 0,
				["announce4971spell"] = true,
				["SpecWarn11894switchSWSound"] = 1,
				["announce8376spell"] = true,
				["Enabled"] = true,
				["Timer15982aiTColor"] = 4,
				["Timer15982aiCVoice"] = 0,
				["Timer11894aiTColor"] = 1,
				["SpecWarn11895interruptSWNote"] = true,
				["SpecWarn15982interrupt"] = false,
				["Timer11895aiCVoice"] = 0,
				["SpecWarn11894switchSWNote"] = true,
				["Timer15982ai"] = true,
				["Timer11895aiTColor"] = 4,
				["Timer11894ai"] = true,
				["SpecWarn15982interruptSWSound"] = 1,
				["Timer11895ai"] = true,
				["SpecWarn11895interruptSWSound"] = 1,
				["SpecWarn11895interrupt"] = false,
				["SpecWarn11894switch"] = true,
			},
		},
		["424"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["431"] = {
			[3] = {
				["announce21909spell"] = true,
				["Timer21869cdTColor"] = 3,
				["SpecWarn21909runSWSound"] = 4,
				["SpecWarn21909run"] = true,
				["Timer21869cdCVoice"] = 0,
				["Timer21909cdTColor"] = 2,
				["announce21832spell"] = true,
				["Enabled"] = true,
				["Timer21869cd"] = true,
				["Timer21909cdCVoice"] = 0,
				["Timer21909cd"] = true,
				["SpecWarn21909runSWNote"] = true,
				["announce21869spell"] = true,
			},
		},
		["455"] = {
			[3] = {
				["Timer5568aiTColor"] = 2,
				["Timer5568aiCVoice"] = 0,
				["Timer5568ai"] = true,
				["Timer17307aiTColor"] = 5,
				["Timer17307ai"] = true,
				["TimerGuardsCVoice"] = 0,
				["Timer17307aiCVoice"] = 0,
				["TimerGuardsTColor"] = 1,
				["announce17307spell"] = true,
				["TimerGuards"] = true,
				["Enabled"] = true,
				["announce5568spell"] = true,
			},
		},
		["Mograine_and_Whitemane"] = {
			[3] = {
				["Enabled"] = true,
				["Timer9256fadesTColor"] = 6,
				["Timer9256fadesCVoice"] = 0,
				["announce9256spell"] = true,
				["Timer9256fades"] = true,
			},
		},
		["456"] = {
			[3] = {
				["Timer17473ai"] = true,
				["Timer17473aiCVoice"] = 0,
				["Timer17471nextCVoice"] = 0,
				["Timer17471nextTColor"] = 5,
				["Timer17471next"] = true,
				["Timer17473aiTColor"] = 1,
				["Enabled"] = true,
				["announce17473spell"] = true,
			},
		},
		["472"] = {
			[3] = {
				["Timer8292ai"] = true,
				["SpecWarn12167interrupt"] = false,
				["announceother9906target"] = true,
				["SpecWarn12167interruptSWNote"] = true,
				["Timer6742aiTColor"] = 5,
				["Timer8292aiTColor"] = 4,
				["Timer12167aiCVoice"] = 0,
				["Timer12167ai"] = true,
				["Timer8292aiCVoice"] = 0,
				["SpecWarn12167interruptSWSound"] = 1,
				["announceother3636target"] = true,
				["Timer6742aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12167aiTColor"] = 4,
				["announceother6742target"] = true,
				["Timer6742ai"] = true,
			},
		},
		["BruegalIronknuckle"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["469"] = {
			[3] = {
				["Enabled"] = true,
				["Timer8374ai2"] = true,
				["announce11876spell"] = true,
				["Timer11876aiCVoice"] = 0,
				["Timer11876aiTColor"] = 2,
				["announce8374spell"] = true,
				["Timer8374ai2TColor"] = 5,
				["Timer8374ai2CVoice"] = 0,
				["Timer11876ai"] = true,
			},
		},
		["TwilightLordKelris"] = {
			[3] = {
				["Enabled"] = true,
				["Timer8399aiTColor"] = 3,
				["Timer8399ai"] = true,
				["Timer8399aiCVoice"] = 0,
				["announceother8399target"] = true,
			},
		},
		["Morphaz"] = {
			[3] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["445"] = {
			[3] = {
				["Enabled"] = true,
				["announceother8599target"] = true,
			},
		},
		["372"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["FenrustheDevourer"] = {
			[3] = {
				["Enabled"] = true,
				["Timer7125aiTColor"] = 3,
				["Timer7125aiCVoice"] = 0,
				["Timer7125ai"] = true,
				["announceother7125target"] = true,
			},
		},
		["457"] = {
			[3] = {
				["Timer12889aiTColor"] = 3,
				["Timer12889ai"] = true,
				["Timer12888aiTColor"] = 3,
				["Timer12889aiCVoice"] = 0,
				["Timer12888ai"] = true,
				["Timer12888aiCVoice"] = 0,
				["Enabled"] = true,
				["announceother12888target"] = true,
				["announceother12889target"] = false,
			},
		},
		["Cookie"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn5174interruptSWSound"] = 1,
				["SpecWarn5174interruptSWNote"] = true,
				["SpecWarn5174interrupt"] = false,
				["Timer5174aiCVoice"] = 0,
				["Timer5174aiTColor"] = 4,
				["Timer5174ai"] = true,
			},
		},
		["AmnennartheColdbringer"] = {
			[3] = {
				["SpecWarn12675interruptSWSound"] = 1,
				["Timer13009aiTColor"] = 2,
				["SpecWarn12675interruptSWNote"] = true,
				["announce13009spell"] = true,
				["Enabled"] = true,
				["SpecWarn13322switchSWNote"] = true,
				["SpecWarn13322switchSWSound"] = 1,
				["Timer13322aiCVoice"] = 0,
				["Timer12675aiCVoice"] = 0,
				["Timer13009ai"] = true,
				["Timer12675ai"] = true,
				["Timer12675aiTColor"] = 4,
				["Timer13322aiTColor"] = 1,
				["Timer13322ai"] = true,
				["Timer13009aiCVoice"] = 0,
				["SpecWarn13322switch"] = true,
				["SpecWarn12675interrupt"] = false,
			},
		},
		["BazilThredd"] = {
			[3] = {
				["Enabled"] = true,
				["Timer7964cd"] = true,
				["announce7964spell"] = true,
				["Timer7964cdTColor"] = 3,
				["Timer7964cdCVoice"] = 0,
			},
		},
		["PyroguardEmberseer"] = {
			[3] = {
				["Enabled"] = true,
				["timer_combatCVoice"] = 1,
				["timer_combat"] = true,
				["timer_combatTColor"] = 0,
			},
		},
		["CaptainGreenskin"] = {
			[3] = {
				["Enabled"] = true,
				["Timer5208ai"] = true,
				["announceother5208target"] = true,
				["Timer5208aiTColor"] = 5,
				["Timer5208aiCVoice"] = 0,
			},
		},
		["453"] = {
			[3] = {
				["Enabled"] = true,
				["Timer16869aiTColor"] = 3,
				["Timer16869ai"] = true,
				["Timer16869aiCVoice"] = 0,
				["announceother16869target"] = true,
			},
		},
		["375"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["475"] = {
			[3] = {
				["announceother17330target"] = true,
				["announce23381cast"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiTColor"] = 5,
				["Timer23381aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer23381ai"] = true,
			},
		},
		["479"] = {
			[3] = {
				["Enabled"] = true,
				["announce23381cast"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiCVoice"] = 0,
				["Timer23381aiTColor"] = 4,
				["Timer23381ai"] = true,
			},
		},
		["379"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["450"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["474"] = {
			[3] = {
				["Enabled"] = true,
				["announce23381cast"] = true,
				["SpecWarn8040interruptSWSound"] = 1,
				["SpecWarn8040interrupt"] = false,
				["SpecWarn8040interruptSWNote"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiCVoice"] = 0,
				["Timer23381aiTColor"] = 4,
				["Timer23381ai"] = true,
			},
		},
		["Weaver"] = {
			[3] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["OdotheBlindwatcher"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["MrSmite"] = {
			[3] = {
				["Enabled"] = true,
				["announceother6435target"] = true,
				["announceother6264target"] = true,
				["Timer6432fadesCVoice"] = 0,
				["Timer6432fades"] = true,
				["Timer6432fadesTColor"] = 2,
			},
		},
		["471"] = {
			[3] = {
				["SpecWarn6725interruptSWSound"] = 1,
				["Timer11969ai"] = true,
				["announce11969spell"] = true,
				["SpecWarn3356interruptSWNote"] = true,
				["SpecWarn6725interrupt"] = false,
				["Timer11969aiTColor"] = 2,
				["Enabled"] = true,
				["SpecWarn3356interruptSWSound"] = 1,
				["SpecWarn3356interrupt"] = false,
				["Timer11969aiCVoice"] = 0,
				["SpecWarn6725interruptSWNote"] = true,
			},
		},
		["KamDeepfury"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["Dreamscythe"] = {
			[3] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["371"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["TheBeast"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["Roogug"] = {
			[3] = {
				["Enabled"] = true,
				["announce8270spell"] = true,
			},
		},
		["BlindHunter"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["SolakarFlamewreath"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["RazorclawtheButcher"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["DeathSpeakerJargba"] = {
			[3] = {
				["Enabled"] = true,
				["announceother14515target2"] = false,
				["announce14515cast"] = true,
				["Timer14515ai"] = true,
				["Timer14515aiCVoice"] = 0,
				["Timer14515aiTColor"] = 3,
			},
		},
		["Ragglesnout"] = {
			[3] = {
				["Enabled"] = true,
				["announceother7645target"] = true,
				["SpecWarn12039interruptSWSound"] = 1,
				["Timer7645ai"] = true,
				["Timer12039ai"] = true,
				["Timer7645aiCVoice"] = 0,
				["SpecWarn12039interrupt"] = false,
				["Timer12039aiTColor"] = 4,
				["SpecWarn12039interruptSWNote"] = true,
				["Timer12039aiCVoice"] = 0,
				["Timer7645aiTColor"] = 3,
			},
		},
		["WarchiefRendBlackhand"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["458"] = {
			[3] = {
				["Yell12479"] = true,
				["announce12492cast"] = true,
				["Timer12479ai"] = true,
				["SpecWarn12471interruptSWSound"] = 1,
				["announce8376spell"] = true,
				["announce12468cast"] = true,
				["Timer8376ai"] = true,
				["SpecWarn12471interruptSWNote"] = true,
				["Timer8376aiTColor"] = 1,
				["announceother12493target"] = false,
				["Timer12479aiCVoice"] = 0,
				["Timer12479aiTColor"] = 4,
				["SpecWarn12479you"] = true,
				["Timer8376aiCVoice"] = 0,
				["announceother12479target"] = true,
				["SpecWarn12479youSWNote"] = true,
				["SpecWarn12471interrupt"] = false,
				["Enabled"] = true,
				["announceother11639target"] = true,
				["SpecWarn12479youSWSound"] = 1,
			},
		},
		["394"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["374"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["467"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn15801interrupt"] = false,
				["Timer16006aiCVoice"] = 0,
				["SpecWarn16006interrupt"] = false,
				["SpecWarn15801interruptSWNote"] = true,
				["Timer15801ai"] = true,
				["Timer15801aiCVoice"] = 0,
				["Timer15801aiTColor"] = 4,
				["SpecWarn16006interruptSWNote"] = true,
				["Timer16006aiTColor"] = 4,
				["Timer16006ai"] = true,
				["SpecWarn15801interruptSWSound"] = 1,
				["SpecWarn16006interruptSWSound"] = 1,
			},
		},
		["DarkmasterGandling"] = {
			[3] = {
				["Enabled"] = true,
				["announce17950spell"] = true,
			},
		},
		["395"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["CommanderSpringvale"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["463"] = {
			[3] = {
				["Enabled"] = true,
				["Timer12533ai"] = true,
				["announceother12890target"] = true,
				["Timer24375ai"] = true,
				["announce12533spell"] = true,
				["Timer24375aiCVoice"] = 0,
				["Timer12890aiCVoice"] = 0,
				["Timer24375aiTColor"] = 2,
				["announce24375spell"] = true,
				["Timer12533aiTColor"] = 5,
				["Timer12890ai"] = true,
				["Timer12890aiTColor"] = 3,
				["Timer12533aiCVoice"] = 0,
			},
		},
		["414"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["407"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["378"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["KirtonostheHerald"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["387"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["369"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["JandiceBarov"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["449"] = {
			[3] = {
				["announceother17405target"] = true,
				["Timer17405aiTColor"] = 3,
				["announce13704spell"] = true,
				["Timer17405aiCVoice"] = 0,
				["Timer13704ai"] = true,
				["Timer13704aiTColor"] = 2,
				["Timer17405ai"] = true,
				["Enabled"] = true,
				["Timer13704aiCVoice"] = 0,
			},
		},
		["HydromancerVelrath"] = {
			[3] = {
				["Enabled"] = true,
				["Timer12491aiTColor"] = 4,
				["Timer12491aiCVoice"] = 0,
				["Timer12491ai"] = true,
			},
		},
		["396"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["749"] = {
			[3] = {
				["Enabled"] = true,
				["Timer15245aiCVoice"] = 0,
				["SpecWarn15245interruptSWSound"] = 1,
				["SpecWarn15245interrupt"] = false,
				["Timer12734aiTColor"] = 2,
				["Timer12734aiCVoice"] = 0,
				["SpecWarn15245interruptSWNote"] = true,
				["announce12734spell"] = true,
				["Timer12734ai"] = true,
				["Timer15245aiTColor"] = 4,
				["Timer15245ai"] = true,
			},
		},
		["Targorr"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["Oggleflint"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["468"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["473"] = {
			[3] = {
				["Enabled"] = true,
				["Timer6524aiCVoice"] = 0,
				["Timer10252aiTColor"] = 1,
				["announce10258spell"] = true,
				["Timer6524ai"] = true,
				["Timer10252aiCVoice"] = 0,
				["announce10252spell"] = true,
				["announce6524spell"] = true,
				["Timer10252ai"] = true,
				["Timer6524aiTColor"] = 2,
			},
		},
		["402"] = {
			[3] = {
				["Enabled"] = true,
				["Yell22651"] = true,
				["announceother22651target"] = true,
			},
		},
		["Gelihast"] = {
			[3] = {
				["Timer6533aiTColor"] = 5,
				["Timer6533aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer6533ai"] = true,
				["announceother6533target"] = true,
			},
		},
		["385"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["420"] = {
			[3] = {
				["Timer21687ai"] = true,
				["announce21687spell"] = true,
				["Timer21687aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer21687aiTColor"] = 3,
			},
		},
	},
	["Hoddl-Everlook"] = {
		["452"] = {
			[0] = {
				["announceother6016target2"] = false,
				["Timer6016ai2"] = false,
				["Timer17235ai"] = true,
				["Timer17235aiCVoice"] = 0,
				["announce17235spell"] = true,
				["Timer17235aiTColor"] = 1,
				["Timer6016ai2CVoice"] = 0,
				["Enabled"] = true,
				["Timer6016ai2TColor"] = 5,
			},
		},
		["RasFrostwhisper"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Tutenkash"] = {
			[0] = {
				["Enabled"] = true,
				["Timer12255aiTColor"] = 3,
				["Timer12252aiTColor"] = 5,
				["announceother12255target"] = false,
				["Timer12255ai"] = true,
				["Timer12252aiCVoice"] = 0,
				["announce12252spell"] = true,
				["Timer12252ai"] = true,
				["Timer12255aiCVoice"] = 0,
			},
		},
		["454"] = {
			[0] = {
				["Enabled"] = true,
				["Timer14099ai2"] = false,
				["Timer10887aiTColor"] = 2,
				["Timer14099ai2TColor"] = 5,
				["Timer10887ai"] = true,
				["Timer10887aiCVoice"] = 0,
				["announce14099spell"] = true,
				["Timer14099ai2CVoice"] = 0,
				["announce10887spell"] = true,
			},
		},
		["WolfMasterNandos"] = {
			[0] = {
				["Enabled"] = true,
				["announce7488spell"] = true,
				["Timer7487ai"] = true,
				["Timer7487aiTColor"] = 1,
				["Timer7489aiTColor"] = 1,
				["Timer7489aiCVoice"] = 0,
				["Timer7489ai"] = true,
				["Timer7487aiCVoice"] = 0,
				["Timer7488aiCVoice"] = 0,
				["announce7489spell"] = true,
				["Timer7488aiTColor"] = 1,
				["Timer7488ai"] = true,
				["announce7487spell"] = true,
			},
		},
		["430"] = {
			[0] = {
				["Timer16495aiTColor"] = 5,
				["Timer16495ai"] = true,
				["Timer16495aiCVoice"] = 0,
				["announce16495spell"] = true,
				["Enabled"] = true,
			},
		},
		["Fairbanks"] = {
			[0] = {
				["Enabled"] = true,
				["announceother8282target"] = false,
			},
		},
		["BloodmageThalnos"] = {
			[0] = {
				["Enabled"] = true,
				["announce8814spell"] = true,
				["Timer8814ai"] = true,
				["announce12470spell"] = true,
				["Timer8814aiCVoice"] = 0,
				["Timer8814aiTColor"] = 3,
			},
		},
		["451"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn17244targetchangeSWNote"] = true,
				["announceother18327target"] = false,
				["SpecWarn17244targetchangeSWSound"] = 1,
				["SpecWarn17244targetchange"] = true,
				["announceother16867target"] = false,
			},
		},
		["DextrenWard"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Gilnid"] = {
			[0] = {
				["Enabled"] = true,
				["Timer5213aiTColor"] = 3,
				["Timer5213ai"] = true,
				["Timer5213aiCVoice"] = 0,
				["announceother5213target"] = true,
			},
		},
		["446"] = {
			[0] = {
				["Enabled"] = true,
				["Timer17279ai"] = true,
				["announce17279spell"] = false,
				["Timer17279aiCVoice"] = 0,
				["Timer17279aiTColor"] = 1,
			},
		},
		["Akumai"] = {
			[0] = {
				["Timer3815aiTColor"] = 3,
				["Timer3490aiTColor"] = 5,
				["announce3490spell"] = true,
				["Timer3490ai"] = true,
				["Timer3815ai"] = true,
				["Timer3490aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer3815aiCVoice"] = 0,
				["announce3815spell"] = true,
			},
		},
		["PlaguemawtheRotting"] = {
			[0] = {
				["Enabled"] = true,
				["Timer12946aiCVoice"] = 0,
				["SpecWarn12946dispelSWNote"] = true,
				["Timer12946ai"] = true,
				["Timer12946aiTColor"] = 5,
				["SpecWarn12946dispelSWSound"] = 1,
				["announceother11442target"] = false,
				["SpecWarn12946dispel"] = false,
			},
		},
		["422"] = {
			[0] = {
				["announce11518spell"] = true,
				["Timer10101aiCVoice"] = 0,
				["announce10101spell"] = true,
				["Enabled"] = true,
				["Timer10101aiTColor"] = 2,
				["Timer10101ai"] = true,
			},
		},
		["443"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn16798interruptSWSound"] = 1,
				["Timer16798ai"] = true,
				["SpecWarn16798interruptSWNote"] = true,
				["SpecWarn16798interrupt"] = false,
				["announceother16798target"] = true,
				["Timer16798aiCVoice"] = 0,
				["Timer16798aiTColor"] = 4,
			},
		},
		["421"] = {
			[0] = {
				["Timer11082aiCVoice"] = 0,
				["SpecWarn11082interruptSWNote"] = true,
				["Timer11082aiTColor"] = 4,
				["Timer11084ai2CVoice"] = 0,
				["SpecWarn11082interrupt"] = false,
				["SpecWarn11085interruptSWSound"] = 1,
				["Timer11085aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer11084ai2TColor"] = 5,
				["Timer11085ai"] = true,
				["Timer11085aiTColor"] = 4,
				["Timer11084ai2"] = false,
				["Timer11082ai"] = true,
				["SpecWarn11085interruptSWNote"] = true,
				["SpecWarn11085interrupt"] = false,
				["SpecWarn11082interruptSWSound"] = 1,
				["announce11084spell"] = false,
			},
		},
		["ArcanistDoan"] = {
			[0] = {
				["Enabled"] = true,
				["announceother13323target"] = true,
				["SpecWarn9435run"] = true,
				["Timer8988cdCVoice"] = 0,
				["SpecWarn9435runSWSound"] = 4,
				["announce8988cast"] = true,
				["Timer8988cd"] = true,
				["Timer8988cdTColor"] = 3,
				["announce9433spell2"] = false,
				["SpecWarn9435runSWNote"] = true,
			},
		},
		["429"] = {
			[0] = {
				["Enabled"] = true,
				["Timer5568cd"] = true,
				["Timer21808aiTColor"] = 0,
				["announce5568spell"] = true,
				["Timer5568cdCVoice"] = 0,
				["Timer11130cd"] = true,
				["Timer5568cdTColor"] = 2,
				["announce11130spell"] = true,
				["Timer21808aiCVoice"] = 0,
				["announce21808spell"] = true,
				["Timer11130cdCVoice"] = 0,
				["Timer21808ai"] = true,
				["Timer11130cdTColor"] = 2,
			},
		},
		["DoctorTheolenKrastinov"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["InterrogatorVishas"] = {
			[0] = {
				["Enabled"] = true,
				["Timer9034aiCVoice"] = 0,
				["Timer9034ai"] = true,
				["announceother9034target"] = true,
				["Timer9034aiTColor"] = 3,
			},
		},
		["Hazzas"] = {
			[0] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["448"] = {
			[0] = {
				["Enabled"] = true,
				["Timer17293aiCVoice"] = 0,
				["Timer17293ai"] = true,
				["Timer17366ai"] = true,
				["announceother17293target"] = true,
				["Timer17293aiTColor"] = 3,
				["announce17366spell"] = true,
				["Timer17366aiCVoice"] = 0,
				["Timer17366aiTColor"] = 2,
			},
		},
		["EdwinVanCleef"] = {
			[0] = {
				["announce5200spell"] = true,
				["Timer3391aiTColor"] = 5,
				["Timer3391aiCVoice"] = 0,
				["Timer3391ai"] = true,
				["Enabled"] = true,
				["announce3391spell"] = true,
			},
		},
		["Jergosh"] = {
			[0] = {
				["Enabled"] = true,
				["Timer18267aiTColor"] = 3,
				["Timer20800aiCVoice"] = 0,
				["Timer18267aiCVoice"] = 0,
				["announceother18267target"] = true,
				["announceother20800target"] = false,
				["Timer20800aiTColor"] = 5,
				["Timer18267ai"] = true,
				["Timer20800ai"] = false,
			},
		},
		["413"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["417"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["BaronSilverlaine"] = {
			[0] = {
				["Timer7068aiTColor"] = 3,
				["announceother7068target"] = true,
				["Timer7068ai"] = true,
				["Timer7068aiCVoice"] = 0,
				["Enabled"] = true,
			},
		},
		["393"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Vectus"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["416"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["390"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["EarthcallerHalmgar"] = {
			[0] = {
				["Enabled"] = true,
				["announce8270spell"] = true,
			},
		},
		["418"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn10887spell"] = false,
				["Timer8374ai2"] = false,
				["SpecWarn10887spellSWNote"] = true,
				["Timer10887aiTColor"] = 2,
				["SpecWarn10887spellSWSound"] = 2,
				["Timer10887ai"] = true,
				["Timer8374ai2CVoice"] = 0,
				["Timer10887aiCVoice"] = 0,
				["Timer8374ai2TColor"] = 5,
			},
		},
		["AggemThorncurse"] = {
			[0] = {
				["Enabled"] = true,
				["announce8286spell"] = true,
				["SpecWarn14900interruptSWSound"] = 1,
				["Timer14900aiCVoice"] = 0,
				["Timer8286aiTColor"] = 1,
				["SpecWarn14900interrupt"] = false,
				["Timer8286ai"] = true,
				["Timer14900ai"] = true,
				["Timer8286aiCVoice"] = 0,
				["SpecWarn14900interruptSWNote"] = true,
				["Timer14900aiTColor"] = 4,
			},
		},
		["Hamhock"] = {
			[0] = {
				["Enabled"] = true,
				["announceother6742target"] = true,
				["RangeFrame"] = true,
			},
		},
		["GeneralDrakkisath"] = {
			[0] = {
				["Enabled"] = true,
				["Timer16805target"] = true,
				["announceother16805target"] = true,
				["Timer16805targetTColor"] = 3,
				["Timer16805targetCVoice"] = 0,
			},
		},
		["HoundmasterLoksey"] = {
			[0] = {
				["Enabled"] = true,
				["announceother6742target"] = true,
			},
		},
		["410"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["AgathelostheRaging"] = {
			[0] = {
				["Enabled"] = true,
				["announceother8269target"] = true,
			},
		},
		["DeathswornCaptain"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["423"] = {
			[0] = {
				["Enabled"] = true,
				["Timer21707aiTColor"] = 1,
				["Timer10966ai"] = true,
				["Timer10966aiCVoice"] = 0,
				["Timer10966aiTColor"] = 5,
				["Timer21707aiCVoice"] = 0,
				["Timer21707ai"] = true,
				["announce10966spell"] = true,
				["announce21707spell"] = true,
			},
		},
		["427"] = {
			[0] = {
				["Enabled"] = true,
				["Timer7964cd"] = true,
				["announce7964spell"] = true,
				["Timer7964cdTColor"] = 3,
				["Timer7964cdCVoice"] = 0,
			},
		},
		["GhamooRa"] = {
			[0] = {
				["Timer5568aiTColor"] = 3,
				["Timer5568aiCVoice"] = 0,
				["announce5568spell"] = true,
				["Enabled"] = true,
				["Timer5568ai"] = true,
			},
		},
		["RhahkZor"] = {
			[0] = {
				["Enabled"] = true,
				["Timer6304ai"] = true,
				["Timer6304aiTColor"] = 5,
				["Timer6304aiCVoice"] = 0,
				["announceother6304target"] = true,
			},
		},
		["ArchmageArugal"] = {
			[0] = {
				["Enabled"] = true,
				["announce7587spell"] = true,
				["Timer7621aiCVoice"] = 0,
				["Timer7621aiTColor"] = 3,
				["Timer7587aiCVoice"] = 0,
				["Timer7621ai"] = true,
				["announceother7621target"] = true,
				["Timer7587aiTColor"] = 6,
				["Timer7587ai"] = true,
			},
		},
		["389"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["489"] = {
			[0] = {
				["Enabled"] = true,
				["announceother8269target"] = true,
			},
		},
		["Rethilgore"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["TheRavenian"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Glutton"] = {
			[0] = {
				["Enabled"] = true,
				["announce12795spell"] = true,
			},
		},
		["381"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["481"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn7967interruptSWSound"] = 1,
				["announceother7967target"] = true,
				["Timer7399ai"] = true,
				["SpecWarn7967interrupt"] = false,
				["Timer8150aiCVoice"] = 0,
				["SpecWarn7967interruptSWNote"] = true,
				["Timer8150aiTColor"] = 2,
				["Timer7399aiCVoice"] = 0,
				["Timer7399aiTColor"] = 3,
				["Timer7967aiTColor"] = 4,
				["Timer8150ai"] = true,
				["Timer7967aiCVoice"] = 0,
				["announceother7399target"] = true,
				["Timer7967ai"] = true,
			},
		},
		["409"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Bazzalan"] = {
			[0] = {
				["Enabled"] = true,
				["Timer744ai"] = false,
				["Timer744aiTColor"] = 5,
				["Timer744aiCVoice"] = 0,
				["announceother744target"] = false,
			},
		},
		["Herod"] = {
			[0] = {
				["Enabled"] = true,
				["announceother8269target"] = true,
				["SpecWarn8989run2SWSound"] = 4,
				["announce8989spell"] = true,
				["SpecWarn8989run2"] = false,
				["Timer8989cdCVoice"] = 0,
				["Timer8989cdTColor"] = 4,
				["SpecWarn8989run2SWNote"] = true,
				["Timer8989cd"] = true,
			},
		},
		["GoralukAnvilcrack"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["428"] = {
			[0] = {
				["Enabled"] = true,
				["announceother12747target"] = true,
				["announce21968spell"] = false,
				["SpecWarn21807interruptSWNote"] = true,
				["SpecWarn21807interrupt"] = false,
				["SpecWarn21807interruptSWSound"] = 1,
			},
		},
		["LadySerevess"] = {
			[0] = {
				["Timer246ai"] = true,
				["announceother246target"] = true,
				["Timer246aiTColor"] = 3,
				["Enabled"] = true,
				["Timer246aiCVoice"] = 0,
			},
		},
		["392"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["LorekeeperPolkelt"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["376"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["476"] = {
			[0] = {
				["Enabled"] = true,
				["announce23381cast"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiCVoice"] = 0,
				["Timer23381aiTColor"] = 4,
				["Timer23381ai"] = true,
			},
		},
		["412"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["CharlgaRazorflank"] = {
			[0] = {
				["Enabled"] = true,
				["announceother8361target"] = true,
				["SpecWarn8292interruptSWNote"] = true,
				["announce8358spell"] = true,
				["SpecWarn8292interrupt"] = false,
				["SpecWarn8292interruptSWSound"] = 1,
			},
		},
		["JedRunewatcher"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["377"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["373"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Taragaman"] = {
			[0] = {
				["Timer18072ai2TColor"] = 5,
				["Timer11970ai"] = true,
				["Timer18072ai2CVoice"] = 0,
				["announce18072spell2"] = false,
				["Enabled"] = true,
				["Timer18072ai2"] = false,
				["Timer11970aiCVoice"] = 0,
				["announce11970spell"] = true,
				["Timer11970aiTColor"] = 2,
			},
		},
		["MinerJohnson"] = {
			[0] = {
				["Timer12097aiTColor"] = 5,
				["Timer12097aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12097ai"] = true,
				["announceother12097target"] = true,
			},
		},
		["411"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["LordAlexeiBarov"] = {
			[0] = {
				["Enabled"] = true,
				["announceother17820target"] = false,
			},
		},
		["415"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["370"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["InstructorMalicia"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["391"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["419"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["478"] = {
			[0] = {
				["Enabled"] = true,
				["Timer6254ai"] = true,
				["Timer6254aiCVoice"] = 0,
				["RangeFrame"] = true,
				["Timer6254aiTColor"] = 3,
			},
		},
		["Rattlegore"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["403"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["477"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["404"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["485"] = {
			[0] = {
				["Enabled"] = true,
				["announce11089spell"] = true,
				["announceother8600target"] = false,
			},
		},
		["386"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["486"] = {
			[0] = {
				["Enabled"] = true,
				["Timer15245ai"] = true,
				["Timer12491aiCVoice"] = 0,
				["Timer11086ai"] = true,
				["announce11086spell"] = true,
				["Timer15245aiCVoice"] = 0,
				["Timer12491aiTColor"] = 4,
				["Timer15245aiTColor"] = 4,
				["Timer12491ai"] = true,
				["SpecWarn12491interruptSWNote"] = true,
				["Timer11086aiCVoice"] = 0,
				["Timer11086aiTColor"] = 1,
				["SpecWarn12491interruptSWSound"] = 1,
				["SpecWarn12491interrupt"] = false,
			},
		},
		["MardukBlackpool"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["425"] = {
			[0] = {
				["Timer21833cdTColor"] = 3,
				["Timer21833cdCVoice"] = 0,
				["announce21833spell"] = true,
				["Timer21833cd"] = true,
				["Enabled"] = true,
			},
		},
		["470"] = {
			[0] = {
				["Timer10132ai"] = true,
				["Timer10132aiCVoice"] = 0,
				["announce10132spell"] = true,
				["Timer10132aiTColor"] = 3,
				["Enabled"] = true,
			},
		},
		["383"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["483"] = {
			[0] = {
				["Enabled"] = true,
				["Timer11836ai"] = true,
				["Timer11836aiCVoice"] = 0,
				["announceother11836target"] = true,
				["Timer11902ai"] = true,
				["Timer11902aiCVoice"] = 0,
				["announce11902spell"] = true,
				["Timer11902aiTColor"] = 2,
				["Timer11836aiTColor"] = 3,
			},
		},
		["406"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["748"] = {
			[0] = {
				["Enabled"] = true,
				["announceother9941target"] = true,
				["announce10072spell"] = true,
			},
		},
		["405"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["487"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn8362interruptSWSound"] = 1,
				["SpecWarn8362interrupt"] = false,
				["Timer13704aiCVoice"] = 0,
				["Timer12039aiTColor"] = 4,
				["Timer8362aiTColor"] = 4,
				["Timer8362aiCVoice"] = 0,
				["Timer12039ai"] = true,
				["Timer13704aiTColor"] = 2,
				["Timer12039aiCVoice"] = 0,
				["SpecWarn8362interruptSWNote"] = true,
				["Timer8362ai"] = true,
				["Timer13704ai"] = true,
				["announceother8600target"] = false,
			},
		},
		["480"] = {
			[0] = {
				["Timer8142ai"] = true,
				["announce8142spell"] = true,
				["Timer8142aiTColor"] = 4,
				["Timer8142aiCVoice"] = 0,
				["Enabled"] = true,
			},
		},
		["380"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["408"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["OverlordRamtusk"] = {
			[0] = {
				["Enabled"] = true,
				["announce8259cast"] = true,
			},
		},
		["LadyIlluciaBarov"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["DeviateFaerie"] = {
			[0] = {
				["Enabled"] = true,
				["announceother8040target"] = true,
			},
		},
		["749"] = {
			[0] = {
				["Enabled"] = true,
				["Timer15245aiCVoice"] = 0,
				["SpecWarn15245interruptSWSound"] = 1,
				["SpecWarn15245interrupt"] = false,
				["Timer12734aiTColor"] = 2,
				["Timer12734aiCVoice"] = 0,
				["SpecWarn15245interruptSWNote"] = true,
				["announce12734spell"] = true,
				["Timer12734ai"] = true,
				["Timer15245aiTColor"] = 4,
				["Timer15245ai"] = true,
			},
		},
		["OldSerrakis"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["SneedsShredder"] = {
			[0] = {
				["Enabled"] = true,
				["announceother7399target"] = true,
				["Timer6713aiCVoice"] = 0,
				["Timer7399aiCVoice"] = 0,
				["announceother6713target"] = true,
				["Timer7399aiTColor"] = 3,
				["announce5141spell"] = true,
				["Timer6713aiTColor"] = 5,
				["Timer6713ai"] = true,
				["Timer7399ai"] = true,
			},
		},
		["388"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["MordreshFireEye"] = {
			[0] = {
				["Timer12466ai"] = true,
				["SpecWarn12466interruptSWNote"] = true,
				["Timer12470aiCVoice"] = 0,
				["SpecWarn12466interruptSWSound"] = 1,
				["Timer12466aiCVoice"] = 0,
				["Timer12470ai"] = true,
				["Timer12470aiTColor"] = 5,
				["Enabled"] = true,
				["announce12470spell"] = true,
				["SpecWarn12466interrupt"] = false,
				["Timer12466aiTColor"] = 4,
			},
		},
		["484"] = {
			[0] = {
				["SpecWarn15982interruptSWNote"] = true,
				["Timer11894aiCVoice"] = 0,
				["announce4971spell"] = true,
				["SpecWarn11894switchSWSound"] = 1,
				["announce8376spell"] = true,
				["Enabled"] = true,
				["Timer15982aiTColor"] = 4,
				["Timer15982aiCVoice"] = 0,
				["Timer11894aiTColor"] = 1,
				["SpecWarn11895interruptSWNote"] = true,
				["SpecWarn15982interrupt"] = false,
				["Timer11895aiCVoice"] = 0,
				["SpecWarn11894switchSWNote"] = true,
				["Timer15982ai"] = true,
				["Timer11895aiTColor"] = 4,
				["Timer11894ai"] = true,
				["SpecWarn15982interruptSWSound"] = 1,
				["Timer11895ai"] = true,
				["SpecWarn11895interruptSWSound"] = 1,
				["SpecWarn11895interrupt"] = false,
				["SpecWarn11894switch"] = true,
			},
		},
		["424"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["431"] = {
			[0] = {
				["announce21909spell"] = true,
				["Timer21869cdTColor"] = 3,
				["SpecWarn21909runSWSound"] = 4,
				["SpecWarn21909run"] = false,
				["Timer21869cdCVoice"] = 0,
				["Timer21909cdTColor"] = 2,
				["announce21832spell"] = true,
				["Enabled"] = true,
				["Timer21869cd"] = true,
				["Timer21909cdCVoice"] = 0,
				["Timer21909cd"] = true,
				["SpecWarn21909runSWNote"] = true,
				["announce21869spell"] = true,
			},
		},
		["TwilightLordKelris"] = {
			[0] = {
				["Enabled"] = true,
				["Timer8399aiTColor"] = 3,
				["Timer8399ai"] = true,
				["Timer8399aiCVoice"] = 0,
				["announceother8399target"] = true,
			},
		},
		["BlindHunter"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["456"] = {
			[0] = {
				["Timer17473ai"] = true,
				["Timer17473aiCVoice"] = 0,
				["Timer17471nextCVoice"] = 0,
				["Timer17471nextTColor"] = 5,
				["Timer17471next"] = true,
				["Timer17473aiTColor"] = 1,
				["Enabled"] = true,
				["announce17473spell"] = true,
			},
		},
		["458"] = {
			[0] = {
				["Yell12479"] = true,
				["announce12492cast"] = true,
				["Timer12479ai"] = true,
				["SpecWarn12471interruptSWSound"] = 1,
				["announce8376spell"] = true,
				["announce12468cast"] = true,
				["Timer8376ai"] = true,
				["SpecWarn12471interruptSWNote"] = true,
				["Timer8376aiTColor"] = 1,
				["announceother12493target"] = false,
				["Timer12479aiCVoice"] = 0,
				["Timer12479aiTColor"] = 4,
				["SpecWarn12479you"] = true,
				["Timer8376aiCVoice"] = 0,
				["announceother12479target"] = true,
				["SpecWarn12479youSWNote"] = true,
				["SpecWarn12471interrupt"] = false,
				["Enabled"] = true,
				["announceother11639target"] = false,
				["SpecWarn12479youSWSound"] = 1,
			},
		},
		["455"] = {
			[0] = {
				["Timer5568aiTColor"] = 2,
				["Timer5568aiCVoice"] = 0,
				["Timer5568ai"] = true,
				["Timer17307aiTColor"] = 5,
				["Timer17307ai"] = true,
				["TimerGuardsCVoice"] = 0,
				["Timer17307aiCVoice"] = 0,
				["TimerGuardsTColor"] = 1,
				["announce17307spell"] = true,
				["TimerGuards"] = true,
				["Enabled"] = true,
				["announce5568spell"] = true,
			},
		},
		["Mograine_and_Whitemane"] = {
			[0] = {
				["Enabled"] = true,
				["Timer9256fadesTColor"] = 6,
				["Timer9256fadesCVoice"] = 0,
				["announce9256spell"] = true,
				["Timer9256fades"] = true,
			},
		},
		["472"] = {
			[0] = {
				["Timer8292ai"] = true,
				["SpecWarn12167interruptSWNote"] = true,
				["announceother9906target"] = true,
				["Timer8292aiTColor"] = 4,
				["Timer6742aiTColor"] = 5,
				["SpecWarn12167interrupt"] = false,
				["Timer12167aiCVoice"] = 0,
				["Timer12167ai"] = true,
				["Timer8292aiCVoice"] = 0,
				["announceother3636target"] = false,
				["SpecWarn12167interruptSWSound"] = 1,
				["Timer6742aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12167aiTColor"] = 4,
				["announceother6742target"] = true,
				["Timer6742ai"] = true,
			},
		},
		["Morphaz"] = {
			[0] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["BruegalIronknuckle"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["372"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["469"] = {
			[0] = {
				["Enabled"] = true,
				["Timer8374ai2"] = false,
				["announce11876spell"] = true,
				["Timer11876aiCVoice"] = 0,
				["Timer11876aiTColor"] = 2,
				["announce8374spell"] = true,
				["Timer8374ai2TColor"] = 5,
				["Timer8374ai2CVoice"] = 0,
				["Timer11876ai"] = true,
			},
		},
		["457"] = {
			[0] = {
				["Timer12889aiTColor"] = 3,
				["Timer12889ai"] = true,
				["Timer12888aiTColor"] = 3,
				["Timer12889aiCVoice"] = 0,
				["Timer12888ai"] = true,
				["Timer12888aiCVoice"] = 0,
				["Enabled"] = true,
				["announceother12888target"] = true,
				["announceother12889target"] = false,
			},
		},
		["445"] = {
			[0] = {
				["Enabled"] = true,
				["announceother8599target"] = true,
			},
		},
		["AmnennartheColdbringer"] = {
			[0] = {
				["SpecWarn12675interruptSWSound"] = 1,
				["Timer13009aiTColor"] = 2,
				["SpecWarn12675interruptSWNote"] = true,
				["announce13009spell"] = true,
				["Enabled"] = true,
				["SpecWarn13322switchSWNote"] = true,
				["SpecWarn13322switchSWSound"] = 1,
				["Timer13322aiCVoice"] = 0,
				["Timer12675aiCVoice"] = 0,
				["Timer13009ai"] = true,
				["Timer12675ai"] = true,
				["Timer12675aiTColor"] = 4,
				["Timer13322aiTColor"] = 1,
				["Timer13322ai"] = true,
				["Timer13009aiCVoice"] = 0,
				["SpecWarn13322switch"] = true,
				["SpecWarn12675interrupt"] = false,
			},
		},
		["PyroguardEmberseer"] = {
			[0] = {
				["Enabled"] = true,
				["timer_combatCVoice"] = 1,
				["timer_combat"] = true,
				["timer_combatTColor"] = 0,
			},
		},
		["FenrustheDevourer"] = {
			[0] = {
				["Enabled"] = true,
				["Timer7125aiTColor"] = 3,
				["Timer7125aiCVoice"] = 0,
				["Timer7125ai"] = true,
				["announceother7125target"] = false,
			},
		},
		["Cookie"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn5174interruptSWSound"] = 1,
				["SpecWarn5174interruptSWNote"] = true,
				["SpecWarn5174interrupt"] = false,
				["Timer5174aiCVoice"] = 0,
				["Timer5174aiTColor"] = 4,
				["Timer5174ai"] = true,
			},
		},
		["453"] = {
			[0] = {
				["Enabled"] = true,
				["Timer16869aiTColor"] = 3,
				["Timer16869ai"] = true,
				["Timer16869aiCVoice"] = 0,
				["announceother16869target"] = true,
			},
		},
		["BazilThredd"] = {
			[0] = {
				["Enabled"] = true,
				["Timer7964cd"] = true,
				["announce7964spell"] = true,
				["Timer7964cdTColor"] = 3,
				["Timer7964cdCVoice"] = 0,
			},
		},
		["371"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["479"] = {
			[0] = {
				["Enabled"] = true,
				["announce23381cast"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiCVoice"] = 0,
				["Timer23381aiTColor"] = 4,
				["Timer23381ai"] = true,
			},
		},
		["379"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["450"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["CaptainGreenskin"] = {
			[0] = {
				["Enabled"] = true,
				["Timer5208ai"] = false,
				["announceother5208target"] = false,
				["Timer5208aiTColor"] = 5,
				["Timer5208aiCVoice"] = 0,
			},
		},
		["374"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["OdotheBlindwatcher"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["MrSmite"] = {
			[0] = {
				["Enabled"] = true,
				["announceother6435target"] = true,
				["announceother6264target"] = true,
				["Timer6432fades"] = true,
				["Timer6432fadesCVoice"] = 0,
				["Timer6432fadesTColor"] = 2,
			},
		},
		["375"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["KamDeepfury"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Dreamscythe"] = {
			[0] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["475"] = {
			[0] = {
				["announceother17330target"] = false,
				["announce23381cast"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiTColor"] = 5,
				["Timer23381aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer23381ai"] = false,
			},
		},
		["TheBeast"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Roogug"] = {
			[0] = {
				["Enabled"] = true,
				["announce8270spell"] = true,
			},
		},
		["471"] = {
			[0] = {
				["SpecWarn6725interruptSWSound"] = 1,
				["Timer11969ai"] = true,
				["announce11969spell"] = true,
				["SpecWarn3356interruptSWNote"] = true,
				["SpecWarn6725interrupt"] = false,
				["Timer11969aiTColor"] = 2,
				["Enabled"] = true,
				["SpecWarn3356interruptSWSound"] = 1,
				["SpecWarn3356interrupt"] = false,
				["Timer11969aiCVoice"] = 0,
				["SpecWarn6725interruptSWNote"] = true,
			},
		},
		["SolakarFlamewreath"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["RazorclawtheButcher"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["DeathSpeakerJargba"] = {
			[0] = {
				["Enabled"] = true,
				["announceother14515target2"] = false,
				["announce14515cast"] = true,
				["Timer14515ai"] = true,
				["Timer14515aiCVoice"] = 0,
				["Timer14515aiTColor"] = 3,
			},
		},
		["Ragglesnout"] = {
			[0] = {
				["Enabled"] = true,
				["announceother7645target"] = true,
				["SpecWarn12039interruptSWSound"] = 1,
				["Timer7645ai"] = true,
				["Timer12039ai"] = true,
				["Timer7645aiCVoice"] = 0,
				["SpecWarn12039interrupt"] = false,
				["Timer12039aiTColor"] = 4,
				["Timer12039aiCVoice"] = 0,
				["SpecWarn12039interruptSWNote"] = true,
				["Timer7645aiTColor"] = 3,
			},
		},
		["WarchiefRendBlackhand"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["394"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Weaver"] = {
			[0] = {
				["Timer12882aiCVoice"] = 0,
				["announce12884spell"] = true,
				["Timer12884aiTColor"] = 5,
				["announce12882spell"] = true,
				["Timer12884ai"] = true,
				["Timer12882ai"] = true,
				["Timer12884aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer12882aiTColor"] = 5,
			},
		},
		["474"] = {
			[0] = {
				["Enabled"] = true,
				["announce23381cast"] = true,
				["SpecWarn8040interruptSWSound"] = 1,
				["SpecWarn8040interrupt"] = false,
				["SpecWarn8040interruptSWNote"] = true,
				["Timer8040ai"] = true,
				["announceother8040target"] = true,
				["Timer8040aiTColor"] = 4,
				["Timer8040aiCVoice"] = 0,
				["Timer23381aiCVoice"] = 0,
				["Timer23381aiTColor"] = 4,
				["Timer23381ai"] = true,
			},
		},
		["467"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn15801interrupt"] = false,
				["Timer16006aiCVoice"] = 0,
				["SpecWarn16006interrupt"] = false,
				["SpecWarn15801interruptSWNote"] = true,
				["Timer15801ai"] = true,
				["Timer15801aiCVoice"] = 0,
				["Timer15801aiTColor"] = 4,
				["SpecWarn16006interruptSWNote"] = true,
				["Timer16006aiTColor"] = 4,
				["Timer16006ai"] = true,
				["SpecWarn15801interruptSWSound"] = 1,
				["SpecWarn16006interruptSWSound"] = 1,
			},
		},
		["DarkmasterGandling"] = {
			[0] = {
				["Enabled"] = true,
				["announce17950spell"] = true,
			},
		},
		["395"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["CommanderSpringvale"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["463"] = {
			[0] = {
				["Enabled"] = true,
				["Timer12533ai"] = true,
				["announceother12890target"] = true,
				["Timer24375ai"] = true,
				["announce12533spell"] = true,
				["Timer12890aiCVoice"] = 0,
				["Timer24375aiCVoice"] = 0,
				["Timer24375aiTColor"] = 2,
				["announce24375spell"] = true,
				["Timer12533aiTColor"] = 5,
				["Timer12890ai"] = true,
				["Timer12890aiTColor"] = 3,
				["Timer12533aiCVoice"] = 0,
			},
		},
		["414"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["407"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["378"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["KirtonostheHerald"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["387"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["369"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["JandiceBarov"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["449"] = {
			[0] = {
				["announceother17405target"] = true,
				["Timer17405aiTColor"] = 3,
				["announce13704spell"] = true,
				["Timer17405aiCVoice"] = 0,
				["Timer13704ai"] = true,
				["Timer13704aiTColor"] = 2,
				["Timer17405ai"] = true,
				["Enabled"] = true,
				["Timer13704aiCVoice"] = 0,
			},
		},
		["HydromancerVelrath"] = {
			[0] = {
				["Enabled"] = true,
				["Timer12491aiTColor"] = 4,
				["Timer12491aiCVoice"] = 0,
				["Timer12491ai"] = true,
			},
		},
		["396"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["384"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Targorr"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["Oggleflint"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["468"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["473"] = {
			[0] = {
				["Enabled"] = true,
				["Timer6524aiCVoice"] = 0,
				["Timer10252aiTColor"] = 1,
				["announce10258spell"] = true,
				["Timer6524ai"] = true,
				["Timer10252aiCVoice"] = 0,
				["announce10252spell"] = true,
				["announce6524spell"] = true,
				["Timer10252ai"] = true,
				["Timer6524aiTColor"] = 2,
			},
		},
		["402"] = {
			[0] = {
				["Enabled"] = true,
				["Yell22651"] = true,
				["announceother22651target"] = true,
			},
		},
		["Gelihast"] = {
			[0] = {
				["Timer6533aiTColor"] = 5,
				["Timer6533aiCVoice"] = 0,
				["Enabled"] = true,
				["announceother6533target"] = true,
				["Timer6533ai"] = true,
			},
		},
		["385"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["420"] = {
			[0] = {
				["Timer21687ai"] = true,
				["announce21687spell"] = false,
				["Timer21687aiCVoice"] = 0,
				["Enabled"] = true,
				["Timer21687aiTColor"] = 3,
			},
		},
	},
}
