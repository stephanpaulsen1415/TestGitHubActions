
BagnonItemInfo_DB = {
	["enableItemLevel"] = true,
	["enableItemBind"] = true,
	["enableGarbage"] = true,
	["enableRarityColoring"] = true,
	["enableUncollected"] = true,
}
