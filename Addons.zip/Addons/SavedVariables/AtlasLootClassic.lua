
AtlasLootClassicDB = {
	["global"] = {
		["__addonrevision"] = 3010001,
		["VendorPrice"] = {
			[42518] = "honor:4480:arena:350",
			[42582] = "honor:4480:arena:350",
			[42614] = "arena:1200",
			[33503] = "BoJ:20",
			[40696] = "EmblemOfHeroism:40",
			[45843] = "EmblemOfConquest:39",
			[41847] = "EmblemOfHeroism:30",
			[30770] = "BoJ:20",
			[45204] = "championsSeal:25",
			[42327] = "arena:4500",
			[35326] = "BoJ:75",
			[42519] = "arena:1200",
			[48689] = "EmblemOfHeroism:40",
			[42583] = "arena:1200",
			[33504] = "BoJ:20",
			[40697] = "EmblemOfHeroism:40",
			[45844] = "EmblemOfConquest:39",
			[41848] = "EmblemOfHeroism:45",
			[40857] = "EmblemOfHeroism:30",
			[41912] = "EmblemOfHeroism:45",
			[42008] = "EmblemOfHeroism:30",
			[45205] = "championsSeal:25",
			[42232] = "arena:1350",
			[48722] = "EmblemOfTriumph:50",
			[40634] = "EmblemOfValor:75",
			[33505] = "BoJ:20",
			[40698] = "EmblemOfHeroism:25",
			[45845] = "EmblemOfConquest:39",
			[41849] = "EmblemOfHeroism:45",
			[40858] = "EmblemOfHeroism:30",
			[41913] = "EmblemOfValor:45",
			[42009] = "EmblemOfValor:30",
			[45206] = "championsSeal:10",
			[34049] = "BoJ:75",
			[42265] = "arena:1350",
			[54637] = "cpvpWarsong:1",
			[28885] = "holydust:2",
			[21740] = "ancestrycoin:5",
			[48691] = "EmblemOfHeroism:40",
			[40635] = "EmblemOfValor:75",
			[33506] = "BoJ:20",
			[40699] = "EmblemOfHeroism:25",
			[45846] = "EmblemOfConquest:39",
			[41850] = "EmblemOfHeroism:30",
			[41914] = "EmblemOfConquest:58",
			[29269] = "BoJ:25",
			[34050] = "BoJ:75",
			[29381] = "BoJ:25",
			[42490] = "arena:4500",
			[48724] = "EmblemOfTriumph:50",
			[42618] = "honor:4480:arena:175",
			[40636] = "EmblemOfValor:75",
			[33507] = "BoJ:20",
			[40700] = "EmblemOfHeroism:35",
			[45847] = "EmblemOfConquest:39",
			[41851] = "EmblemOfHeroism:45",
			[40860] = "EmblemOfValor:30",
			[45016] = "championsSeal:15",
			[30772] = "BoJ:30",
			[41084] = "EmblemOfHeroism:45",
			[45208] = "championsSeal:25",
			[50355] = "EmblemOfFrost:60",
			[28886] = "holydust:8",
			[21741] = "ancestrycoin:5",
			[42587] = "honor:4480:arena:350",
			[47734] = "EmblemOfTriumph:50",
			[32083] = "BoJ:50",
			[40637] = "EmblemOfValor:60",
			[33508] = "BoJ:20",
			[40701] = "EmblemOfHeroism:35",
			[40733] = "EmblemOfValor:60",
			[41852] = "EmblemOfValor:45",
			[40861] = "EmblemOfValor:30",
			[40925] = "EmblemOfValor:30",
			[41085] = "EmblemOfValor:45",
			[45209] = "championsSeal:10",
			[50356] = "EmblemOfFrost:60",
			[42332] = "arena:4500",
			[29382] = "BoJ:25",
			[42588] = "arena:1200",
			[47735] = "EmblemOfTriumph:50",
			[40638] = "EmblemOfValor:60",
			[33509] = "BoJ:20",
			[40702] = "EmblemOfHeroism:50",
			[40734] = "EmblemOfValor:60",
			[40798] = "EmblemOfHeroism:30",
			[41853] = "EmblemOfConquest:58",
			[40926] = "EmblemOfConquest:46",
			[30773] = "BoJ:30",
			[45210] = "championsSeal:25",
			[50357] = "EmblemOfFrost:60",
			[40191] = "EmblemOfValor:25",
			[28887] = "holydust:8",
			[33222] = "BoJ:60",
			[42525] = "arena:1350",
			[32084] = "BoJ:50",
			[40639] = "EmblemOfValor:60",
			[33510] = "BoJ:20",
			[40703] = "EmblemOfHeroism:50",
			[40735] = "EmblemOfValor:60",
			[40799] = "EmblemOfHeroism:30",
			[41918] = "EmblemOfHeroism:45",
			[42014] = "EmblemOfHeroism:30",
			[45211] = "championsSeal:10",
			[50358] = "EmblemOfFrost:60",
			[41215] = "EmblemOfValor:30",
			[42270] = "arena:1350",
			[29367] = "BoJ:25",
			[29383] = "BoJ:41",
			[33287] = "BoJ:60",
			[46746] = "championsSeal:5",
			[45819] = "EmblemOfConquest:19",
			[40736] = "EmblemOfValor:60",
			[40864] = "EmblemOfConquest:46",
			[41919] = "EmblemOfValor:45",
			[40960] = "EmblemOfHeroism:30",
			[42015] = "EmblemOfValor:30",
			[19505] = "honor:12000",
			[30774] = "BoJ:20",
			[45212] = "championsSeal:25",
			[40321] = "EmblemOfValor:25",
			[33192] = "BoJ:25",
			[28904] = "arcanerune:2",
			[42495] = "arena:4500",
			[42559] = "arena:2250",
			[32085] = "BoJ:50",
			[33512] = "BoJ:60",
			[45820] = "EmblemOfConquest:19",
			[40737] = "EmblemOfValor:60",
			[30183] = "BoJ:15",
			[40961] = "EmblemOfValor:30",
			[33832] = "BoJ:75",
			[45213] = "championsSeal:10",
			[42208] = "arena:3150",
			[29368] = "BoJ:25",
			[29384] = "BoJ:25",
			[45597] = "championsSeal:100",
			[45725] = "championsSeal:150",
			[33513] = "BoJ:35",
			[40706] = "EmblemOfHeroism:15",
			[33577] = "BoJ:60",
			[44894] = "cpvpWintergrasp:15",
			[41857] = "EmblemOfValor:45",
			[42944] = "EmblemOfHeroism:40",
			[40930] = "EmblemOfHeroism:45",
			[40962] = "EmblemOfConquest:46",
			[45214] = "championsSeal:25",
			[41154] = "EmblemOfHeroism:45",
			[28889] = "holydust:8",
			[33386] = "BoJ:60",
			[32086] = "BoJ:50",
			[33514] = "BoJ:60",
			[45822] = "EmblemOfConquest:19",
			[33578] = "BoJ:35",
			[44895] = "cpvpWintergrasp:15",
			[41858] = "EmblemOfConquest:58",
			[42945] = "EmblemOfHeroism:40",
			[40931] = "EmblemOfValor:45",
			[45087] = "EmblemOfConquest:18",
			[45215] = "championsSeal:10",
			[41155] = "EmblemOfValor:45",
			[42242] = "arena:3150",
			[29369] = "BoJ:25",
			[29385] = "BoJ:25",
			[33291] = "BoJ:60",
			[42594] = "honor:4480:arena:175",
			[40612] = "EmblemOfHeroism:80",
			[33515] = "BoJ:75",
			[45823] = "EmblemOfConquest:19",
			[33579] = "BoJ:75",
			[42946] = "EmblemOfHeroism:65",
			[40932] = "EmblemOfConquest:58",
			[21537] = "ancestrycoin:1",
			[30776] = "BoJ:30",
			[45216] = "championsSeal:10",
			[42275] = "arena:3150",
			[33324] = "BoJ:60",
			[45632] = "EmblemOfConquest:58",
			[42595] = "honor:4480:arena:175",
			[32087] = "BoJ:50",
			[33484] = "BoJ:60",
			[33516] = "BoJ:35",
			[45824] = "EmblemOfConquest:28",
			[33580] = "BoJ:35",
			[40805] = "EmblemOfConquest:46",
			[40837] = "EmblemOfHeroism:45",
			[42947] = "EmblemOfHeroism:65",
			[45217] = "championsSeal:10",
			[29370] = "BoJ:41",
			[29386] = "BoJ:25",
			[33325] = "BoJ:35",
			[42564] = "arena:2250",
			[42596] = "honor:4480:arena:350",
			[40614] = "EmblemOfHeroism:60",
			[40678] = "EmblemOfHeroism:25",
			[45825] = "EmblemOfConquest:28",
			[41765] = "EmblemOfValor:30",
			[42852] = "arena:1200",
			[40838] = "EmblemOfHeroism:45",
			[41925] = "EmblemOfValor:45",
			[21538] = "ancestrycoin:5",
			[30761] = "BoJ:30",
			[33965] = "BoJ:75",
			[43236] = "honor:12",
			[44419] = "arena:4500",
			[28907] = "arcanerune:2",
			[42501] = "honor:4480:arena:350",
			[45634] = "EmblemOfConquest:58",
			[42597] = "arena:1200",
			[40615] = "EmblemOfHeroism:60",
			[41670] = "EmblemOfValor:45",
			[40679] = "EmblemOfHeroism:25",
			[45826] = "EmblemOfConquest:28",
			[40743] = "EmblemOfValor:40",
			[41862] = "EmblemOfValor:45",
			[41926] = "EmblemOfConquest:58",
			[41990] = "EmblemOfHeroism:45",
			[45219] = "championsSeal:10",
			[15197] = "honor:1000",
			[44420] = "arena:4500",
			[42502] = "arena:1200",
			[41671] = "EmblemOfConquest:58",
			[40680] = "EmblemOfHeroism:25",
			[45827] = "EmblemOfConquest:28",
			[33583] = "BoJ:60",
			[41863] = "EmblemOfConquest:58",
			[42950] = "EmblemOfHeroism:40",
			[40936] = "EmblemOfHeroism:45",
			[41991] = "EmblemOfValor:45",
			[21539] = "ancestrycoin:5",
			[30762] = "BoJ:30",
			[30778] = "BoJ:30",
			[45220] = "championsSeal:10",
			[28908] = "arcanerune:2",
			[33296] = "BoJ:35",
			[32089] = "BoJ:50",
			[40681] = "EmblemOfHeroism:25",
			[33552] = "BoJ:75",
			[40745] = "EmblemOfValor:40",
			[44901] = "cpvpWintergrasp:40",
			[40841] = "EmblemOfValor:45",
			[42951] = "EmblemOfHeroism:40",
			[40937] = "EmblemOfValor:45",
			[45221] = "championsSeal:10",
			[42248] = "arena:1350",
			[42280] = "arena:1350",
			[29388] = "BoJ:15",
			[40682] = "EmblemOfHeroism:40",
			[40714] = "EmblemOfHeroism:15",
			[33585] = "BoJ:75",
			[44902] = "cpvpWintergrasp:40",
			[40842] = "EmblemOfValor:45",
			[42952] = "EmblemOfHeroism:40",
			[42984] = "EmblemOfHeroism:40",
			[30763] = "BoJ:20",
			[30779] = "BoJ:20",
			[45222] = "championsSeal:25",
			[44231] = "EmblemOfHeroism:200",
			[40267] = "EmblemOfValor:25",
			[28909] = "arcanerune:8",
			[42537] = "arena:1350",
			[45638] = "EmblemOfConquest:58",
			[42601] = "honor:4480:arena:350",
			[32090] = "BoJ:50",
			[40683] = "EmblemOfHeroism:40",
			[40715] = "EmblemOfHeroism:15",
			[40747] = "EmblemOfValor:40",
			[40779] = "EmblemOfHeroism:45",
			[41930] = "EmblemOfHeroism:30",
			[42985] = "EmblemOfHeroism:40",
			[33810] = "BoJ:75",
			[19031] = "honor:15000",
			[33970] = "BoJ:60",
			[21157] = "ancestrycoin:5",
			[40268] = "EmblemOfValor:25",
			[42346] = "arena:3150",
			[29389] = "BoJ:15",
			[33331] = "BoJ:60",
			[42570] = "arena:2250",
			[42602] = "arena:1200",
			[201993] = "arena:550",
			[41643] = "EmblemOfHeroism:30",
			[40684] = "EmblemOfHeroism:40",
			[40716] = "EmblemOfHeroism:15",
			[40748] = "EmblemOfValor:40",
			[40780] = "EmblemOfHeroism:45",
			[41867] = "EmblemOfValor:30",
			[41931] = "EmblemOfValor:30",
			[21541] = "ancestrycoin:5",
			[30764] = "BoJ:20",
			[30780] = "BoJ:20",
			[34163] = "BoJ:75",
			[28878] = "holydust:2",
			[28910] = "arcanerune:8",
			[48677] = "EmblemOfHeroism:40",
			[45640] = "EmblemOfConquest:58",
			[41644] = "EmblemOfHeroism:45",
			[40685] = "EmblemOfHeroism:40",
			[40717] = "EmblemOfValor:25",
			[40749] = "EmblemOfValor:40",
			[40781] = "EmblemOfValor:45",
			[41868] = "EmblemOfConquest:46",
			[41996] = "EmblemOfHeroism:45",
			[33972] = "BoJ:75",
			[29374] = "BoJ:25",
			[29390] = "BoJ:15",
			[42444] = "honor:4480:arena:175",
			[33333] = "BoJ:60",
			[41645] = "EmblemOfHeroism:45",
			[40718] = "EmblemOfValor:25",
			[33589] = "BoJ:35",
			[40782] = "EmblemOfValor:45",
			[40846] = "EmblemOfConquest:58",
			[41933] = "EmblemOfConquest:46",
			[23572] = "BoJ:10",
			[33973] = "BoJ:60",
			[40207] = "EmblemOfValor:25",
			[42285] = "arena:3150",
			[42317] = "arena:4500",
			[28911] = "arcanerune:8",
			[33334] = "BoJ:35",
			[41646] = "EmblemOfHeroism:30",
			[45834] = "EmblemOfConquest:28",
			[39728] = "EmblemOfValor:25",
			[44971] = "championsSeal:40",
			[33974] = "BoJ:60",
			[15199] = "honor:10000",
			[29375] = "BoJ:25",
			[33207] = "BoJ:60",
			[42574] = "honor:4480:arena:175",
			[42606] = "honor:4480:arena:350",
			[41647] = "EmblemOfHeroism:45",
			[40688] = "EmblemOfHeroism:40",
			[33559] = "BoJ:60",
			[21543] = "ancestrycoin:5",
			[30766] = "BoJ:30",
			[42255] = "arena:1350",
			[40337] = "EmblemOfValor:25",
			[28912] = "arcanerune:8",
			[33304] = "BoJ:60",
			[42575] = "honor:4480:arena:175",
			[42607] = "arena:1200",
			[41648] = "EmblemOfValor:45",
			[33528] = "BoJ:60",
			[45836] = "EmblemOfConquest:28",
			[40785] = "EmblemOfConquest:58",
			[40817] = "EmblemOfHeroism:45",
			[41872] = "EmblemOfValor:30",
			[42991] = "EmblemOfHeroism:50",
			[42352] = "arena:3150",
			[42384] = "arena:4500",
			[42448] = "honor:4480:arena:175",
			[42512] = "honor:4480:arena:350",
			[42576] = "honor:4480:arena:175",
			[41649] = "EmblemOfConquest:58",
			[41681] = "EmblemOfValor:30",
			[33529] = "BoJ:35",
			[45837] = "EmblemOfConquest:28",
			[33593] = "BoJ:35",
			[40818] = "EmblemOfHeroism:45",
			[41873] = "EmblemOfConquest:46",
			[41937] = "EmblemOfHeroism:30",
			[42992] = "EmblemOfHeroism:50",
			[42001] = "EmblemOfValor:45",
			[21544] = "ancestrycoin:5",
			[30767] = "BoJ:20",
			[41202] = "EmblemOfHeroism:45",
			[28881] = "holydust:2",
			[42449] = "honor:4480:arena:350",
			[42513] = "arena:1200",
			[48683] = "EmblemOfHeroism:40",
			[42577] = "honor:4480:arena:350",
			[44918] = "ancestrycoin:5",
			[44919] = "ancestrycoin:5",
			[21743] = "ancestrycoin:5",
			[41682] = "EmblemOfConquest:46",
			[40691] = "EmblemOfHeroism:40",
			[45838] = "EmblemOfConquest:28",
			[21742] = "ancestrycoin:5",
			[44917] = "ancestrycoin:5",
			[44916] = "ancestrycoin:5",
			[21640] = "ancestrycoin:5",
			[29373] = "BoJ:25",
			[41938] = "EmblemOfValor:30",
			[45829] = "EmblemOfConquest:28",
			[42002] = "EmblemOfHeroism:45",
			[42948] = "EmblemOfHeroism:50",
			[39757] = "EmblemOfValor:25",
			[45218] = "championsSeal:10",
			[45203] = "championsSeal:25",
			[40938] = "EmblemOfConquest:58",
			[40746] = "EmblemOfValor:40",
			[41203] = "EmblemOfValor:45",
			[40905] = "EmblemOfConquest:58",
			[42290] = "arena:1350",
			[42322] = "arena:4500",
			[42949] = "EmblemOfHeroism:40",
			[29268] = "BoJ:33",
			[40825] = "EmblemOfConquest:58",
			[42450] = "arena:1200",
			[35321] = "BoJ:60",
			[45583] = "championsSeal:50",
			[33517] = "BoJ:60",
			[48716] = "EmblemOfHeroism:40",
			[29387] = "BoJ:41",
			[33527] = "BoJ:75",
			[29275] = "BoJ:50",
			[40720] = "EmblemOfValor:25",
			[40692] = "EmblemOfHeroism:40",
			[45839] = "EmblemOfConquest:28",
			[33566] = "BoJ:75",
			[40695] = "EmblemOfHeroism:40",
			[44912] = "cpvpWintergrasp:25",
			[40739] = "EmblemOfValor:60",
			[42851] = "honor:4480:arena:350",
			[41939] = "EmblemOfConquest:46",
			[45821] = "EmblemOfConquest:19",
			[42003] = "EmblemOfValor:45",
			[29274] = "BoJ:25",
			[30768] = "BoJ:20",
			[40689] = "EmblemOfHeroism:40",
			[40904] = "EmblemOfValor:45",
			[41140] = "EmblemOfHeroism:30",
			[41766] = "EmblemOfConquest:46",
			[42227] = "arena:1350",
			[42485] = "arena:4500",
			[41924] = "EmblemOfHeroism:45",
			[40610] = "EmblemOfHeroism:80",
			[40322] = "EmblemOfValor:25",
			[28882] = "holydust:2",
			[28888] = "holydust:8",
			[33530] = "BoJ:75",
			[41214] = "EmblemOfHeroism:30",
			[40705] = "EmblemOfHeroism:15",
			[48685] = "EmblemOfHeroism:40",
			[33588] = "BoJ:35",
			[42611] = "honor:4480:arena:175",
			[33540] = "BoJ:35",
			[33519] = "BoJ:60",
			[33532] = "BoJ:35",
			[40693] = "EmblemOfHeroism:40",
			[45840] = "EmblemOfConquest:28",
			[42578] = "arena:1200",
			[44115] = "cpvpWintergrasp:9",
			[40821] = "EmblemOfValor:45",
			[33524] = "BoJ:60",
			[40738] = "EmblemOfValor:60",
			[34162] = "BoJ:75",
			[33587] = "BoJ:60",
			[45835] = "EmblemOfConquest:28",
			[41920] = "EmblemOfConquest:58",
			[40742] = "EmblemOfValor:40",
			[33539] = "BoJ:60",
			[29266] = "BoJ:33",
			[41141] = "EmblemOfValor:30",
			[33523] = "BoJ:60",
			[40613] = "EmblemOfHeroism:60",
			[42260] = "arena:3150",
			[29272] = "BoJ:25",
			[29273] = "BoJ:25",
			[42593] = "honor:4480:arena:175",
			[40342] = "EmblemOfValor:25",
			[40803] = "EmblemOfValor:30",
			[40741] = "EmblemOfValor:60",
			[40820] = "EmblemOfValor:45",
			[40724] = "EmblemOfValor:25",
			[33586] = "BoJ:60",
			[48718] = "EmblemOfHeroism:65",
			[42612] = "honor:4480:arena:175",
			[33522] = "BoJ:75",
			[41653] = "EmblemOfValor:45",
			[33501] = "BoJ:75",
			[40694] = "EmblemOfHeroism:40",
			[45841] = "EmblemOfConquest:39",
			[33538] = "BoJ:75",
			[42943] = "EmblemOfHeroism:65",
			[44914] = "cpvpWintergrasp:25",
			[40723] = "EmblemOfValor:25",
			[40707] = "EmblemOfHeroism:15",
			[40918] = "EmblemOfHeroism:30",
			[43102] = "EmblemOfHeroism:10",
			[33531] = "BoJ:60",
			[42511] = "honor:4480:arena:175",
			[30769] = "BoJ:30",
			[29376] = "BoJ:41",
			[45833] = "EmblemOfConquest:28",
			[40802] = "EmblemOfValor:30",
			[33537] = "BoJ:60",
			[45848] = "EmblemOfConquest:39",
			[40722] = "EmblemOfValor:25",
			[33536] = "BoJ:60",
			[33520] = "BoJ:35",
			[40611] = "EmblemOfHeroism:80",
			[40898] = "EmblemOfHeroism:45",
			[33584] = "BoJ:75",
			[42362] = "arena:4500",
			[35324] = "BoJ:60",
			[42517] = "honor:4480:arena:175",
			[48687] = "EmblemOfHeroism:40",
			[33280] = "BoJ:60",
			[42613] = "honor:4480:arena:350",
			[45831] = "EmblemOfConquest:28",
			[41654] = "EmblemOfConquest:58",
			[33502] = "BoJ:20",
			[33534] = "BoJ:60",
			[45842] = "EmblemOfConquest:39",
			[29271] = "BoJ:25",
			[40721] = "EmblemOfValor:25",
			[33535] = "BoJ:35",
			[33557] = "BoJ:35",
			[32088] = "BoJ:50",
			[33582] = "BoJ:60",
			[45830] = "EmblemOfConquest:28",
			[40704] = "EmblemOfHeroism:50",
			[33518] = "BoJ:75",
			[42531] = "arena:1350",
			[45223] = "championsSeal:10",
			[29267] = "BoJ:33",
			[45828] = "EmblemOfConquest:28",
			[40750] = "EmblemOfValor:40",
			[45207] = "championsSeal:10",
			[28903] = "arcanerune:2",
			[40751] = "EmblemOfValor:40",
			[40719] = "EmblemOfValor:25",
			[29379] = "BoJ:25",
			[40740] = "EmblemOfValor:60",
			[29270] = "BoJ:25",
			[42619] = "honor:4480:arena:350",
			[33279] = "BoJ:60",
			[42620] = "arena:1200",
		},
	},
	["profileKeys"] = {
		["Nedro - Ashbringer"] = "Nedro - Ashbringer",
		["Resonatorr - Venoxis"] = "Resonatorr - Venoxis",
		["Stoc - Everlook"] = "Stoc - Everlook",
		["Postorc - Ashbringer"] = "Postorc - Ashbringer",
		["Hoddl - Ewige Warte"] = "Hoddl - Ewige Warte",
		["Gdgfgfdh - Venoxis"] = "Gdgfgfdh - Venoxis",
		["Teststsws - Venoxis"] = "Teststsws - Venoxis",
		["Knallus - Ewige Warte"] = "Knallus - Ewige Warte",
		["Schwerlast - Everlook"] = "Schwerlast - Everlook",
		["Neilyoung - Everlook"] = "Neilyoung - Everlook",
		["Postorc - Everlook"] = "Postorc - Everlook",
		["Restset - Razorfen"] = "Restset - Razorfen",
		["Resonator - Ewige Warte"] = "Resonator - Ewige Warte",
		["Felton - Lakeshire"] = "Felton - Lakeshire",
		["Radorn - Venoxis"] = "Radorn - Venoxis",
		["Resonatorr - Transcendence"] = "Resonatorr - Transcendence",
		["Drushnak - Lakeshire"] = "Drushnak - Lakeshire",
		["Crimora - Venoxis"] = "Crimora - Venoxis",
		["Nedro - Transcendence"] = "Nedro - Transcendence",
		["Fearleader - Lucifron"] = "Fearleader - Lucifron",
		["Pädagoge - Everlook"] = "Pädagoge - Everlook",
		["Saucier - Everlook"] = "Saucier - Everlook",
		["Skatron - Ashbringer"] = "Skatron - Ashbringer",
		["Dfsgdsgds - Venoxis"] = "Dfsgdsgds - Venoxis",
		["Giselheer - Everlook"] = "Giselheer - Everlook",
		["Neilyoung - Ashbringer"] = "Neilyoung - Ashbringer",
		["Crimora - Everlook"] = "Crimora - Everlook",
		["Biologe - Everlook"] = "Biologe - Everlook",
		["Drushnak - Mograine"] = "Drushnak - Mograine",
		["Explorerr - Venoxis"] = "Explorerr - Venoxis",
		["Postbotee - Everlook"] = "Postbotee - Everlook",
		["Akuhstiker - Transcendence"] = "Akuhstiker - Transcendence",
		["Privee - Everlook"] = "Privee - Everlook",
		["Drushnak - Transcendence"] = "Drushnak - Transcendence",
		["Sparbier - Ashbringer"] = "Sparbier - Ashbringer",
		["Hoddl - Everlook"] = "Hoddl - Everlook",
		["Testdgfz - Venoxis"] = "Testdgfz - Venoxis",
		["Ragoûtfin - Everlook"] = "Ragoûtfin - Everlook",
		["Schwerlast - Ashbringer"] = "Schwerlast - Ashbringer",
		["Tinyevil - Lakeshire"] = "Tinyevil - Lakeshire",
		["Postbotee - Ashbringer"] = "Postbotee - Ashbringer",
		["Skatron - Everlook"] = "Skatron - Everlook",
		["Drushnak - Ashbringer"] = "Drushnak - Ashbringer",
		["Sibo - Lakeshire"] = "Sibo - Lakeshire",
		["Resonator - Everlook"] = "Resonator - Everlook",
		["Knallus - Everlook"] = "Knallus - Everlook",
		["Drushnak - Venoxis"] = "Drushnak - Venoxis",
		["Sparbier - Everlook"] = "Sparbier - Everlook",
		["Testtata - Venoxis"] = "Testtata - Venoxis",
		["Nedro - Venoxis"] = "Nedro - Venoxis",
		["Clintfastfud - Everlook"] = "Clintfastfud - Everlook",
		["Lastenasd - Everlook"] = "Lastenasd - Everlook",
	},
	["profiles"] = {
		["Nedro - Ashbringer"] = {
		},
		["Resonatorr - Venoxis"] = {
			["minimap"] = {
				["minimapPos"] = 182.4904390319152,
			},
		},
		["Stoc - Everlook"] = {
			["GUI"] = {
				["selected"] = {
					"AtlasLootClassic_Crafting", -- [1]
					"AlchemyWrath", -- [2]
					2, -- [3]
					1, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 242.608131865239,
			},
		},
		["Postorc - Ashbringer"] = {
		},
		["Hoddl - Ewige Warte"] = {
			["GUI"] = {
				["point"] = {
					nil, -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					-5.187298665987328e-05, -- [4]
					0, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"TheSlavePens", -- [2]
					3, -- [3]
					6, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 221.7230632606461,
			},
		},
		["Gdgfgfdh - Venoxis"] = {
		},
		["Teststsws - Venoxis"] = {
		},
		["Knallus - Ewige Warte"] = {
		},
		["Schwerlast - Everlook"] = {
			["GUI"] = {
				["selected"] = {
					nil, -- [1]
					"TheNexus", -- [2]
					[5] = 0,
				},
			},
		},
		["Neilyoung - Everlook"] = {
			["minimap"] = {
				["minimapPos"] = 246.0516292748074,
			},
			["GUI"] = {
				["selected"] = {
					"AtlasLootClassic_Crafting", -- [1]
					"AlchemyWrath", -- [2]
					nil, -- [3]
					1, -- [4]
					0, -- [5]
				},
			},
		},
		["Postorc - Everlook"] = {
		},
		["Restset - Razorfen"] = {
		},
		["Resonator - Ewige Warte"] = {
			["GUI"] = {
				["selected"] = {
					nil, -- [1]
					"HellfireRamparts", -- [2]
					[5] = 0,
				},
			},
			["minimap"] = {
				["minimapPos"] = 198.2189896252882,
			},
		},
		["Felton - Lakeshire"] = {
		},
		["Radorn - Venoxis"] = {
			["minimap"] = {
				["minimapPos"] = 233.850131000729,
			},
			["GUI"] = {
				["point"] = {
					"LEFT", -- [1]
					nil, -- [2]
					"LEFT", -- [3]
					0, -- [4]
					27.99997711181641, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"VaultofArchavon", -- [2]
					2, -- [3]
					9, -- [4]
					0, -- [5]
				},
			},
		},
		["Resonatorr - Transcendence"] = {
		},
		["Drushnak - Lakeshire"] = {
		},
		["Crimora - Venoxis"] = {
			["minimap"] = {
				["minimapPos"] = 228.3886791055503,
			},
			["GUI"] = {
				["selected"] = {
					nil, -- [1]
					"AhnKahet", -- [2]
					5, -- [3]
					6, -- [4]
					0, -- [5]
				},
			},
		},
		["Nedro - Transcendence"] = {
		},
		["Fearleader - Lucifron"] = {
		},
		["Pädagoge - Everlook"] = {
		},
		["Saucier - Everlook"] = {
			["GUI"] = {
				["point"] = {
					"RIGHT", -- [1]
					nil, -- [2]
					"RIGHT", -- [3]
					-85.00001525878906, -- [4]
					-21.00000190734863, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"UtgardeKeep", -- [2]
					3, -- [3]
					9, -- [4]
					0, -- [5]
				},
			},
			["Addons"] = {
				["Favourites"] = {
					["lists"] = {
						["ProfileBase"] = {
							["mainItems"] = {
								[8] = true,
							},
						},
					},
				},
			},
			["minimap"] = {
				["minimapPos"] = 243.6245376637463,
			},
		},
		["Skatron - Ashbringer"] = {
		},
		["Dfsgdsgds - Venoxis"] = {
		},
		["Giselheer - Everlook"] = {
		},
		["Neilyoung - Ashbringer"] = {
		},
		["Crimora - Everlook"] = {
			["GUI"] = {
				["point"] = {
					"RIGHT", -- [1]
					nil, -- [2]
					"RIGHT", -- [3]
					-115.0000381469727, -- [4]
					-12.00003910064697, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"AhnKahet", -- [2]
					nil, -- [3]
					9, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 223.6616450002167,
			},
		},
		["Biologe - Everlook"] = {
			["minimap"] = {
				["minimapPos"] = 244.4107126672495,
			},
			["GUI"] = {
				["classFilter"] = true,
				["selected"] = {
					nil, -- [1]
					"VioletHold", -- [2]
					7, -- [3]
					1, -- [4]
					0, -- [5]
				},
				["point"] = {
					"RIGHT", -- [1]
					nil, -- [2]
					"RIGHT", -- [3]
					-125.5800476074219, -- [4]
					57.83950042724609, -- [5]
				},
			},
		},
		["Drushnak - Mograine"] = {
		},
		["Explorerr - Venoxis"] = {
			["GUI"] = {
				["selected"] = {
					nil, -- [1]
					"SunwellPlateau", -- [2]
					7, -- [3]
					[5] = 0,
				},
			},
			["minimap"] = {
				["minimapPos"] = 246.9737576363861,
			},
		},
		["Postbotee - Everlook"] = {
		},
		["Akuhstiker - Transcendence"] = {
		},
		["Privee - Everlook"] = {
			["GUI"] = {
				["classFilter"] = true,
				["selected"] = {
					"AtlasLootClassic_Factions", -- [1]
					"TheSonsofHodir", -- [2]
					2, -- [3]
					2, -- [4]
					0, -- [5]
				},
				["point"] = {
					"TOP", -- [1]
					nil, -- [2]
					"TOP", -- [3]
					42.2098274230957, -- [4]
					-58.32101058959961, -- [5]
				},
			},
			["Addons"] = {
				["Favourites"] = {
					["activeList"] = {
						"GlobalBase", -- [1]
						true, -- [2]
					},
				},
			},
			["minimap"] = {
				["minimapPos"] = 246.3293454166952,
			},
		},
		["Drushnak - Transcendence"] = {
		},
		["Sparbier - Ashbringer"] = {
		},
		["Hoddl - Everlook"] = {
			["GUI"] = {
				["point"] = {
					"RIGHT", -- [1]
					nil, -- [2]
					"RIGHT", -- [3]
					-105.9999618530273, -- [4]
					30.79012298583984, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"VioletHold", -- [2]
					7, -- [3]
					6, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 245.6501182896046,
			},
		},
		["Testdgfz - Venoxis"] = {
		},
		["Ragoûtfin - Everlook"] = {
			["GUI"] = {
				["point"] = {
					nil, -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					96.83956146240234, -- [4]
					5.839498043060303, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"Gundrak", -- [2]
					nil, -- [3]
					6, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 246.0516292748074,
			},
		},
		["Schwerlast - Ashbringer"] = {
		},
		["Tinyevil - Lakeshire"] = {
		},
		["Postbotee - Ashbringer"] = {
		},
		["Skatron - Everlook"] = {
			["GUI"] = {
				["classFilter"] = true,
				["selected"] = {
					nil, -- [1]
					"Gundrak", -- [2]
					5, -- [3]
					6, -- [4]
					0, -- [5]
				},
				["point"] = {
					"LEFT", -- [1]
					nil, -- [2]
					"LEFT", -- [3]
					68, -- [4]
					41.00007629394531, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 246.3926985804546,
			},
		},
		["Drushnak - Ashbringer"] = {
			["GUI"] = {
				["classFilter"] = true,
				["selected"] = {
					nil, -- [1]
					"Ulduar", -- [2]
					11, -- [3]
					7, -- [4]
					0, -- [5]
				},
				["point"] = {
					"LEFT", -- [1]
					nil, -- [2]
					"LEFT", -- [3]
					13, -- [4]
					-25.00003242492676, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 247.1278637352727,
			},
		},
		["Sibo - Lakeshire"] = {
		},
		["Resonator - Everlook"] = {
			["GUI"] = {
				["point"] = {
					nil, -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					146, -- [4]
					31.00000190734863, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"VaultofArchavon", -- [2]
					2, -- [3]
					9, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 194.9880839030737,
			},
			["Addons"] = {
				["Favourites"] = {
					["lists"] = {
						["p1674219618"] = {
							[46052] = true,
							[44008] = true,
							[45866] = true,
							[45308] = true,
							[45933] = true,
							[45647] = true,
							[46341] = true,
							["mainItems"] = {
								[14] = true,
								[10] = true,
								[8] = true,
							},
							[46030] = true,
							[45659] = true,
							[45713] = true,
							[46096] = true,
							[46034] = true,
							[46035] = true,
							[45447] = true,
							["__name"] = "NEEEEDDDD!!!!!",
							[45294] = true,
							[45297] = true,
							[45699] = true,
							[45886] = true,
							[46042] = true,
							[45702] = true,
							[46045] = true,
							[45332] = true,
							[46046] = true,
							[46068] = true,
							[39426] = true,
							[45685] = true,
							[46050] = true,
							[44005] = true,
							["__icon"] = "Interface\\AddOns\\AtlasLootClassic\\Images\\Icons\\groupfinder-icon-class-priest",
						},
						["ProfileBase"] = {
							["mainItems"] = {
								[16] = true,
								[2] = true,
							},
						},
					},
					["activeList"] = {
						"p1674219618", -- [1]
					},
					["showIconInTT"] = true,
					["activeSubLists"] = {
						["p1674219618"] = false,
					},
				},
			},
		},
		["Knallus - Everlook"] = {
			["GUI"] = {
				["classFilter"] = true,
				["selected"] = {
					nil, -- [1]
					"UtgardeKeep", -- [2]
					3, -- [3]
					6, -- [4]
					0, -- [5]
				},
				["point"] = {
					"TOP", -- [1]
					nil, -- [2]
					"TOP", -- [3]
					87.99998474121094, -- [4]
					-62, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 241.3706166630366,
			},
		},
		["Drushnak - Venoxis"] = {
			["GUI"] = {
				["point"] = {
					nil, -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					-5.187299029785208e-05, -- [4]
					0, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"NaxxramasWrath", -- [2]
					14, -- [3]
					6, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 230.9320043785135,
			},
		},
		["Sparbier - Everlook"] = {
		},
		["Testtata - Venoxis"] = {
		},
		["Nedro - Venoxis"] = {
			["minimap"] = {
				["minimapPos"] = 228.1325755042601,
			},
			["GUI"] = {
				["selected"] = {
					nil, -- [1]
					"VaultofArchavon", -- [2]
					2, -- [3]
					9, -- [4]
					0, -- [5]
				},
			},
		},
		["Clintfastfud - Everlook"] = {
		},
		["Lastenasd - Everlook"] = {
		},
	},
}
