
DBMPartyBC_AllSavedVars = {
	["Privee-Everlook"] = {
		["533"] = {
			[0] = {
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = true,
				["Timer44194next"] = true,
				["Timer36819castTColor"] = 4,
				["Timer44194nextTColor"] = 6,
				["Timer44194cd"] = true,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer44194nextCVoice"] = 0,
				["Timer46165nextCVoice"] = 0,
				["Timer36819cast"] = true,
				["Enabled"] = true,
				["Timer44194cdCVoice"] = 0,
				["Timer44194activeTColor"] = 6,
				["Timer46165next"] = true,
				["announce44224spell"] = true,
				["SpecWarn44194switch"] = true,
				["Timer44194active"] = true,
			},
		},
		["537"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371addsSWNote"] = true,
				["SpecWarn32371adds"] = true,
			},
		},
		["572"] = {
			[0] = {
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			},
		},
		["576"] = {
			[0] = {
				["Enabled"] = true,
				["announce31673spell"] = true,
			},
		},
		["552"] = {
			[0] = {
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel2"] = false,
				["SpecWarn31467dispel2SWSound"] = 1,
				["SpecWarn31467dispel2SWNote"] = true,
			},
		},
		["532"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = true,
				["SpecWarn44175dispel2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = true,
				["announceother44141target2"] = false,
				["announceother46192target2"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
			},
		},
		["557"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["573"] = {
			[0] = {
				["announce25033spell"] = true,
				["Timer31481targetTColor"] = 3,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Timer31718target"] = true,
				["Enabled"] = true,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			},
		},
		["566"] = {
			[0] = {
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496next"] = true,
				["Timer30496nextTColor"] = 3,
				["announce30496spell"] = true,
			},
		},
		["544"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce33547spell"] = true,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			},
		},
		["577"] = {
			[0] = {
				["Enabled"] = true,
				["announce15716spell"] = true,
			},
		},
		["524"] = {
			[0] = {
				["Enabled"] = true,
				["announce32424spell"] = true,
				["announceother32346target"] = true,
			},
		},
		["579"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = false,
				["SpecWarn31715moveawaySWNote"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
			},
		},
		["Ironhand"] = {
			[0] = {
				["SpecWarn39194run"] = false,
				["SpecWarn39194runSWNote"] = true,
				["Timer39194activeTColor"] = 2,
				["SpecWarn39194runSWSound"] = 4,
				["Timer39194activeCVoice"] = 0,
				["announce39194spell"] = true,
				["Timer35322active2TColor"] = 5,
				["Enabled"] = true,
				["announceother35322target"] = true,
				["Timer35322active2CVoice"] = 0,
				["Timer39194active"] = true,
				["Timer35322active2"] = false,
			},
		},
		["531"] = {
			[0] = {
				["Enabled"] = true,
				["warnEnergy"] = true,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			},
		},
		["555"] = {
			[0] = {
				["Timer30923targetCVoice"] = 0,
				["Timer30923targetTColor"] = 3,
				["Enabled"] = true,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			},
		},
		["550"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn35759dispel2SWSound"] = 1,
				["SpecWarn35759dispel2"] = false,
				["SpecWarn35759dispel2SWNote"] = true,
				["announce36512spell"] = true,
			},
		},
		["535"] = {
			[0] = {
				["Enabled"] = true,
				["Timer32361cd"] = true,
				["announceother32361target"] = true,
				["Timer32361cdCVoice"] = 0,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["SpecWarn33919spell"] = true,
			},
		},
		["570"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			},
		},
		["578"] = {
			[0] = {
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			},
		},
		["548"] = {
			[0] = {
				["announceother39367target"] = false,
				["SpecWarn39005spell"] = true,
				["Timer39367target2CVoice"] = 0,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = false,
				["announce36119spell"] = true,
				["SpecWarn36121gtfoSWSound"] = 1,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn39005spellSWSound"] = 2,
				["SpecWarn36121gtfo"] = true,
				["SpecWarn39005spellSWNote"] = true,
			},
		},
		["530"] = {
			[0] = {
				["Enabled"] = true,
				["warningFelCrystalSWSound"] = 1,
				["timerFelCrystal"] = true,
				["timerFelCrystalCVoice"] = 0,
				["warningFelCrystal"] = true,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			},
		},
		["536"] = {
			[0] = {
				["Enabled"] = true,
				["announce36405spell"] = true,
			},
		},
		["551"] = {
			[0] = {
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["Enabled"] = true,
				["Timer39017target2TColor"] = 3,
				["Timer39017target2"] = false,
				["warnSplitSoon"] = true,
			},
		},
		["575"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31534reflect"] = true,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["Timer31534active"] = true,
				["Timer31534activeCVoice"] = 0,
				["Timer31534activeTColor"] = 5,
				["SpecWarn31534reflectSWNote"] = true,
			},
		},
		["571"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = false,
				["announce34970spell"] = true,
			},
		},
		["556"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["523"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["SpecWarn32300dodgeSWNote"] = true,
				["announceother32300target"] = true,
			},
		},
		["564"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["542"] = {
			[0] = {
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40303targetTColor"] = 3,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40321targetTColor"] = 3,
				["Timer40184castTColor"] = 2,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["SpecWarn40184spellSWNote"] = true,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184active"] = true,
				["Timer40321target"] = true,
				["Timer40303target"] = true,
			},
		},
		["PT"] = {
			[0] = {
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["ShowAllPortalTimersCVoice"] = 0,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["TimerNextPortalTColor"] = 6,
			},
		},
		["562"] = {
			[0] = {
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			},
		},
		["AuctTombsTrash"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn34945interrupt"] = true,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = true,
				["announceother34925target"] = true,
			},
		},
		["527"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["539"] = {
			[0] = {
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["Timer13005target"] = true,
				["SpecWarn38385moveSWNote"] = true,
				["Enabled"] = true,
				["SpecWarn38385move"] = true,
				["SpecWarn29427interrupt"] = true,
				["announceother13005target"] = true,
			},
		},
		["545"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33676nextTColor"] = 6,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["announce33676spell"] = true,
				["Timer33676activeCVoice"] = 0,
				["Timer33676activeTColor"] = 3,
			},
		},
		["553"] = {
			[0] = {
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2"] = false,
				["Timer38592active2CVoice"] = 0,
			},
		},
		["549"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = false,
				["SpecWarn36175run"] = false,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = true,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = false,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target4TColor"] = 5,
			},
		},
		["538"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31909run"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = false,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["SpecWarn31909runSWNote"] = true,
				["announceother33792target"] = true,
			},
		},
		["Gyrokill"] = {
			[0] = {
				["SpecWarn35322dispel"] = false,
				["Timer35322active2TColor"] = 5,
				["Timer35322active2CVoice"] = 0,
				["Enabled"] = true,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = false,
			},
		},
		["563"] = {
			[0] = {
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["Timer35158active"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["Timer35159activeTColor"] = 5,
				["timer_berserk"] = true,
				["Timer35159activeCVoice"] = 0,
				["Timer35158activeTColor"] = 5,
				["announce35158spell"] = true,
				["timer_berserkTColor"] = 0,
				["announce39096cast"] = true,
			},
		},
		["543"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castCVoice"] = 0,
				["Timer38197castTColor"] = 2,
			},
		},
		["534"] = {
			[0] = {
				["Enabled"] = true,
				["Timer32358active"] = true,
				["Timer32358activeTColor"] = 5,
				["Timer32358activeCVoice"] = 0,
				["SpecWarn32358reflect2"] = true,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
			},
		},
		["569"] = {
			[0] = {
				["Timer30739cdCVoice"] = 0,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdTColor"] = 2,
				["SpecWarn30739spellSWSound"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			},
		},
		["547"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["SpecWarn33711moveawaySWNote"] = true,
				["Timer33711targetTColor"] = 3,
				["Timer33711targetCVoice"] = 0,
				["Timer33923castTColor"] = 2,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SetIconOnTouchTarget"] = true,
				["SpecWarn33923run"] = true,
				["SpecWarn33923runSWNote"] = true,
				["Timer33711target"] = true,
				["Timer33923castCVoice"] = 0,
				["Timer33923cast"] = true,
				["announceother33711target"] = true,
			},
		},
		["546"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			},
		},
		["554"] = {
			[0] = {
				["announce37605spell"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["Enabled"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			},
		},
		["540"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			},
		},
		["565"] = {
			[0] = {
				["Enabled"] = true,
				["Timer35280targetCVoice"] = 0,
				["Timer35280target"] = true,
				["Timer35280targetTColor"] = 3,
				["announceother35280target"] = true,
			},
		},
		["560"] = {
			[0] = {
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfo"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfoSWNote"] = true,
				["Timer34670active"] = false,
				["announce34670spell"] = false,
				["Timer34670activeCVoice"] = 0,
				["Timer34670activeTColor"] = 0,
				["announceother34661target"] = true,
				["Timer34661targetCVoice"] = 0,
			},
		},
		["529"] = {
			[0] = {
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689targetTColor"] = 3,
				["Yell30689"] = true,
				["SpecWarn30689youSWNote"] = true,
			},
		},
		["559"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn34557adds"] = true,
				["SpecWarn34557addsSWNote"] = true,
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34752dispel"] = false,
				["SpecWarn34557addsSWSound"] = 1,
			},
		},
		["568"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["574"] = {
			[0] = {
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = true,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["Timer35107targetCVoice"] = 0,
				["Enabled"] = true,
				["timer_berserkTColor"] = 0,
				["Timer35107target"] = true,
				["warnSummonSWNote"] = true,
			},
		},
		["558"] = {
			[0] = {
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["Timer34803cd"] = true,
				["Timer34803cdTColor"] = 2,
				["announce34803soon"] = true,
			},
		},
		["728"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["541"] = {
			[0] = {
				["Enabled"] = true,
				["warnSummon"] = true,
			},
		},
		["528"] = {
			[0] = {
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["RangeFrame"] = true,
				["Timer37566target"] = true,
				["announceother37566target"] = true,
				["Enabled"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["SpecWarn37566moveaway"] = true,
			},
		},
		["561"] = {
			[0] = {
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			},
		},
	},
	["Biologe-Everlook"] = {
		["533"] = {
			{
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["Timer44194next"] = true,
				["Timer36819castTColor"] = 4,
				["Timer44194nextTColor"] = 6,
				["Timer44194cd"] = true,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer44194nextCVoice"] = 0,
				["SpecWarn44194switch"] = true,
				["Timer36819cast"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194cdCVoice"] = 0,
				["Timer46165next"] = true,
				["Enabled"] = true,
				["announce44224spell"] = true,
				["Timer46165nextCVoice"] = 0,
				["Timer44194active"] = true,
			}, -- [1]
			{
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194next"] = true,
				["Timer44194cd"] = true,
				["Timer46165nextCVoice"] = 0,
				["Timer44194nextCVoice"] = 0,
				["SpecWarn44194switch"] = true,
				["Timer36819cast"] = true,
				["announce44224spell"] = true,
				["Timer44194cdCVoice"] = 0,
				["Enabled"] = true,
				["Timer46165next"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194nextTColor"] = 6,
				["Timer44194active"] = true,
			}, -- [2]
		},
		["537"] = {
			{
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371addsSWNote"] = true,
				["SpecWarn32371adds"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371adds"] = true,
				["SpecWarn32371addsSWNote"] = true,
			}, -- [2]
		},
		["572"] = {
			{
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			}, -- [2]
		},
		["576"] = {
			{
				["Enabled"] = true,
				["announce31673spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce31673spell"] = true,
			}, -- [2]
		},
		["552"] = {
			{
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel2SWNote"] = true,
				["SpecWarn31467dispel2"] = false,
				["SpecWarn31467dispel2SWSound"] = 1,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel"] = false,
				["SpecWarn31467dispelSWSound"] = 1,
				["SpecWarn31467dispelSWNote"] = true,
			}, -- [2]
		},
		["532"] = {
			{
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn44175dispel2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother46192target2"] = false,
				["announceother44141target2"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
				["announceother44141target2"] = false,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother46192target2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["SpecWarn44175dispel2"] = false,
			}, -- [2]
		},
		["557"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
		},
		["528"] = {
			{
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["announceother37566target"] = true,
				["Timer37566target"] = true,
				["RangeFrame"] = true,
				["Enabled"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["SpecWarn37566moveaway"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["SpecWarn37566moveaway"] = true,
				["Timer37566target"] = true,
				["RangeFrame"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["announceother37566target"] = true,
			}, -- [2]
		},
		["talent1"] = "SHAMAN1",
		["573"] = {
			{
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Timer31718target"] = true,
				["announce25033spell"] = true,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			}, -- [1]
			{
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			}, -- [2]
		},
		["541"] = {
			{
				["Enabled"] = true,
				["warnSummon"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["warnSummon"] = true,
			}, -- [2]
		},
		["544"] = {
			{
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce33547spell"] = true,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["announce33547spell"] = true,
				["timer_berserkCVoice"] = 0,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			}, -- [2]
		},
		["577"] = {
			{
				["Enabled"] = true,
				["announce15716spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce15716spell"] = true,
			}, -- [2]
		},
		["728"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
		},
		["talent2"] = "SHAMAN2",
		["Ironhand"] = {
			{
				["SpecWarn39194run"] = false,
				["SpecWarn39194runSWNote"] = true,
				["Timer39194activeTColor"] = 2,
				["SpecWarn39194runSWSound"] = 4,
				["Timer39194activeCVoice"] = 0,
				["announce39194spell"] = true,
				["Timer35322active2TColor"] = 5,
				["Timer39194active"] = true,
				["announceother35322target"] = true,
				["Timer35322active2CVoice"] = 0,
				["Enabled"] = true,
				["Timer35322active2"] = false,
			}, -- [1]
			{
				["SpecWarn39194run"] = true,
				["SpecWarn39194runSWNote"] = true,
				["Timer35322active2"] = false,
				["announce39194spell"] = true,
				["Enabled"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["SpecWarn39194runSWSound"] = 4,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispel"] = false,
				["Timer35322active2TColor"] = 5,
				["Timer35322active2CVoice"] = 0,
				["announceother35322target"] = true,
				["Timer39194active"] = true,
				["Timer39194activeTColor"] = 2,
				["Timer39194activeCVoice"] = 0,
			}, -- [2]
		},
		["531"] = {
			{
				["Enabled"] = true,
				["warnEnergy"] = true,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["warnEnergy"] = true,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			}, -- [2]
		},
		["555"] = {
			{
				["Timer30923targetCVoice"] = 0,
				["Timer30923targetTColor"] = 3,
				["Enabled"] = true,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer30923targetTColor"] = 3,
				["Timer30923targetCVoice"] = 0,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			}, -- [2]
		},
		["550"] = {
			{
				["Enabled"] = true,
				["SpecWarn35759dispel2"] = false,
				["SpecWarn35759dispel2SWSound"] = 1,
				["SpecWarn35759dispel2SWNote"] = true,
				["announce36512spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn35759dispelSWSound"] = 1,
				["SpecWarn35759dispelSWNote"] = true,
				["SpecWarn35759dispel"] = false,
				["announce36512spell"] = true,
			}, -- [2]
		},
		["535"] = {
			{
				["Enabled"] = true,
				["Timer32361cd"] = true,
				["announceother32361target"] = true,
				["Timer32361cdCVoice"] = 0,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["SpecWarn33919spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer32361cdCVoice"] = 0,
				["announceother32361target"] = true,
				["Timer32361cd"] = true,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361target"] = true,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spell"] = true,
			}, -- [2]
		},
		["570"] = {
			{
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			}, -- [2]
		},
		["578"] = {
			{
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			}, -- [1]
			{
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			}, -- [2]
		},
		["579"] = {
			{
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = false,
				["SpecWarn31715moveawaySWNote"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = false,
				["SpecWarn31715moveawaySWSound"] = 1,
				["SpecWarn31715moveawaySWNote"] = true,
			}, -- [2]
		},
		["530"] = {
			{
				["Enabled"] = true,
				["warningFelCrystalSWSound"] = 1,
				["timerFelCrystal"] = true,
				["timerFelCrystalCVoice"] = 0,
				["warningFelCrystal"] = true,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["warningFelCrystalSWSound"] = 1,
				["timerFelCrystal"] = true,
				["timerFelCrystalCVoice"] = 0,
				["warningFelCrystal"] = true,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			}, -- [2]
		},
		["536"] = {
			{
				["Enabled"] = true,
				["announce36405spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce36405spell"] = true,
			}, -- [2]
		},
		["551"] = {
			{
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["Timer39017target2TColor"] = 3,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["warnSplit"] = true,
				["Timer39017target2"] = false,
				["Enabled"] = true,
				["warnSplitSoon"] = true,
			}, -- [1]
			{
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["warnSplitSoon"] = true,
				["Enabled"] = true,
				["Timer39017target2"] = false,
				["Timer39017target2TColor"] = 3,
			}, -- [2]
		},
		["575"] = {
			{
				["Enabled"] = true,
				["Timer31534activeCVoice"] = 0,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["SpecWarn31534reflectSWNote"] = true,
				["SpecWarn31534reflect"] = true,
				["Timer31534activeTColor"] = 5,
				["Timer31534active"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer31534active"] = true,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["SpecWarn31534reflectSWNote"] = true,
				["Timer31534activeCVoice"] = 0,
				["Timer31534activeTColor"] = 5,
				["SpecWarn31534reflect"] = false,
			}, -- [2]
		},
		["571"] = {
			{
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = false,
				["announce34970spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce34970spell"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = false,
				["SpecWarn38801targetSWNote"] = true,
			}, -- [2]
		},
		["556"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
		},
		["523"] = {
			{
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["SpecWarn32300dodgeSWNote"] = true,
				["announceother32300target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["announceother32300target"] = true,
				["SpecWarn32300dodgeSWNote"] = true,
			}, -- [2]
		},
		["564"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
		},
		["542"] = {
			{
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40303targetTColor"] = 3,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40321targetTColor"] = 3,
				["Timer40184active"] = true,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["SpecWarn40184spellSWNote"] = true,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184castTColor"] = 2,
				["Timer40321target"] = true,
				["Timer40303target"] = true,
			}, -- [1]
			{
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40321target"] = true,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40184castTColor"] = 2,
				["Timer40184active"] = true,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["announceother40303target"] = true,
				["SpecWarn40184spellSWNote"] = true,
				["Timer40184cast"] = true,
				["Timer40321targetTColor"] = 3,
				["Timer40303targetTColor"] = 3,
				["Timer40303target"] = true,
			}, -- [2]
		},
		["PT"] = {
			{
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["ShowAllPortalTimersCVoice"] = 0,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["TimerNextPortalTColor"] = 6,
			}, -- [1]
			{
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["TimerNextPortalTColor"] = 6,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["ShowAllPortalTimersCVoice"] = 0,
			}, -- [2]
		},
		["562"] = {
			{
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			}, -- [2]
		},
		["AuctTombsTrash"] = {
			{
				["Enabled"] = true,
				["SpecWarn34945interrupt"] = false,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["announceother34925target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announceother34925target"] = true,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["SpecWarn34945interrupt"] = false,
			}, -- [2]
		},
		["527"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
		},
		["529"] = {
			{
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689targetTColor"] = 3,
				["Yell30689"] = true,
				["SpecWarn30689youSWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["SpecWarn30689youSWNote"] = true,
				["Yell30689"] = true,
				["Timer30689targetTColor"] = 3,
			}, -- [2]
		},
		["574"] = {
			{
				["timer_berserkTColor"] = 0,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = true,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["Timer35107targetCVoice"] = 0,
				["warnSummonSWSound"] = 1,
				["Enabled"] = true,
				["Timer35107target"] = true,
				["warnSummonSWNote"] = true,
			}, -- [1]
			{
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = true,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["warnSummonSWNote"] = true,
				["Timer35107target"] = true,
				["timer_berserkTColor"] = 0,
				["Enabled"] = true,
				["Timer35107targetCVoice"] = 0,
			}, -- [2]
		},
		["565"] = {
			{
				["Enabled"] = true,
				["Timer35280targetCVoice"] = 0,
				["Timer35280target"] = true,
				["Timer35280targetTColor"] = 3,
				["announceother35280target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer35280targetTColor"] = 3,
				["Timer35280target"] = true,
				["announceother35280target"] = true,
				["Timer35280targetCVoice"] = 0,
			}, -- [2]
		},
		["539"] = {
			{
				["Enabled"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["SpecWarn38385moveSWNote"] = true,
				["Timer13005target"] = true,
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385move"] = true,
				["SpecWarn29427interrupt"] = false,
				["announceother13005target"] = true,
			}, -- [1]
			{
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["announceother13005target"] = true,
				["Timer13005target"] = true,
				["SpecWarn29427interrupt"] = false,
				["SpecWarn38385move"] = true,
				["Enabled"] = true,
				["SpecWarn38385moveSWNote"] = true,
			}, -- [2]
		},
		["546"] = {
			{
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["announce33563spell"] = true,
				["Timer33563next"] = true,
				["Timer33563nextTColor"] = 6,
			}, -- [2]
		},
		["563"] = {
			{
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["Timer35158active"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["Timer35159activeCVoice"] = 0,
				["timer_berserk"] = true,
				["Timer35159activeTColor"] = 5,
				["Timer35158activeTColor"] = 5,
				["announce35158spell"] = true,
				["timer_berserkTColor"] = 0,
				["announce39096cast"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce39096cast"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserk"] = true,
				["Timer35159activeCVoice"] = 0,
				["announce35158spell"] = true,
				["Timer35158activeTColor"] = 5,
				["Timer35159activeTColor"] = 5,
				["Timer35158active"] = true,
			}, -- [2]
		},
		["554"] = {
			{
				["announce37605spell"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["Enabled"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["announce37605spell"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			}, -- [2]
		},
		["547"] = {
			{
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["Timer33711targetTColor"] = 3,
				["SetIconOnTouchTarget"] = true,
				["Timer33711targetCVoice"] = 0,
				["Timer33923cast"] = true,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SpecWarn33711moveawaySWNote"] = true,
				["Timer33711target"] = true,
				["SpecWarn33923runSWNote"] = true,
				["SpecWarn33923run"] = true,
				["Timer33923castCVoice"] = 0,
				["Timer33923castTColor"] = 2,
				["announceother33711target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["announceother33711target"] = true,
				["Timer33923castTColor"] = 2,
				["Timer33711targetCVoice"] = 0,
				["Timer33923cast"] = true,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SetIconOnTouchTarget"] = true,
				["Timer33923castCVoice"] = 0,
				["SpecWarn33923runSWNote"] = true,
				["Timer33711target"] = true,
				["SpecWarn33923run"] = true,
				["SpecWarn33711moveawaySWNote"] = true,
				["Timer33711targetTColor"] = 3,
			}, -- [2]
		},
		["543"] = {
			{
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castCVoice"] = 0,
				["Timer38197castTColor"] = 2,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castTColor"] = 2,
				["Timer38197castCVoice"] = 0,
			}, -- [2]
		},
		["569"] = {
			{
				["Timer30739cdCVoice"] = 0,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdTColor"] = 2,
				["SpecWarn30739spellSWSound"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			}, -- [1]
			{
				["SpecWarn30739spellSWSound"] = 2,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdCVoice"] = 0,
				["Timer30739cdTColor"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			}, -- [2]
		},
		["534"] = {
			{
				["Enabled"] = true,
				["Timer32358active"] = true,
				["Timer32358activeTColor"] = 5,
				["Timer32358activeCVoice"] = 0,
				["SpecWarn32358reflect2"] = true,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
				["Timer32358activeTColor"] = 5,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2"] = true,
				["Timer32358active"] = true,
				["Timer32358activeCVoice"] = 0,
			}, -- [2]
		},
		["Gyrokill"] = {
			{
				["SpecWarn35322dispel"] = false,
				["Timer35322active2TColor"] = 5,
				["Timer35322active2CVoice"] = 0,
				["Enabled"] = true,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = false,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer35322active2TColor"] = 5,
				["Timer35322active2CVoice"] = 0,
				["SpecWarn35322dispel"] = false,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = false,
			}, -- [2]
		},
		["538"] = {
			{
				["Enabled"] = true,
				["SpecWarn31909run"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = false,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["SpecWarn31909runSWNote"] = true,
				["announceother33792target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn31909runSWNote"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = false,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["announceother33792target"] = true,
				["SpecWarn31909run"] = true,
			}, -- [2]
		},
		["540"] = {
			{
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			}, -- [2]
		},
		["549"] = {
			{
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = false,
				["SpecWarn36175run"] = false,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = false,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target4TColor"] = 5,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = false,
				["SpecWarn36175run"] = true,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = false,
				["SpecWarn36175runSWNote"] = true,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["Timer39009target4TColor"] = 5,
			}, -- [2]
		},
		["560"] = {
			{
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfo"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfoSWNote"] = true,
				["Timer34670activeCVoice"] = 0,
				["announce34670spell"] = false,
				["Timer34670active"] = false,
				["Timer34670activeTColor"] = 0,
				["announceother34661target"] = true,
				["Timer34661targetCVoice"] = 0,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfoSWNote"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfo"] = true,
				["announceother34661target"] = true,
				["announce34670spell"] = false,
				["Timer34670activeCVoice"] = 0,
				["Timer34670activeTColor"] = 0,
				["Timer34670active"] = false,
				["Timer34661targetCVoice"] = 0,
			}, -- [2]
		},
		["545"] = {
			{
				["Enabled"] = true,
				["Timer33676nextTColor"] = 6,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["announce33676spell"] = true,
				["Timer33676activeCVoice"] = 0,
				["Timer33676activeTColor"] = 3,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer33676activeTColor"] = 3,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["Timer33676activeCVoice"] = 0,
				["announce33676spell"] = true,
				["Timer33676nextTColor"] = 6,
			}, -- [2]
		},
		["553"] = {
			{
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2"] = false,
				["Timer38592active2CVoice"] = 0,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer38592active2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2CVoice"] = 0,
			}, -- [2]
		},
		["568"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
		},
		["558"] = {
			{
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["Timer34803cdTColor"] = 2,
				["Timer34803cd"] = true,
				["announce34803soon"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["announce34803soon"] = true,
				["Timer34803cdTColor"] = 2,
				["Timer34803cd"] = true,
			}, -- [2]
		},
		["559"] = {
			{
				["SpecWarn34557addsSWSound"] = 1,
				["SpecWarn34557adds"] = true,
				["SpecWarn34557addsSWNote"] = true,
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34752dispel"] = false,
				["Enabled"] = true,
			}, -- [1]
			{
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34557adds"] = true,
				["SpecWarn34557addsSWNote"] = true,
				["Enabled"] = true,
				["SpecWarn34752dispel"] = false,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34557addsSWSound"] = 1,
			}, -- [2]
		},
		["548"] = {
			{
				["SpecWarn39005spell"] = true,
				["Timer39367target2CVoice"] = 0,
				["SpecWarn36121gtfoSWNote"] = true,
				["announceother39367target"] = false,
				["Timer39367target2"] = false,
				["announce36119spell"] = true,
				["SpecWarn36121gtfoSWSound"] = 1,
				["SpecWarn39005spellSWSound"] = 2,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn36121gtfo"] = true,
				["SpecWarn39005spellSWNote"] = true,
			}, -- [1]
			{
				["SpecWarn39367dispel"] = false,
				["SpecWarn39005spell"] = true,
				["SpecWarn39367dispelSWNote"] = true,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = false,
				["announce36119spell"] = true,
				["SpecWarn39005spellSWNote"] = true,
				["SpecWarn39005spellSWSound"] = 2,
				["SpecWarn36121gtfoSWSound"] = 1,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn39367dispelSWSound"] = 1,
				["SpecWarn36121gtfo"] = true,
				["Timer39367target2CVoice"] = 0,
			}, -- [2]
		},
		["524"] = {
			{
				["Enabled"] = true,
				["announce32424spell"] = true,
				["announceother32346target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announceother32346target"] = true,
				["announce32424spell"] = true,
			}, -- [2]
		},
		["566"] = {
			{
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496next"] = true,
				["Timer30496nextTColor"] = 3,
				["announce30496spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496nextTColor"] = 3,
				["Timer30496next"] = true,
				["announce30496spell"] = true,
			}, -- [2]
		},
		["561"] = {
			{
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			}, -- [2]
		},
	},
	["Hoddl-Everlook"] = {
		["533"] = {
			[0] = {
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194next"] = true,
				["Timer44194cd"] = true,
				["Timer44194nextTColor"] = 6,
				["Timer44194nextCVoice"] = 0,
				["Timer46165nextCVoice"] = 0,
				["Timer36819cast"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194cdCVoice"] = 0,
				["Timer46165next"] = true,
				["Enabled"] = true,
				["announce44224spell"] = true,
				["SpecWarn44194switch"] = true,
				["Timer44194active"] = true,
			},
		},
		["537"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371addsSWNote"] = true,
				["SpecWarn32371adds"] = true,
			},
		},
		["572"] = {
			[0] = {
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			},
		},
		["576"] = {
			[0] = {
				["Enabled"] = true,
				["announce31673spell"] = true,
			},
		},
		["552"] = {
			[0] = {
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel"] = false,
				["SpecWarn31467dispelSWSound"] = 1,
				["SpecWarn31467dispelSWNote"] = true,
			},
		},
		["532"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn44175dispel2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother44141target2"] = false,
				["announceother46192target2"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
			},
		},
		["557"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["573"] = {
			[0] = {
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			},
		},
		["566"] = {
			[0] = {
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496nextTColor"] = 3,
				["Timer30496next"] = true,
				["announce30496spell"] = true,
			},
		},
		["544"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce33547spell"] = true,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			},
		},
		["577"] = {
			[0] = {
				["Enabled"] = true,
				["announce15716spell"] = true,
			},
		},
		["524"] = {
			[0] = {
				["Enabled"] = true,
				["announce32424spell"] = true,
				["announceother32346target"] = true,
			},
		},
		["579"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = false,
				["SpecWarn31715moveawaySWNote"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
			},
		},
		["Ironhand"] = {
			[0] = {
				["SpecWarn39194run"] = false,
				["SpecWarn39194runSWNote"] = true,
				["announce39194spell"] = true,
				["SpecWarn39194runSWSound"] = 4,
				["Timer39194activeCVoice"] = 0,
				["Timer39194activeTColor"] = 2,
				["Timer35322active2TColor"] = 5,
				["Timer39194active"] = true,
				["announceother35322target"] = true,
				["Timer35322active2CVoice"] = 0,
				["Enabled"] = true,
				["Timer35322active2"] = false,
			},
		},
		["531"] = {
			[0] = {
				["Enabled"] = true,
				["warnEnergy"] = true,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			},
		},
		["555"] = {
			[0] = {
				["Enabled"] = true,
				["Timer30923targetTColor"] = 3,
				["Timer30923targetCVoice"] = 0,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			},
		},
		["550"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn35759dispelSWSound"] = 1,
				["SpecWarn35759dispelSWNote"] = true,
				["SpecWarn35759dispel"] = false,
				["announce36512spell"] = true,
			},
		},
		["535"] = {
			[0] = {
				["Enabled"] = true,
				["Timer32361cdCVoice"] = 0,
				["announceother32361target"] = true,
				["Timer32361cd"] = true,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["SpecWarn33919spell"] = true,
			},
		},
		["570"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			},
		},
		["578"] = {
			[0] = {
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			},
		},
		["548"] = {
			[0] = {
				["SpecWarn39367dispel"] = false,
				["SpecWarn39005spell"] = true,
				["SpecWarn39367dispelSWNote"] = true,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = false,
				["announce36119spell"] = true,
				["Timer39367target2CVoice"] = 0,
				["SpecWarn36121gtfoSWSound"] = 1,
				["SpecWarn39005spellSWSound"] = 2,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn39367dispelSWSound"] = 1,
				["SpecWarn36121gtfo"] = true,
				["SpecWarn39005spellSWNote"] = true,
			},
		},
		["530"] = {
			[0] = {
				["Enabled"] = true,
				["timerFelCrystalCVoice"] = 0,
				["timerFelCrystal"] = true,
				["warningFelCrystalSWSound"] = 1,
				["warningFelCrystal"] = true,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			},
		},
		["558"] = {
			[0] = {
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["Timer34803cd"] = true,
				["Timer34803cdTColor"] = 2,
				["announce34803soon"] = true,
			},
		},
		["551"] = {
			[0] = {
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["Timer39017target2TColor"] = 3,
				["Timer39017target2"] = false,
				["Enabled"] = true,
				["warnSplitSoon"] = true,
			},
		},
		["536"] = {
			[0] = {
				["Enabled"] = true,
				["announce36405spell"] = true,
			},
		},
		["571"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = false,
				["announce34970spell"] = true,
			},
		},
		["556"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["523"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["SpecWarn32300dodgeSWNote"] = true,
				["announceother32300target"] = true,
			},
		},
		["564"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["542"] = {
			[0] = {
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40303targetTColor"] = 3,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40321targetTColor"] = 3,
				["Timer40184castTColor"] = 2,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["SpecWarn40184spellSWNote"] = true,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184active"] = true,
				["Timer40321target"] = true,
				["Timer40303target"] = true,
			},
		},
		["PT"] = {
			[0] = {
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["ShowAllPortalTimersCVoice"] = 0,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["TimerNextPortalTColor"] = 6,
			},
		},
		["562"] = {
			[0] = {
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			},
		},
		["AuctTombsTrash"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn34945interrupt"] = false,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["announceother34925target"] = true,
			},
		},
		["527"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["539"] = {
			[0] = {
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["SpecWarn38385moveSWNote"] = true,
				["Timer13005target"] = true,
				["Enabled"] = true,
				["SpecWarn38385move"] = true,
				["SpecWarn29427interrupt"] = false,
				["announceother13005target"] = true,
			},
		},
		["545"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33676nextTColor"] = 6,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["announce33676spell"] = true,
				["Timer33676activeCVoice"] = 0,
				["Timer33676activeTColor"] = 3,
			},
		},
		["553"] = {
			[0] = {
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2"] = false,
				["Timer38592active2CVoice"] = 0,
			},
		},
		["549"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = false,
				["SpecWarn36175run"] = false,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = false,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target4TColor"] = 5,
			},
		},
		["538"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31909runSWNote"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = false,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["SpecWarn31909run"] = true,
				["announceother33792target"] = true,
			},
		},
		["554"] = {
			[0] = {
				["Enabled"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["announce37605spell"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			},
		},
		["Gyrokill"] = {
			[0] = {
				["Enabled"] = true,
				["Timer35322active2CVoice"] = 0,
				["Timer35322active2TColor"] = 5,
				["SpecWarn35322dispel"] = false,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = false,
			},
		},
		["534"] = {
			[0] = {
				["Enabled"] = true,
				["Timer32358activeCVoice"] = 0,
				["Timer32358activeTColor"] = 5,
				["Timer32358active"] = true,
				["SpecWarn32358reflect2"] = true,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
			},
		},
		["543"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castCVoice"] = 0,
				["Timer38197castTColor"] = 2,
			},
		},
		["569"] = {
			[0] = {
				["SpecWarn30739spellSWSound"] = 2,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdCVoice"] = 0,
				["Timer30739cdTColor"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			},
		},
		["547"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["Timer33711targetTColor"] = 3,
				["SpecWarn33711moveawaySWNote"] = true,
				["Timer33711targetCVoice"] = 0,
				["Timer33923castTColor"] = 2,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SetIconOnTouchTarget"] = true,
				["SpecWarn33923run"] = true,
				["SpecWarn33923runSWNote"] = true,
				["Timer33711target"] = true,
				["Timer33923castCVoice"] = 0,
				["Timer33923cast"] = true,
				["announceother33711target"] = true,
			},
		},
		["546"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			},
		},
		["563"] = {
			[0] = {
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["Timer35158active"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["Timer35159activeTColor"] = 5,
				["timer_berserk"] = true,
				["Timer35159activeCVoice"] = 0,
				["Timer35158activeTColor"] = 5,
				["announce35158spell"] = true,
				["timer_berserkTColor"] = 0,
				["announce39096cast"] = true,
			},
		},
		["540"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			},
		},
		["565"] = {
			[0] = {
				["Enabled"] = true,
				["Timer35280targetTColor"] = 3,
				["Timer35280target"] = true,
				["Timer35280targetCVoice"] = 0,
				["announceother35280target"] = true,
			},
		},
		["560"] = {
			[0] = {
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfoSWNote"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfo"] = true,
				["Timer34670active"] = false,
				["announce34670spell"] = false,
				["Timer34670activeCVoice"] = 0,
				["Timer34670activeTColor"] = 0,
				["announceother34661target"] = true,
				["Timer34661targetCVoice"] = 0,
			},
		},
		["529"] = {
			[0] = {
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689targetTColor"] = 3,
				["Yell30689"] = true,
				["SpecWarn30689youSWNote"] = true,
			},
		},
		["559"] = {
			[0] = {
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34557adds"] = true,
				["SpecWarn34557addsSWNote"] = true,
				["SpecWarn34557addsSWSound"] = 1,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34752dispel"] = false,
				["Enabled"] = true,
			},
		},
		["568"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["574"] = {
			[0] = {
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = true,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["Timer35107targetCVoice"] = 0,
				["Enabled"] = true,
				["timer_berserkTColor"] = 0,
				["Timer35107target"] = true,
				["warnSummonSWNote"] = true,
			},
		},
		["575"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31534reflect"] = true,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["Timer31534active"] = true,
				["Timer31534activeCVoice"] = 0,
				["Timer31534activeTColor"] = 5,
				["SpecWarn31534reflectSWNote"] = true,
			},
		},
		["728"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["541"] = {
			[0] = {
				["Enabled"] = true,
				["warnSummon"] = true,
			},
		},
		["528"] = {
			[0] = {
				["Enabled"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["announceother37566target"] = true,
				["Timer37566target"] = true,
				["RangeFrame"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["SpecWarn37566moveaway"] = true,
			},
		},
		["561"] = {
			[0] = {
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			},
		},
	},
	["Hoddl-Ewige Warte"] = {
		["533"] = {
			[0] = {
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194next"] = true,
				["Timer44194cd"] = true,
				["Timer44194nextTColor"] = 6,
				["Timer44194nextCVoice"] = 0,
				["Timer46165nextCVoice"] = 0,
				["Timer36819cast"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194cdCVoice"] = 0,
				["Timer46165next"] = true,
				["Enabled"] = true,
				["announce44224spell"] = true,
				["SpecWarn44194switch"] = true,
				["Timer44194active"] = true,
			},
		},
		["537"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371addsSWNote"] = true,
				["SpecWarn32371adds"] = true,
			},
		},
		["572"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["576"] = {
			[0] = {
				["Enabled"] = true,
				["announce31673spell"] = true,
			},
		},
		["552"] = {
			[0] = {
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel"] = false,
				["SpecWarn31467dispelSWSound"] = 1,
				["SpecWarn31467dispelSWNote"] = true,
			},
		},
		["532"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn44175dispel2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother44141target2"] = false,
				["announceother46192target2"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
			},
		},
		["557"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["573"] = {
			[0] = {
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			},
		},
		["566"] = {
			[0] = {
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496nextTColor"] = 3,
				["Timer30496next"] = true,
				["announce30496spell"] = true,
			},
		},
		["544"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce33547spell"] = true,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			},
		},
		["577"] = {
			[0] = {
				["Enabled"] = true,
				["announce15716spell"] = true,
			},
		},
		["524"] = {
			[0] = {
				["Enabled"] = true,
				["announce32424spell"] = true,
				["announceother32346target"] = true,
			},
		},
		["579"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = false,
				["SpecWarn31715moveawaySWNote"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
			},
		},
		["Ironhand"] = {
			[0] = {
				["SpecWarn39194run"] = false,
				["SpecWarn39194runSWNote"] = true,
				["Timer39194activeCVoice"] = 0,
				["announce39194spell"] = true,
				["Timer39194activeTColor"] = 2,
				["SpecWarn35322dispelSWSound"] = 1,
				["SpecWarn39194runSWSound"] = 4,
				["SpecWarn35322dispelSWNote"] = true,
				["Timer39194active"] = true,
				["Timer35322active2TColor"] = 5,
				["Timer35322active2CVoice"] = 0,
				["announceother35322target"] = true,
				["SpecWarn35322dispel"] = false,
				["Enabled"] = true,
				["Timer35322active2"] = false,
			},
		},
		["531"] = {
			[0] = {
				["Enabled"] = true,
				["warnEnergy"] = true,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			},
		},
		["555"] = {
			[0] = {
				["Enabled"] = true,
				["Timer30923targetTColor"] = 3,
				["Timer30923targetCVoice"] = 0,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			},
		},
		["550"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn35759dispelSWSound"] = 1,
				["SpecWarn35759dispelSWNote"] = true,
				["SpecWarn35759dispel"] = false,
				["announce36512spell"] = true,
			},
		},
		["535"] = {
			[0] = {
				["Enabled"] = true,
				["Timer32361cdCVoice"] = 0,
				["announceother32361target"] = true,
				["Timer32361cd"] = true,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["SpecWarn33919spell"] = true,
			},
		},
		["570"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			},
		},
		["578"] = {
			[0] = {
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			},
		},
		["548"] = {
			[0] = {
				["SpecWarn39367dispel"] = false,
				["SpecWarn39005spell"] = true,
				["SpecWarn39367dispelSWNote"] = true,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = false,
				["announce36119spell"] = true,
				["Timer39367target2CVoice"] = 0,
				["SpecWarn36121gtfoSWSound"] = 1,
				["SpecWarn39005spellSWSound"] = 2,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn39367dispelSWSound"] = 1,
				["SpecWarn36121gtfo"] = true,
				["SpecWarn39005spellSWNote"] = true,
			},
		},
		["530"] = {
			[0] = {
				["Enabled"] = true,
				["timerFelCrystalCVoice"] = 0,
				["timerFelCrystal"] = true,
				["warningFelCrystalSWSound"] = 1,
				["warningFelCrystal"] = true,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			},
		},
		["575"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31534reflect"] = true,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["Timer31534active"] = true,
				["Timer31534activeCVoice"] = 0,
				["Timer31534activeTColor"] = 5,
				["SpecWarn31534reflectSWNote"] = true,
			},
		},
		["551"] = {
			[0] = {
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["Timer39017target2TColor"] = 3,
				["Timer39017target2"] = false,
				["Enabled"] = true,
				["warnSplitSoon"] = true,
			},
		},
		["558"] = {
			[0] = {
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["Timer34803cd"] = true,
				["Timer34803cdTColor"] = 2,
				["announce34803soon"] = true,
			},
		},
		["571"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = false,
				["announce34970spell"] = true,
			},
		},
		["556"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["523"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["SpecWarn32300dodgeSWNote"] = true,
				["announceother32300target"] = true,
			},
		},
		["564"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["542"] = {
			[0] = {
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40303targetTColor"] = 3,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40321targetTColor"] = 3,
				["Timer40184castTColor"] = 2,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["SpecWarn40184spellSWNote"] = true,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184active"] = true,
				["Timer40321target"] = true,
				["Timer40303target"] = true,
			},
		},
		["PT"] = {
			[0] = {
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["ShowAllPortalTimersCVoice"] = 0,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["TimerNextPortalTColor"] = 6,
			},
		},
		["562"] = {
			[0] = {
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			},
		},
		["AuctTombsTrash"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn34945interrupt"] = false,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["announceother34925target"] = true,
			},
		},
		["527"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["539"] = {
			[0] = {
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["SpecWarn38385moveSWNote"] = true,
				["Timer13005target"] = true,
				["Enabled"] = true,
				["SpecWarn38385move"] = true,
				["SpecWarn29427interrupt"] = false,
				["announceother13005target"] = true,
			},
		},
		["545"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33676nextTColor"] = 6,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["announce33676spell"] = true,
				["Timer33676activeCVoice"] = 0,
				["Timer33676activeTColor"] = 3,
			},
		},
		["553"] = {
			[0] = {
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2"] = false,
				["Timer38592active2CVoice"] = 0,
			},
		},
		["549"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = false,
				["SpecWarn36175run"] = false,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = false,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target4TColor"] = 5,
			},
		},
		["538"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn31909runSWNote"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = false,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["SpecWarn31909run"] = true,
				["announceother33792target"] = true,
			},
		},
		["563"] = {
			[0] = {
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["Timer35158active"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["Timer35159activeTColor"] = 5,
				["timer_berserk"] = true,
				["Timer35159activeCVoice"] = 0,
				["Timer35158activeTColor"] = 5,
				["announce35158spell"] = true,
				["timer_berserkTColor"] = 0,
				["announce39096cast"] = true,
			},
		},
		["554"] = {
			[0] = {
				["Enabled"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["announce37605spell"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			},
		},
		["534"] = {
			[0] = {
				["Enabled"] = true,
				["Timer32358activeCVoice"] = 0,
				["Timer32358activeTColor"] = 5,
				["Timer32358active"] = true,
				["SpecWarn32358reflect2"] = true,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
			},
		},
		["543"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castCVoice"] = 0,
				["Timer38197castTColor"] = 2,
			},
		},
		["569"] = {
			[0] = {
				["SpecWarn30739spellSWSound"] = 2,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdCVoice"] = 0,
				["Timer30739cdTColor"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			},
		},
		["547"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["SetIconOnTouchTarget"] = true,
				["Timer33711targetTColor"] = 3,
				["Timer33711targetCVoice"] = 0,
				["Timer33923castTColor"] = 2,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SpecWarn33711moveawaySWNote"] = true,
				["SpecWarn33923run"] = true,
				["SpecWarn33923runSWNote"] = true,
				["Timer33711target"] = true,
				["Timer33923castCVoice"] = 0,
				["Timer33923cast"] = true,
				["announceother33711target"] = true,
			},
		},
		["546"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			},
		},
		["Gyrokill"] = {
			[0] = {
				["Enabled"] = true,
				["Timer35322active2CVoice"] = 0,
				["Timer35322active2TColor"] = 5,
				["SpecWarn35322dispel"] = false,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = false,
			},
		},
		["540"] = {
			[0] = {
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			},
		},
		["565"] = {
			[0] = {
				["Enabled"] = true,
				["Timer35280targetTColor"] = 3,
				["Timer35280target"] = true,
				["Timer35280targetCVoice"] = 0,
				["announceother35280target"] = true,
			},
		},
		["560"] = {
			[0] = {
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfoSWNote"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfo"] = true,
				["Timer34670active"] = false,
				["announce34670spell"] = false,
				["Timer34670activeCVoice"] = 0,
				["Timer34670activeTColor"] = 0,
				["announceother34661target"] = true,
				["Timer34661targetCVoice"] = 0,
			},
		},
		["529"] = {
			[0] = {
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689targetTColor"] = 3,
				["Yell30689"] = true,
				["SpecWarn30689youSWNote"] = true,
			},
		},
		["559"] = {
			[0] = {
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34557adds"] = true,
				["SpecWarn34557addsSWNote"] = true,
				["SpecWarn34557addsSWSound"] = 1,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34752dispel"] = false,
				["Enabled"] = true,
			},
		},
		["568"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["574"] = {
			[0] = {
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = true,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["Timer35107targetCVoice"] = 0,
				["Enabled"] = true,
				["timer_berserkTColor"] = 0,
				["Timer35107target"] = true,
				["warnSummonSWNote"] = true,
			},
		},
		["536"] = {
			[0] = {
				["Enabled"] = true,
				["announce36405spell"] = true,
			},
		},
		["728"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["541"] = {
			[0] = {
				["Enabled"] = true,
				["warnSummon"] = true,
			},
		},
		["528"] = {
			[0] = {
				["Enabled"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["announceother37566target"] = true,
				["Timer37566target"] = true,
				["RangeFrame"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["SpecWarn37566moveaway"] = true,
			},
		},
		["561"] = {
			[0] = {
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			},
		},
	},
	["Knallus-Everlook"] = {
		["533"] = {
			{
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194next"] = true,
				["Timer44194cd"] = true,
				["Timer44194nextTColor"] = 6,
				["Timer44194nextCVoice"] = 0,
				["Timer46165nextCVoice"] = 0,
				["Timer36819cast"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194cdCVoice"] = 0,
				["Timer46165next"] = true,
				["Enabled"] = true,
				["announce44224spell"] = true,
				["SpecWarn44194switch"] = true,
				["Timer44194active"] = true,
			}, -- [1]
		},
		["537"] = {
			{
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371addsSWNote"] = true,
				["SpecWarn32371adds"] = true,
			}, -- [1]
		},
		["572"] = {
			{
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			}, -- [1]
		},
		["576"] = {
			{
				["Enabled"] = true,
				["announce31673spell"] = true,
			}, -- [1]
		},
		["552"] = {
			{
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel"] = false,
				["SpecWarn31467dispelSWSound"] = 1,
				["SpecWarn31467dispelSWNote"] = true,
			}, -- [1]
		},
		["532"] = {
			{
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn44175dispel2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother44141target2"] = false,
				["announceother46192target2"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
			}, -- [1]
		},
		["557"] = {
			{
				["Enabled"] = true,
			}, -- [1]
		},
		["talent1"] = "HUNTER1",
		["573"] = {
			{
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			}, -- [1]
		},
		["566"] = {
			{
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496nextTColor"] = 3,
				["Timer30496next"] = true,
				["announce30496spell"] = true,
			}, -- [1]
		},
		["544"] = {
			{
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce33547spell"] = true,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			}, -- [1]
		},
		["577"] = {
			{
				["Enabled"] = true,
				["announce15716spell"] = true,
			}, -- [1]
		},
		["524"] = {
			{
				["Enabled"] = true,
				["announce32424spell"] = true,
				["announceother32346target"] = true,
			}, -- [1]
		},
		["579"] = {
			{
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = false,
				["SpecWarn31715moveawaySWNote"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
			}, -- [1]
		},
		["Ironhand"] = {
			{
				["SpecWarn39194run"] = false,
				["SpecWarn39194runSWNote"] = true,
				["announce39194spell"] = true,
				["SpecWarn39194runSWSound"] = 4,
				["Timer39194activeCVoice"] = 0,
				["Timer39194activeTColor"] = 2,
				["Timer35322active2TColor"] = 5,
				["Timer39194active"] = true,
				["announceother35322target"] = true,
				["Timer35322active2CVoice"] = 0,
				["Enabled"] = true,
				["Timer35322active2"] = false,
			}, -- [1]
		},
		["531"] = {
			{
				["Enabled"] = true,
				["warnEnergy"] = true,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			}, -- [1]
		},
		["555"] = {
			{
				["Enabled"] = true,
				["Timer30923targetTColor"] = 3,
				["Timer30923targetCVoice"] = 0,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			}, -- [1]
		},
		["550"] = {
			{
				["Enabled"] = true,
				["SpecWarn35759dispelSWSound"] = 1,
				["SpecWarn35759dispelSWNote"] = true,
				["SpecWarn35759dispel"] = false,
				["announce36512spell"] = true,
			}, -- [1]
		},
		["535"] = {
			{
				["Enabled"] = true,
				["Timer32361cdCVoice"] = 0,
				["announceother32361target"] = true,
				["Timer32361cd"] = true,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["SpecWarn33919spell"] = true,
			}, -- [1]
		},
		["570"] = {
			{
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			}, -- [1]
		},
		["578"] = {
			{
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			}, -- [1]
		},
		["548"] = {
			{
				["SpecWarn39367dispel"] = false,
				["SpecWarn39005spell"] = true,
				["SpecWarn39367dispelSWNote"] = true,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = false,
				["announce36119spell"] = true,
				["Timer39367target2CVoice"] = 0,
				["SpecWarn36121gtfoSWSound"] = 1,
				["SpecWarn39005spellSWSound"] = 2,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn39367dispelSWSound"] = 1,
				["SpecWarn36121gtfo"] = true,
				["SpecWarn39005spellSWNote"] = true,
			}, -- [1]
		},
		["530"] = {
			{
				["Enabled"] = true,
				["timerFelCrystalCVoice"] = 0,
				["timerFelCrystal"] = true,
				["warningFelCrystalSWSound"] = 1,
				["warningFelCrystal"] = true,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			}, -- [1]
		},
		["536"] = {
			{
				["Enabled"] = true,
				["announce36405spell"] = true,
			}, -- [1]
		},
		["551"] = {
			{
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["Timer39017target2TColor"] = 3,
				["Timer39017target2"] = false,
				["Enabled"] = true,
				["warnSplitSoon"] = true,
			}, -- [1]
		},
		["575"] = {
			{
				["Enabled"] = true,
				["SpecWarn31534reflect"] = true,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["Timer31534active"] = true,
				["Timer31534activeCVoice"] = 0,
				["Timer31534activeTColor"] = 5,
				["SpecWarn31534reflectSWNote"] = true,
			}, -- [1]
		},
		["571"] = {
			{
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = false,
				["announce34970spell"] = true,
			}, -- [1]
		},
		["556"] = {
			{
				["Enabled"] = true,
			}, -- [1]
		},
		["523"] = {
			{
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["SpecWarn32300dodgeSWNote"] = true,
				["announceother32300target"] = true,
			}, -- [1]
		},
		["564"] = {
			{
				["Enabled"] = true,
			}, -- [1]
		},
		["542"] = {
			{
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40303targetTColor"] = 3,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40321targetTColor"] = 3,
				["Timer40184castTColor"] = 2,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["SpecWarn40184spellSWNote"] = true,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184active"] = true,
				["Timer40321target"] = true,
				["Timer40303target"] = true,
			}, -- [1]
		},
		["PT"] = {
			{
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["ShowAllPortalTimersCVoice"] = 0,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["TimerNextPortalTColor"] = 6,
			}, -- [1]
		},
		["562"] = {
			{
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			}, -- [1]
		},
		["AuctTombsTrash"] = {
			{
				["Enabled"] = true,
				["SpecWarn34945interrupt"] = false,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["announceother34925target"] = true,
			}, -- [1]
		},
		["527"] = {
			{
				["Enabled"] = true,
			}, -- [1]
		},
		["539"] = {
			{
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["SpecWarn38385moveSWNote"] = true,
				["Timer13005target"] = true,
				["Enabled"] = true,
				["SpecWarn38385move"] = true,
				["SpecWarn29427interrupt"] = false,
				["announceother13005target"] = true,
			}, -- [1]
		},
		["545"] = {
			{
				["Enabled"] = true,
				["Timer33676nextTColor"] = 6,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["announce33676spell"] = true,
				["Timer33676activeCVoice"] = 0,
				["Timer33676activeTColor"] = 3,
			}, -- [1]
		},
		["553"] = {
			{
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2"] = false,
				["Timer38592active2CVoice"] = 0,
			}, -- [1]
		},
		["549"] = {
			{
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = false,
				["SpecWarn36175run"] = false,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = false,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target4TColor"] = 5,
			}, -- [1]
		},
		["538"] = {
			{
				["Enabled"] = true,
				["SpecWarn31909runSWNote"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = false,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["SpecWarn31909run"] = true,
				["announceother33792target"] = true,
			}, -- [1]
		},
		["Gyrokill"] = {
			{
				["Enabled"] = true,
				["Timer35322active2CVoice"] = 0,
				["Timer35322active2TColor"] = 5,
				["SpecWarn35322dispel"] = false,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = false,
			}, -- [1]
		},
		["563"] = {
			{
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["Timer35158active"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["Timer35159activeTColor"] = 5,
				["timer_berserk"] = true,
				["Timer35159activeCVoice"] = 0,
				["Timer35158activeTColor"] = 5,
				["announce35158spell"] = true,
				["timer_berserkTColor"] = 0,
				["announce39096cast"] = true,
			}, -- [1]
		},
		["534"] = {
			{
				["Enabled"] = true,
				["Timer32358activeCVoice"] = 0,
				["Timer32358activeTColor"] = 5,
				["Timer32358active"] = true,
				["SpecWarn32358reflect2"] = true,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
			}, -- [1]
		},
		["543"] = {
			{
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castCVoice"] = 0,
				["Timer38197castTColor"] = 2,
			}, -- [1]
		},
		["569"] = {
			{
				["SpecWarn30739spellSWSound"] = 2,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdCVoice"] = 0,
				["Timer30739cdTColor"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			}, -- [1]
		},
		["547"] = {
			{
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["SpecWarn33711moveawaySWNote"] = true,
				["SetIconOnTouchTarget"] = true,
				["Timer33711targetCVoice"] = 0,
				["Timer33923castTColor"] = 2,
				["SpecWarn33711moveawaySWSound"] = 1,
				["Timer33711targetTColor"] = 3,
				["SpecWarn33923run"] = true,
				["SpecWarn33923runSWNote"] = true,
				["Timer33711target"] = true,
				["Timer33923castCVoice"] = 0,
				["Timer33923cast"] = true,
				["announceother33711target"] = true,
			}, -- [1]
		},
		["546"] = {
			{
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			}, -- [1]
		},
		["554"] = {
			{
				["Enabled"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["announce37605spell"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			}, -- [1]
		},
		["540"] = {
			{
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			}, -- [1]
		},
		["565"] = {
			{
				["Enabled"] = true,
				["Timer35280targetTColor"] = 3,
				["Timer35280target"] = true,
				["Timer35280targetCVoice"] = 0,
				["announceother35280target"] = true,
			}, -- [1]
		},
		["560"] = {
			{
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfoSWNote"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfo"] = true,
				["Timer34670active"] = false,
				["announce34670spell"] = false,
				["Timer34670activeCVoice"] = 0,
				["Timer34670activeTColor"] = 0,
				["announceother34661target"] = true,
				["Timer34661targetCVoice"] = 0,
			}, -- [1]
		},
		["529"] = {
			{
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689targetTColor"] = 3,
				["Yell30689"] = true,
				["SpecWarn30689youSWNote"] = true,
			}, -- [1]
		},
		["559"] = {
			{
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34557adds"] = true,
				["SpecWarn34557addsSWNote"] = true,
				["SpecWarn34557addsSWSound"] = 1,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34752dispel"] = false,
				["Enabled"] = true,
			}, -- [1]
		},
		["568"] = {
			{
				["Enabled"] = true,
			}, -- [1]
		},
		["574"] = {
			{
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = true,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["Timer35107targetCVoice"] = 0,
				["Enabled"] = true,
				["timer_berserkTColor"] = 0,
				["Timer35107target"] = true,
				["warnSummonSWNote"] = true,
			}, -- [1]
		},
		["558"] = {
			{
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["Timer34803cd"] = true,
				["Timer34803cdTColor"] = 2,
				["announce34803soon"] = true,
			}, -- [1]
		},
		["728"] = {
			{
				["Enabled"] = true,
			}, -- [1]
		},
		["541"] = {
			{
				["Enabled"] = true,
				["warnSummon"] = true,
			}, -- [1]
		},
		["528"] = {
			{
				["Enabled"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["announceother37566target"] = true,
				["Timer37566target"] = true,
				["RangeFrame"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["SpecWarn37566moveaway"] = true,
			}, -- [1]
		},
		["561"] = {
			{
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			}, -- [1]
		},
	},
	["Resonator-Everlook"] = {
		["533"] = {
			[3] = {
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194next"] = true,
				["Timer44194cd"] = true,
				["Timer46165nextCVoice"] = 0,
				["Timer44194nextCVoice"] = 0,
				["SpecWarn44194switch"] = true,
				["Timer36819cast"] = true,
				["announce44224spell"] = true,
				["Timer44194cdCVoice"] = 0,
				["Enabled"] = true,
				["Timer46165next"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194nextTColor"] = 6,
				["Timer44194active"] = true,
			},
		},
		["537"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371adds"] = true,
				["SpecWarn32371addsSWNote"] = true,
			},
		},
		["572"] = {
			[3] = {
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			},
		},
		["576"] = {
			[3] = {
				["Enabled"] = true,
				["announce31673spell"] = true,
			},
		},
		["552"] = {
			[3] = {
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel"] = false,
				["SpecWarn31467dispelSWSound"] = 1,
				["SpecWarn31467dispelSWNote"] = true,
			},
		},
		["532"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
				["announceother44141target2"] = false,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother46192target2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["SpecWarn44175dispel2"] = true,
			},
		},
		["557"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["528"] = {
			[3] = {
				["Enabled"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["SpecWarn37566moveaway"] = true,
				["Timer37566target"] = true,
				["RangeFrame"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["announceother37566target"] = true,
			},
		},
		["573"] = {
			[3] = {
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			},
		},
		["541"] = {
			[3] = {
				["Enabled"] = true,
				["warnSummon"] = true,
			},
		},
		["544"] = {
			[3] = {
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["announce33547spell"] = true,
				["timer_berserkCVoice"] = 0,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			},
		},
		["577"] = {
			[3] = {
				["Enabled"] = true,
				["announce15716spell"] = true,
			},
		},
		["728"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["579"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
				["SpecWarn31715moveawaySWNote"] = true,
			},
		},
		["Ironhand"] = {
			[3] = {
				["SpecWarn39194run"] = false,
				["SpecWarn39194runSWNote"] = true,
				["announce39194spell"] = true,
				["SpecWarn39194runSWSound"] = 4,
				["Timer35322active2"] = true,
				["Enabled"] = true,
				["Timer35322active2TColor"] = 5,
				["Timer35322active2CVoice"] = 0,
				["announceother35322target"] = true,
				["Timer39194active"] = true,
				["Timer39194activeTColor"] = 2,
				["Timer39194activeCVoice"] = 0,
			},
		},
		["531"] = {
			[3] = {
				["Enabled"] = true,
				["warnEnergy"] = true,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			},
		},
		["555"] = {
			[3] = {
				["Enabled"] = true,
				["Timer30923targetTColor"] = 3,
				["Timer30923targetCVoice"] = 0,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			},
		},
		["550"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn35759dispelSWSound"] = 1,
				["SpecWarn35759dispelSWNote"] = true,
				["SpecWarn35759dispel"] = false,
				["announce36512spell"] = true,
			},
		},
		["535"] = {
			[3] = {
				["Enabled"] = true,
				["Timer32361cdCVoice"] = 0,
				["announceother32361target"] = true,
				["Timer32361cd"] = true,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361target"] = true,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spell"] = true,
			},
		},
		["570"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			},
		},
		["578"] = {
			[3] = {
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			},
		},
		["536"] = {
			[3] = {
				["Enabled"] = true,
				["announce36405spell"] = true,
			},
		},
		["530"] = {
			[3] = {
				["Enabled"] = true,
				["warningFelCrystalSWSound"] = 1,
				["timerFelCrystal"] = true,
				["timerFelCrystalCVoice"] = 0,
				["warningFelCrystal"] = true,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			},
		},
		["558"] = {
			[3] = {
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["announce34803soon"] = true,
				["Timer34803cdTColor"] = 2,
				["Timer34803cd"] = true,
			},
		},
		["551"] = {
			[3] = {
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["warnSplitSoon"] = true,
				["Enabled"] = true,
				["Timer39017target2"] = false,
				["Timer39017target2TColor"] = 3,
			},
		},
		["575"] = {
			[3] = {
				["Enabled"] = true,
				["Timer31534active"] = true,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["SpecWarn31534reflectSWNote"] = true,
				["Timer31534activeCVoice"] = 0,
				["Timer31534activeTColor"] = 5,
				["SpecWarn31534reflect"] = true,
			},
		},
		["571"] = {
			[3] = {
				["Enabled"] = true,
				["announce34970spell"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = false,
				["SpecWarn38801targetSWNote"] = true,
			},
		},
		["556"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["523"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["announceother32300target"] = true,
				["SpecWarn32300dodgeSWNote"] = true,
			},
		},
		["564"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["542"] = {
			[3] = {
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40321target"] = true,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40184castTColor"] = 2,
				["Timer40184active"] = true,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["announceother40303target"] = true,
				["SpecWarn40184spellSWNote"] = true,
				["Timer40184cast"] = true,
				["Timer40321targetTColor"] = 3,
				["Timer40303targetTColor"] = 3,
				["Timer40303target"] = true,
			},
		},
		["PT"] = {
			[3] = {
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["TimerNextPortalTColor"] = 6,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["ShowAllPortalTimersCVoice"] = 0,
			},
		},
		["562"] = {
			[3] = {
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			},
		},
		["AuctTombsTrash"] = {
			[3] = {
				["Enabled"] = true,
				["announceother34925target"] = true,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["SpecWarn34945interrupt"] = false,
			},
		},
		["527"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["529"] = {
			[3] = {
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["SpecWarn30689youSWNote"] = true,
				["Yell30689"] = true,
				["Timer30689targetTColor"] = 3,
			},
		},
		["574"] = {
			[3] = {
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = true,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["warnSummonSWNote"] = true,
				["Timer35107target"] = true,
				["timer_berserkTColor"] = 0,
				["Enabled"] = true,
				["Timer35107targetCVoice"] = 0,
			},
		},
		["565"] = {
			[3] = {
				["Enabled"] = true,
				["Timer35280targetTColor"] = 3,
				["Timer35280target"] = true,
				["announceother35280target"] = true,
				["Timer35280targetCVoice"] = 0,
			},
		},
		["539"] = {
			[3] = {
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["announceother13005target"] = true,
				["Timer13005target"] = true,
				["SpecWarn29427interrupt"] = false,
				["SpecWarn38385move"] = true,
				["Enabled"] = true,
				["SpecWarn38385moveSWNote"] = true,
			},
		},
		["546"] = {
			[3] = {
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["announce33563spell"] = true,
				["Timer33563next"] = true,
				["Timer33563nextTColor"] = 6,
			},
		},
		["Gyrokill"] = {
			[3] = {
				["Enabled"] = true,
				["Timer35322active2TColor"] = 5,
				["Timer35322active2CVoice"] = 0,
				["SpecWarn35322dispel"] = true,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = true,
			},
		},
		["563"] = {
			[3] = {
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce39096cast"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserk"] = true,
				["Timer35159activeCVoice"] = 0,
				["announce35158spell"] = true,
				["Timer35158activeTColor"] = 5,
				["Timer35159activeTColor"] = 5,
				["Timer35158active"] = true,
			},
		},
		["547"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["announceother33711target"] = true,
				["Timer33923castTColor"] = 2,
				["Timer33711targetCVoice"] = 0,
				["Timer33923cast"] = true,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SpecWarn33711moveawaySWNote"] = true,
				["Timer33923castCVoice"] = 0,
				["SpecWarn33923runSWNote"] = true,
				["Timer33711target"] = true,
				["SpecWarn33923run"] = true,
				["Timer33711targetTColor"] = 3,
				["SetIconOnTouchTarget"] = true,
			},
		},
		["543"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castTColor"] = 2,
				["Timer38197castCVoice"] = 0,
			},
		},
		["569"] = {
			[3] = {
				["SpecWarn30739spellSWSound"] = 2,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdCVoice"] = 0,
				["Timer30739cdTColor"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			},
		},
		["534"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
				["Timer32358activeTColor"] = 5,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2"] = true,
				["Timer32358active"] = true,
				["Timer32358activeCVoice"] = 0,
			},
		},
		["554"] = {
			[3] = {
				["Enabled"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["announce37605spell"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			},
		},
		["538"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn31909runSWNote"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = false,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["announceother33792target"] = true,
				["SpecWarn31909run"] = true,
			},
		},
		["540"] = {
			[3] = {
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			},
		},
		["549"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = false,
				["SpecWarn36175run"] = false,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = false,
				["SpecWarn36175runSWNote"] = true,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["Timer39009target4TColor"] = 5,
			},
		},
		["560"] = {
			[3] = {
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfoSWNote"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfo"] = true,
				["announceother34661target"] = true,
				["announce34670spell"] = false,
				["Timer34670activeCVoice"] = 0,
				["Timer34670activeTColor"] = 0,
				["Timer34670active"] = false,
				["Timer34661targetCVoice"] = 0,
			},
		},
		["545"] = {
			[3] = {
				["Enabled"] = true,
				["Timer33676activeTColor"] = 3,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["Timer33676activeCVoice"] = 0,
				["announce33676spell"] = true,
				["Timer33676nextTColor"] = 6,
			},
		},
		["553"] = {
			[3] = {
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer38592active2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = true,
				["Timer31458target2"] = true,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2CVoice"] = 0,
			},
		},
		["568"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["talent3"] = "PRIEST3",
		["559"] = {
			[3] = {
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34557adds"] = true,
				["SpecWarn34557addsSWNote"] = true,
				["Enabled"] = true,
				["SpecWarn34752dispel"] = true,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34557addsSWSound"] = 1,
			},
		},
		["548"] = {
			[3] = {
				["SpecWarn39367dispel"] = false,
				["SpecWarn39005spell"] = true,
				["SpecWarn39367dispelSWNote"] = true,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = false,
				["announce36119spell"] = true,
				["SpecWarn39005spellSWNote"] = true,
				["SpecWarn39005spellSWSound"] = 2,
				["SpecWarn36121gtfoSWSound"] = 1,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn39367dispelSWSound"] = 1,
				["SpecWarn36121gtfo"] = true,
				["Timer39367target2CVoice"] = 0,
			},
		},
		["524"] = {
			[3] = {
				["Enabled"] = true,
				["announceother32346target"] = true,
				["announce32424spell"] = true,
			},
		},
		["566"] = {
			[3] = {
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496nextTColor"] = 3,
				["Timer30496next"] = true,
				["announce30496spell"] = true,
			},
		},
		["561"] = {
			[3] = {
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			},
		},
	},
	["Crimora-Everlook"] = {
		["533"] = {
			[3] = {
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194next"] = true,
				["Timer44194cd"] = true,
				["Timer44194nextTColor"] = 6,
				["Timer44194nextCVoice"] = 0,
				["SpecWarn44194switch"] = true,
				["Timer36819cast"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194cdCVoice"] = 0,
				["Timer46165next"] = true,
				["Enabled"] = true,
				["announce44224spell"] = true,
				["Timer46165nextCVoice"] = 0,
				["Timer44194active"] = true,
			},
		},
		["537"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371addsSWNote"] = true,
				["SpecWarn32371adds"] = true,
			},
		},
		["572"] = {
			[3] = {
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			},
		},
		["576"] = {
			[3] = {
				["Enabled"] = true,
				["announce31673spell"] = true,
			},
		},
		["552"] = {
			[3] = {
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel2"] = true,
				["SpecWarn31467dispel2SWSound"] = 1,
				["SpecWarn31467dispel2SWNote"] = true,
			},
		},
		["532"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn44175dispel2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother46192target2"] = false,
				["announceother44141target2"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
			},
		},
		["557"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["566"] = {
			[3] = {
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496nextTColor"] = 3,
				["Timer30496next"] = true,
				["announce30496spell"] = true,
			},
		},
		["573"] = {
			[3] = {
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			},
		},
		["524"] = {
			[3] = {
				["Enabled"] = true,
				["announce32424spell"] = true,
				["announceother32346target"] = true,
			},
		},
		["544"] = {
			[3] = {
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce33547spell"] = true,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			},
		},
		["577"] = {
			[3] = {
				["Enabled"] = true,
				["announce15716spell"] = true,
			},
		},
		["548"] = {
			[3] = {
				["announceother39367target"] = false,
				["SpecWarn39005spell"] = true,
				["Timer39367target2CVoice"] = 0,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = false,
				["announce36119spell"] = true,
				["SpecWarn36121gtfoSWSound"] = 1,
				["Timer39367target2TColor"] = 3,
				["SpecWarn39005spellSWSound"] = 2,
				["Enabled"] = true,
				["SpecWarn36121gtfo"] = true,
				["SpecWarn39005spellSWNote"] = true,
			},
		},
		["579"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = true,
				["SpecWarn31715moveawaySWNote"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
			},
		},
		["Ironhand"] = {
			[3] = {
				["SpecWarn39194run"] = true,
				["SpecWarn39194runSWNote"] = true,
				["announce39194spell"] = true,
				["SpecWarn39194runSWSound"] = 4,
				["Timer39194activeCVoice"] = 0,
				["Timer39194activeTColor"] = 2,
				["Timer35322active2TColor"] = 5,
				["Timer39194active"] = true,
				["announceother35322target"] = true,
				["Timer35322active2CVoice"] = 0,
				["Enabled"] = true,
				["Timer35322active2"] = true,
			},
		},
		["531"] = {
			[3] = {
				["Enabled"] = true,
				["warnEnergy"] = true,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			},
		},
		["555"] = {
			[3] = {
				["Enabled"] = true,
				["Timer30923targetTColor"] = 3,
				["Timer30923targetCVoice"] = 0,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			},
		},
		["550"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn35759dispel2"] = true,
				["SpecWarn35759dispel2SWSound"] = 1,
				["SpecWarn35759dispel2SWNote"] = true,
				["announce36512spell"] = true,
			},
		},
		["535"] = {
			[3] = {
				["Enabled"] = true,
				["Timer32361cdCVoice"] = 0,
				["announceother32361target"] = true,
				["Timer32361cd"] = true,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["SpecWarn33919spell"] = true,
			},
		},
		["570"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			},
		},
		["578"] = {
			[3] = {
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			},
		},
		["559"] = {
			[3] = {
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34557adds"] = true,
				["SpecWarn34557addsSWNote"] = true,
				["SpecWarn34557addsSWSound"] = 1,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34752dispel"] = false,
				["Enabled"] = true,
			},
		},
		["530"] = {
			[3] = {
				["Enabled"] = true,
				["timerFelCrystalCVoice"] = 0,
				["timerFelCrystal"] = true,
				["warningFelCrystalSWSound"] = 1,
				["warningFelCrystal"] = true,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			},
		},
		["575"] = {
			[3] = {
				["Enabled"] = true,
				["Timer31534activeCVoice"] = 0,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["SpecWarn31534reflectSWNote"] = true,
				["SpecWarn31534reflect"] = false,
				["Timer31534activeTColor"] = 5,
				["Timer31534active"] = true,
			},
		},
		["551"] = {
			[3] = {
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["Timer39017target2TColor"] = 3,
				["Timer39017target2"] = false,
				["Enabled"] = true,
				["warnSplitSoon"] = true,
			},
		},
		["558"] = {
			[3] = {
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["Timer34803cdTColor"] = 2,
				["Timer34803cd"] = true,
				["announce34803soon"] = true,
			},
		},
		["571"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = false,
				["announce34970spell"] = true,
			},
		},
		["556"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["523"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["SpecWarn32300dodgeSWNote"] = true,
				["announceother32300target"] = true,
			},
		},
		["564"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["553"] = {
			[3] = {
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2"] = true,
				["Timer38592active2CVoice"] = 0,
			},
		},
		["PT"] = {
			[3] = {
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["ShowAllPortalTimersCVoice"] = 0,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["TimerNextPortalTColor"] = 6,
			},
		},
		["562"] = {
			[3] = {
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			},
		},
		["AuctTombsTrash"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn34945interrupt"] = false,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["announceother34925target"] = true,
			},
		},
		["527"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["545"] = {
			[3] = {
				["Enabled"] = true,
				["Timer33676nextTColor"] = 6,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["announce33676spell"] = true,
				["Timer33676activeCVoice"] = 0,
				["Timer33676activeTColor"] = 3,
			},
		},
		["574"] = {
			[3] = {
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = true,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["Timer35107targetCVoice"] = 0,
				["Enabled"] = true,
				["timer_berserkTColor"] = 0,
				["Timer35107target"] = true,
				["warnSummonSWNote"] = true,
			},
		},
		["549"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = false,
				["SpecWarn36175run"] = true,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = false,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target4TColor"] = 5,
			},
		},
		["539"] = {
			[3] = {
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["Timer13005target"] = true,
				["SpecWarn38385moveSWNote"] = true,
				["Enabled"] = true,
				["SpecWarn38385move"] = true,
				["SpecWarn29427interrupt"] = false,
				["announceother13005target"] = true,
			},
		},
		["538"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn31909runSWNote"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = true,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["SpecWarn31909run"] = true,
				["announceother33792target"] = true,
			},
		},
		["Gyrokill"] = {
			[3] = {
				["Enabled"] = true,
				["Timer35322active2CVoice"] = 0,
				["Timer35322active2TColor"] = 5,
				["SpecWarn35322dispel"] = false,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = true,
			},
		},
		["563"] = {
			[3] = {
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["Timer35158active"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["Timer35159activeCVoice"] = 0,
				["timer_berserk"] = true,
				["Timer35159activeTColor"] = 5,
				["Timer35158activeTColor"] = 5,
				["announce35158spell"] = true,
				["timer_berserkTColor"] = 0,
				["announce39096cast"] = true,
			},
		},
		["543"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castCVoice"] = 0,
				["Timer38197castTColor"] = 2,
			},
		},
		["534"] = {
			[3] = {
				["Enabled"] = true,
				["Timer32358activeCVoice"] = 0,
				["Timer32358activeTColor"] = 5,
				["Timer32358active"] = true,
				["SpecWarn32358reflect2"] = true,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
			},
		},
		["569"] = {
			[3] = {
				["SpecWarn30739spellSWSound"] = 2,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdCVoice"] = 0,
				["Timer30739cdTColor"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			},
		},
		["547"] = {
			[3] = {
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["Timer33711targetTColor"] = 3,
				["SpecWarn33711moveawaySWNote"] = true,
				["Timer33711targetCVoice"] = 0,
				["Timer33923cast"] = true,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SetIconOnTouchTarget"] = true,
				["Timer33711target"] = true,
				["SpecWarn33923runSWNote"] = true,
				["SpecWarn33923run"] = true,
				["Timer33923castCVoice"] = 0,
				["Timer33923castTColor"] = 2,
				["announceother33711target"] = true,
			},
		},
		["554"] = {
			[3] = {
				["Enabled"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["announce37605spell"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			},
		},
		["546"] = {
			[3] = {
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			},
		},
		["540"] = {
			[3] = {
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			},
		},
		["565"] = {
			[3] = {
				["Enabled"] = true,
				["Timer35280targetTColor"] = 3,
				["Timer35280target"] = true,
				["Timer35280targetCVoice"] = 0,
				["announceother35280target"] = true,
			},
		},
		["560"] = {
			[3] = {
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfoSWNote"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfo"] = true,
				["Timer34670activeCVoice"] = 0,
				["announce34670spell"] = true,
				["Timer34670active"] = true,
				["Timer34670activeTColor"] = 0,
				["announceother34661target"] = true,
				["Timer34661targetCVoice"] = 0,
			},
		},
		["529"] = {
			[3] = {
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689targetTColor"] = 3,
				["Yell30689"] = true,
				["SpecWarn30689youSWNote"] = true,
			},
		},
		["542"] = {
			[3] = {
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40303targetTColor"] = 3,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40321targetTColor"] = 3,
				["Timer40184active"] = true,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["SpecWarn40184spellSWNote"] = true,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184castTColor"] = 2,
				["Timer40321target"] = true,
				["Timer40303target"] = true,
			},
		},
		["568"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["talent3"] = "PALADIN3",
		["536"] = {
			[3] = {
				["Enabled"] = true,
				["announce36405spell"] = true,
			},
		},
		["728"] = {
			[3] = {
				["Enabled"] = true,
			},
		},
		["541"] = {
			[3] = {
				["Enabled"] = true,
				["warnSummon"] = true,
			},
		},
		["528"] = {
			[3] = {
				["Enabled"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["RangeFrame"] = true,
				["Timer37566target"] = true,
				["announceother37566target"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["SpecWarn37566moveaway"] = true,
			},
		},
		["561"] = {
			[3] = {
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			},
		},
	},
	["Saucier-Everlook"] = {
		["533"] = {
			{
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194next"] = true,
				["Timer44194cd"] = true,
				["Timer44194nextTColor"] = 6,
				["Timer44194nextCVoice"] = 0,
				["SpecWarn44194switch"] = false,
				["Timer36819cast"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194cdCVoice"] = 0,
				["Timer46165next"] = true,
				["Enabled"] = true,
				["announce44224spell"] = true,
				["Timer46165nextCVoice"] = 0,
				["Timer44194active"] = true,
			}, -- [1]
			{
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194next"] = true,
				["Timer44194cd"] = true,
				["Timer44194nextTColor"] = 6,
				["Timer44194nextCVoice"] = 0,
				["SpecWarn44194switch"] = false,
				["Timer36819cast"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194cdCVoice"] = 0,
				["Timer46165next"] = true,
				["Enabled"] = true,
				["announce44224spell"] = true,
				["Timer46165nextCVoice"] = 0,
				["Timer44194active"] = true,
			}, -- [2]
			{
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["Timer44194activeCVoice"] = 0,
				["SpecWarn36819interrupt2SWNote"] = true,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer36819castCVoice"] = 0,
				["SpecWarn36819interrupt2SWSound"] = 1,
				["SpecWarn36819interrupt2"] = false,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194next"] = true,
				["Timer44194cd"] = true,
				["Timer44194nextTColor"] = 6,
				["Timer44194nextCVoice"] = 0,
				["Timer46165nextCVoice"] = 0,
				["Timer36819cast"] = true,
				["Timer44194activeTColor"] = 6,
				["Timer44194cdCVoice"] = 0,
				["Timer46165next"] = true,
				["Enabled"] = true,
				["announce44224spell"] = true,
				["SpecWarn44194switch"] = false,
				["Timer44194active"] = true,
			}, -- [3]
		},
		["576"] = {
			{
				["Enabled"] = true,
				["announce31673spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce31673spell"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["announce31673spell"] = true,
			}, -- [3]
		},
		["537"] = {
			{
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371addsSWNote"] = true,
				["SpecWarn32371adds"] = false,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371addsSWNote"] = true,
				["SpecWarn32371adds"] = false,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn32371addsSWSound"] = 1,
				["SpecWarn32371addsSWNote"] = true,
				["SpecWarn32371adds"] = false,
			}, -- [3]
		},
		["572"] = {
			{
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			}, -- [2]
			{
				["Enabled"] = true,
				["announce39340spell"] = true,
				["Timer39340cd"] = true,
				["Timer39340cdTColor"] = 2,
				["Timer39340cdCVoice"] = 0,
			}, -- [3]
		},
		["557"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
			}, -- [3]
		},
		["552"] = {
			{
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel"] = true,
				["SpecWarn31467dispelSWSound"] = 1,
				["SpecWarn31467dispelSWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel"] = true,
				["SpecWarn31467dispelSWSound"] = 1,
				["SpecWarn31467dispelSWNote"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["announce38539spell"] = true,
				["SpecWarn31467dispel"] = true,
				["SpecWarn31467dispelSWSound"] = 1,
				["SpecWarn31467dispelSWNote"] = true,
			}, -- [3]
		},
		["532"] = {
			{
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn44175dispel2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother46192target2"] = false,
				["announceother44141target2"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn44175dispel2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother46192target2"] = false,
				["announceother44141target2"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn46181interrupt3SWSound"] = 1,
				["announce46195spell"] = true,
				["announceother13323target"] = true,
				["SpecWarn17843interrupt3SWSound"] = 1,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn17843interrupt3"] = false,
				["SpecWarn44175dispel2"] = false,
				["SpecWarn46181interrupt3SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt3"] = false,
				["announceother44141target2"] = false,
				["announceother46192target2"] = false,
				["SpecWarn17843interrupt3SWNote"] = true,
			}, -- [3]
		},
		["566"] = {
			{
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496nextTColor"] = 3,
				["Timer30496next"] = true,
				["announce30496spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496nextTColor"] = 3,
				["Timer30496next"] = true,
				["announce30496spell"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer30496nextCVoice"] = 0,
				["Timer30496nextTColor"] = 3,
				["Timer30496next"] = true,
				["announce30496spell"] = true,
			}, -- [3]
		},
		["524"] = {
			{
				["Enabled"] = true,
				["announce32424spell"] = true,
				["announceother32346target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce32424spell"] = true,
				["announceother32346target"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["announce32424spell"] = true,
				["announceother32346target"] = true,
			}, -- [3]
		},
		["talent1"] = "DRUID1",
		["573"] = {
			{
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			}, -- [1]
			{
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			}, -- [2]
			{
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 3,
				["Timer31718targetCVoice"] = 0,
				["Enabled"] = true,
				["Timer31481targetTColor"] = 3,
				["Timer31481targetCVoice"] = 0,
				["Timer31481target"] = true,
			}, -- [3]
		},
		["548"] = {
			{
				["SpecWarn39367dispel"] = true,
				["SpecWarn39005spell"] = true,
				["SpecWarn39367dispelSWNote"] = true,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = true,
				["announce36119spell"] = true,
				["Timer39367target2CVoice"] = 0,
				["SpecWarn36121gtfoSWSound"] = 1,
				["SpecWarn39005spellSWSound"] = 2,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn39367dispelSWSound"] = 1,
				["SpecWarn36121gtfo"] = true,
				["SpecWarn39005spellSWNote"] = true,
			}, -- [1]
			{
				["SpecWarn39367dispel"] = true,
				["SpecWarn39005spell"] = true,
				["SpecWarn39367dispelSWNote"] = true,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = true,
				["announce36119spell"] = true,
				["Timer39367target2CVoice"] = 0,
				["SpecWarn36121gtfoSWSound"] = 1,
				["SpecWarn39005spellSWSound"] = 2,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn39367dispelSWSound"] = 1,
				["SpecWarn36121gtfo"] = true,
				["SpecWarn39005spellSWNote"] = true,
			}, -- [2]
			{
				["SpecWarn39367dispel"] = true,
				["SpecWarn39005spell"] = true,
				["SpecWarn39367dispelSWNote"] = true,
				["SpecWarn36121gtfoSWNote"] = true,
				["Timer39367target2"] = true,
				["announce36119spell"] = true,
				["Timer39367target2CVoice"] = 0,
				["SpecWarn36121gtfoSWSound"] = 1,
				["SpecWarn39005spellSWSound"] = 2,
				["Timer39367target2TColor"] = 3,
				["Enabled"] = true,
				["SpecWarn39367dispelSWSound"] = 1,
				["SpecWarn36121gtfo"] = true,
				["SpecWarn39005spellSWNote"] = true,
			}, -- [3]
		},
		["544"] = {
			{
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce33547spell"] = true,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce33547spell"] = true,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserkCVoice"] = 0,
				["announce33547spell"] = true,
				["Timer33547nextCVoice"] = 0,
				["Timer33547nextTColor"] = 2,
			}, -- [3]
		},
		["577"] = {
			{
				["Enabled"] = true,
				["announce15716spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce15716spell"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["announce15716spell"] = true,
			}, -- [3]
		},
		["559"] = {
			{
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34557adds"] = false,
				["SpecWarn34557addsSWNote"] = true,
				["SpecWarn34557addsSWSound"] = 1,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34752dispel"] = false,
				["Enabled"] = true,
			}, -- [1]
			{
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34557adds"] = false,
				["SpecWarn34557addsSWNote"] = true,
				["SpecWarn34557addsSWSound"] = 1,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34752dispel"] = false,
				["Enabled"] = true,
			}, -- [2]
			{
				["SpecWarn34752dispelSWNote"] = true,
				["SpecWarn34557adds"] = false,
				["SpecWarn34557addsSWNote"] = true,
				["SpecWarn34557addsSWSound"] = 1,
				["SpecWarn34752dispelSWSound"] = 1,
				["SpecWarn34752dispel"] = false,
				["Enabled"] = true,
			}, -- [3]
		},
		["579"] = {
			{
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = true,
				["SpecWarn31715moveawaySWNote"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = true,
				["SpecWarn31715moveawaySWNote"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn31715moveaway"] = true,
				["announceother31715target"] = true,
				["announceother31704target"] = true,
				["SpecWarn31715moveawaySWNote"] = true,
				["SpecWarn31715moveawaySWSound"] = 1,
			}, -- [3]
		},
		["Ironhand"] = {
			{
				["SpecWarn39194run"] = false,
				["SpecWarn39194runSWNote"] = true,
				["announce39194spell"] = true,
				["SpecWarn39194runSWSound"] = 4,
				["Timer39194activeCVoice"] = 0,
				["Timer39194activeTColor"] = 2,
				["Timer35322active2TColor"] = 5,
				["Timer39194active"] = true,
				["announceother35322target"] = true,
				["Timer35322active2CVoice"] = 0,
				["Enabled"] = true,
				["Timer35322active2"] = false,
			}, -- [1]
			{
				["SpecWarn39194run"] = true,
				["SpecWarn39194runSWNote"] = true,
				["Timer39194activeCVoice"] = 0,
				["announce39194spell"] = true,
				["Timer39194activeTColor"] = 2,
				["SpecWarn35322dispelSWSound"] = 1,
				["SpecWarn39194runSWSound"] = 4,
				["SpecWarn35322dispelSWNote"] = true,
				["Timer39194active"] = true,
				["Timer35322active2TColor"] = 5,
				["Timer35322active2CVoice"] = 0,
				["announceother35322target"] = true,
				["SpecWarn35322dispel"] = false,
				["Enabled"] = true,
				["Timer35322active2"] = true,
			}, -- [2]
			{
				["SpecWarn39194run"] = false,
				["SpecWarn39194runSWNote"] = true,
				["announce39194spell"] = true,
				["SpecWarn39194runSWSound"] = 4,
				["Timer39194activeCVoice"] = 0,
				["Timer39194activeTColor"] = 2,
				["Timer35322active2TColor"] = 5,
				["Timer39194active"] = true,
				["announceother35322target"] = true,
				["Timer35322active2CVoice"] = 0,
				["Enabled"] = true,
				["Timer35322active2"] = false,
			}, -- [3]
		},
		["531"] = {
			{
				["Enabled"] = true,
				["warnEnergy"] = false,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["warnEnergy"] = false,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["warnEnergy"] = false,
				["warnEnergySWSound"] = 1,
				["warnEnergySWNote"] = true,
			}, -- [3]
		},
		["555"] = {
			{
				["Enabled"] = true,
				["Timer30923targetTColor"] = 3,
				["Timer30923targetCVoice"] = 0,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer30923targetTColor"] = 3,
				["Timer30923targetCVoice"] = 0,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer30923targetTColor"] = 3,
				["Timer30923targetCVoice"] = 0,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			}, -- [3]
		},
		["550"] = {
			{
				["Enabled"] = true,
				["SpecWarn35759dispelSWSound"] = 1,
				["SpecWarn35759dispelSWNote"] = true,
				["SpecWarn35759dispel"] = true,
				["announce36512spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn35759dispelSWSound"] = 1,
				["SpecWarn35759dispelSWNote"] = true,
				["SpecWarn35759dispel"] = true,
				["announce36512spell"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn35759dispelSWSound"] = 1,
				["SpecWarn35759dispelSWNote"] = true,
				["SpecWarn35759dispel"] = true,
				["announce36512spell"] = true,
			}, -- [3]
		},
		["535"] = {
			{
				["Enabled"] = true,
				["Timer32361cdCVoice"] = 0,
				["announceother32361target"] = true,
				["Timer32361cd"] = true,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["SpecWarn33919spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer32361cdCVoice"] = 0,
				["announceother32361target"] = true,
				["Timer32361cd"] = true,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["SpecWarn33919spell"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer32361cdCVoice"] = 0,
				["announceother32361target"] = true,
				["Timer32361cd"] = true,
				["Timer32361cdTColor"] = 2,
				["Timer32361targetTColor"] = 3,
				["Timer32361targetCVoice"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["SpecWarn33919spell"] = true,
			}, -- [3]
		},
		["570"] = {
			{
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn31991move"] = false,
				["announce34980spell"] = true,
				["SpecWarn31991moveSWSound"] = 1,
				["announce31985spell"] = true,
				["SpecWarn31991moveSWNote"] = true,
			}, -- [3]
		},
		["578"] = {
			{
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			}, -- [1]
			{
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			}, -- [2]
			{
				["announce31429spell"] = true,
				["announce34971spell"] = true,
				["Enabled"] = true,
			}, -- [3]
		},
		["558"] = {
			{
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["Timer34803cdTColor"] = 2,
				["Timer34803cd"] = true,
				["announce34803soon"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["Timer34803cdTColor"] = 2,
				["Timer34803cd"] = true,
				["announce34803soon"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer34803cdCVoice"] = 0,
				["announce34803spell"] = true,
				["Timer34803cd"] = true,
				["Timer34803cdTColor"] = 2,
				["announce34803soon"] = true,
			}, -- [3]
		},
		["530"] = {
			{
				["Enabled"] = true,
				["timerFelCrystalCVoice"] = 0,
				["timerFelCrystal"] = true,
				["warningFelCrystalSWSound"] = 1,
				["warningFelCrystal"] = false,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["timerFelCrystalCVoice"] = 0,
				["timerFelCrystal"] = true,
				["warningFelCrystalSWSound"] = 1,
				["warningFelCrystal"] = false,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["timerFelCrystalCVoice"] = 0,
				["timerFelCrystal"] = true,
				["warningFelCrystalSWSound"] = 1,
				["warningFelCrystal"] = false,
				["timerFelCrystalTColor"] = 1,
				["warningFelCrystalSWNote"] = true,
			}, -- [3]
		},
		["536"] = {
			{
				["Enabled"] = true,
				["announce36405spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce36405spell"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["announce36405spell"] = true,
			}, -- [3]
		},
		["551"] = {
			{
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["Timer39017target2TColor"] = 3,
				["Timer39017target2"] = false,
				["Enabled"] = true,
				["warnSplitSoon"] = true,
			}, -- [1]
			{
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["Timer39017target2TColor"] = 3,
				["Timer39017target2"] = false,
				["Enabled"] = true,
				["warnSplitSoon"] = true,
			}, -- [2]
			{
				["Timer39019targetCVoice"] = 0,
				["Timer39019target"] = true,
				["Timer39019targetTColor"] = 3,
				["warnSplit"] = true,
				["Timer39017target2CVoice"] = 0,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["Timer39017target2TColor"] = 3,
				["Timer39017target2"] = false,
				["Enabled"] = true,
				["warnSplitSoon"] = true,
			}, -- [3]
		},
		["575"] = {
			{
				["Enabled"] = true,
				["Timer31534activeCVoice"] = 0,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["SpecWarn31534reflectSWNote"] = true,
				["SpecWarn31534reflect"] = true,
				["Timer31534activeTColor"] = 5,
				["Timer31534active"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer31534activeCVoice"] = 0,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["SpecWarn31534reflectSWNote"] = true,
				["SpecWarn31534reflect"] = false,
				["Timer31534activeTColor"] = 5,
				["Timer31534active"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn31534reflect"] = true,
				["announce31543spell"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
				["Timer31534active"] = true,
				["Timer31534activeCVoice"] = 0,
				["Timer31534activeTColor"] = 5,
				["SpecWarn31534reflectSWNote"] = true,
			}, -- [3]
		},
		["571"] = {
			{
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = true,
				["announce34970spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = true,
				["announce34970spell"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = true,
				["announce34970spell"] = true,
			}, -- [3]
		},
		["556"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
			}, -- [3]
		},
		["523"] = {
			{
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["SpecWarn32300dodgeSWNote"] = true,
				["announceother32300target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["SpecWarn32300dodgeSWNote"] = true,
				["announceother32300target"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn32300dodge"] = true,
				["SpecWarn32300dodgeSWSound"] = 1,
				["SpecWarn32300dodgeSWNote"] = true,
				["announceother32300target"] = true,
			}, -- [3]
		},
		["564"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
			}, -- [3]
		},
		["545"] = {
			{
				["Enabled"] = true,
				["Timer33676nextTColor"] = 6,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["announce33676spell"] = true,
				["Timer33676activeCVoice"] = 0,
				["Timer33676activeTColor"] = 3,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer33676nextTColor"] = 6,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["announce33676spell"] = true,
				["Timer33676activeCVoice"] = 0,
				["Timer33676activeTColor"] = 3,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer33676nextTColor"] = 6,
				["Timer33676active"] = true,
				["Timer33676nextCVoice"] = 0,
				["Timer33676next"] = true,
				["announce33676spell"] = true,
				["Timer33676activeCVoice"] = 0,
				["Timer33676activeTColor"] = 3,
			}, -- [3]
		},
		["PT"] = {
			{
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["ShowAllPortalTimersCVoice"] = 0,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["TimerNextPortalTColor"] = 6,
			}, -- [1]
			{
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["ShowAllPortalTimersCVoice"] = 0,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["TimerNextPortalTColor"] = 6,
			}, -- [2]
			{
				["Enabled"] = true,
				["TimerNextPortalCVoice"] = 0,
				["ShowAllPortalTimersTColor"] = 0,
				["ShowAllPortalTimersCVoice"] = 0,
				["TimerNextPortal"] = true,
				["ShowAllPortalTimers"] = false,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["TimerNextPortalTColor"] = 6,
			}, -- [3]
		},
		["562"] = {
			{
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["announce34716spell"] = true,
				["Timer34716activeCVoice"] = 0,
				["Timer34727nextCVoice"] = 0,
				["announce34727spell"] = true,
				["Timer34716activeTColor"] = 3,
				["Timer34727nextTColor"] = 1,
				["Timer34727next"] = true,
				["Timer34716active"] = true,
			}, -- [3]
		},
		["AuctTombsTrash"] = {
			{
				["Enabled"] = true,
				["SpecWarn34945interrupt"] = false,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["announceother34925target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn34945interrupt"] = false,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["announceother34925target"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn34945interrupt"] = false,
				["SpecWarn34945interruptSWSound"] = 1,
				["SpecWarn15785interruptSWSound"] = 1,
				["SpecWarn34945interruptSWNote"] = true,
				["SpecWarn15785interruptSWNote"] = true,
				["SpecWarn15785interrupt"] = false,
				["announceother34925target"] = true,
			}, -- [3]
		},
		["527"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
			}, -- [3]
		},
		["553"] = {
			{
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2"] = true,
				["Timer38592active2CVoice"] = 0,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2"] = true,
				["Timer38592active2CVoice"] = 0,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer38592active2TColor"] = 5,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2CVoice"] = 0,
				["Timer38592active2"] = true,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2TColor"] = 5,
				["Timer31458target2"] = true,
				["Timer38592active2CVoice"] = 0,
			}, -- [3]
		},
		["549"] = {
			{
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = true,
				["SpecWarn36175run"] = false,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = true,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target4TColor"] = 5,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = true,
				["SpecWarn36175run"] = true,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = true,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target4TColor"] = 5,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn39013interrupt2SWNote"] = true,
				["Timer39009target4"] = true,
				["SpecWarn36175run"] = false,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interrupt2"] = false,
				["Timer39009target4CVoice"] = 0,
				["announceother39009target2"] = true,
				["SpecWarn39013interrupt2SWSound"] = 1,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target4TColor"] = 5,
			}, -- [3]
		},
		["574"] = {
			{
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = false,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["Timer35107targetCVoice"] = 0,
				["Enabled"] = true,
				["timer_berserkTColor"] = 0,
				["Timer35107target"] = true,
				["warnSummonSWNote"] = true,
			}, -- [1]
			{
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = false,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["Timer35107targetCVoice"] = 0,
				["Enabled"] = true,
				["timer_berserkTColor"] = 0,
				["Timer35107target"] = true,
				["warnSummonSWNote"] = true,
			}, -- [2]
			{
				["warnSummonSWSound"] = 1,
				["Timer35107targetTColor"] = 3,
				["warnSummon"] = false,
				["timer_berserkCVoice"] = 0,
				["announceother35107target"] = true,
				["timer_berserk"] = true,
				["Timer35107targetCVoice"] = 0,
				["Enabled"] = true,
				["timer_berserkTColor"] = 0,
				["Timer35107target"] = true,
				["warnSummonSWNote"] = true,
			}, -- [3]
		},
		["538"] = {
			{
				["Enabled"] = true,
				["SpecWarn31909runSWNote"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = true,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["SpecWarn31909run"] = true,
				["announceother33792target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn31909runSWNote"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = true,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["SpecWarn31909run"] = true,
				["announceother33792target"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn31909runSWNote"] = true,
				["Timer33792targetTColor"] = 3,
				["Timer33792targetCVoice"] = 0,
				["announceother31911target"] = true,
				["Timer33792target"] = true,
				["SpecWarn31909runSWSound"] = 4,
				["SpecWarn31909run"] = true,
				["announceother33792target"] = true,
			}, -- [3]
		},
		["563"] = {
			{
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["Timer35158active"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["Timer35159activeCVoice"] = 0,
				["timer_berserk"] = true,
				["Timer35159activeTColor"] = 5,
				["Timer35158activeTColor"] = 5,
				["announce35158spell"] = true,
				["timer_berserkTColor"] = 0,
				["announce39096cast"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["Timer35158active"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["Timer35159activeCVoice"] = 0,
				["timer_berserk"] = true,
				["Timer35159activeTColor"] = 5,
				["Timer35158activeTColor"] = 5,
				["announce35158spell"] = true,
				["timer_berserkTColor"] = 0,
				["announce39096cast"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer35158activeCVoice"] = 0,
				["timer_berserkCVoice"] = 0,
				["Timer35158active"] = true,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["Timer35159activeTColor"] = 5,
				["timer_berserk"] = true,
				["Timer35159activeCVoice"] = 0,
				["Timer35158activeTColor"] = 5,
				["announce35158spell"] = true,
				["timer_berserkTColor"] = 0,
				["announce39096cast"] = true,
			}, -- [3]
		},
		["Gyrokill"] = {
			{
				["Enabled"] = true,
				["Timer35322active2CVoice"] = 0,
				["Timer35322active2TColor"] = 5,
				["SpecWarn35322dispel"] = false,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = false,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer35322active2CVoice"] = 0,
				["Timer35322active2TColor"] = 5,
				["SpecWarn35322dispel"] = false,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer35322active2CVoice"] = 0,
				["Timer35322active2TColor"] = 5,
				["SpecWarn35322dispel"] = false,
				["announceother35322target"] = true,
				["SpecWarn35322dispelSWNote"] = true,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active2"] = false,
			}, -- [3]
		},
		["554"] = {
			{
				["Enabled"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["announce37605spell"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["announce37605spell"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer31422active"] = true,
				["Timer31422activeCVoice"] = 0,
				["announce37605spell"] = true,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 3,
			}, -- [3]
		},
		["534"] = {
			{
				["Enabled"] = true,
				["Timer32358activeCVoice"] = 0,
				["Timer32358activeTColor"] = 5,
				["Timer32358active"] = true,
				["SpecWarn32358reflect2"] = true,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer32358activeCVoice"] = 0,
				["Timer32358activeTColor"] = 5,
				["Timer32358active"] = true,
				["SpecWarn32358reflect2"] = true,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer32358activeCVoice"] = 0,
				["Timer32358activeTColor"] = 5,
				["Timer32358active"] = true,
				["SpecWarn32358reflect2"] = true,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
			}, -- [3]
		},
		["543"] = {
			{
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castCVoice"] = 0,
				["Timer38197castTColor"] = 2,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castCVoice"] = 0,
				["Timer38197castTColor"] = 2,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn38197spell2SWSound"] = 3,
				["SpecWarn38197spell2"] = true,
				["Timer38197cast"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spell2SWNote"] = true,
				["Timer38197castCVoice"] = 0,
				["Timer38197castTColor"] = 2,
			}, -- [3]
		},
		["569"] = {
			{
				["SpecWarn30739spellSWSound"] = 2,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdCVoice"] = 0,
				["Timer30739cdTColor"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			}, -- [1]
			{
				["SpecWarn30739spellSWSound"] = 2,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdCVoice"] = 0,
				["Timer30739cdTColor"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			}, -- [2]
			{
				["SpecWarn30739spellSWSound"] = 2,
				["warnSharpShooter"] = true,
				["timerReaver"] = true,
				["warnHeathen"] = true,
				["timerSharpShooter"] = true,
				["timerHeathenTColor"] = 1,
				["timerHeathenCVoice"] = 0,
				["warnReaver"] = true,
				["timerSharpShooterTColor"] = 1,
				["Enabled"] = true,
				["SpecWarn30739spell"] = true,
				["Timer30739cd"] = true,
				["timerSharpShooterCVoice"] = 0,
				["SpecWarn30739spellSWNote"] = true,
				["Timer30739cdCVoice"] = 0,
				["Timer30739cdTColor"] = 2,
				["timerHeathen"] = true,
				["timerReaverTColor"] = 1,
				["timerReaverCVoice"] = 0,
			}, -- [3]
		},
		["547"] = {
			{
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["Timer33711targetTColor"] = 3,
				["SpecWarn33711moveawaySWNote"] = true,
				["Timer33711targetCVoice"] = 0,
				["Timer33923cast"] = true,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SetIconOnTouchTarget"] = true,
				["Timer33711target"] = true,
				["SpecWarn33923runSWNote"] = true,
				["SpecWarn33923run"] = true,
				["Timer33923castCVoice"] = 0,
				["Timer33923castTColor"] = 2,
				["announceother33711target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["SetIconOnTouchTarget"] = true,
				["Timer33711targetTColor"] = 3,
				["Timer33711targetCVoice"] = 0,
				["Timer33923cast"] = true,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SpecWarn33711moveawaySWNote"] = true,
				["Timer33711target"] = true,
				["SpecWarn33923runSWNote"] = true,
				["SpecWarn33923run"] = true,
				["Timer33923castCVoice"] = 0,
				["Timer33923castTColor"] = 2,
				["announceother33711target"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["SpecWarn33711moveawaySWNote"] = true,
				["SetIconOnTouchTarget"] = true,
				["Timer33711targetCVoice"] = 0,
				["Timer33923castTColor"] = 2,
				["SpecWarn33711moveawaySWSound"] = 1,
				["Timer33711targetTColor"] = 3,
				["SpecWarn33923run"] = true,
				["SpecWarn33923runSWNote"] = true,
				["Timer33711target"] = true,
				["Timer33923castCVoice"] = 0,
				["Timer33923cast"] = true,
				["announceother33711target"] = true,
			}, -- [3]
		},
		["546"] = {
			{
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer33563nextCVoice"] = 0,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			}, -- [3]
		},
		["539"] = {
			{
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["Timer13005target"] = true,
				["SpecWarn38385moveSWNote"] = true,
				["Enabled"] = true,
				["SpecWarn38385move"] = true,
				["SpecWarn29427interrupt"] = false,
				["announceother13005target"] = true,
			}, -- [1]
			{
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["Timer13005target"] = true,
				["SpecWarn38385moveSWNote"] = true,
				["Enabled"] = true,
				["SpecWarn38385move"] = true,
				["SpecWarn29427interrupt"] = false,
				["announceother13005target"] = true,
			}, -- [2]
			{
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["Timer13005targetCVoice"] = 0,
				["SpecWarn29427interruptSWSound"] = 1,
				["Timer13005targetTColor"] = 3,
				["SpecWarn38385moveSWNote"] = true,
				["Timer13005target"] = true,
				["Enabled"] = true,
				["SpecWarn38385move"] = true,
				["SpecWarn29427interrupt"] = false,
				["announceother13005target"] = true,
			}, -- [3]
		},
		["540"] = {
			{
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer33834active"] = true,
				["announce31914spell"] = true,
				["Timer33834activeTColor"] = 1,
				["Timer33834activeCVoice"] = 0,
			}, -- [3]
		},
		["565"] = {
			{
				["Enabled"] = true,
				["Timer35280targetTColor"] = 3,
				["Timer35280target"] = true,
				["Timer35280targetCVoice"] = 0,
				["announceother35280target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer35280targetTColor"] = 3,
				["Timer35280target"] = true,
				["Timer35280targetCVoice"] = 0,
				["announceother35280target"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer35280targetTColor"] = 3,
				["Timer35280target"] = true,
				["Timer35280targetCVoice"] = 0,
				["announceother35280target"] = true,
			}, -- [3]
		},
		["560"] = {
			{
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfoSWNote"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfo"] = true,
				["Timer34670activeCVoice"] = 0,
				["announce34670spell"] = true,
				["Timer34670active"] = true,
				["Timer34670activeTColor"] = 0,
				["announceother34661target"] = true,
				["Timer34661targetCVoice"] = 0,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfoSWNote"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfo"] = true,
				["Timer34670activeCVoice"] = 0,
				["announce34670spell"] = true,
				["Timer34670active"] = true,
				["Timer34670activeTColor"] = 0,
				["announceother34661target"] = true,
				["Timer34661targetCVoice"] = 0,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer34661targetTColor"] = 3,
				["SpecWarn34660gtfoSWNote"] = true,
				["SpecWarn34660gtfoSWSound"] = 1,
				["Timer34661target"] = true,
				["SpecWarn34660gtfo"] = true,
				["Timer34670active"] = true,
				["announce34670spell"] = true,
				["Timer34670activeCVoice"] = 0,
				["Timer34670activeTColor"] = 0,
				["announceother34661target"] = true,
				["Timer34661targetCVoice"] = 0,
			}, -- [3]
		},
		["529"] = {
			{
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689targetTColor"] = 3,
				["Yell30689"] = true,
				["SpecWarn30689youSWNote"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689targetTColor"] = 3,
				["Yell30689"] = true,
				["SpecWarn30689youSWNote"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer30689targetCVoice"] = 0,
				["SpecWarn30689you"] = true,
				["Timer30689target"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689targetTColor"] = 3,
				["Yell30689"] = true,
				["SpecWarn30689youSWNote"] = true,
			}, -- [3]
		},
		["542"] = {
			{
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40303targetTColor"] = 3,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40321targetTColor"] = 3,
				["Timer40184active"] = true,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["SpecWarn40184spellSWNote"] = true,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184castTColor"] = 2,
				["Timer40321target"] = true,
				["Timer40303target"] = true,
			}, -- [1]
			{
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40303targetTColor"] = 3,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40321targetTColor"] = 3,
				["Timer40184active"] = true,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["SpecWarn40184spellSWNote"] = true,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184castTColor"] = 2,
				["Timer40321target"] = true,
				["Timer40303target"] = true,
			}, -- [2]
			{
				["warnBrood"] = true,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 3,
				["announceother40321target"] = true,
				["Timer40303targetCVoice"] = 0,
				["Timer40321targetCVoice"] = 0,
				["Timer40184activeCVoice"] = 0,
				["Enabled"] = true,
				["Timer40303targetTColor"] = 3,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40321targetTColor"] = 3,
				["Timer40184castTColor"] = 2,
				["Timer40184castCVoice"] = 0,
				["SpecWarn40184spellSWSound"] = 2,
				["Timer40184cd"] = true,
				["Timer40184cdCVoice"] = 0,
				["SpecWarn40184spellSWNote"] = true,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184active"] = true,
				["Timer40321target"] = true,
				["Timer40303target"] = true,
			}, -- [3]
		},
		["568"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
			}, -- [3]
		},
		["talent3"] = "DRUID3",
		["talent2"] = "DRUID2",
		["728"] = {
			{
				["Enabled"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
			}, -- [3]
		},
		["541"] = {
			{
				["Enabled"] = true,
				["warnSummon"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["warnSummon"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["warnSummon"] = true,
			}, -- [3]
		},
		["528"] = {
			{
				["Enabled"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["RangeFrame"] = true,
				["Timer37566target"] = true,
				["announceother37566target"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["SpecWarn37566moveaway"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["RangeFrame"] = true,
				["Timer37566target"] = true,
				["announceother37566target"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["SpecWarn37566moveaway"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer37566targetTColor"] = 3,
				["Yell37566"] = true,
				["SpecWarn37566moveawaySWSound"] = 1,
				["announceother37566target"] = true,
				["Timer37566target"] = true,
				["RangeFrame"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetCVoice"] = 0,
				["SpecWarn37566moveawaySWNote"] = true,
				["SpecWarn37566moveaway"] = true,
			}, -- [3]
		},
		["561"] = {
			{
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			}, -- [1]
			{
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			}, -- [2]
			{
				["Enabled"] = true,
				["Timer34697targetCVoice"] = 0,
				["Timer34697targetTColor"] = 3,
				["Timer34697target"] = true,
				["announceother34697target"] = true,
			}, -- [3]
		},
	},
}
