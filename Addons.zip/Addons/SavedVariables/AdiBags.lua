
AdiBagsDB = {
	["namespaces"] = {
		["ItemLevel"] = {
		},
		["FilterOverride"] = {
			["profiles"] = {
				["Default"] = {
					["version"] = 3,
				},
			},
		},
		["ItemCategory"] = {
		},
		["NewItem"] = {
		},
		["Equipment"] = {
		},
		["MoneyFrame"] = {
		},
		["DataSource"] = {
		},
		["Junk"] = {
		},
		["AdiBags_TooltipInfo"] = {
		},
	},
	["profileKeys"] = {
		["Biologe - Ewige Warte"] = "Default",
		["Saucier - Ewige Warte"] = "Default",
		["Stoc - Everlook"] = "Default",
		["Hoddl - Ewige Warte"] = "Default",
		["Pinkfear - Lakeshire"] = "Default",
		["Resonator - Everlook"] = "Default",
		["Nedro - Everlook"] = "Default",
		["Cretax - Everlook"] = "Default",
		["Cadix - Lakeshire"] = "Default",
		["Resonator - Ewige Warte"] = "Default",
		["Felton - Lakeshire"] = "Default",
		["Deramahsteht - Lucifron"] = "Default",
		["Sibo - Lakeshire"] = "Default",
		["Stoc - Ewige Warte"] = "Default",
		["Hoddl - Everlook"] = "Default",
		["Saucier - Everlook"] = "Default",
		["Felton - Seenhain"] = "Default",
		["Resonator - Lakeshire"] = "Default",
		["Containerd - Lakeshire"] = "Default",
		["Biologe - Everlook"] = "Default",
		["Cretax - Ewige Warte"] = "Default",
		["Akuhstiker - Transcendence"] = "Default",
		["Privee - Everlook"] = "Default",
		["Privatfrau - Everlook"] = "Default",
		["Tinyevil - Lakeshire"] = "Default",
		["Pädagoge - Everlook"] = "Default",
		["Haspahhmitte - Everlook"] = "Default",
		["Pädagoge - Ewige Warte"] = "Default",
		["Sortis - Lakeshire"] = "Default",
		["Raidbankk - Lakeshire"] = "Default",
		["Herrkuhfuß - Lakeshire"] = "Default",
		["Knallus - Everlook"] = "Default",
		["Nedro - Ewige Warte"] = "Default",
		["Drushnak - Lakeshire"] = "Default",
		["Refractor - Everlook"] = "Default",
		["Privee - Ewige Warte"] = "Default",
		["Nedro - Lakeshire"] = "Default",
		["Giselheer - Everlook"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["maxHeight"] = 0.3,
			["positions"] = {
				["anchor"] = {
					["xOffset"] = 4.74067401885986,
					["point"] = "BOTTOMLEFT",
					["yOffset"] = 18.9632873535156,
				},
				["Backpack"] = {
					["xOffset"] = -98.7212679279474,
					["yOffset"] = 85.0027905732809,
				},
				["Bank"] = {
					["xOffset"] = 384.395464712314,
					["yOffset"] = -176.691469409438,
				},
			},
			["positionMode"] = "manual",
		},
	},
}
