
Bagnon_Sets = {
	["tackleColor"] = {
	},
	["leatherColor"] = {
	},
	["engineerColor"] = {
	},
	["herbColor"] = {
	},
	["inscribeColor"] = {
	},
	["soulColor"] = {
	},
	["quiverColor"] = {
	},
	["reagentColor"] = {
	},
	["gemColor"] = {
	},
	["enchantColor"] = {
	},
	["keyColor"] = {
	},
	["normalColor"] = {
	},
	["profiles"] = {
	},
	["mineColor"] = {
	},
	["version"] = "10.0.16",
	["display"] = {
	},
	["fridgeColor"] = {
	},
	["global"] = {
		["inventory"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
				"all/souls", -- [21]
				"equip/ammo", -- [22]
			},
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				[0] = false,
				[-2] = true,
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["y"] = -77.39495849609375,
			["x"] = -170.0963134765625,
			["borderColor"] = {
			},
			["showBags"] = true,
		},
		["vault"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["borderColor"] = {
			},
		},
		["guild"] = {
			["y"] = 242.1667022705078,
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
				"all/souls", -- [21]
				"equip/ammo", -- [22]
			},
			["point"] = "BOTTOMLEFT",
			["borderColor"] = {
			},
			["color"] = {
			},
			["hiddenBags"] = {
			},
			["hiddenRules"] = {
			},
			["x"] = 478.5184020996094,
		},
		["bank"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
				"all/souls", -- [21]
				"equip/ammo", -- [22]
			},
			["point"] = "TOPLEFT",
			["hiddenBags"] = {
				[11] = false,
				[7] = false,
				[8] = false,
				[10] = false,
				[6] = false,
				[5] = false,
				[-1] = false,
				[9] = false,
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["y"] = -71.1048583984375,
			["x"] = 355.5559387207031,
			["borderColor"] = {
			},
			["showBags"] = true,
			["brokerObject"] = "BagnonLauncher",
		},
	},
}
