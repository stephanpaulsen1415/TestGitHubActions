
DBMEyeOfEternity_SavedStats = {
	["Malygos"] = {
		["normal25LastTime"] = 305.8349999999919,
		["normalPulls"] = 0,
		["challengeKills"] = 0,
		["normal25BestTime"] = 305.8349999999919,
		["challengeBestRank"] = 0,
		["mythicKills"] = 0,
		["lfr25Kills"] = 0,
		["heroic25Pulls"] = 0,
		["lfr25Pulls"] = 0,
		["normal25Pulls"] = 1,
		["normalKills"] = 0,
		["heroic25Kills"] = 0,
		["timewalkerPulls"] = 0,
		["heroicKills"] = 0,
		["heroicPulls"] = 0,
		["normal25Kills"] = 1,
		["timewalkerKills"] = 0,
		["mythicPulls"] = 0,
		["challengePulls"] = 0,
	},
}
