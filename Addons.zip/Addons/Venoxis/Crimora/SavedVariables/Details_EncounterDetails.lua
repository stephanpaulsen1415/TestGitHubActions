
EncounterDetailsDB = {
	["encounter_spells"] = {
		[64217] = {
			["school"] = 1,
			["type"] = "BUFF",
			["token"] = {
				["SPELL_AURA_APPLIED"] = true,
			},
			["source"] = "Tempest Minion",
		},
		[48210] = {
			["school"] = 32,
			["token"] = {
				["SPELL_HEAL"] = true,
			},
			["source"] = "Emalon the Storm Watcher",
		},
		[57984] = {
			["school"] = 4,
			["token"] = {
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Greater Fire Elemental",
		},
		[64363] = {
			["school"] = 8,
			["token"] = {
				["SPELL_CAST_SUCCESS"] = true,
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Tempest Minion",
		},
		[64218] = {
			["school"] = 8,
			["token"] = {
				["SPELL_CAST_SUCCESS"] = true,
				["SPELL_HEAL"] = true,
			},
			["source"] = "Emalon the Storm Watcher",
		},
		[65279] = {
			["school"] = 8,
			["token"] = {
				["SPELL_CAST_START"] = true,
				["SPELL_CAST_SUCCESS"] = true,
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Emalon the Storm Watcher",
		},
		[64215] = {
			["school"] = 8,
			["token"] = {
				["SPELL_CAST_START"] = true,
				["SPELL_CAST_SUCCESS"] = true,
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Emalon the Storm Watcher",
		},
		[59638] = {
			["school"] = 16,
			["token"] = {
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Mirror Image",
		},
	},
	["emotes"] = {
		{
			{
				43.40100000001257, -- [1]
				"%s overcharges a Tempest Minion!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [1]
			{
				64.43499999999767, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [2]
			{
				88.66800000000512, -- [1]
				"%s overcharges a Tempest Minion!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [3]
			{
				111.3190000000177, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [4]
			{
				134.0190000000002, -- [1]
				"%s overcharges a Tempest Minion!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [5]
			{
				158.3360000000102, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [6]
			{
				176.1199999999953, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [7]
			{
				179.3699999999953, -- [1]
				"%s overcharges a Tempest Minion!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [8]
			{
				202.0199999999895, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [9]
			{
				224.6710000000021, -- [1]
				"%s overcharges a Tempest Minion!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [10]
			{
				247.3880000000063, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [11]
			{
				259.2880000000005, -- [1]
				"%s has transferred your soul into the body of a Ghoul.", -- [2]
				"Aúrelia", -- [3]
				2, -- [4]
			}, -- [12]
			{
				270.0210000000079, -- [1]
				"%s overcharges a Tempest Minion!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [13]
			["boss"] = "Emalon the Storm Watcher",
		}, -- [1]
	},
}
