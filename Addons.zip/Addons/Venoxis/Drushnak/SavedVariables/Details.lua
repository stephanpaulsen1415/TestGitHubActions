
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 815,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001053,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 13407,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 13407.001053,
							["end_time"] = 1675856790,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 13407.001053,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 3010,
										["g_amt"] = 0,
										["n_max"] = 395,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 4483,
										},
										["n_dmg"] = 1473,
										["n_min"] = 350,
										["g_dmg"] = 0,
										["counter"] = 10,
										["ChartData"] = {
											[5] = 2517,
										},
										["total"] = 4483,
										["c_max"] = 881,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 2,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 690,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[48665] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 812,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1506,
										},
										["n_dmg"] = 1506,
										["n_min"] = 694,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 1506,
										},
										["total"] = 1506,
										["c_max"] = 0,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57970] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1152,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1152,
										},
										["n_dmg"] = 1152,
										["n_min"] = 1152,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1152,
										["c_max"] = 0,
										["id"] = 57970,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57965] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 919,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1831,
										},
										["n_dmg"] = 1831,
										["n_min"] = 912,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 1831,
										},
										["total"] = 1831,
										["c_max"] = 0,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1379,
										["g_amt"] = 0,
										["n_max"] = 762,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2141,
										},
										["n_dmg"] = 762,
										["n_min"] = 762,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 2141,
										},
										["total"] = 2141,
										["c_max"] = 1379,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1379,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57993] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1529,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2294,
										},
										["n_dmg"] = 2294,
										["n_min"] = 765,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2294,
										["c_max"] = 0,
										["id"] = 57993,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 1651.718744985926,
							["custom"] = 0,
							["last_event"] = 1675856789,
							["damage_taken"] = 1354.001053,
							["start_time"] = 1675856784,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003396,
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["targets"] = {
								["Drushnak"] = 1354,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-29333-0000E3196C",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "29333",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1354.003396,
							["fight_component"] = true,
							["end_time"] = 1675856790,
							["dps_started"] = false,
							["total"] = 1354.003396,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 392,
										["targets"] = {
											["Drushnak"] = 1354,
										},
										["n_dmg"] = 1354,
										["n_min"] = 306,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1354,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 13407.003396,
							["start_time"] = 1675856781,
							["delay"] = 0,
							["last_event"] = 1675856787,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 815,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 815,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 60.006974,
							["resource"] = 0.006974,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 60,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.006974,
							["total"] = 60.006974,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 10,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 10,
										},
										["counter"] = 5,
									},
									[14181] = {
										["total"] = 50,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 50,
										},
										["counter"] = 2,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856788,
							["alternatepower"] = 0.006974,
							["passiveover"] = 0.006974,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 815,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[57970] = {
										["activedamt"] = 0,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 8,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 44,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[55775] = {
										["activedamt"] = 1,
										["id"] = 55775,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[32243] = {
										["activedamt"] = 1,
										["id"] = 32243,
										["targets"] = {
										},
										["actived_at"] = 1675856781,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[57993] = {
										["activedamt"] = 1,
										["id"] = 57993,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[60233] = {
										["activedamt"] = 1,
										["id"] = 60233,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 3,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[48666] = 2,
								[6774] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856790,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 815,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708958.034,
				["tempo_start"] = 1675856781,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 885,
				["playing_solo"] = true,
				["totals"] = {
					14760.907085, -- [1]
					-0.1491559999999481, -- [2]
					{
						0, -- [1]
						[0] = -0.02634500000033313,
						["alternatepower"] = 0,
						[3] = 60,
						[6] = -0.006149999999998101,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:46:30",
				["hasTimer"] = 8,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 3.266000000061467,
				["CombatEndedAt"] = 708961.3,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:46:22",
				["end_time"] = 708947.517,
				["combat_id"] = 815,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 1,
				},
				["totals_grupo"] = {
					13407, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 60,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 13407.001053,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708939.4,
				["contra"] = "Onslaught Gryphon Rider",
				["TimeData"] = {
				},
			}, -- [1]
			{
				{
					["combatId"] = 814,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006768,
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["targets"] = {
								["Onslaught Gryphon Rider"] = 39830,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 39830.006768,
							["end_time"] = 1675856730,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 39830.006768,
							["friendlyfire_total"] = 0,
							["aID"] = "4477-04D9C2D1",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 9,
										["b_amt"] = 1,
										["c_dmg"] = 6514,
										["g_amt"] = 2,
										["n_max"] = 420,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 12957,
										},
										["n_dmg"] = 5790,
										["n_min"] = 307,
										["g_dmg"] = 653,
										["counter"] = 28,
										["ChartData"] = {
											[8] = 7019,
											[6] = 3465,
											[15] = 11496,
											[11] = 9341,
										},
										["total"] = 12957,
										["c_max"] = 788,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 687,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 16,
										["b_dmg"] = 307,
										["r_amt"] = 0,
									}, -- [1]
									[48665] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 4721,
										["g_amt"] = 0,
										["n_max"] = 696,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 5417,
										},
										["n_dmg"] = 696,
										["n_min"] = 696,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[8] = 3828,
											[6] = 3132,
											[15] = 5417,
											[11] = 3828,
										},
										["total"] = 5417,
										["c_max"] = 1642,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1490,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57970] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1102,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2136,
										},
										["n_dmg"] = 2136,
										["n_min"] = 1034,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[8] = 1034,
											[6] = 1034,
											[15] = 1034,
											[11] = 1034,
										},
										["total"] = 2136,
										["c_max"] = 0,
										["id"] = 57970,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57965] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 2501,
										["g_amt"] = 0,
										["n_max"] = 917,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 6735,
										},
										["n_dmg"] = 4234,
										["n_min"] = 802,
										["g_dmg"] = 0,
										["counter"] = 7,
										["ChartData"] = {
											[8] = 3717,
											[6] = 2515,
											[15] = 5016,
											[11] = 3717,
										},
										["total"] = 6735,
										["c_max"] = 1299,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1202,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 4429,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 4429,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[8] = 2872,
											[6] = 1498,
											[15] = 4429,
											[11] = 2872,
										},
										["total"] = 4429,
										["c_max"] = 1557,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1374,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57993] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3814,
										["g_amt"] = 0,
										["n_max"] = 2189,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 8156,
										},
										["n_dmg"] = 4342,
										["n_min"] = 2153,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[8] = 2153,
											[6] = 2153,
											[15] = 5967,
											[11] = 5967,
										},
										["total"] = 8156,
										["c_max"] = 3814,
										["id"] = 57993,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3814,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 2231.372928182182,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 4232.006768,
							["start_time"] = 1675856712,
							["delay"] = 0,
							["last_event"] = 1675856728,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006552,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 4232,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-29333-000063726C",
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["aID"] = "29333",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4232.006552,
							["fight_component"] = true,
							["end_time"] = 1675856730,
							["dps_started"] = false,
							["total"] = 4232.006552,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 400,
										["targets"] = {
											["Drushnak"] = 2166,
										},
										["n_dmg"] = 2166,
										["n_min"] = 311,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 2166,
										["c_max"] = 0,
										["DODGE"] = 3,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 2,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 65,
										["targets"] = {
											["Drushnak"] = 65,
										},
										["n_dmg"] = 65,
										["n_min"] = 65,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[54617] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1008,
										["targets"] = {
											["Drushnak"] = 2001,
										},
										["n_dmg"] = 2001,
										["n_min"] = 993,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2001,
										["c_max"] = 0,
										["id"] = 54617,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 39830.006552,
							["start_time"] = 1675856712,
							["delay"] = 0,
							["last_event"] = 1675856726,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 814,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 814,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 57.006193,
							["resource"] = 0.006193,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 57,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.006193,
							["total"] = 57.006193,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 32,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 32,
										},
										["counter"] = 16,
									},
									[14181] = {
										["total"] = 25,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856728,
							["alternatepower"] = 0.006193,
							["passiveover"] = 0.006193,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 814,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[57970] = {
										["activedamt"] = 0,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 3,
										["refreshamt"] = 20,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 93,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[59620] = {
										["activedamt"] = 1,
										["id"] = 59620,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57993] = {
										["activedamt"] = 3,
										["id"] = 57993,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 3,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[60233] = {
										["activedamt"] = 1,
										["id"] = 60233,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[32243] = {
										["activedamt"] = 1,
										["id"] = 32243,
										["targets"] = {
										},
										["actived_at"] = 1675856712,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 8,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[48666] = 4,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856730,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[40652] = 2,
								[54617] = 2,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-4457-571-155-29333-000063726C",
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 814,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708937.8,
				["tempo_start"] = 1675856712,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 884,
				["playing_solo"] = true,
				["totals"] = {
					44061.992845, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 57,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:45:31",
				["hasTimer"] = 17,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 708887.932,
				["CombatEndedAt"] = 708887.932,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:45:13",
				["end_time"] = 708887.932,
				["combat_id"] = 814,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 3,
				},
				["totals_grupo"] = {
					39830, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 57,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 39830.006768,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708870.082,
				["contra"] = "Onslaught Gryphon Rider",
				["TimeData"] = {
				},
			}, -- [2]
			{
				{
					["combatId"] = 813,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007299,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 17178,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 17178.007299,
							["end_time"] = 1675856700,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 17178.007299,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 2272,
										["g_amt"] = 0,
										["n_max"] = 368,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2964,
										},
										["n_dmg"] = 692,
										["n_min"] = 324,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2964,
										["c_max"] = 767,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 750,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[57965] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 832,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2479,
										},
										["n_dmg"] = 2479,
										["n_min"] = 818,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2479,
										["c_max"] = 0,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1535,
										["g_amt"] = 0,
										["n_max"] = 829,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2364,
										},
										["n_dmg"] = 829,
										["n_min"] = 829,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2364,
										["c_max"] = 1535,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1535,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57993] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 6051,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 6051,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 6051,
										["c_max"] = 6051,
										["id"] = 57993,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 6051,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48665] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3320,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3320,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3320,
										["c_max"] = 1761,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1559,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 5052.355087906579,
							["custom"] = 0,
							["last_event"] = 1675856699,
							["damage_taken"] = 686.007299,
							["start_time"] = 1675856696,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006928,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 686,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-29333-0000637FBC",
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["aID"] = "29333",
							["raid_targets"] = {
							},
							["total_without_pet"] = 686.006928,
							["fight_component"] = true,
							["end_time"] = 1675856700,
							["dps_started"] = false,
							["total"] = 686.006928,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 354,
										["targets"] = {
											["Drushnak"] = 686,
										},
										["n_dmg"] = 686,
										["n_min"] = 332,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 686,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Drushnak"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 17178.006928,
							["start_time"] = 1675856697,
							["delay"] = 0,
							["last_event"] = 1675856710,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 813,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 813,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 39.001238,
							["resource"] = 0.001238,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 39,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.001238,
							["total"] = 39.001238,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 14,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 14,
										},
										["counter"] = 7,
									},
									[14181] = {
										["total"] = 25,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856699,
							["alternatepower"] = 0.001238,
							["passiveover"] = 0.001238,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 813,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[57970] = {
										["activedamt"] = 0,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 18,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[60233] = {
										["activedamt"] = 1,
										["id"] = 60233,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57993] = {
										["activedamt"] = 1,
										["id"] = 57993,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 2,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[48666] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856700,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[40652] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-4457-571-155-29333-0000637FBC",
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 813,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708868.449,
				["tempo_start"] = 1675856696,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 883,
				["playing_solo"] = true,
				["totals"] = {
					17863.994153, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 39,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:45:00",
				["hasTimer"] = 3,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 708857.515,
				["CombatEndedAt"] = 708857.515,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:44:57",
				["end_time"] = 708857.515,
				["combat_id"] = 813,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 1,
				},
				["totals_grupo"] = {
					17178, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 39,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 17178.007299,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708854.115,
				["contra"] = "Onslaught Gryphon Rider",
				["TimeData"] = {
				},
			}, -- [3]
			{
				{
					["combatId"] = 812,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008878,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 15518,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 15518.008878,
							["end_time"] = 1675856681,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 15518.008878,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 1,
										["c_dmg"] = 2162,
										["g_amt"] = 0,
										["n_max"] = 371,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3513,
										},
										["n_dmg"] = 1351,
										["n_min"] = 307,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 3513,
										["c_max"] = 795,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 2,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 677,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 321,
										["r_amt"] = 0,
									}, -- [1]
									[48665] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 1742,
										["g_amt"] = 0,
										["n_max"] = 584,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2326,
										},
										["n_dmg"] = 584,
										["n_min"] = 584,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2326,
										["c_max"] = 1742,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1742,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 584,
										["r_amt"] = 0,
									},
									[57970] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 621,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 621,
										},
										["n_dmg"] = 621,
										["n_min"] = 621,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 621,
										["c_max"] = 0,
										["id"] = 57970,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57965] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 825,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1624,
										},
										["n_dmg"] = 1624,
										["n_min"] = 799,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1624,
										["c_max"] = 0,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1331,
										["g_amt"] = 0,
										["n_max"] = 830,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2161,
										},
										["n_dmg"] = 830,
										["n_min"] = 830,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2161,
										["c_max"] = 1331,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1331,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57993] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 5273,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 5273,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5273,
										["c_max"] = 5273,
										["id"] = 57993,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 5273,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 2796.037635652216,
							["custom"] = 0,
							["last_event"] = 1675856696,
							["damage_taken"] = 943.008878,
							["start_time"] = 1675856676,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002143,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 943,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-29333-0000637FAC",
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["aID"] = "29333",
							["raid_targets"] = {
							},
							["total_without_pet"] = 943.002143,
							["fight_component"] = true,
							["end_time"] = 1675856696,
							["dps_started"] = false,
							["total"] = 943.002143,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 581,
										["g_amt"] = 0,
										["n_max"] = 300,
										["targets"] = {
											["Drushnak"] = 881,
										},
										["n_dmg"] = 300,
										["n_min"] = 300,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 881,
										["c_max"] = 581,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 581,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 62,
										["targets"] = {
											["Drushnak"] = 62,
										},
										["n_dmg"] = 62,
										["n_min"] = 62,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 62,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 15518.002143,
							["start_time"] = 1675856677,
							["delay"] = 0,
							["last_event"] = 1675856695,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 812,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 812,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 62.001553,
							["resource"] = 0.001553,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 62,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.001553,
							["total"] = 62.001553,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 12,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 12,
										},
										["counter"] = 6,
									},
									[14181] = {
										["total"] = 50,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 50,
										},
										["counter"] = 2,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856680,
							["alternatepower"] = 0.001553,
							["passiveover"] = 0.001553,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 812,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[57970] = {
										["activedamt"] = 0,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 22,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[55775] = {
										["activedamt"] = 1,
										["id"] = 55775,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57993] = {
										["activedamt"] = 1,
										["id"] = 57993,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[48666] = 2,
								[6774] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856681,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[40652] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-4457-571-155-29333-0000637FAC",
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 812,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708852.682,
				["tempo_start"] = 1675856676,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 882,
				["playing_solo"] = true,
				["totals"] = {
					16460.988032, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 62,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Drushnak"] = {
						{
							true, -- [1]
							1, -- [2]
							300, -- [3]
							1675856695.576, -- [4]
							15128, -- [5]
							"Onslaught Gryphon Rider", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:44:42",
				["hasTimer"] = 5,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 708839.3150000001,
				["CombatEndedAt"] = 708839.3150000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:44:36",
				["end_time"] = 708839.3150000001,
				["combat_id"] = 812,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 1,
					["Corrupted Scarlet Onslaught"] = 1,
				},
				["totals_grupo"] = {
					15518, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 62,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 15518.008878,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708833.765,
				["contra"] = "Onslaught Gryphon Rider",
				["TimeData"] = {
				},
			}, -- [4]
			{
				{
					["combatId"] = 811,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005134,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 13453,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 13453.005134,
							["end_time"] = 1675856653,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 13453.005134,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1787,
										["g_amt"] = 2,
										["n_max"] = 468,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3435,
										},
										["n_dmg"] = 830,
										["n_min"] = 362,
										["g_dmg"] = 818,
										["counter"] = 6,
										["total"] = 3435,
										["c_max"] = 951,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 836,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[48665] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3719,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3719,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3719,
										["c_max"] = 2203,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1516,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3436,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3436,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3436,
										["c_max"] = 2033,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1403,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57970] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1003,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1003,
										},
										["n_dmg"] = 1003,
										["n_min"] = 1003,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1003,
										["c_max"] = 0,
										["id"] = 57970,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57965] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 957,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1860,
										},
										["n_dmg"] = 1860,
										["n_min"] = 903,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1860,
										["c_max"] = 0,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 2764.694848724709,
							["custom"] = 0,
							["last_event"] = 1675856652,
							["damage_taken"] = 792.005134,
							["start_time"] = 1675856649,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007334,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 792,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-29333-0000637F82",
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["aID"] = "29333",
							["raid_targets"] = {
							},
							["total_without_pet"] = 792.007334,
							["fight_component"] = true,
							["end_time"] = 1675856653,
							["dps_started"] = false,
							["total"] = 792.007334,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 414,
										["targets"] = {
											["Drushnak"] = 725,
										},
										["n_dmg"] = 725,
										["n_min"] = 311,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 725,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 67,
										["targets"] = {
											["Drushnak"] = 67,
										},
										["n_dmg"] = 67,
										["n_min"] = 67,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 67,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 13453.007334,
							["start_time"] = 1675856648,
							["delay"] = 0,
							["last_event"] = 1675856675,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 811,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 811,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 37.006445,
							["resource"] = 0.006445,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 37,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.006445,
							["total"] = 37.006445,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 12,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 12,
										},
										["counter"] = 6,
									},
									[14181] = {
										["total"] = 25,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856652,
							["alternatepower"] = 0.006445,
							["passiveover"] = 0.006445,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 811,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[57970] = {
										["activedamt"] = 0,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 6,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 25,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[32243] = {
										["activedamt"] = 1,
										["id"] = 32243,
										["targets"] = {
										},
										["actived_at"] = 1675856648,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[60233] = {
										["activedamt"] = 1,
										["id"] = 60233,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[60065] = {
										["activedamt"] = 1,
										["id"] = 60065,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 3,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[48666] = 2,
								[6774] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856653,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[40652] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-4457-571-155-29333-0000637F82",
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 811,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708829.598,
				["tempo_start"] = 1675856648,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 881,
				["playing_solo"] = true,
				["totals"] = {
					14244.991071, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 37,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:44:14",
				["hasTimer"] = 4,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 708811.3640000001,
				["CombatEndedAt"] = 708811.3640000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:44:09",
				["end_time"] = 708811.3640000001,
				["combat_id"] = 811,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 1,
				},
				["totals_grupo"] = {
					13453, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 37,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 13453.005134,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708806.498,
				["contra"] = "Onslaught Gryphon Rider",
				["TimeData"] = {
				},
			}, -- [5]
			{
				{
					["combatId"] = 810,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008253,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 25379,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 25379.008253,
							["end_time"] = 1675856623,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 25379.008253,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 11,
										["b_amt"] = 1,
										["c_dmg"] = 7575,
										["g_amt"] = 1,
										["n_max"] = 398,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 9711,
										},
										["n_dmg"] = 1797,
										["n_min"] = 307,
										["g_dmg"] = 339,
										["counter"] = 17,
										["ChartData"] = {
											[5] = 3726,
											[8] = 7901,
										},
										["total"] = 9711,
										["c_max"] = 731,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 613,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 307,
										["r_amt"] = 0,
									}, -- [1]
									[48665] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1825,
										["g_amt"] = 0,
										["n_max"] = 632,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2457,
										},
										["n_dmg"] = 632,
										["n_min"] = 632,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 632,
											[8] = 2457,
										},
										["total"] = 2457,
										["c_max"] = 1825,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1825,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[52874] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 810,
										["g_amt"] = 0,
										["n_max"] = 422,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1232,
										},
										["n_dmg"] = 422,
										["n_min"] = 422,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 1232,
											[8] = 1232,
										},
										["total"] = 1232,
										["c_max"] = 810,
										["id"] = 52874,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 810,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57965] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1287,
										["g_amt"] = 0,
										["n_max"] = 862,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 5388,
										},
										["n_dmg"] = 4101,
										["n_min"] = 763,
										["g_dmg"] = 0,
										["counter"] = 6,
										["ChartData"] = {
											[5] = 1684,
											[8] = 3338,
										},
										["total"] = 5388,
										["c_max"] = 1287,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1287,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3155,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3155,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 1344,
											[8] = 3155,
										},
										["total"] = 3155,
										["c_max"] = 1811,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1344,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57970] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1034,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2689,
										},
										["n_dmg"] = 2689,
										["n_min"] = 207,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[5] = 621,
											[8] = 1655,
										},
										["total"] = 2689,
										["c_max"] = 0,
										["id"] = 57970,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[51723] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 391,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 747,
										},
										["n_dmg"] = 747,
										["n_min"] = 356,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 747,
											[8] = 747,
										},
										["total"] = 747,
										["c_max"] = 0,
										["id"] = 51723,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 2242.754352511382,
							["custom"] = 0,
							["last_event"] = 1675856622,
							["damage_taken"] = 2496.008253,
							["start_time"] = 1675856614,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007419,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 2496,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-29333-0000637F88",
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["aID"] = "29333",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2496.007419,
							["fight_component"] = true,
							["end_time"] = 1675856623,
							["dps_started"] = false,
							["total"] = 2496.007419,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 410,
										["targets"] = {
											["Drushnak"] = 1446,
										},
										["n_dmg"] = 1446,
										["n_min"] = 303,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 1446,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 72,
										["targets"] = {
											["Drushnak"] = 72,
										},
										["n_dmg"] = 72,
										["n_min"] = 72,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 72,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[54617] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 978,
										["targets"] = {
											["Drushnak"] = 978,
										},
										["n_dmg"] = 978,
										["n_min"] = 978,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 978,
										["c_max"] = 0,
										["id"] = 54617,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 25379.007419,
							["start_time"] = 1675856612,
							["delay"] = 0,
							["last_event"] = 1675856621,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 810,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 810,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 28.003348,
							["resource"] = 0.003348,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 28,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.003348,
							["total"] = 28.003348,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 28,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 28,
										},
										["counter"] = 14,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856621,
							["alternatepower"] = 0.003348,
							["passiveover"] = 0.003348,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 810,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[57970] = {
										["activedamt"] = 0,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 2,
										["refreshamt"] = 15,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 41,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[55775] = {
										["activedamt"] = 1,
										["id"] = 55775,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 11,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 11,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 11,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[32243] = {
										["activedamt"] = 1,
										["id"] = 32243,
										["targets"] = {
										},
										["actived_at"] = 1675856612,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 8,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[51723] = 1,
								[6774] = 1,
								[48666] = 2,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856623,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[40652] = 1,
								[54617] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-4457-571-155-29333-0000637F88",
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 810,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708804.8640000001,
				["tempo_start"] = 1675856612,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 880,
				["playing_solo"] = true,
				["totals"] = {
					27874.986427, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 28,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:43:44",
				["hasTimer"] = 11,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 708780.98,
				["CombatEndedAt"] = 708780.98,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:43:32",
				["end_time"] = 708780.98,
				["combat_id"] = 810,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 2,
				},
				["totals_grupo"] = {
					25379, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 28,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 25379.008253,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708769.664,
				["contra"] = "Onslaught Gryphon Rider",
				["TimeData"] = {
				},
			}, -- [6]
			{
				{
					["combatId"] = 809,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008316,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Onslaught Gryphon Rider"] = 12970,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Onslaught Gryphon Rider"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 12970.008316,
							["end_time"] = 1675856601,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 12970.008316,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 1,
										["c_dmg"] = 2474,
										["g_amt"] = 1,
										["n_max"] = 457,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 4241,
										},
										["n_dmg"] = 1315,
										["n_min"] = 409,
										["g_dmg"] = 452,
										["counter"] = 7,
										["total"] = 4241,
										["c_max"] = 912,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 748,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 409,
										["r_amt"] = 0,
									}, -- [1]
									[57965] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1009,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 2823,
										},
										["n_dmg"] = 2823,
										["n_min"] = 806,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2823,
										["c_max"] = 0,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 855,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 1453,
										},
										["n_dmg"] = 1453,
										["n_min"] = 598,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1453,
										["c_max"] = 0,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57970] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 792,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 792,
										},
										["n_dmg"] = 792,
										["n_min"] = 792,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 792,
										["c_max"] = 0,
										["id"] = 57970,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48665] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3661,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 3661,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3661,
										["c_max"] = 2209,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1452,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 3242.502079,
							["custom"] = 0,
							["last_event"] = 1675856599,
							["damage_taken"] = 765.0083159999999,
							["start_time"] = 1675856595,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005632,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 765,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-29333-0000637F49",
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["aID"] = "29333",
							["raid_targets"] = {
							},
							["total_without_pet"] = 765.005632,
							["fight_component"] = true,
							["end_time"] = 1675856601,
							["dps_started"] = false,
							["total"] = 765.005632,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 367,
										["targets"] = {
											["Drushnak"] = 693,
										},
										["n_dmg"] = 693,
										["n_min"] = 326,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 693,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[40652] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 72,
										["targets"] = {
											["Drushnak"] = 72,
										},
										["n_dmg"] = 72,
										["n_min"] = 72,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 72,
										["c_max"] = 0,
										["id"] = 40652,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 12970.005632,
							["start_time"] = 1675856596,
							["delay"] = 0,
							["last_event"] = 1675856599,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 809,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 809,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 35.00601,
							["resource"] = 0.00601,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 35,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.00601,
							["total"] = 35.00601,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 10,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 10,
										},
										["counter"] = 5,
									},
									[14181] = {
										["total"] = 25,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856598,
							["alternatepower"] = 0.00601,
							["passiveover"] = 0.00601,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 809,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[57970] = {
										["activedamt"] = 0,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 6,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 38,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[55775] = {
										["activedamt"] = 1,
										["id"] = 55775,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[60065] = {
										["activedamt"] = 1,
										["id"] = 60065,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[60233] = {
										["activedamt"] = 1,
										["id"] = 60233,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[6774] = 1,
								[48666] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856601,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Onslaught Gryphon Rider",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[40652] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-4457-571-155-29333-0000637F49",
							["aID"] = "29333",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 809,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708768.03,
				["tempo_start"] = 1675856595,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 879,
				["playing_solo"] = true,
				["totals"] = {
					13735, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 35,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:43:21",
				["hasTimer"] = 5,
				["cleu_timeline"] = {
				},
				["enemy"] = "Onslaught Gryphon Rider",
				["TotalElapsedCombatTime"] = 708758.713,
				["CombatEndedAt"] = 708758.713,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:43:16",
				["end_time"] = 708758.713,
				["combat_id"] = 809,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Onslaught Gryphon Rider"] = 1,
				},
				["totals_grupo"] = {
					12970, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 35,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 12970.008316,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708753.1630000001,
				["contra"] = "Onslaught Gryphon Rider",
				["TimeData"] = {
				},
			}, -- [7]
			{
				{
					["combatId"] = 808,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.002517,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002517,
							["end_time"] = 1675856350,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 32760.002517,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Onslaught Gryphon Rider"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 32760.002517,
							["custom"] = 0,
							["last_event"] = 1675856595,
							["damage_taken"] = 0.002517,
							["start_time"] = 1675856349,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005859,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["pets"] = {
							},
							["end_time"] = 1675856350,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.005859,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 32760.005859,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856349,
							["damage_taken"] = 0.005859,
							["start_time"] = 1675856349,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001378,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001378,
							["fight_component"] = true,
							["end_time"] = 1675856350,
							["dps_started"] = false,
							["total"] = 0.001378,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389DA",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32760.001378,
							["start_time"] = 1675856350,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 808,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 808,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 808,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856350,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 808,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708752.197,
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					32759.987508, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856349,
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 32760.002517,
						}, -- [1]
					},
				},
				["end_time"] = 708508.443,
				["last_events_tables"] = {
				},
				["combat_id"] = 808,
				["combat_counter"] = 878,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:39:11",
				["data_inicio"] = "12:39:10",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake Rider"] = 1,
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708507.443,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [8]
			{
				{
					["combatId"] = 807,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006695,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006695,
							["end_time"] = 1675856349,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.006695,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 101633.9262550757,
							["custom"] = 0,
							["last_event"] = 1675856349,
							["damage_taken"] = 0.006695,
							["start_time"] = 1675856348,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.008386,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856349,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.008386,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.008386,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856349,
							["damage_taken"] = 0.008386,
							["start_time"] = 1675856348,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006144,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006144,
							["fight_component"] = true,
							["end_time"] = 1675856349,
							["dps_started"] = false,
							["total"] = 0.006144,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389DA",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.006144,
							["start_time"] = 1675856349,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 807,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 807,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 807,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856349,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 807,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856348,
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.006695,
						}, -- [1]
					},
				},
				["end_time"] = 708507.393,
				["last_events_tables"] = {
				},
				["combat_id"] = 807,
				["combat_counter"] = 877,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:39:10",
				["data_inicio"] = "12:39:09",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708506.392,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [9]
			{
				{
					["combatId"] = 806,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.007292,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007292,
							["end_time"] = 1675856348,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 65520.007292,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 358032.8268087686,
							["custom"] = 0,
							["last_event"] = 1675856347,
							["damage_taken"] = 0.007292,
							["start_time"] = 1675856347,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007748,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["pets"] = {
							},
							["end_time"] = 1675856348,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.007748,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 65520.007748,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856347,
							["damage_taken"] = 0.007748,
							["start_time"] = 1675856347,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006492,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006492,
							["fight_component"] = true,
							["end_time"] = 1675856348,
							["dps_started"] = false,
							["total"] = 0.006492,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389D6",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 65520.006492,
							["start_time"] = 1675856348,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 806,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 806,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 806,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856348,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 806,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856347,
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 65520.007292,
						}, -- [1]
					},
				},
				["end_time"] = 708505.976,
				["last_events_tables"] = {
				},
				["combat_id"] = 806,
				["combat_counter"] = 876,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:39:09",
				["data_inicio"] = "12:39:08",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708504.976,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [10]
			{
				{
					["combatId"] = 805,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.007725,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007725,
							["end_time"] = 1675856346,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 32760.007725,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 42711.87447890252,
							["custom"] = 0,
							["last_event"] = 1675856345,
							["damage_taken"] = 0.007725,
							["start_time"] = 1675856345,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002751,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["pets"] = {
							},
							["end_time"] = 1675856346,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.002751,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 32760.002751,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856345,
							["damage_taken"] = 0.002751,
							["start_time"] = 1675856345,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003021,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003021,
							["fight_component"] = true,
							["end_time"] = 1675856346,
							["dps_started"] = false,
							["total"] = 0.003021,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389D6",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32760.003021,
							["start_time"] = 1675856346,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 805,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 805,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 805,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856346,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 805,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					32759.985338, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856345,
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 32760.007725,
						}, -- [1]
					},
				},
				["end_time"] = 708503.792,
				["last_events_tables"] = {
				},
				["combat_id"] = 805,
				["combat_counter"] = 875,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:39:06",
				["data_inicio"] = "12:39:05",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake Rider"] = 1,
				},
				["start_time"] = 708502.792,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [11]
			{
				{
					["combatId"] = 804,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005123,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005123,
							["end_time"] = 1675856345,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 65520.005123,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 178528.624328302,
							["custom"] = 0,
							["last_event"] = 1675856344,
							["damage_taken"] = 0.005123,
							["start_time"] = 1675856344,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006444,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["pets"] = {
							},
							["end_time"] = 1675856345,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.006444,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 65520.006444,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856344,
							["damage_taken"] = 0.006444,
							["start_time"] = 1675856344,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007836,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007836,
							["fight_component"] = true,
							["end_time"] = 1675856345,
							["dps_started"] = false,
							["total"] = 0.007836,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389CF",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 65520.007836,
							["start_time"] = 1675856345,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 804,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 804,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 804,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856345,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 804,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856344,
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 65520.005123,
						}, -- [1]
					},
				},
				["end_time"] = 708502.5920000001,
				["last_events_tables"] = {
				},
				["combat_id"] = 804,
				["combat_counter"] = 874,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:39:05",
				["data_inicio"] = "12:39:04",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708501.5920000001,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [12]
			{
				{
					["combatId"] = 803,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.002574,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002574,
							["end_time"] = 1675856343,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 65520.002574,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 85535.25140822453,
							["custom"] = 0,
							["last_event"] = 1675856343,
							["damage_taken"] = 0.002574,
							["start_time"] = 1675856342,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.001036,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["pets"] = {
							},
							["end_time"] = 1675856343,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.001036,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 65520.001036,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856343,
							["damage_taken"] = 0.001036,
							["start_time"] = 1675856342,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00319,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00319,
							["fight_component"] = true,
							["end_time"] = 1675856343,
							["dps_started"] = false,
							["total"] = 0.00319,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389CF",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 65520.00319,
							["start_time"] = 1675856343,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 803,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 803,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 803,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856343,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 803,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					65519.98742999999, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856342,
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 65520.002574,
						}, -- [1]
					},
				},
				["end_time"] = 708501.376,
				["last_events_tables"] = {
				},
				["combat_id"] = 803,
				["combat_counter"] = 873,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:39:04",
				["data_inicio"] = "12:39:03",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake Rider"] = 1,
				},
				["start_time"] = 708500.376,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [13]
			{
				{
					["combatId"] = 802,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.003141,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003141,
							["end_time"] = 1675856340,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.003141,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 98280.003141,
							["custom"] = 0,
							["last_event"] = 1675856340,
							["damage_taken"] = 0.003141,
							["start_time"] = 1675856339,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005997,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856340,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.005997,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.005997,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856340,
							["damage_taken"] = 0.005997,
							["start_time"] = 1675856339,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00837,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00837,
							["fight_component"] = true,
							["end_time"] = 1675856340,
							["dps_started"] = false,
							["total"] = 0.00837,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389B7",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.00837,
							["start_time"] = 1675856340,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 802,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 802,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 802,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856340,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 802,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856339,
				["totals"] = {
					98279.991395, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.003141,
						}, -- [1]
					},
				},
				["end_time"] = 708498.3420000001,
				["combat_counter"] = 872,
				["combat_id"] = 802,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:39:01",
				["data_inicio"] = "12:39:00",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake Rider"] = 1,
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708497.3420000001,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [14]
			{
				{
					["combatId"] = 801,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008521,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008521,
							["end_time"] = 1675856339,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 32760.008521,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 179016.4399298474,
							["custom"] = 0,
							["last_event"] = 1675856338,
							["damage_taken"] = 0.008521,
							["start_time"] = 1675856338,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002796,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["pets"] = {
							},
							["end_time"] = 1675856339,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.002796,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 32760.002796,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856338,
							["damage_taken"] = 0.002796,
							["start_time"] = 1675856338,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008581,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008581,
							["fight_component"] = true,
							["end_time"] = 1675856339,
							["dps_started"] = false,
							["total"] = 0.008581,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389B7",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32760.008581,
							["start_time"] = 1675856339,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 801,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 801,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 801,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856339,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 801,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856338,
				["totals"] = {
					32760, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 32760.008521,
						}, -- [1]
					},
				},
				["end_time"] = 708497.159,
				["combat_counter"] = 871,
				["combat_id"] = 801,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:39:00",
				["data_inicio"] = "12:38:59",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708496.159,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [15]
			{
				{
					["combatId"] = 800,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.003495,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003495,
							["end_time"] = 1675856337,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 65520.003495,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 303333.3496564474,
							["custom"] = 0,
							["last_event"] = 1675856336,
							["damage_taken"] = 0.003495,
							["start_time"] = 1675856336,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006704,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["pets"] = {
							},
							["end_time"] = 1675856337,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.006704,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 65520.006704,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856336,
							["damage_taken"] = 0.006704,
							["start_time"] = 1675856336,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006495,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006495,
							["fight_component"] = true,
							["end_time"] = 1675856337,
							["dps_started"] = false,
							["total"] = 0.006495,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000E37D71",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 65520.006495,
							["start_time"] = 1675856337,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 800,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 800,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 800,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856337,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 800,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856336,
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 65520.003495,
						}, -- [1]
					},
				},
				["end_time"] = 708494.5260000001,
				["combat_counter"] = 870,
				["combat_id"] = 800,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:57",
				["data_inicio"] = "12:38:56",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 2,
				},
				["start_time"] = 708493.5260000001,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [16]
			{
				{
					["combatId"] = 799,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005171,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005171,
							["end_time"] = 1675856334,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 65520.005171,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 145600.011468511,
							["custom"] = 0,
							["last_event"] = 1675856333,
							["damage_taken"] = 0.005171,
							["start_time"] = 1675856332,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002064,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["pets"] = {
							},
							["end_time"] = 1675856334,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.002064,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 65520.002064,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856333,
							["damage_taken"] = 0.002064,
							["start_time"] = 1675856332,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008528,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008528,
							["fight_component"] = true,
							["end_time"] = 1675856334,
							["dps_started"] = false,
							["total"] = 0.008528,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D71",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 65520.008528,
							["start_time"] = 1675856334,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 799,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 799,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 799,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 6,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856334,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 799,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856332,
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 65520.005171,
						}, -- [1]
					},
				},
				["end_time"] = 708491.492,
				["last_events_tables"] = {
				},
				["combat_id"] = 799,
				["combat_counter"] = 869,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:54",
				["data_inicio"] = "12:38:53",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708490.492,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [17]
			{
				{
					["combatId"] = 798,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.007917,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007917,
							["end_time"] = 1675856332,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 65520.007917,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 246315.8192877239,
							["custom"] = 0,
							["last_event"] = 1675856332,
							["damage_taken"] = 0.007917,
							["start_time"] = 1675856331,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005072,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["pets"] = {
							},
							["end_time"] = 1675856332,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.005072,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 65520.005072,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856332,
							["damage_taken"] = 0.005072,
							["start_time"] = 1675856331,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00834,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00834,
							["fight_component"] = true,
							["end_time"] = 1675856332,
							["dps_started"] = false,
							["total"] = 0.00834,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D71",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 65520.00834,
							["start_time"] = 1675856332,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 798,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 798,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 798,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856332,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 798,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856331,
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 65520.007917,
						}, -- [1]
					},
				},
				["end_time"] = 708490.476,
				["last_events_tables"] = {
				},
				["combat_id"] = 798,
				["combat_counter"] = 868,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:53",
				["data_inicio"] = "12:38:52",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708489.476,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [18]
			{
				{
					["combatId"] = 797,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006133,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006133,
							["end_time"] = 1675856329,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 32760.006133,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 32760.006133,
							["custom"] = 0,
							["last_event"] = 1675856328,
							["damage_taken"] = 0.006133,
							["start_time"] = 1675856328,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005095,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["pets"] = {
							},
							["end_time"] = 1675856329,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.005095,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 32760.005095,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856328,
							["damage_taken"] = 0.005095,
							["start_time"] = 1675856328,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004037,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004037,
							["fight_component"] = true,
							["end_time"] = 1675856329,
							["dps_started"] = false,
							["total"] = 0.004037,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D5F",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32760.004037,
							["start_time"] = 1675856329,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 797,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 797,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 797,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856329,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 797,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856328,
				["totals"] = {
					32759.991886, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 32760.006133,
						}, -- [1]
					},
				},
				["end_time"] = 708486.609,
				["combat_counter"] = 867,
				["combat_id"] = 797,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:49",
				["data_inicio"] = "12:38:48",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708485.609,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [19]
			{
				{
					["combatId"] = 796,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.002146,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002146,
							["end_time"] = 1675856325,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 131040.002146,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 131040.002146,
							["custom"] = 0,
							["last_event"] = 1675856325,
							["damage_taken"] = 0.002146,
							["start_time"] = 1675856324,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.003915,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["pets"] = {
							},
							["end_time"] = 1675856325,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 131040.003915,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 131040.003915,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 131040,
										},
										["n_dmg"] = 131040,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 131040,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856325,
							["damage_taken"] = 0.003915,
							["start_time"] = 1675856324,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003428,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003428,
							["fight_component"] = true,
							["end_time"] = 1675856325,
							["dps_started"] = false,
							["total"] = 0.003428,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389C0",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 131040.003428,
							["start_time"] = 1675856325,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 796,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 796,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 796,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856325,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 796,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856324,
				["totals"] = {
					131040, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 131040.002146,
						}, -- [1]
					},
				},
				["end_time"] = 708482.775,
				["combat_counter"] = 866,
				["combat_id"] = 796,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:45",
				["data_inicio"] = "12:38:44",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708481.775,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [20]
			{
				{
					["combatId"] = 795,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005114,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005114,
							["end_time"] = 1675856320,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.005114,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 203478.2714544182,
							["custom"] = 0,
							["last_event"] = 1675856319,
							["damage_taken"] = 0.005114,
							["start_time"] = 1675856319,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002502,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856320,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.002502,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.002502,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856319,
							["damage_taken"] = 0.002502,
							["start_time"] = 1675856319,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005951,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005951,
							["fight_component"] = true,
							["end_time"] = 1675856320,
							["dps_started"] = false,
							["total"] = 0.005951,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389BE",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.005951,
							["start_time"] = 1675856320,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 795,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 795,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 795,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856320,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 795,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856319,
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.005114,
						}, -- [1]
					},
				},
				["end_time"] = 708478.042,
				["last_events_tables"] = {
				},
				["combat_id"] = 795,
				["combat_counter"] = 865,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:41",
				["data_inicio"] = "12:38:40",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708477.042,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [21]
			{
				{
					["combatId"] = 794,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.007949,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007949,
							["end_time"] = 1675856317,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 32760.007949,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 32760.007949,
							["custom"] = 0,
							["last_event"] = 1675856316,
							["damage_taken"] = 0.007949,
							["start_time"] = 1675856316,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.003076,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["pets"] = {
							},
							["end_time"] = 1675856317,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.003076,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 32760.003076,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856316,
							["damage_taken"] = 0.003076,
							["start_time"] = 1675856316,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005828,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005828,
							["fight_component"] = true,
							["end_time"] = 1675856317,
							["dps_started"] = false,
							["total"] = 0.005828,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389B9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32760.005828,
							["start_time"] = 1675856317,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 794,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 794,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 794,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856317,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 794,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856316,
				["totals"] = {
					32759.986512, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 32760.007949,
						}, -- [1]
					},
				},
				["end_time"] = 708474.5750000001,
				["combat_counter"] = 864,
				["combat_id"] = 794,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:37",
				["data_inicio"] = "12:38:36",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake Rider"] = 1,
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708473.5750000001,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [22]
			{
				{
					["combatId"] = 793,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008224,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008224,
							["end_time"] = 1675856316,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.008224,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 128302.88278866,
							["custom"] = 0,
							["last_event"] = 1675856315,
							["damage_taken"] = 0.008224,
							["start_time"] = 1675856315,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005134,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856316,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.005134,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.005134,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856315,
							["damage_taken"] = 0.005134,
							["start_time"] = 1675856315,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005018,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005018,
							["fight_component"] = true,
							["end_time"] = 1675856316,
							["dps_started"] = false,
							["total"] = 0.005018,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-00006389B9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.005018,
							["start_time"] = 1675856316,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 793,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 793,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 793,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856316,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 793,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856315,
				["totals"] = {
					98279.99249199999, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.008224,
						}, -- [1]
					},
				},
				["end_time"] = 708473.559,
				["combat_counter"] = 863,
				["combat_id"] = 793,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:36",
				["data_inicio"] = "12:38:35",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake Rider"] = 1,
				},
				["start_time"] = 708472.559,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [23]
			{
				{
					["combatId"] = 792,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008289,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["colocacao"] = 1,
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008289,
							["spec"] = 259,
							["end_time"] = 1675856312,
							["dps_started"] = false,
							["total"] = 32760.008289,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["friendlyfire"] = {
							},
							["on_hold"] = false,
							["last_dps"] = 32760.008289,
							["custom"] = 0,
							["last_event"] = 1675856311,
							["damage_taken"] = 0.008289,
							["start_time"] = 1675856311,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.008665,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["pets"] = {
							},
							["end_time"] = 1675856312,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.008665,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 32760.008665,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856311,
							["damage_taken"] = 0.008665,
							["start_time"] = 1675856311,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004397,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004397,
							["fight_component"] = true,
							["end_time"] = 1675856312,
							["dps_started"] = false,
							["total"] = 0.004397,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D58",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32760.004397,
							["start_time"] = 1675856312,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 792,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 792,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 792,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "Drushnak",
							["buff_uptime_targets"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["spec"] = 259,
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856312,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 792,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					32759.988054, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856311,
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 32760.008289,
						}, -- [1]
					},
				},
				["end_time"] = 708469.908,
				["last_events_tables"] = {
				},
				["combat_id"] = 792,
				["combat_counter"] = 862,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:33",
				["data_inicio"] = "12:38:32",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708468.908,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [24]
			{
				{
					["combatId"] = 791,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008662,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["colocacao"] = 1,
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008662,
							["spec"] = 259,
							["end_time"] = 1675856311,
							["dps_started"] = false,
							["total"] = 98280.00866200001,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["friendlyfire"] = {
							},
							["on_hold"] = false,
							["last_dps"] = 207341.7995687909,
							["custom"] = 0,
							["last_event"] = 1675856311,
							["damage_taken"] = 0.008662,
							["start_time"] = 1675856310,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006294,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856311,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.00629399999,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.00629399999,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856311,
							["damage_taken"] = 0.006294,
							["start_time"] = 1675856310,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004331,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004331,
							["fight_component"] = true,
							["end_time"] = 1675856311,
							["dps_started"] = false,
							["total"] = 0.004331,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D58",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.004331,
							["start_time"] = 1675856311,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 791,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 791,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 791,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 3,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["need_refresh"] = true,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856311,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 791,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856310,
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.00866200001,
						}, -- [1]
					},
				},
				["end_time"] = 708468.809,
				["last_events_tables"] = {
				},
				["combat_id"] = 791,
				["combat_counter"] = 861,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:31",
				["data_inicio"] = "12:38:30",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708467.809,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [25]
			{
				{
					["combatId"] = 790,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.002363,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002363,
							["end_time"] = 1675856309,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 131040.002363,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 131040.002363,
							["custom"] = 0,
							["last_event"] = 1675856309,
							["damage_taken"] = 0.002363,
							["start_time"] = 1675856308,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.004763,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 131040,
							},
							["pets"] = {
							},
							["end_time"] = 1675856309,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 131040.004763,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 131040.004763,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 131040,
										},
										["n_dmg"] = 131040,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 131040,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856309,
							["damage_taken"] = 0.004763,
							["start_time"] = 1675856308,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001047,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001047,
							["fight_component"] = true,
							["end_time"] = 1675856309,
							["dps_started"] = false,
							["total"] = 0.001047,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637CFE",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 131040.001047,
							["start_time"] = 1675856309,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 790,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 790,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 790,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856309,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 790,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856308,
				["totals"] = {
					131040, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 131040.002363,
						}, -- [1]
					},
				},
				["end_time"] = 708467.142,
				["combat_counter"] = 860,
				["combat_id"] = 790,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:30",
				["data_inicio"] = "12:38:29",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708466.142,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [26]
			{
				{
					["combatId"] = 789,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005565,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005565,
							["end_time"] = 1675856307,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 32760.005565,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 327600.05565,
							["custom"] = 0,
							["last_event"] = 1675856306,
							["damage_taken"] = 0.005565,
							["start_time"] = 1675856306,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002342,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["pets"] = {
							},
							["end_time"] = 1675856307,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.002342,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 32760.002342,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856306,
							["damage_taken"] = 0.002342,
							["start_time"] = 1675856306,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007482,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007482,
							["fight_component"] = true,
							["end_time"] = 1675856307,
							["dps_started"] = false,
							["total"] = 0.007482,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D03",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32760.007482,
							["start_time"] = 1675856307,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 789,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 789,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 789,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856307,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 789,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856306,
				["totals"] = {
					32760, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 32760.005565,
						}, -- [1]
					},
				},
				["end_time"] = 708465.258,
				["combat_counter"] = 859,
				["combat_id"] = 789,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:28",
				["data_inicio"] = "12:38:27",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708464.258,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [27]
			{
				{
					["combatId"] = 788,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.007007,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007007,
							["end_time"] = 1675856304,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.00700700001,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 98280.00700700001,
							["custom"] = 0,
							["last_event"] = 1675856304,
							["damage_taken"] = 0.007007,
							["start_time"] = 1675856303,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007492,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856304,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.007492,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.007492,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856304,
							["damage_taken"] = 0.007492,
							["start_time"] = 1675856303,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003417,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003417,
							["fight_component"] = true,
							["end_time"] = 1675856304,
							["dps_started"] = false,
							["total"] = 0.003417,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D03",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.003417,
							["start_time"] = 1675856304,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 788,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 788,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 788,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856304,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 788,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856303,
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.00700700001,
						}, -- [1]
					},
				},
				["end_time"] = 708462.192,
				["last_events_tables"] = {
				},
				["combat_id"] = 788,
				["combat_counter"] = 858,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:25",
				["data_inicio"] = "12:38:24",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708461.192,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [28]
			{
				{
					["combatId"] = 787,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.007733,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007733,
							["end_time"] = 1675856300,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.007733,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 98280.007733,
							["custom"] = 0,
							["last_event"] = 1675856300,
							["damage_taken"] = 0.007733,
							["start_time"] = 1675856299,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002066,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856300,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.002066,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.002066,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856300,
							["damage_taken"] = 0.002066,
							["start_time"] = 1675856299,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005519,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005519,
							["fight_component"] = true,
							["end_time"] = 1675856300,
							["dps_started"] = false,
							["total"] = 0.005519,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000E37D71",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.005519,
							["start_time"] = 1675856300,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 787,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 787,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 787,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856300,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 787,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856299,
				["totals"] = {
					98279.988775, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.007733,
						}, -- [1]
					},
				},
				["end_time"] = 708458.408,
				["combat_counter"] = 857,
				["combat_id"] = 787,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:21",
				["data_inicio"] = "12:38:20",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708457.408,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [29]
			{
				{
					["combatId"] = 786,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008232,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008232,
							["end_time"] = 1675856299,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 32760.008232,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 282413.8642594271,
							["custom"] = 0,
							["last_event"] = 1675856298,
							["damage_taken"] = 0.008232,
							["start_time"] = 1675856298,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007271,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["pets"] = {
							},
							["end_time"] = 1675856299,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.007271,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 32760.007271,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856298,
							["damage_taken"] = 0.007271,
							["start_time"] = 1675856298,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007168,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007168,
							["fight_component"] = true,
							["end_time"] = 1675856299,
							["dps_started"] = false,
							["total"] = 0.007168,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D74",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32760.007168,
							["start_time"] = 1675856299,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 786,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 786,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 786,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856299,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 786,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					32760, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856298,
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 32760.008232,
						}, -- [1]
					},
				},
				["end_time"] = 708456.5920000001,
				["last_events_tables"] = {
				},
				["combat_id"] = 786,
				["combat_counter"] = 856,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:19",
				["data_inicio"] = "12:38:18",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708455.5920000001,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [30]
			{
				{
					["combatId"] = 785,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.00391,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00391,
							["end_time"] = 1675856297,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 65520.00391,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 72800.00434256111,
							["custom"] = 0,
							["last_event"] = 1675856297,
							["damage_taken"] = 0.00391,
							["start_time"] = 1675856296,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.00177,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 65520,
							},
							["pets"] = {
							},
							["end_time"] = 1675856297,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65520.00177,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 65520.00177,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 65520,
										},
										["n_dmg"] = 65520,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 65520,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856297,
							["damage_taken"] = 0.00177,
							["start_time"] = 1675856296,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005809,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005809,
							["fight_component"] = true,
							["end_time"] = 1675856297,
							["dps_started"] = false,
							["total"] = 0.005809,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D86",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 65520.005809,
							["start_time"] = 1675856297,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 785,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 785,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 785,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856297,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 785,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856296,
				["totals"] = {
					65520, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 65520.00391,
						}, -- [1]
					},
				},
				["end_time"] = 708455.008,
				["combat_counter"] = 855,
				["combat_id"] = 785,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:18",
				["data_inicio"] = "12:38:17",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708454.008,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [31]
			{
				{
					["combatId"] = 784,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004627,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004627,
							["end_time"] = 1675856296,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.004627,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 178690.9174885074,
							["custom"] = 0,
							["last_event"] = 1675856295,
							["damage_taken"] = 0.004627,
							["start_time"] = 1675856295,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002329,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856296,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.002329,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.002329,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856295,
							["damage_taken"] = 0.002329,
							["start_time"] = 1675856295,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00794,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00794,
							["fight_component"] = true,
							["end_time"] = 1675856296,
							["dps_started"] = false,
							["total"] = 0.00794,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D52",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.00794,
							["start_time"] = 1675856296,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 784,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 784,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 784,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856296,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 784,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856295,
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.004627,
						}, -- [1]
					},
				},
				["end_time"] = 708453.958,
				["combat_counter"] = 854,
				["combat_id"] = 784,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:17",
				["data_inicio"] = "12:38:16",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708452.958,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [32]
			{
				{
					["combatId"] = 783,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008792,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008792,
							["end_time"] = 1675856295,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.00879200001,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 98280.00879200001,
							["custom"] = 0,
							["last_event"] = 1675856295,
							["damage_taken"] = 0.008792,
							["start_time"] = 1675856294,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006513,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856295,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.006513,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.006513,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856295,
							["damage_taken"] = 0.006513,
							["start_time"] = 1675856294,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001573,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001573,
							["fight_component"] = true,
							["end_time"] = 1675856295,
							["dps_started"] = false,
							["total"] = 0.001573,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D52",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.001573,
							["start_time"] = 1675856295,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 783,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 783,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 783,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856295,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 783,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856294,
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.00879200001,
						}, -- [1]
					},
				},
				["end_time"] = 708452.675,
				["last_events_tables"] = {
				},
				["combat_id"] = 783,
				["combat_counter"] = 853,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:15",
				["data_inicio"] = "12:38:14",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708451.675,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [33]
			{
				{
					["combatId"] = 782,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006745,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006745,
							["end_time"] = 1675856291,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.00674499999,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 98280.00674499999,
							["custom"] = 0,
							["last_event"] = 1675856291,
							["damage_taken"] = 0.006745,
							["start_time"] = 1675856290,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006979,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856291,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.006979,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.006979,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856291,
							["damage_taken"] = 0.006979,
							["start_time"] = 1675856290,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002383,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002383,
							["fight_component"] = true,
							["end_time"] = 1675856291,
							["dps_started"] = false,
							["total"] = 0.002383,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D74",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.002383,
							["start_time"] = 1675856291,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 782,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 782,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 782,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856291,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 782,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					98279.993054, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["tempo_start"] = 1675856290,
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.00674499999,
						}, -- [1]
					},
				},
				["end_time"] = 708448.808,
				["last_events_tables"] = {
				},
				["combat_id"] = 782,
				["combat_counter"] = 852,
				["player_last_events"] = {
				},
				["instance_type"] = "none",
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:11",
				["data_inicio"] = "12:38:10",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708447.808,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [34]
			{
				{
					["combatId"] = 781,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005165,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005165,
							["end_time"] = 1675856288,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 32760.005165,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 327600.05165,
							["custom"] = 0,
							["last_event"] = 1675856286,
							["damage_taken"] = 0.005165,
							["start_time"] = 1675856286,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.002138,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 32760,
							},
							["pets"] = {
							},
							["end_time"] = 1675856288,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 32760.002138,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 32760.002138,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 32760,
										},
										["n_dmg"] = 32760,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32760,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856286,
							["damage_taken"] = 0.002138,
							["start_time"] = 1675856286,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007714,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007714,
							["fight_component"] = true,
							["end_time"] = 1675856288,
							["dps_started"] = false,
							["total"] = 0.007714,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D7B",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32760.007714,
							["start_time"] = 1675856288,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 781,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 781,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 781,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 6,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856288,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 781,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856286,
				["totals"] = {
					32760, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 32760.005165,
						}, -- [1]
					},
				},
				["end_time"] = 708445.508,
				["combat_counter"] = 851,
				["combat_id"] = 781,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1.016000000061467,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:08",
				["data_inicio"] = "12:38:07",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["Jotunheim Proto-Drake"] = 1,
				},
				["start_time"] = 708444.492,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [35]
			{
				{
					["combatId"] = 780,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004582,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
								"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [1]
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004582,
							["end_time"] = 1675856286,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 98280.004582,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 226974.6064454463,
							["custom"] = 0,
							["last_event"] = 1675856286,
							["damage_taken"] = 0.004582,
							["start_time"] = 1675856285,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.001547,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Jotunheim Proto-Drake"] = 98280,
							},
							["pets"] = {
							},
							["end_time"] = 1675856286,
							["damage_from"] = {
							},
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 98280.00154699999,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 98280.00154699999,
							["aID"] = "",
							["ownerName"] = "Drushnak",
							["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[56578] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32760,
										["targets"] = {
											["Jotunheim Proto-Drake"] = 98280,
										},
										["n_dmg"] = 98280,
										["n_min"] = 32760,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 98280,
										["c_max"] = 0,
										["id"] = 56578,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30337-0000637CD9",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675856286,
							["damage_taken"] = 0.001547,
							["start_time"] = 1675856285,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001845,
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["aID"] = "",
							["damage_from"] = {
								["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001845,
							["fight_component"] = true,
							["end_time"] = 1675856286,
							["dps_started"] = false,
							["total"] = 0.001845,
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["nome"] = "Jotunheim Proto-Drake",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["serial"] = "Vehicle-0-4457-571-155-30330-0000637D7B",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 98280.00184499999,
							["start_time"] = 1675856286,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 780,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 780,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 780,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["spec"] = 259,
							["nome"] = "Drushnak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 3,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4477-04D9C2D1",
							["last_event"] = 1675856286,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 780,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "Jotunheim Proto-Drake",
				["cleu_events"] = {
					["n"] = 1,
				},
				["tempo_start"] = 1675856285,
				["totals"] = {
					98280, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 98280.004582,
						}, -- [1]
					},
				},
				["end_time"] = 708444.258,
				["combat_counter"] = 850,
				["combat_id"] = 780,
				["instance_type"] = "none",
				["player_last_events"] = {
				},
				["hasTimer"] = 1,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "12:38:07",
				["data_inicio"] = "12:38:06",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 708443.258,
				["TimeData"] = {
				},
				["contra"] = "Jotunheim Proto-Drake",
			}, -- [36]
			{
				{
					["combatId"] = 779,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003275,
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["targets"] = {
								["Mjordin Combatant"] = 28271,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 28271.003275,
							["end_time"] = 1675856251,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 28271.003275,
							["friendlyfire_total"] = 0,
							["aID"] = "4477-04D9C2D1",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 6,
										["b_amt"] = 1,
										["c_dmg"] = 4632,
										["g_amt"] = 0,
										["n_max"] = 450,
										["targets"] = {
											["Mjordin Combatant"] = 9288,
										},
										["n_dmg"] = 4656,
										["n_min"] = 336,
										["g_dmg"] = 0,
										["counter"] = 21,
										["ChartData"] = {
											[11] = 6602,
											[6] = 4890,
											[9] = 5310,
											[14] = 9288,
										},
										["total"] = 9288,
										["c_max"] = 874,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 665,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 12,
										["b_dmg"] = 336,
										["r_amt"] = 0,
									}, -- [1]
									[48665] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1384,
										["g_amt"] = 0,
										["n_max"] = 757,
										["targets"] = {
											["Mjordin Combatant"] = 2799,
										},
										["n_dmg"] = 1415,
										["n_min"] = 658,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[11] = 2141,
											[6] = 1384,
											[9] = 1384,
											[14] = 2799,
										},
										["total"] = 2799,
										["c_max"] = 1384,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1384,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3077,
										["g_amt"] = 0,
										["n_max"] = 674,
										["targets"] = {
											["Mjordin Combatant"] = 3751,
										},
										["n_dmg"] = 674,
										["n_min"] = 674,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[11] = 3077,
											[6] = 1437,
											[9] = 1437,
											[14] = 3751,
										},
										["total"] = 3751,
										["c_max"] = 1640,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1437,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57993] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 5487,
										["g_amt"] = 0,
										["n_max"] = 2356,
										["targets"] = {
											["Mjordin Combatant"] = 8643,
										},
										["n_dmg"] = 3156,
										["n_min"] = 800,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[11] = 3156,
											[6] = 2356,
											[9] = 3156,
											[14] = 3156,
										},
										["total"] = 8643,
										["c_max"] = 5487,
										["id"] = 57993,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 5487,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57965] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 987,
										["targets"] = {
											["Mjordin Combatant"] = 3790,
										},
										["n_dmg"] = 3790,
										["n_min"] = 909,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[11] = 2881,
											[6] = 985,
											[9] = 985,
											[14] = 3790,
										},
										["total"] = 3790,
										["c_max"] = 0,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 1794.984334920635,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1357.003275,
							["start_time"] = 1675856235,
							["delay"] = 0,
							["last_event"] = 1675856250,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004907,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 1357,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-30037-0000E3798F",
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["aID"] = "30037",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1357.004907,
							["fight_component"] = true,
							["end_time"] = 1675856251,
							["dps_started"] = false,
							["total"] = 1357.004907,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 395,
										["targets"] = {
											["Drushnak"] = 1357,
										},
										["n_dmg"] = 1357,
										["n_min"] = 300,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1357,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 28271.004907,
							["start_time"] = 1675856239,
							["delay"] = 0,
							["last_event"] = 1675856250,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 779,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 779,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 70.003634,
							["resource"] = 0.003634,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 70,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.003634,
							["total"] = 70.003634,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 20,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 20,
										},
										["counter"] = 10,
									},
									[14181] = {
										["total"] = 50,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 50,
										},
										["counter"] = 2,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856250,
							["alternatepower"] = 0.003634,
							["passiveover"] = 0.003634,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 779,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1833] = {
										["activedamt"] = -1,
										["id"] = 1833,
										["targets"] = {
										},
										["actived_at"] = 1675856239,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57970] = {
										["activedamt"] = 0,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 2,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
									[51724] = {
										["activedamt"] = -1,
										["id"] = 51724,
										["targets"] = {
										},
										["actived_at"] = 1675856246,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 98,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[60233] = {
										["activedamt"] = 1,
										["id"] = 60233,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57993] = {
										["activedamt"] = 2,
										["id"] = 57993,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 2,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[58427] = {
										["activedamt"] = 1,
										["id"] = 58427,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[60065] = {
										["activedamt"] = 1,
										["id"] = 60065,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[6774] = 1,
								[48666] = 3,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856251,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 779,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["tempo_start"] = 1675856235,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 849,
				["playing_solo"] = true,
				["totals"] = {
					29628, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 70,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:37:31",
				["hasTimer"] = 15,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 708408.691,
				["CombatEndedAt"] = 708408.691,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:37:16",
				["end_time"] = 708408.691,
				["combat_id"] = 779,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["totals_grupo"] = {
					28271, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 70,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 28271.003275,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708392.941,
				["contra"] = "Mjordin Combatant",
				["TimeData"] = {
				},
			}, -- [37]
			{
				{
					["combatId"] = 778,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00493,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Mjordin Combatant"] = 27640,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 27640.00493,
							["end_time"] = 1675856209,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 27640.00493,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 3752,
										["g_amt"] = 1,
										["n_max"] = 441,
										["targets"] = {
											["Mjordin Combatant"] = 7203,
										},
										["n_dmg"] = 3095,
										["n_min"] = 356,
										["g_dmg"] = 356,
										["counter"] = 17,
										["ChartData"] = {
											[8] = 3714,
											[12] = 5314,
											[5] = 3714,
										},
										["total"] = 7203,
										["c_max"] = 800,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 720,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[48665] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 5330,
										["g_amt"] = 0,
										["n_max"] = 842,
										["targets"] = {
											["Mjordin Combatant"] = 6172,
										},
										["n_dmg"] = 842,
										["n_min"] = 842,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[8] = 3806,
											[12] = 6172,
											[5] = 3806,
										},
										["total"] = 6172,
										["c_max"] = 1964,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1524,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57970] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 922,
										["targets"] = {
											["Mjordin Combatant"] = 922,
										},
										["n_dmg"] = 922,
										["n_min"] = 922,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[8] = 922,
											[12] = 922,
											[5] = 922,
										},
										["total"] = 922,
										["c_max"] = 0,
										["id"] = 57970,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57965] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1271,
										["g_amt"] = 0,
										["n_max"] = 921,
										["targets"] = {
											["Mjordin Combatant"] = 2192,
										},
										["n_dmg"] = 921,
										["n_min"] = 921,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[8] = 2192,
											[12] = 2192,
											[5] = 2192,
										},
										["total"] = 2192,
										["c_max"] = 1271,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1271,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 1823,
										["g_amt"] = 0,
										["n_max"] = 793,
										["targets"] = {
											["Mjordin Combatant"] = 4065,
										},
										["n_dmg"] = 2242,
										["n_min"] = 671,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[8] = 2616,
											[12] = 4065,
											[5] = 2616,
										},
										["total"] = 4065,
										["c_max"] = 1823,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1823,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 778,
										["r_amt"] = 0,
									},
									[57993] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 7086,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Mjordin Combatant"] = 7086,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 7086,
										["c_max"] = 7086,
										["id"] = 57993,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 7086,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 1930.572391557204,
							["custom"] = 0,
							["last_event"] = 1675856208,
							["damage_taken"] = 404.00493,
							["start_time"] = 1675856194,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008602,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 404,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-30037-0000637DCA",
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["aID"] = "30037",
							["raid_targets"] = {
							},
							["total_without_pet"] = 404.008602,
							["fight_component"] = true,
							["end_time"] = 1675856209,
							["dps_started"] = false,
							["total"] = 404.008602,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 404,
										["targets"] = {
											["Drushnak"] = 404,
										},
										["n_dmg"] = 404,
										["n_min"] = 404,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 404,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["PARRY"] = 2,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[50370] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Drushnak"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 50370,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["extra"] = {
										},
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 27640.008602,
							["start_time"] = 1675856199,
							["delay"] = 0,
							["last_event"] = 1675856208,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 778,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 778,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 70.00655,
							["resource"] = 0.00655,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 70,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.00655,
							["total"] = 70.00655,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 20,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 20,
										},
										["counter"] = 10,
									},
									[14181] = {
										["total"] = 50,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 50,
										},
										["counter"] = 2,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856208,
							["alternatepower"] = 0.00655,
							["passiveover"] = 0.00655,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 778,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1833] = {
										["activedamt"] = -1,
										["id"] = 1833,
										["targets"] = {
										},
										["actived_at"] = 1675856198,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57970] = {
										["activedamt"] = -1,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 14,
										["actived"] = false,
										["counter"] = 0,
									},
									[51724] = {
										["activedamt"] = -1,
										["id"] = 51724,
										["targets"] = {
										},
										["actived_at"] = 1675856205,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 101,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[55775] = {
										["activedamt"] = 1,
										["id"] = 55775,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57993] = {
										["activedamt"] = 1,
										["id"] = 57993,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[58427] = {
										["activedamt"] = 1,
										["id"] = 58427,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[60233] = {
										["activedamt"] = 1,
										["id"] = 60233,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 15,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[48666] = 4,
								[6774] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856209,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Mjordin Combatant",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[50370] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-4457-571-155-30037-0000637D66",
							["aID"] = "30037",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 778,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708392.774,
				["tempo_start"] = 1675856194,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 848,
				["playing_solo"] = true,
				["totals"] = {
					28044, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 70,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:36:49",
				["hasTimer"] = 14,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 708366.54,
				["CombatEndedAt"] = 708366.54,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:36:35",
				["end_time"] = 708366.54,
				["combat_id"] = 778,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["totals_grupo"] = {
					27640, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 70,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 27640.00493,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708352.223,
				["contra"] = "Mjordin Combatant",
				["TimeData"] = {
				},
			}, -- [38]
			{
				{
					["combatId"] = 777,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006563,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Mjordin Combatant"] = 26409,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 26409.006563,
							["end_time"] = 1675856154,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 26409.006563,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 2800,
										["g_amt"] = 0,
										["n_max"] = 395,
										["targets"] = {
											["Mjordin Combatant"] = 6069,
										},
										["n_dmg"] = 3269,
										["n_min"] = 324,
										["g_dmg"] = 0,
										["counter"] = 14,
										["ChartData"] = {
											[5] = 3124,
											[9] = 5329,
										},
										["total"] = 6069,
										["c_max"] = 748,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 652,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[48665] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3370,
										["g_amt"] = 0,
										["n_max"] = 645,
										["targets"] = {
											["Mjordin Combatant"] = 4015,
										},
										["n_dmg"] = 645,
										["n_min"] = 645,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[5] = 1697,
											[9] = 4015,
										},
										["total"] = 4015,
										["c_max"] = 1697,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1673,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3250,
										["g_amt"] = 0,
										["n_max"] = 798,
										["targets"] = {
											["Mjordin Combatant"] = 4048,
										},
										["n_dmg"] = 798,
										["n_min"] = 798,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[5] = 798,
											[9] = 4048,
										},
										["total"] = 4048,
										["c_max"] = 1699,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1551,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57993] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 6823,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Mjordin Combatant"] = 6823,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[5] = 6823,
											[9] = 6823,
										},
										["total"] = 6823,
										["c_max"] = 6823,
										["id"] = 57993,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 6823,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57965] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1245,
										["g_amt"] = 0,
										["n_max"] = 876,
										["targets"] = {
											["Mjordin Combatant"] = 5454,
										},
										["n_dmg"] = 4209,
										["n_min"] = 824,
										["g_dmg"] = 0,
										["counter"] = 6,
										["ChartData"] = {
											[5] = 1700,
											[9] = 4209,
										},
										["total"] = 5454,
										["c_max"] = 1245,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1245,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 2296.235680626983,
							["custom"] = 0,
							["last_event"] = 1675856152,
							["damage_taken"] = 0.006563,
							["start_time"] = 1675856142,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002503,
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-30037-0000637DB5",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "30037",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002503,
							["end_time"] = 1675856154,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.002503,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Drushnak"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[61227] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Drushnak"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 61227,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 26409.002503,
							["start_time"] = 1675856154,
							["delay"] = 0,
							["last_event"] = 1675856151,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 777,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 777,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 43.006882,
							["resource"] = 0.006882,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 43,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.006882,
							["total"] = 43.006882,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 18,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 18,
										},
										["counter"] = 9,
									},
									[14181] = {
										["total"] = 25,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856151,
							["alternatepower"] = 0.006882,
							["passiveover"] = 0.006882,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 777,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1833] = {
										["activedamt"] = -1,
										["id"] = 1833,
										["targets"] = {
										},
										["actived_at"] = 1675856145,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57970] = {
										["activedamt"] = 0,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 2,
										["refreshamt"] = 16,
										["actived"] = false,
										["counter"] = 0,
									},
									[51724] = {
										["activedamt"] = -1,
										["id"] = 51724,
										["targets"] = {
										},
										["actived_at"] = 1675856149,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 66,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[58427] = {
										["activedamt"] = 1,
										["id"] = 58427,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57993] = {
										["activedamt"] = 1,
										["id"] = 57993,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[48666] = 3,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856154,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Mjordin Combatant",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[61227] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-4457-571-155-30037-0000637E28",
							["aID"] = "30037",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 777,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708352.09,
				["tempo_start"] = 1675856142,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 847,
				["playing_solo"] = true,
				["totals"] = {
					26409, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 43,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:35:54",
				["hasTimer"] = 11.01699999999255,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 708311.873,
				["CombatEndedAt"] = 708311.873,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:35:43",
				["end_time"] = 708311.873,
				["combat_id"] = 777,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["totals_grupo"] = {
					26409, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 43,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 26409.006563,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708300.372,
				["contra"] = "Mjordin Combatant",
				["TimeData"] = {
				},
			}, -- [39]
			{
				{
					["combatId"] = 776,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002158,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Mjordin Combatant"] = 34748,
							},
							["serial"] = "Player-4477-04D9C2D1",
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Mjordin Combatant"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 34748.002158,
							["end_time"] = 1675856126,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 34748.002158,
							["aID"] = "4477-04D9C2D1",
							["classe"] = "ROGUE",
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 7,
										["b_amt"] = 0,
										["c_dmg"] = 5334,
										["g_amt"] = 0,
										["n_max"] = 415,
										["targets"] = {
											["Mjordin Combatant"] = 8412,
										},
										["n_dmg"] = 3078,
										["n_min"] = 345,
										["g_dmg"] = 0,
										["counter"] = 17,
										["ChartData"] = {
											[8] = 5233,
											[6] = 5233,
											[11] = 8013,
										},
										["total"] = 8412,
										["c_max"] = 845,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 2,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 667,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[48665] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 5417,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Mjordin Combatant"] = 5417,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[8] = 2008,
											[6] = 2008,
											[11] = 5417,
										},
										["total"] = 5417,
										["c_max"] = 2008,
										["id"] = 48665,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1494,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57970] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 661,
										["targets"] = {
											["Mjordin Combatant"] = 661,
										},
										["n_dmg"] = 661,
										["n_min"] = 661,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[8] = 661,
											[6] = 661,
											[11] = 661,
										},
										["total"] = 661,
										["c_max"] = 0,
										["id"] = 57970,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57965] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1336,
										["g_amt"] = 0,
										["n_max"] = 951,
										["targets"] = {
											["Mjordin Combatant"] = 3130,
										},
										["n_dmg"] = 1794,
										["n_min"] = 843,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[8] = 843,
											[6] = 843,
											[11] = 2179,
										},
										["total"] = 3130,
										["c_max"] = 1336,
										["id"] = 57965,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1336,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[48664] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3611,
										["g_amt"] = 0,
										["n_max"] = 687,
										["targets"] = {
											["Mjordin Combatant"] = 4298,
										},
										["n_dmg"] = 687,
										["n_min"] = 687,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[8] = 1736,
											[6] = 1736,
											[11] = 4298,
										},
										["total"] = 4298,
										["c_max"] = 1875,
										["id"] = 48664,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1736,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[57993] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 12830,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Mjordin Combatant"] = 12830,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[8] = 5836,
											[6] = 5836,
											[11] = 5836,
										},
										["total"] = 12830,
										["c_max"] = 6994,
										["id"] = 57993,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 5836,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["on_hold"] = false,
							["last_dps"] = 2464.397316174282,
							["custom"] = 0,
							["last_event"] = 1675856125,
							["damage_taken"] = 338.002158,
							["start_time"] = 1675856112,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006627,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 338,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-4457-571-155-30037-0000637D71",
							["damage_from"] = {
								["Drushnak"] = true,
							},
							["aID"] = "30037",
							["raid_targets"] = {
							},
							["total_without_pet"] = 338.006627,
							["fight_component"] = true,
							["end_time"] = 1675856126,
							["dps_started"] = false,
							["total"] = 338.006627,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Mjordin Combatant",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 338,
										["targets"] = {
											["Drushnak"] = 338,
										},
										["n_dmg"] = 338,
										["n_min"] = 338,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 338,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[49807] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 49807,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 34748.006627,
							["start_time"] = 1675856123,
							["delay"] = 0,
							["last_event"] = 1675856123,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 776,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 776,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 78.00820999999999,
							["resource"] = 0.00821,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Drushnak"] = 78,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["totalover"] = 0.00821,
							["total"] = 78.00820999999999,
							["nome"] = "Drushnak",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[51637] = {
										["total"] = 28,
										["id"] = 51637,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 28,
										},
										["counter"] = 14,
									},
									[14181] = {
										["total"] = 50,
										["id"] = 14181,
										["totalover"] = 0,
										["targets"] = {
											["Drushnak"] = 50,
										},
										["counter"] = 2,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 259,
							["aID"] = "4477-04D9C2D1",
							["flag_original"] = 1297,
							["last_event"] = 1675856125,
							["alternatepower"] = 0.00821,
							["passiveover"] = 0.00821,
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 776,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1833] = {
										["activedamt"] = -1,
										["id"] = 1833,
										["targets"] = {
										},
										["actived_at"] = 1675856116,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57970] = {
										["activedamt"] = -1,
										["id"] = 57970,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 11,
										["actived"] = false,
										["counter"] = 0,
									},
									[51724] = {
										["activedamt"] = -1,
										["id"] = 51724,
										["targets"] = {
										},
										["actived_at"] = 1675856121,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 94,
							["aID"] = "4477-04D9C2D1",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[60233] = {
										["activedamt"] = 1,
										["id"] = 60233,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[58427] = {
										["activedamt"] = 1,
										["id"] = 58427,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[59620] = {
										["activedamt"] = 1,
										["id"] = 59620,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[6774] = {
										["activedamt"] = 1,
										["id"] = 6774,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[48101] = {
										["activedamt"] = 1,
										["id"] = 48101,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57822] = {
										["activedamt"] = 1,
										["id"] = 57822,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[55775] = {
										["activedamt"] = 1,
										["id"] = 55775,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57940] = {
										["activedamt"] = 1,
										["id"] = 57940,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[57993] = {
										["activedamt"] = 2,
										["id"] = 57993,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 14,
							["nome"] = "Drushnak",
							["spec"] = 259,
							["grupo"] = true,
							["spell_cast"] = {
								[6774] = 1,
								[48666] = 3,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675856126,
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["serial"] = "Player-4477-04D9C2D1",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Mjordin Combatant",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[49807] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-4457-571-155-30037-0000637D71",
							["aID"] = "30037",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 776,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Drushnak"] = "Player-4477-04D9C2D1",
				},
				["raid_roster_indexed"] = {
					"Drushnak", -- [1]
				},
				["CombatStartedAt"] = 708300.272,
				["tempo_start"] = 1675856112,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 846,
				["playing_solo"] = true,
				["totals"] = {
					35086, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 78,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "12:35:27",
				["hasTimer"] = 14,
				["cleu_timeline"] = {
				},
				["enemy"] = "Mjordin Combatant",
				["TotalElapsedCombatTime"] = 708284.322,
				["CombatEndedAt"] = 708284.322,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "12:35:13",
				["end_time"] = 708284.322,
				["combat_id"] = 776,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Mjordin Combatant"] = 2,
				},
				["totals_grupo"] = {
					34748, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 78,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Drushnak"] = 34748.002158,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 708270.2220000001,
				["contra"] = "Mjordin Combatant",
				["TimeData"] = {
				},
			}, -- [40]
		},
	},
	["ocd_tracker"] = {
		["enabled"] = false,
		["current_cooldowns"] = {
		},
		["lines_per_column"] = 12,
		["frames"] = {
			["defensive-raid"] = {
			},
			["main"] = {
			},
			["ofensive"] = {
			},
			["defensive-target"] = {
			},
			["utility"] = {
			},
			["defensive-personal"] = {
			},
		},
		["show_options"] = false,
		["own_frame"] = {
			["defensive-raid"] = false,
			["ofensive"] = false,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["width"] = 120,
		["cooldowns"] = {
		},
		["framme_locked"] = false,
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["height"] = 18,
		["filters"] = {
			["defensive-raid"] = false,
			["ofensive"] = true,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
	},
	["last_version"] = "3.4.1 10410",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["on_death_menu"] = false,
	["cached_talents"] = {
		["Player-4477-04D9C2D1"] = {
			{
				132273, -- [1]
				5, -- [2]
				4, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [1]
			{
				132109, -- [1]
				4, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [2]
			{
				132277, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [3]
			{
				132151, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [4]
			{
				132122, -- [1]
				3, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [5]
			{
				136147, -- [1]
				2, -- [2]
				6, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [6]
			{
				132292, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [7]
			{
				132090, -- [1]
				3, -- [2]
				2, -- [3]
				4, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [8]
			{
				132354, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [9]
			{
				132298, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [10]
			{
				135988, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [11]
			{
				132205, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [12]
			{
				136130, -- [1]
				5, -- [2]
				6, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [13]
			{
				136023, -- [1]
				1, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [14]
			{
				132293, -- [1]
				3, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [15]
			{
				132108, -- [1]
				3, -- [2]
				9, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [16]
			{
				132295, -- [1]
				3, -- [2]
				8, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [17]
			{
				132304, -- [1]
				1, -- [2]
				9, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [18]
			{
				132296, -- [1]
				2, -- [2]
				5, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [19]
			{
				132286, -- [1]
				0, -- [2]
				7, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [20]
			{
				132301, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [21]
			{
				236270, -- [1]
				0, -- [2]
				7, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [22]
			{
				236284, -- [1]
				0, -- [2]
				9, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [23]
			{
				236268, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [24]
			{
				236274, -- [1]
				3, -- [2]
				8, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [25]
			{
				236269, -- [1]
				5, -- [2]
				10, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [26]
			{
				236276, -- [1]
				1, -- [2]
				11, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [27]
			{
				132222, -- [1]
				5, -- [2]
				2, -- [3]
				4, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [28]
			{
				135641, -- [1]
				3, -- [2]
				3, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [29]
			{
				133476, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [30]
			{
				136047, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [31]
			{
				132269, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [32]
			{
				136189, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [33]
			{
				132155, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [34]
			{
				136205, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [35]
			{
				136206, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [36]
			{
				132219, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [37]
			{
				132147, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [38]
			{
				132307, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [39]
			{
				132350, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [40]
			{
				135328, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [41]
			{
				132336, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [42]
			{
				132275, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [43]
			{
				135882, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [44]
			{
				132353, -- [1]
				0, -- [2]
				7, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [45]
			{
				132283, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [46]
			{
				132300, -- [1]
				0, -- [2]
				7, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [47]
			{
				132308, -- [1]
				0, -- [2]
				9, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [48]
			{
				135673, -- [1]
				0, -- [2]
				8, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [49]
			{
				132306, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [50]
			{
				236282, -- [1]
				0, -- [2]
				8, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [51]
			{
				236285, -- [1]
				0, -- [2]
				9, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [52]
			{
				132100, -- [1]
				0, -- [2]
				9, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [53]
			{
				236278, -- [1]
				0, -- [2]
				10, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [54]
			{
				236277, -- [1]
				0, -- [2]
				11, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [55]
			{
				136129, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [56]
			{
				132320, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [57]
			{
				136159, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [58]
			{
				136056, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [59]
			{
				135994, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [60]
			{
				132366, -- [1]
				2, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [61]
			{
				132310, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [62]
			{
				132282, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [63]
			{
				136220, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [64]
			{
				136121, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [65]
			{
				136136, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [66]
			{
				136183, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [67]
			{
				136168, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [68]
			{
				135315, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [69]
			{
				132294, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [70]
			{
				132089, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [71]
			{
				135540, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [72]
			{
				132291, -- [1]
				0, -- [2]
				7, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [73]
			{
				132305, -- [1]
				0, -- [2]
				8, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [74]
			{
				132299, -- [1]
				0, -- [2]
				6, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [75]
			{
				132303, -- [1]
				0, -- [2]
				9, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [76]
			{
				132285, -- [1]
				0, -- [2]
				7, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [77]
			{
				236286, -- [1]
				0, -- [2]
				8, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [78]
			{
				236275, -- [1]
				0, -- [2]
				9, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [79]
			{
				236287, -- [1]
				0, -- [2]
				9, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [80]
			{
				236280, -- [1]
				0, -- [2]
				10, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [81]
			{
				236279, -- [1]
				0, -- [2]
				11, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [82]
			{
				132340, -- [1]
				5, -- [2]
				1, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [83]
		},
	},
	["last_instance_id"] = 595,
	["data_harvest_for_charsts"] = {
		["players"] = {
			{
				["name"] = "Damage of Each Individual Player",
				["playerOnly"] = true,
				["playerKey"] = "total",
				["combatObjectContainer"] = 1,
			}, -- [1]
		},
		["totals"] = {
			{
				["combatObjectSubTableKey"] = 1,
				["name"] = "Damage of All Player Combined",
				["combatObjectSubTableName"] = "totals",
			}, -- [1]
		},
	},
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Drushnak-Venoxis",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1676618681,
		["last_version"] = 15,
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["mythic_plus_log"] = {
	},
	["cached_roles"] = {
		["Player-4477-01EA8AA3"] = "HEALER",
		["Player-4477-046A4DAD"] = "DAMAGER",
		["Player-4477-04D989C1"] = "DAMAGER",
		["Player-4477-030A5B72"] = "DAMAGER",
		["Player-4477-04C9E996"] = "DAMAGER",
		["Player-4477-04D88871"] = "DAMAGER",
		["Player-4477-017BA204"] = "HEALER",
		["Player-4477-047CB4FF"] = "DAMAGER",
		["Player-4477-042124EC"] = "DAMAGER",
		["Player-4477-04D9C2D1"] = "DAMAGER",
		["Player-4477-038F4939"] = "DAMAGER",
		["Player-4477-03B10A0F"] = "DAMAGER",
		["Player-4477-04D8A8E6"] = "HEALER",
		["Player-4477-0450EBD6"] = "HEALER",
		["Player-4477-044DC3C2"] = "DAMAGER",
		["Player-4477-04384E12"] = "HEALER",
		["Player-4477-0458B10B"] = "DAMAGER",
		["Player-4477-033C0DF9"] = "DAMAGER",
		["Player-4477-04614609"] = "DAMAGER",
		["Player-4477-03AFCA74"] = "DAMAGER",
		["Player-4477-04D7E1D0"] = "DAMAGER",
		["Player-4477-04383888"] = "DAMAGER",
		["Player-4477-044DD481"] = "TANK",
		["Player-4477-0437D0A7"] = "DAMAGER",
		["Player-4477-04D94C83"] = "DAMAGER",
		["Player-4477-04CE474D"] = "HEALER",
		["Player-4477-048E333D"] = "DAMAGER",
		["Player-4477-032FD30D"] = "HEALER",
		["Player-4477-03BACC59"] = "HEALER",
		["Player-4477-01065F3B"] = "DAMAGER",
		["Player-4477-0472280C"] = "DAMAGER",
		["Player-4477-04BE5EA3"] = "DAMAGER",
		["Player-4477-03B52B88"] = "TANK",
		["Player-4477-03AFDF69"] = "DAMAGER",
		["Player-4477-04D7E0CC"] = "DAMAGER",
		["Player-4477-0363B447"] = "DAMAGER",
		["Player-4477-01778C86"] = "DAMAGER",
		["Player-4477-04D88787"] = "DAMAGER",
		["Player-4477-04D380D6"] = "DAMAGER",
		["Player-4477-03A11F28"] = "DAMAGER",
		["Player-4477-033AB1D6"] = "DAMAGER",
		["Player-4477-04A7CC1B"] = "DAMAGER",
		["Player-4477-04D8FDF2"] = "DAMAGER",
		["Player-4477-04D9CC58"] = "HEALER",
		["Player-4477-0346759C"] = "HEALER",
		["Player-4477-044DECF5"] = "DAMAGER",
		["Player-4477-04D8C3BF"] = "DAMAGER",
		["Player-4477-04D8D288"] = "DAMAGER",
		["Player-4477-03386108"] = "DAMAGER",
		["Player-4477-048ECA71"] = "DAMAGER",
		["Player-4477-04D7DBEF"] = "HEALER",
		["Player-4477-04D965B5"] = "HEALER",
		["Player-4477-04D96597"] = "DAMAGER",
		["Player-4477-04413A99"] = "DAMAGER",
		["Player-4477-04CFB3D5"] = "HEALER",
		["Player-4477-02520A9C"] = "DAMAGER",
		["Player-4477-04C25F0C"] = "DAMAGER",
		["Player-4477-04D7F0EF"] = "TANK",
		["Player-4477-037249C6"] = "DAMAGER",
		["Player-4477-04C324BC"] = "DAMAGER",
		["Player-4477-046F6CAB"] = "DAMAGER",
		["Player-4477-04D9A4C6"] = "DAMAGER",
		["Player-4477-04526F12"] = "DAMAGER",
		["Player-4477-034EB9CF"] = "HEALER",
		["Player-4477-01F5E2E1"] = "DAMAGER",
		["Player-4477-03B261F1"] = "DAMAGER",
		["Player-4477-04D8FEA8"] = "TANK",
		["Player-4477-0246730D"] = "DAMAGER",
		["Player-4477-03B0B6F0"] = "DAMAGER",
		["Player-4477-03BA2B16"] = "TANK",
		["Player-4477-01D576EC"] = "DAMAGER",
		["Player-4477-04BC1751"] = "HEALER",
		["Player-4477-04D965E1"] = "DAMAGER",
		["Player-4477-04D09897"] = "DAMAGER",
		["Player-4477-0485C650"] = "DAMAGER",
		["Player-4477-03B06DF7"] = "HEALER",
		["Player-4477-043290DB"] = "DAMAGER",
		["Player-4477-044A2BDC"] = "HEALER",
		["Player-4477-03BF82F5"] = "DAMAGER",
		["Player-4477-04B0F804"] = "DAMAGER",
		["Player-4477-03B1F270"] = "DAMAGER",
		["Player-4477-045CB3C6"] = "TANK",
		["Player-4477-035B8D11"] = "DAMAGER",
		["Player-4477-04AE71E9"] = "HEALER",
		["Player-4477-04D96652"] = "DAMAGER",
		["Player-4477-04ACADE4"] = "DAMAGER",
		["Player-4477-042BF677"] = "DAMAGER",
		["Player-4477-03859A52"] = "DAMAGER",
		["Player-4477-04D56596"] = "HEALER",
		["Player-4477-04D4ADE5"] = "DAMAGER",
		["Player-4477-03B0B4D0"] = "TANK",
		["Player-4477-04D96776"] = "DAMAGER",
		["Player-4477-044066D2"] = "TANK",
	},
	["last_realversion"] = 148,
	["last_instance_time"] = 1675425808,
	["combat_counter"] = 885,
	["last_encounter"] = "Malygos",
	["character_data"] = {
		["logons"] = 31,
	},
	["ignore_nicktag"] = false,
	["combat_id"] = 815,
	["savedStyles"] = {
	},
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["disable_gouge"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["useclasscolors"] = false,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["last_section_selected"] = "main",
			["author"] = "Terciob",
			["window_scale"] = 1,
			["hide_on_combat"] = false,
			["show_icon"] = 5,
			["opened"] = 0,
			["encounter_timers_dbm"] = {
			},
		},
		["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
			["enabled"] = true,
			["author"] = "Terciob",
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["grow_direction"] = "right",
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["scale"] = 1,
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 65.8667497247642,
				["radius"] = 160,
				["hide"] = false,
			},
			["row_height"] = 20,
			["arrow_anchor_x"] = 0,
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["point"] = "CENTER",
			["main_frame_strata"] = "LOW",
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["use_spark"] = true,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["author"] = "Details! Team",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["font_size"] = 10,
			["y"] = -1.52587890625e-05,
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -1.52587890625e-05,
				["x"] = -3.0517578125e-05,
				["size"] = 32,
				["update_speed"] = 0.05,
				["attribute_type"] = 1,
			},
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["main_frame_locked"] = false,
			["arrow_anchor_y"] = 0,
		},
	},
	["data_harvested_for_charts"] = {
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 28192.084031,
					["damage_from"] = {
						["Drushnak"] = true,
						["Lordaeron Footman"] = true,
						["Leayae"] = true,
						["High Elf Mage-Priest"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Ýurríi"] = true,
					},
					["targets"] = {
						["Leayae"] = 18676,
						["Lordaeron Footman"] = 9197,
						["Drushnak"] = 9274,
						["Ûrsus"] = 4550,
						["Atb"] = 21187,
						["Ýurríi"] = 8423,
					},
					["dps_started"] = false,
					["pets"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 71307.084031,
					["aID"] = "27737",
					["classe"] = "UNKNOW",
					["monster"] = true,
					["end_time"] = 1675425986,
					["on_hold"] = false,
					["serial"] = "Creature-0-4445-595-881-27737-00005CF870",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 4,
								["b_amt"] = 1,
								["c_dmg"] = 2851,
								["g_amt"] = 0,
								["n_max"] = 749,
								["targets"] = {
									["Leayae"] = 18676,
									["Lordaeron Footman"] = 9197,
									["Drushnak"] = 9274,
									["Ûrsus"] = 4550,
									["Atb"] = 21187,
									["Ýurríi"] = 8423,
								},
								["n_dmg"] = 68456,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 324,
								["a_dmg"] = 419,
								["total"] = 71307,
								["c_max"] = 781,
								["DODGE"] = 40,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 19,
								["extra"] = {
								},
								["BLOCK"] = 26,
								["PARRY"] = 9,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 2,
								["n_amt"] = 226,
								["b_dmg"] = 487,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["total"] = 71307.084031,
					["nome"] = "Risen Zombie",
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675425693,
					["delay"] = 0,
					["damage_taken"] = 421120.084031,
				}, -- [1]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.09729399999999999,
					["damage_from"] = {
						["Patchwork Construct"] = true,
						["[*] Shadow Word: Death"] = true,
						["Skeletal Minion <Master Necromancer>"] = true,
						["Acolyte"] = true,
						["Bile Golem"] = true,
						["Devouring Ghoul"] = true,
						["Risen Zombie"] = true,
						["Mal'Ganis"] = true,
						["Chrono-Lord Epoch"] = true,
						["Meathook"] = true,
					},
					["targets"] = {
						["Patchwork Construct"] = 10321,
						["Skeletal Minion"] = 9578,
						["Acolyte"] = 82218,
						["Bile Golem"] = 59728,
						["Roach"] = 21,
						["Tomb Stalker"] = 66348,
						["Risen Zombie"] = 99464,
						["Stratholme Resident"] = 955,
						["Dark Necromancer"] = 33640,
						["Infinite Hunter"] = 24428,
						["Mal'Ganis"] = 91869,
						["Chrono-Lord Epoch"] = 47644,
						["Skeletal Minion <Master Necromancer>"] = 8636,
						["Stratholme Citizen"] = 1459,
						["Ghoul Minion <Salramm the Fleshcrafter>"] = 2838,
						["Master Necromancer"] = 34669,
						["Infinite Agent"] = 20048,
						["Infinite Adversary"] = 20832,
						["Ghoul Minion"] = 1725,
						["Rat"] = 7,
						["Salramm the Fleshcrafter"] = 52531,
						["Enraging Ghoul"] = 125937,
						["Meathook"] = 54361,
						["Devouring Ghoul"] = 102798,
					},
					["last_event"] = 0,
					["pets"] = {
						"Shadowfiend <Atb>", -- [1]
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire"] = {
						["Leayae"] = {
							["spells"] = {
								[64205] = 0,
							},
							["total"] = 5724,
						},
					},
					["classe"] = "PRIEST",
					["raid_targets"] = {
					},
					["total_without_pet"] = 920599.0972939999,
					["on_hold"] = false,
					["friendlyfire_total"] = 5724,
					["dps_started"] = false,
					["end_time"] = 1675425986,
					["spec"] = 256,
					["serial"] = "Player-4477-01EA8AA3",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 5,
								["b_amt"] = 2,
								["c_dmg"] = 1171,
								["g_amt"] = 3,
								["n_max"] = 201,
								["targets"] = {
									["Chrono-Lord Epoch"] = 717,
									["Tomb Stalker"] = 409,
									["Risen Zombie"] = 352,
									["Salramm the Fleshcrafter"] = 243,
									["Bile Golem"] = 731,
									["Enraging Ghoul"] = 469,
								},
								["n_dmg"] = 1359,
								["n_min"] = 0,
								["g_dmg"] = 391,
								["counter"] = 19,
								["total"] = 2921,
								["c_max"] = 409,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 173,
								["r_amt"] = 0,
							}, -- [1]
							[48127] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 7915,
								["g_amt"] = 0,
								["n_max"] = 2740,
								["targets"] = {
									["Salramm the Fleshcrafter"] = 5047,
									["Mal'Ganis"] = 7912,
									["Chrono-Lord Epoch"] = 8946,
									["Meathook"] = 9327,
								},
								["n_dmg"] = 23317,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 31232,
								["c_max"] = 3983,
								["id"] = 48127,
								["r_dmg"] = 2339,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[48300] = {
								["c_amt"] = 15,
								["b_amt"] = 0,
								["c_dmg"] = 24292,
								["g_amt"] = 0,
								["n_max"] = 914,
								["targets"] = {
									["Salramm the Fleshcrafter"] = 14045,
									["Mal'Ganis"] = 15436,
									["Chrono-Lord Epoch"] = 12468,
									["Meathook"] = 15510,
								},
								["n_dmg"] = 33167,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 56,
								["total"] = 57459,
								["c_max"] = 1714,
								["id"] = 48300,
								["r_dmg"] = 18035,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 41,
								["b_dmg"] = 0,
								["r_amt"] = 19,
							},
							[397567] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1779,
								["g_amt"] = 0,
								["n_max"] = 524,
								["targets"] = {
									["Tomb Stalker"] = 458,
									["Risen Zombie"] = 212,
									["Devouring Ghoul"] = 699,
									["Master Necromancer"] = 524,
									["Enraging Ghoul"] = 868,
								},
								["n_dmg"] = 982,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 2761,
								["c_max"] = 868,
								["id"] = 397567,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[48078] = {
								["c_amt"] = 28,
								["b_amt"] = 0,
								["c_dmg"] = 31151,
								["g_amt"] = 0,
								["n_max"] = 1175,
								["targets"] = {
									["Patchwork Construct"] = 5468,
									["Acolyte"] = 959,
									["Bile Golem"] = 983,
									["Roach"] = 14,
									["Stratholme Citizen"] = 1459,
									["Risen Zombie"] = 42743,
									["Stratholme Resident"] = 955,
									["Infinite Hunter"] = 1110,
									["Mal'Ganis"] = 1175,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 2838,
									["Master Necromancer"] = 3014,
									["Chrono-Lord Epoch"] = 4910,
									["Tomb Stalker"] = 1030,
									["Infinite Adversary"] = 2344,
									["Rat"] = 7,
									["Salramm the Fleshcrafter"] = 3100,
									["Ghoul Minion"] = 1725,
									["Enraging Ghoul"] = 14616,
									["Devouring Ghoul"] = 7145,
								},
								["n_dmg"] = 64444,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 103,
								["total"] = 95595,
								["c_max"] = 1760,
								["id"] = 48078,
								["r_dmg"] = 1653,
								["MISS"] = 5,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 70,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							},
							[48125] = {
								["c_amt"] = 11,
								["b_amt"] = 0,
								["c_dmg"] = 19983,
								["g_amt"] = 0,
								["n_max"] = 978,
								["targets"] = {
									["Salramm the Fleshcrafter"] = 14766,
									["Mal'Ganis"] = 19333,
									["Chrono-Lord Epoch"] = 10491,
									["Meathook"] = 12627,
								},
								["n_dmg"] = 37234,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 53,
								["total"] = 57217,
								["c_max"] = 1956,
								["id"] = 48125,
								["r_dmg"] = 16563,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 41,
								["b_dmg"] = 0,
								["r_amt"] = 16,
							},
							[53022] = {
								["c_amt"] = 147,
								["b_amt"] = 0,
								["c_dmg"] = 216349,
								["g_amt"] = 0,
								["n_max"] = 1212,
								["targets"] = {
									["Patchwork Construct"] = 4853,
									["Infinite Hunter"] = 23318,
									["Skeletal Minion <Master Necromancer>"] = 8636,
									["Skeletal Minion"] = 9578,
									["Acolyte"] = 81259,
									["Bile Golem"] = 44405,
									["Roach"] = 7,
									["Enraging Ghoul"] = 109807,
									["Infinite Adversary"] = 16912,
									["Master Necromancer"] = 31131,
									["Tomb Stalker"] = 64451,
									["Risen Zombie"] = 56157,
									["Infinite Agent"] = 20048,
									["Dark Necromancer"] = 33640,
									["Devouring Ghoul"] = 94954,
								},
								["n_dmg"] = 382807,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 553,
								["total"] = 599156,
								["c_max"] = 1814,
								["id"] = 53022,
								["r_dmg"] = 9825,
								["MISS"] = 24,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 382,
								["b_dmg"] = 0,
								["r_amt"] = 8,
							},
							[53000] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 5674,
								["g_amt"] = 0,
								["n_max"] = 1332,
								["targets"] = {
									["Mal'Ganis"] = 7409,
									["Infinite Adversary"] = 1576,
									["Chrono-Lord Epoch"] = 3222,
									["Salramm the Fleshcrafter"] = 3728,
									["Meathook"] = 4160,
								},
								["n_dmg"] = 14421,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 17,
								["total"] = 20095,
								["c_max"] = 1892,
								["id"] = 53000,
								["r_dmg"] = 6690,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 13,
								["b_dmg"] = 0,
								["r_amt"] = 6,
							},
							[53023] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Bile Golem"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 53023,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[48123] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 9741,
								["g_amt"] = 0,
								["n_max"] = 3291,
								["targets"] = {
									["Salramm the Fleshcrafter"] = 4822,
									["Mal'Ganis"] = 15698,
									["Chrono-Lord Epoch"] = 3256,
									["Meathook"] = 8182,
								},
								["n_dmg"] = 22217,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 31958,
								["c_max"] = 4919,
								["id"] = 48123,
								["r_dmg"] = 5852,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							},
							[48158] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 10414,
								["g_amt"] = 0,
								["n_max"] = 2687,
								["targets"] = {
									["Salramm the Fleshcrafter"] = 6780,
									["Mal'Ganis"] = 7236,
									["Chrono-Lord Epoch"] = 3634,
									["Meathook"] = 4555,
								},
								["n_dmg"] = 11791,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 22205,
								["c_max"] = 3844,
								["id"] = 48158,
								["r_dmg"] = 12040,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 5,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["total"] = 952055.0972939999,
					["aID"] = "4477-01EA8AA3",
					["nome"] = "Atb",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675425471,
					["delay"] = 0,
					["damage_taken"] = 101259.097294,
				}, -- [2]
				{
					["flag_original"] = 2584,
					["totalabsorbed"] = 0.032414,
					["damage_from"] = {
						["Risen Zombie"] = true,
						["Stratholme Resident"] = true,
						["Stratholme Citizen"] = true,
					},
					["targets"] = {
						["Risen Zombie"] = 11358,
						["Stratholme Resident"] = 19173,
						["Stratholme Citizen"] = 10258,
					},
					["serial"] = "Creature-0-4445-595-881-27745-0001DCF82D",
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 40789.032414,
					["aID"] = "27745",
					["dps_started"] = false,
					["total"] = 40789.032414,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "Lordaeron Footman",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 6,
								["b_amt"] = 3,
								["c_dmg"] = 3293,
								["g_amt"] = 0,
								["n_max"] = 367,
								["targets"] = {
									["Risen Zombie"] = 10118,
									["Stratholme Resident"] = 16650,
									["Stratholme Citizen"] = 9612,
								},
								["n_dmg"] = 33087,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 139,
								["total"] = 36380,
								["c_max"] = 677,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 7,
								["MISS"] = 8,
								["extra"] = {
								},
								["PARRY"] = 5,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 113,
								["b_dmg"] = 774,
								["r_amt"] = 0,
							}, -- [1]
							[25710] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 444,
								["targets"] = {
									["Risen Zombie"] = 1240,
									["Stratholme Resident"] = 2523,
									["Stratholme Citizen"] = 646,
								},
								["n_dmg"] = 4409,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 4409,
								["c_max"] = 0,
								["id"] = 25710,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 13,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["boss_fight_component"] = true,
					["end_time"] = 1675425986,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 12039.032414,
					["start_time"] = 1675425879,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [3]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.034204,
					["damage_from"] = {
						["High Elf Mage-Priest"] = true,
						["Atb"] = true,
						["Leayae"] = true,
						["Drushnak"] = true,
						["Lordaeron Footman"] = true,
					},
					["targets"] = {
						["Leayae"] = 169,
						["Lordaeron Footman"] = 1953,
					},
					["serial"] = "Creature-0-4445-595-881-28169-00005CF885",
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 2122.034204,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["total"] = 2122.034204,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "Stratholme Resident",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 161,
								["g_amt"] = 0,
								["n_max"] = 169,
								["targets"] = {
									["Leayae"] = 169,
									["Lordaeron Footman"] = 1953,
								},
								["n_dmg"] = 1961,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 2122,
								["c_max"] = 161,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 22,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["dps_started"] = false,
					["end_time"] = 1675425986,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 21361.034204,
					["start_time"] = 1675425934,
					["delay"] = 0,
					["aID"] = "28169",
				}, -- [4]
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 2760.744256000001,
					["nome"] = "Drushnak",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Orgrimmar Valiant"] = 45425,
						["Vrykul Necrolord"] = 73800,
						["Skeletal Minion"] = 5282,
						["Onslaught Gryphon Rider"] = 734647,
						["Stratholme Citizen"] = 2822,
						["Angry Oak Spirit"] = 241754,
						["Grove Walker"] = 0,
						["Lord Everblaze"] = 35065,
						["Restless Frostborn Warrior"] = 137410,
						["Ghoul Minion <Salramm the Fleshcrafter>"] = 2356,
						["Melee Target"] = 77500,
						["Rabbit"] = 1237,
						["Mjordin Combatant"] = 938434,
						["Ghoul Minion"] = 5168,
						["Ravenous Jormungar"] = 283073,
						["Seething Revenant"] = 73817,
						["Sinewy Wolf"] = 0,
						["Acolyte"] = 45197,
						["Squirrel"] = 606,
						["Roach"] = 14,
						["Brittle Revenant"] = 458274,
						["Frostbrood Whelp"] = 165670,
						["Ice Steppe Bull"] = 12565,
						["Cult Conspirator"] = 0,
						["Infinite Hunter"] = 46457,
						["Restless Frostborn Ghost"] = 237509,
						["Shadow Vault Abomination"] = 5027,
						["Shadow Vault Skirmisher"] = 20245,
						["Boneguard Commander"] = 68500,
						["Enraging Ghoul"] = 247764,
						["Onslaught Harbor Guard"] = 26929,
						["Thunder Bluff Valiant"] = 96975,
						["Infinite Adversary"] = 110130,
						["Charge Target"] = 85050,
						["Unbound Seer"] = 0,
						["Shadow Vault Assaulter"] = 34938,
						["Roaming Jormungar"] = 183846,
						["Viscous Oil"] = 333908,
						["Skeletal Minion <Master Necromancer>"] = 2675,
						["Skeletal Woodcutter"] = 0,
						["Master Necromancer"] = 15896,
						["Undercity Valiant"] = 86900,
						["Niffelem Forefather"] = 401093,
						["Chrono-Lord Epoch"] = 181222,
						["Maloric"] = 0,
						["Patchwork Construct"] = 45087,
						["Jotunheim Warrior"] = 212042,
						["Boneguard Scout"] = 240000,
						["Ranged Target"] = 10800,
						["Risen Zombie"] = 79748,
						["Jotunheim Proto-Drake"] = 10483200,
						["Boneguard Lieutenant"] = 246000,
						["Converted Hero"] = 146564,
						["Bile Golem"] = 267101,
						["Mal'Ganis"] = 231670,
						["Spider"] = 0,
						["Devouring Ghoul"] = 244778,
						["Disembodied Jormungar"] = 257226,
						["Boneguard Footman"] = 195000,
						["Infinite Agent"] = 109018,
						["Crypt Fiend"] = 24102,
						["Sunreaver Hawkstrider <Drushnak>"] = 43030,
						["Stormforged Infiltrator"] = 197344,
						["Sen'jin Valiant"] = 18225,
						["Argent Valiant <Drushnak>"] = 29850,
						["Salramm the Fleshcrafter"] = 217195,
						["Tomb Stalker"] = 87525,
						["Dark Necromancer"] = 15068,
						["Meathook"] = 207409,
					},
					["total"] = 19133164.74425602,
					["pets"] = {
						"Sunreaver Hawkstrider <Drushnak>", -- [1]
						"Jotunheim Rapid-Fire Harpoon <Drushnak>", -- [2]
						"Argent Valiant <Drushnak>", -- [3]
						"Orgrimmar Wolf <Drushnak>", -- [4]
						"Campaign Warhorse <Drushnak>", -- [5]
					},
					["damage_from"] = {
						["Vrykul Necrolord"] = true,
						["Onslaught Gryphon Rider"] = true,
						["Stratholme Citizen"] = true,
						["Shadow Vault Assaulter"] = true,
						["Angry Oak Spirit"] = true,
						["Roaming Jormungar"] = true,
						["Viscous Oil"] = true,
						["Restless Frostborn Warrior"] = true,
						["Skeletal Minion <Master Necromancer>"] = true,
						["Mjordin Combatant"] = true,
						["Ghoul Minion"] = true,
						["Niffelem Forefather"] = true,
						["Devouring Ghoul"] = true,
						["Ravenous Jormungar"] = true,
						["Seething Revenant"] = true,
						["Acolyte"] = true,
						["Jotunheim Warrior"] = true,
						["Brittle Revenant"] = true,
						["Risen Zombie"] = true,
						["Restless Frostborn Ghost"] = true,
						["Mal'Ganis"] = true,
						["Drushnak"] = true,
						["Disembodied Jormungar"] = true,
						["Patchwork Construct"] = true,
						["Shadow Vault Abomination"] = true,
						["Enraging Ghoul"] = true,
						["Stormforged Infiltrator"] = true,
						["Onslaught Harbor Guard"] = true,
						["Bile Golem"] = true,
						["Converted Hero"] = true,
						["Salramm the Fleshcrafter"] = true,
						["Frostbrood Whelp"] = true,
						["Chrono-Lord Epoch"] = true,
						["Meathook"] = true,
					},
					["friendlyfire_total"] = 9871,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 8316984.744256004,
					["last_dps"] = 0,
					["aID"] = "4477-04D9C2D1",
					["dps_started"] = false,
					["end_time"] = 1675425986,
					["serial"] = "Player-4477-04D9C2D1",
					["friendlyfire"] = {
						["Leayae"] = {
							["spells"] = {
								[64205] = 0,
							},
							["total"] = 7113,
						},
						["Drushnak"] = {
							["spells"] = {
								[56488] = 0,
							},
							["total"] = 2758,
						},
					},
					["boss_fight_component"] = true,
					["spec"] = 259,
					["grupo"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1753,
								["b_amt"] = 109,
								["c_dmg"] = 1418665,
								["g_amt"] = 214,
								["n_max"] = 749,
								["targets"] = {
									["Vrykul Necrolord"] = 25530,
									["Unbound Seer"] = 0,
									["Onslaught Gryphon Rider"] = 236843,
									["Shadow Vault Assaulter"] = 8551,
									["Angry Oak Spirit"] = 48471,
									["Grove Walker"] = 0,
									["Viscous Oil"] = 100778,
									["Lord Everblaze"] = 9623,
									["Crypt Fiend"] = 10976,
									["Skeletal Minion <Master Necromancer>"] = 421,
									["Skeletal Woodcutter"] = 0,
									["Master Necromancer"] = 2539,
									["Rabbit"] = 1237,
									["Mjordin Combatant"] = 291832,
									["Converted Hero"] = 48518,
									["Maloric"] = 0,
									["Niffelem Forefather"] = 143832,
									["Devouring Ghoul"] = 73149,
									["Ravenous Jormungar"] = 97375,
									["Seething Revenant"] = 26590,
									["Squirrel"] = 606,
									["Sinewy Wolf"] = 0,
									["Salramm the Fleshcrafter"] = 57260,
									["Acolyte"] = 7862,
									["Bile Golem"] = 79492,
									["Frostbrood Whelp"] = 45652,
									["Mal'Ganis"] = 59576,
									["Brittle Revenant"] = 120837,
									["Dark Necromancer"] = 5014,
									["Tomb Stalker"] = 23132,
									["Risen Zombie"] = 8953,
									["Ice Steppe Bull"] = 5657,
									["Cult Conspirator"] = 0,
									["Infinite Hunter"] = 3643,
									["Restless Frostborn Ghost"] = 71956,
									["Shadow Vault Abomination"] = 647,
									["Spider"] = 0,
									["Shadow Vault Skirmisher"] = 2683,
									["Disembodied Jormungar"] = 91922,
									["Roaming Jormungar"] = 62194,
									["Restless Frostborn Warrior"] = 36871,
									["Enraging Ghoul"] = 65762,
									["Stormforged Infiltrator"] = 56876,
									["Onslaught Harbor Guard"] = 10689,
									["Jotunheim Warrior"] = 70346,
									["Patchwork Construct"] = 15715,
									["Infinite Agent"] = 43449,
									["Chrono-Lord Epoch"] = 46587,
									["Infinite Adversary"] = 29678,
									["Meathook"] = 50317,
								},
								["n_dmg"] = 701907,
								["n_min"] = 0,
								["g_dmg"] = 79069,
								["counter"] = 4151,
								["total"] = 2199641,
								["c_max"] = 1369,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 5,
								["MISS"] = 360,
								["extra"] = {
								},
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1816,
								["b_dmg"] = 35896,
								["r_amt"] = 0,
							}, -- [1]
							[62544] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3250,
								["targets"] = {
									["Melee Target"] = 32500,
									["Charge Target"] = 6500,
									["Thunder Bluff Valiant"] = 29575,
									["Undercity Valiant"] = 8450,
									["Sen'jin Valiant"] = 2275,
									["Argent Valiant <Drushnak>"] = 7800,
									["Orgrimmar Valiant"] = 10075,
								},
								["n_dmg"] = 97175,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 38,
								["total"] = 97175,
								["c_max"] = 0,
								["id"] = 62544,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 38,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[52874] = {
								["c_amt"] = 118,
								["b_amt"] = 9,
								["c_dmg"] = 101359,
								["g_amt"] = 0,
								["n_max"] = 816,
								["targets"] = {
									["Ravenous Jormungar"] = 1000,
									["Patchwork Construct"] = 1865,
									["Sinewy Wolf"] = 0,
									["Skeletal Minion"] = 1813,
									["Acolyte"] = 10520,
									["Bile Golem"] = 7636,
									["Roach"] = 14,
									["Tomb Stalker"] = 10034,
									["Risen Zombie"] = 39286,
									["Shadow Vault Assaulter"] = 5916,
									["Dark Necromancer"] = 2576,
									["Infinite Hunter"] = 11446,
									["Shadow Vault Abomination"] = 1269,
									["Onslaught Gryphon Rider"] = 2417,
									["Crypt Fiend"] = 444,
									["Skeletal Minion <Master Necromancer>"] = 1387,
									["Shadow Vault Skirmisher"] = 9687,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 1243,
									["Master Necromancer"] = 3881,
									["Angry Oak Spirit"] = 0,
									["Salramm the Fleshcrafter"] = 2358,
									["Enraging Ghoul"] = 18932,
									["Ghoul Minion"] = 1847,
									["Infinite Agent"] = 12722,
									["Infinite Adversary"] = 13735,
									["Stratholme Citizen"] = 1934,
									["Devouring Ghoul"] = 15968,
								},
								["n_dmg"] = 78571,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 297,
								["total"] = 179930,
								["c_max"] = 1482,
								["id"] = 52874,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 179,
								["b_dmg"] = 3485,
								["r_amt"] = 0,
							},
							[57993] = {
								["c_amt"] = 133,
								["b_amt"] = 14,
								["c_dmg"] = 763802,
								["g_amt"] = 0,
								["n_max"] = 5764,
								["targets"] = {
									["Maloric"] = 0,
									["Patchwork Construct"] = 890,
									["Vrykul Necrolord"] = 16646,
									["Sinewy Wolf"] = 0,
									["Devouring Ghoul"] = 17402,
									["Jotunheim Warrior"] = 57199,
									["Bile Golem"] = 20852,
									["Onslaught Gryphon Rider"] = 107128,
									["Seething Revenant"] = 21268,
									["Brittle Revenant"] = 116608,
									["Infinite Agent"] = 4682,
									["Ravenous Jormungar"] = 54445,
									["Frostbrood Whelp"] = 47968,
									["Restless Frostborn Ghost"] = 60810,
									["Cult Conspirator"] = 0,
									["Grove Walker"] = 0,
									["Viscous Oil"] = 62386,
									["Lord Everblaze"] = 12179,
									["Mal'Ganis"] = 29092,
									["Restless Frostborn Warrior"] = 29612,
									["Converted Hero"] = 46798,
									["Roaming Jormungar"] = 36388,
									["Skeletal Woodcutter"] = 0,
									["Enraging Ghoul"] = 23291,
									["Stormforged Infiltrator"] = 55371,
									["Onslaught Harbor Guard"] = 2549,
									["Mjordin Combatant"] = 223658,
									["Angry Oak Spirit"] = 68054,
									["Salramm the Fleshcrafter"] = 20313,
									["Chrono-Lord Epoch"] = 21131,
									["Niffelem Forefather"] = 72920,
									["Meathook"] = 32324,
								},
								["n_dmg"] = 498162,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 307,
								["total"] = 1261964,
								["c_max"] = 10075,
								["id"] = 57993,
								["r_dmg"] = 30811,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 174,
								["b_dmg"] = 53694,
								["r_amt"] = 6,
							},
							[1766] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Meathook"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1766,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[57965] = {
								["c_amt"] = 244,
								["b_amt"] = 0,
								["c_dmg"] = 343628,
								["g_amt"] = 0,
								["n_max"] = 1311,
								["targets"] = {
									["Vrykul Necrolord"] = 12668,
									["Skeletal Minion"] = 957,
									["Unbound Seer"] = 0,
									["Onslaught Gryphon Rider"] = 116095,
									["Stratholme Citizen"] = 421,
									["Shadow Vault Assaulter"] = 5467,
									["Angry Oak Spirit"] = 28046,
									["Grove Walker"] = 0,
									["Viscous Oil"] = 44400,
									["Lord Everblaze"] = 3616,
									["Crypt Fiend"] = 3921,
									["Converted Hero"] = 12100,
									["Skeletal Woodcutter"] = 0,
									["Master Necromancer"] = 5150,
									["Mjordin Combatant"] = 123801,
									["Ghoul Minion"] = 1696,
									["Niffelem Forefather"] = 62332,
									["Devouring Ghoul"] = 64090,
									["Maloric"] = 0,
									["Seething Revenant"] = 9154,
									["Sinewy Wolf"] = 0,
									["Restless Frostborn Warrior"] = 19979,
									["Acolyte"] = 9383,
									["Bile Golem"] = 87981,
									["Jotunheim Warrior"] = 25245,
									["Frostbrood Whelp"] = 19306,
									["Brittle Revenant"] = 57185,
									["Infinite Adversary"] = 26518,
									["Tomb Stalker"] = 26996,
									["Risen Zombie"] = 14303,
									["Ice Steppe Bull"] = 3049,
									["Cult Conspirator"] = 0,
									["Infinite Hunter"] = 11507,
									["Restless Frostborn Ghost"] = 29012,
									["Mal'Ganis"] = 68402,
									["Shadow Vault Abomination"] = 816,
									["Shadow Vault Skirmisher"] = 2994,
									["Disembodied Jormungar"] = 38631,
									["Ravenous Jormungar"] = 33328,
									["Roaming Jormungar"] = 27890,
									["Enraging Ghoul"] = 47185,
									["Stormforged Infiltrator"] = 22527,
									["Onslaught Harbor Guard"] = 3392,
									["Patchwork Construct"] = 13743,
									["Chrono-Lord Epoch"] = 52171,
									["Salramm the Fleshcrafter"] = 77842,
									["Dark Necromancer"] = 4152,
									["Infinite Agent"] = 21265,
									["Meathook"] = 66139,
								},
								["n_dmg"] = 961227,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1298,
								["total"] = 1304855,
								["c_max"] = 2031,
								["id"] = 57965,
								["r_dmg"] = 80782,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1054,
								["b_dmg"] = 0,
								["r_amt"] = 73,
							},
							[1833] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Mal'Ganis"] = 0,
									["Chrono-Lord Epoch"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1833,
								["r_dmg"] = 0,
								["IMMUNE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[57970] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1637,
								["targets"] = {
									["Vrykul Necrolord"] = 3095,
									["Skeletal Minion"] = 246,
									["Unbound Seer"] = 0,
									["Onslaught Gryphon Rider"] = 39894,
									["Shadow Vault Assaulter"] = 624,
									["Angry Oak Spirit"] = 10531,
									["Grove Walker"] = 0,
									["Viscous Oil"] = 11927,
									["Lord Everblaze"] = 2432,
									["Crypt Fiend"] = 1099,
									["Converted Hero"] = 4483,
									["Skeletal Woodcutter"] = 0,
									["Master Necromancer"] = 698,
									["Mjordin Combatant"] = 31919,
									["Ghoul Minion"] = 225,
									["Niffelem Forefather"] = 22284,
									["Devouring Ghoul"] = 30864,
									["Maloric"] = 0,
									["Seething Revenant"] = 3494,
									["Jotunheim Warrior"] = 7259,
									["Acolyte"] = 5664,
									["Bile Golem"] = 27421,
									["Roaming Jormungar"] = 6023,
									["Restless Frostborn Warrior"] = 3304,
									["Brittle Revenant"] = 18136,
									["Infinite Agent"] = 7807,
									["Tomb Stalker"] = 9258,
									["Risen Zombie"] = 570,
									["Ice Steppe Bull"] = 462,
									["Dark Necromancer"] = 1099,
									["Infinite Hunter"] = 4485,
									["Restless Frostborn Ghost"] = 10500,
									["Shadow Vault Abomination"] = 232,
									["Frostbrood Whelp"] = 6131,
									["Mal'Ganis"] = 24985,
									["Disembodied Jormungar"] = 19824,
									["Ravenous Jormungar"] = 13975,
									["Patchwork Construct"] = 4040,
									["Enraging Ghoul"] = 30795,
									["Stormforged Infiltrator"] = 7344,
									["Onslaught Harbor Guard"] = 2404,
									["Salramm the Fleshcrafter"] = 22960,
									["Chrono-Lord Epoch"] = 17361,
									["Infinite Adversary"] = 16066,
									["Cult Conspirator"] = 0,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 226,
									["Meathook"] = 20810,
								},
								["n_dmg"] = 452956,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 609,
								["total"] = 452956,
								["c_max"] = 0,
								["id"] = 57970,
								["r_dmg"] = 26066,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 609,
								["b_dmg"] = 0,
								["r_amt"] = 26,
							},
							[48672] = {
								["c_amt"] = 18,
								["b_amt"] = 0,
								["c_dmg"] = 22058,
								["g_amt"] = 0,
								["n_max"] = 698,
								["targets"] = {
									["Mal'Ganis"] = 8487,
									["Salramm the Fleshcrafter"] = 5301,
									["Chrono-Lord Epoch"] = 7799,
									["Bile Golem"] = 3580,
									["Meathook"] = 7789,
								},
								["n_dmg"] = 10898,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 36,
								["total"] = 32956,
								["c_max"] = 1438,
								["id"] = 48672,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 18,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[1776] = {
								["c_amt"] = 9,
								["b_amt"] = 0,
								["c_dmg"] = 11654,
								["g_amt"] = 0,
								["n_max"] = 724,
								["targets"] = {
									["Ravenous Jormungar"] = 1348,
									["Lord Everblaze"] = 724,
									["Vrykul Necrolord"] = 626,
									["Disembodied Jormungar"] = 12222,
									["Jotunheim Warrior"] = 1329,
									["Niffelem Forefather"] = 541,
									["Mjordin Combatant"] = 583,
								},
								["n_dmg"] = 5719,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 19,
								["total"] = 17373,
								["c_max"] = 1464,
								["id"] = 1776,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[56488] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 4820,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Chrono-Lord Epoch"] = 4820,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 4820,
								["c_max"] = 4820,
								["id"] = 56488,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[64590] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 10000,
								["targets"] = {
									["Boneguard Lieutenant"] = 21000,
									["Boneguard Footman"] = 60000,
									["Boneguard Commander"] = 46000,
									["Boneguard Scout"] = 240000,
								},
								["n_dmg"] = 367000,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 40,
								["total"] = 367000,
								["c_max"] = 0,
								["id"] = 64590,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 40,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[56350] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1293,
								["targets"] = {
									["Mal'Ganis"] = 1293,
								},
								["n_dmg"] = 1293,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 1293,
								["c_max"] = 0,
								["id"] = 56350,
								["r_dmg"] = 1293,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[64588] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 15000,
								["targets"] = {
									["Boneguard Footman"] = 90000,
									["Boneguard Commander"] = 4500,
									["Boneguard Lieutenant"] = 225000,
								},
								["n_dmg"] = 319500,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 319500,
								["c_max"] = 0,
								["id"] = 64588,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 24,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[62626] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2000,
								["targets"] = {
									["Melee Target"] = 28000,
									["Charge Target"] = 14800,
									["Sen'jin Valiant"] = 10000,
									["Thunder Bluff Valiant"] = 16400,
									["Undercity Valiant"] = 30000,
									["Orgrimmar Valiant"] = 12400,
									["Argent Valiant <Drushnak>"] = 4200,
									["Ranged Target"] = 10800,
								},
								["n_dmg"] = 126600,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 84,
								["total"] = 126600,
								["c_max"] = 0,
								["id"] = 62626,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 84,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[2764] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 1558,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Shadow Vault Skirmisher"] = 1558,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 1558,
								["c_max"] = 1558,
								["id"] = 2764,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[51723] = {
								["c_amt"] = 84,
								["b_amt"] = 6,
								["c_dmg"] = 77031,
								["g_amt"] = 0,
								["n_max"] = 700,
								["targets"] = {
									["Ravenous Jormungar"] = 1635,
									["Patchwork Construct"] = 1393,
									["Sinewy Wolf"] = 0,
									["Skeletal Minion"] = 1421,
									["Acolyte"] = 9866,
									["Bile Golem"] = 6729,
									["Onslaught Gryphon Rider"] = 1879,
									["Tomb Stalker"] = 11774,
									["Risen Zombie"] = 16636,
									["Shadow Vault Assaulter"] = 5421,
									["Dark Necromancer"] = 2227,
									["Infinite Hunter"] = 10506,
									["Shadow Vault Abomination"] = 294,
									["Crypt Fiend"] = 919,
									["Skeletal Minion <Master Necromancer>"] = 867,
									["Shadow Vault Skirmisher"] = 3323,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 887,
									["Master Necromancer"] = 3628,
									["Angry Oak Spirit"] = 0,
									["Enraging Ghoul"] = 18081,
									["Salramm the Fleshcrafter"] = 2491,
									["Ghoul Minion"] = 1400,
									["Infinite Agent"] = 11977,
									["Infinite Adversary"] = 16294,
									["Stratholme Citizen"] = 467,
									["Devouring Ghoul"] = 16582,
								},
								["n_dmg"] = 69666,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 240,
								["total"] = 146697,
								["c_max"] = 1234,
								["id"] = 51723,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 156,
								["b_dmg"] = 2264,
								["r_amt"] = 0,
							},
							[48664] = {
								["c_amt"] = 359,
								["b_amt"] = 22,
								["c_dmg"] = 632592,
								["g_amt"] = 0,
								["n_max"] = 1111,
								["targets"] = {
									["Vrykul Necrolord"] = 5779,
									["Unbound Seer"] = 0,
									["Onslaught Gryphon Rider"] = 108561,
									["Shadow Vault Assaulter"] = 2923,
									["Angry Oak Spirit"] = 42080,
									["Grove Walker"] = 0,
									["Viscous Oil"] = 56873,
									["Lord Everblaze"] = 3701,
									["Crypt Fiend"] = 2790,
									["Converted Hero"] = 18046,
									["Skeletal Woodcutter"] = 0,
									["Mjordin Combatant"] = 129237,
									["Niffelem Forefather"] = 50247,
									["Devouring Ghoul"] = 13097,
									["Ravenous Jormungar"] = 34669,
									["Seething Revenant"] = 7221,
									["Sinewy Wolf"] = 0,
									["Acolyte"] = 933,
									["Bile Golem"] = 15574,
									["Brittle Revenant"] = 74093,
									["Shadow Vault Abomination"] = 1216,
									["Tomb Stalker"] = 1704,
									["Frostbrood Whelp"] = 21229,
									["Ice Steppe Bull"] = 2285,
									["Cult Conspirator"] = 0,
									["Infinite Hunter"] = 2283,
									["Restless Frostborn Ghost"] = 31951,
									["Mal'Ganis"] = 17463,
									["Jotunheim Warrior"] = 26562,
									["Maloric"] = 0,
									["Disembodied Jormungar"] = 44386,
									["Infinite Agent"] = 3366,
									["Patchwork Construct"] = 4383,
									["Enraging Ghoul"] = 20226,
									["Stormforged Infiltrator"] = 27329,
									["Onslaught Harbor Guard"] = 4070,
									["Roaming Jormungar"] = 21415,
									["Restless Frostborn Warrior"] = 24546,
									["Infinite Adversary"] = 3175,
									["Salramm the Fleshcrafter"] = 15764,
									["Chrono-Lord Epoch"] = 16027,
									["Meathook"] = 16517,
								},
								["n_dmg"] = 239129,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 677,
								["total"] = 871721,
								["c_max"] = 2291,
								["id"] = 48664,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 318,
								["b_dmg"] = 16105,
								["r_amt"] = 0,
							},
							[48665] = {
								["c_amt"] = 370,
								["b_amt"] = 25,
								["c_dmg"] = 680151,
								["g_amt"] = 0,
								["n_max"] = 1212,
								["targets"] = {
									["Vrykul Necrolord"] = 9456,
									["Skeletal Minion"] = 845,
									["Unbound Seer"] = 0,
									["Onslaught Gryphon Rider"] = 121830,
									["Shadow Vault Assaulter"] = 6036,
									["Angry Oak Spirit"] = 44572,
									["Grove Walker"] = 0,
									["Viscous Oil"] = 57544,
									["Lord Everblaze"] = 2790,
									["Crypt Fiend"] = 3953,
									["Converted Hero"] = 16619,
									["Skeletal Woodcutter"] = 0,
									["Mjordin Combatant"] = 137404,
									["Niffelem Forefather"] = 48937,
									["Devouring Ghoul"] = 13626,
									["Ravenous Jormungar"] = 45298,
									["Seething Revenant"] = 6090,
									["Sinewy Wolf"] = 0,
									["Acolyte"] = 969,
									["Bile Golem"] = 17836,
									["Brittle Revenant"] = 71415,
									["Shadow Vault Abomination"] = 553,
									["Tomb Stalker"] = 4627,
									["Frostbrood Whelp"] = 25384,
									["Ice Steppe Bull"] = 1112,
									["Cult Conspirator"] = 0,
									["Infinite Hunter"] = 2587,
									["Restless Frostborn Ghost"] = 33280,
									["Mal'Ganis"] = 22372,
									["Jotunheim Warrior"] = 24102,
									["Maloric"] = 0,
									["Disembodied Jormungar"] = 50241,
									["Infinite Agent"] = 3750,
									["Patchwork Construct"] = 3058,
									["Enraging Ghoul"] = 23492,
									["Stormforged Infiltrator"] = 27897,
									["Onslaught Harbor Guard"] = 3825,
									["Roaming Jormungar"] = 29936,
									["Restless Frostborn Warrior"] = 23098,
									["Infinite Adversary"] = 4664,
									["Salramm the Fleshcrafter"] = 12906,
									["Chrono-Lord Epoch"] = 15326,
									["Meathook"] = 13513,
								},
								["n_dmg"] = 250792,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 686,
								["total"] = 930943,
								["c_max"] = 2630,
								["id"] = 48665,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 316,
								["b_dmg"] = 17864,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675422384,
					["delay"] = 0,
					["damage_taken"] = 366763.7442559999,
				}, -- [5]
				{
					["flag_original"] = 132370,
					["totalabsorbed"] = 2059.083371,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["aID"] = "4477-03B0B4D0",
					["total_without_pet"] = 2434391.083371,
					["dps_started"] = false,
					["total"] = 2434391.083371,
					["spec"] = 66,
					["on_hold"] = false,
					["isTank"] = true,
					["serial"] = "Player-4477-03B0B4D0",
					["damage_from"] = {
						["Patchwork Construct"] = true,
						["Skeletal Minion"] = true,
						["Ûrsus"] = true,
						["Bile Golem"] = true,
						["Atb"] = true,
						["Leayae"] = true,
						["Tomb Stalker"] = true,
						["Risen Zombie"] = true,
						["Stratholme Resident"] = true,
						["Dark Necromancer"] = true,
						["Infinite Hunter"] = true,
						["Mal'Ganis"] = true,
						["Crypt Fiend"] = true,
						["Skeletal Minion <Master Necromancer>"] = true,
						["Chrono-Lord Epoch"] = true,
						["Drushnak"] = true,
						["Enraging Ghoul"] = true,
						["Infinite Agent"] = true,
						["Infinite Adversary"] = true,
						["Ýurríi"] = true,
						["Master Necromancer"] = true,
						["Salramm the Fleshcrafter"] = true,
						["Meathook"] = true,
						["Acolyte"] = true,
						["Devouring Ghoul"] = true,
					},
					["targets"] = {
						["Patchwork Construct"] = 39663,
						["Skeletal Minion"] = 23732,
						["Acolyte"] = 75141,
						["Bile Golem"] = 213657,
						["Tomb Stalker"] = 178653,
						["Risen Zombie"] = 136175,
						["Stratholme Resident"] = 171,
						["Dark Necromancer"] = 37263,
						["Infinite Hunter"] = 99161,
						["Chrono-Lord Epoch"] = 112946,
						["Mal'Ganis"] = 161753,
						["Spider"] = 7,
						["Crypt Fiend"] = 28361,
						["Skeletal Minion <Master Necromancer>"] = 17055,
						["Stratholme Citizen"] = 2109,
						["Ghoul Minion <Salramm the Fleshcrafter>"] = 9753,
						["Master Necromancer"] = 87463,
						["Infinite Adversary"] = 157098,
						["Infinite Agent"] = 88592,
						["Ghoul Minion"] = 16222,
						["Rat"] = 7,
						["Salramm the Fleshcrafter"] = 129647,
						["Enraging Ghoul"] = 404605,
						["Meathook"] = 123432,
						["Devouring Ghoul"] = 291725,
					},
					["friendlyfire_total"] = 10425,
					["raid_targets"] = {
					},
					["boss_fight_component"] = true,
					["fight_component"] = true,
					["end_time"] = 1675425986,
					["friendlyfire"] = {
						["Leayae"] = {
							["spells"] = {
								[56488] = 10425,
							},
							["total"] = 10425,
						},
					},
					["classe"] = "PALADIN",
					["nome"] = "Leayae",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 95,
								["b_amt"] = 21,
								["c_dmg"] = 97777,
								["g_amt"] = 42,
								["n_max"] = 682,
								["targets"] = {
									["Patchwork Construct"] = 4670,
									["Skeletal Minion"] = 519,
									["Acolyte"] = 4496,
									["Bile Golem"] = 32634,
									["Tomb Stalker"] = 18316,
									["Risen Zombie"] = 9540,
									["Dark Necromancer"] = 2596,
									["Infinite Hunter"] = 8292,
									["Mal'Ganis"] = 23621,
									["Crypt Fiend"] = 909,
									["Enraging Ghoul"] = 30370,
									["Chrono-Lord Epoch"] = 14568,
									["Salramm the Fleshcrafter"] = 19014,
									["Infinite Agent"] = 4562,
									["Ghoul Minion"] = 521,
									["Infinite Adversary"] = 18746,
									["Master Necromancer"] = 10071,
									["Meathook"] = 23278,
									["Devouring Ghoul"] = 21342,
								},
								["n_dmg"] = 130936,
								["n_min"] = 0,
								["g_dmg"] = 19352,
								["counter"] = 420,
								["total"] = 248065,
								["c_max"] = 1374,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 13,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 270,
								["b_dmg"] = 9102,
								["r_amt"] = 0,
							}, -- [1]
							[53307] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 233,
								["targets"] = {
									["Crypt Fiend"] = 172,
									["Skeletal Minion <Master Necromancer>"] = 172,
									["Acolyte"] = 170,
									["Bile Golem"] = 2140,
									["Enraging Ghoul"] = 4156,
									["Meathook"] = 1218,
									["Skeletal Minion"] = 171,
									["Salramm the Fleshcrafter"] = 588,
									["Tomb Stalker"] = 1199,
									["Risen Zombie"] = 3223,
									["Stratholme Resident"] = 171,
									["Dark Necromancer"] = 340,
									["Devouring Ghoul"] = 3258,
								},
								["n_dmg"] = 16978,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 96,
								["total"] = 16978,
								["c_max"] = 0,
								["id"] = 53307,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 96,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[53742] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 821,
								["targets"] = {
									["Mal'Ganis"] = 14047,
									["Ghoul Minion"] = 354,
									["Risen Zombie"] = 246,
									["Salramm the Fleshcrafter"] = 14161,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 0,
									["Chrono-Lord Epoch"] = 10769,
								},
								["n_dmg"] = 39577,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 67,
								["total"] = 39577,
								["c_max"] = 0,
								["id"] = 53742,
								["r_dmg"] = 9630,
								["MISS"] = 4,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 63,
								["b_dmg"] = 0,
								["r_amt"] = 16,
							},
							[32747] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Mal'Ganis"] = 0,
									["Chrono-Lord Epoch"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 32747,
								["r_dmg"] = 0,
								["IMMUNE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[48817] = {
								["c_amt"] = 17,
								["b_amt"] = 0,
								["c_dmg"] = 29340,
								["g_amt"] = 0,
								["n_max"] = 1812,
								["targets"] = {
									["Patchwork Construct"] = 2435,
									["Crypt Fiend"] = 1371,
									["Bile Golem"] = 9549,
									["Enraging Ghoul"] = 20321,
									["Tomb Stalker"] = 8539,
									["Risen Zombie"] = 34599,
									["Ghoul Minion"] = 2692,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 1512,
									["Devouring Ghoul"] = 12246,
								},
								["n_dmg"] = 63924,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 67,
								["total"] = 93264,
								["c_max"] = 2806,
								["id"] = 48817,
								["r_dmg"] = 1512,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 49,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[48819] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 451,
								["targets"] = {
									["Patchwork Construct"] = 4845,
									["Skeletal Minion"] = 4319,
									["Acolyte"] = 10855,
									["Bile Golem"] = 26863,
									["Tomb Stalker"] = 25004,
									["Risen Zombie"] = 20514,
									["Dark Necromancer"] = 3290,
									["Infinite Hunter"] = 13787,
									["Mal'Ganis"] = 12149,
									["Crypt Fiend"] = 5318,
									["Skeletal Minion <Master Necromancer>"] = 4319,
									["Chrono-Lord Epoch"] = 8825,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 2559,
									["Master Necromancer"] = 14073,
									["Infinite Adversary"] = 22538,
									["Ghoul Minion"] = 2557,
									["Infinite Agent"] = 10543,
									["Rat"] = 7,
									["Salramm the Fleshcrafter"] = 10691,
									["Enraging Ghoul"] = 59328,
									["Meathook"] = 6218,
									["Devouring Ghoul"] = 40471,
								},
								["n_dmg"] = 309073,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 941,
								["total"] = 309073,
								["c_max"] = 0,
								["id"] = 48819,
								["r_dmg"] = 17847,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 940,
								["b_dmg"] = 0,
								["r_amt"] = 56,
							},
							[53595] = {
								["c_amt"] = 56,
								["b_amt"] = 8,
								["c_dmg"] = 196864,
								["g_amt"] = 0,
								["n_max"] = 2586,
								["targets"] = {
									["Patchwork Construct"] = 5969,
									["Skeletal Minion"] = 9534,
									["Acolyte"] = 20635,
									["Bile Golem"] = 48592,
									["Tomb Stalker"] = 45260,
									["Risen Zombie"] = 23190,
									["Dark Necromancer"] = 8941,
									["Infinite Hunter"] = 30278,
									["Mal'Ganis"] = 26029,
									["Crypt Fiend"] = 7627,
									["Skeletal Minion <Master Necromancer>"] = 5720,
									["Chrono-Lord Epoch"] = 19596,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 5682,
									["Master Necromancer"] = 24542,
									["Stratholme Citizen"] = 1833,
									["Infinite Adversary"] = 37591,
									["Infinite Agent"] = 33468,
									["Ghoul Minion"] = 7818,
									["Salramm the Fleshcrafter"] = 19356,
									["Enraging Ghoul"] = 104591,
									["Meathook"] = 17600,
									["Devouring Ghoul"] = 84813,
								},
								["n_dmg"] = 391801,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 273,
								["total"] = 588665,
								["c_max"] = 4654,
								["id"] = 53595,
								["r_dmg"] = 26254,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 217,
								["b_dmg"] = 13348,
								["r_amt"] = 10,
							},
							[69403] = {
								["c_amt"] = 245,
								["b_amt"] = 43,
								["c_dmg"] = 139999,
								["g_amt"] = 0,
								["n_max"] = 435,
								["targets"] = {
									["Patchwork Construct"] = 6610,
									["Skeletal Minion"] = 6183,
									["Acolyte"] = 17075,
									["Bile Golem"] = 37248,
									["Tomb Stalker"] = 35325,
									["Risen Zombie"] = 26991,
									["Dark Necromancer"] = 8642,
									["Infinite Hunter"] = 21058,
									["Crypt Fiend"] = 7700,
									["Skeletal Minion <Master Necromancer>"] = 5472,
									["Master Necromancer"] = 14906,
									["Meathook"] = 19540,
									["Infinite Adversary"] = 28293,
									["Infinite Agent"] = 21376,
									["Stratholme Citizen"] = 276,
									["Enraging Ghoul"] = 77467,
									["Devouring Ghoul"] = 61064,
								},
								["n_dmg"] = 255227,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1165,
								["total"] = 395226,
								["c_max"] = 882,
								["id"] = 69403,
								["r_dmg"] = 11365,
								["MISS"] = 23,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["BLOCK"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 896,
								["b_dmg"] = 9735,
								["r_amt"] = 33,
							},
							[61411] = {
								["c_amt"] = 16,
								["b_amt"] = 1,
								["c_dmg"] = 108977,
								["g_amt"] = 0,
								["n_max"] = 4638,
								["targets"] = {
									["Patchwork Construct"] = 10262,
									["Acolyte"] = 9090,
									["Bile Golem"] = 35456,
									["Tomb Stalker"] = 22323,
									["Dark Necromancer"] = 7466,
									["Infinite Hunter"] = 11076,
									["Mal'Ganis"] = 40903,
									["Crypt Fiend"] = 3865,
									["Master Necromancer"] = 6238,
									["Chrono-Lord Epoch"] = 22595,
									["Enraging Ghoul"] = 47245,
									["Infinite Adversary"] = 25293,
									["Ghoul Minion"] = 2168,
									["Infinite Agent"] = 9772,
									["Salramm the Fleshcrafter"] = 31033,
									["Meathook"] = 36506,
									["Devouring Ghoul"] = 23752,
								},
								["n_dmg"] = 236066,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 91,
								["total"] = 345043,
								["c_max"] = 9277,
								["id"] = 61411,
								["r_dmg"] = 35060,
								["MISS"] = 3,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 72,
								["b_dmg"] = 2810,
								["r_amt"] = 9,
							},
							[48827] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 13310,
								["g_amt"] = 0,
								["n_max"] = 2145,
								["targets"] = {
									["Chrono-Lord Epoch"] = 3763,
									["Mal'Ganis"] = 3358,
									["Patchwork Construct"] = 1662,
									["Infinite Hunter"] = 3317,
									["Infinite Agent"] = 6060,
									["Acolyte"] = 7883,
									["Bile Golem"] = 2963,
									["Master Necromancer"] = 4691,
									["Infinite Adversary"] = 7516,
									["Salramm the Fleshcrafter"] = 3629,
									["Meathook"] = 3178,
									["Tomb Stalker"] = 6214,
									["Risen Zombie"] = 8906,
									["Enraging Ghoul"] = 15465,
									["Dark Necromancer"] = 1424,
									["Devouring Ghoul"] = 14564,
								},
								["n_dmg"] = 81283,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 57,
								["total"] = 94593,
								["c_max"] = 3097,
								["id"] = 48827,
								["r_dmg"] = 2972,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 52,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							},
							[48952] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 988,
								["targets"] = {
									["Mal'Ganis"] = 5072,
									["Skeletal Minion"] = 1472,
									["Acolyte"] = 1456,
									["Bile Golem"] = 5908,
									["Enraging Ghoul"] = 15547,
									["Chrono-Lord Epoch"] = 2957,
									["Infinite Hunter"] = 1416,
									["Tomb Stalker"] = 3134,
									["Salramm the Fleshcrafter"] = 2305,
									["Infinite Adversary"] = 6373,
									["Meathook"] = 3325,
									["Devouring Ghoul"] = 7358,
								},
								["n_dmg"] = 56323,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 77,
								["total"] = 56323,
								["c_max"] = 0,
								["id"] = 48952,
								["r_dmg"] = 4292,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 77,
								["b_dmg"] = 0,
								["r_amt"] = 6,
							},
							[56488] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 8082,
								["g_amt"] = 0,
								["n_max"] = 3520,
								["targets"] = {
									["Patchwork Construct"] = 2600,
									["Spider"] = 7,
									["Bile Golem"] = 3155,
									["Enraging Ghoul"] = 13124,
									["Infinite Hunter"] = 3023,
									["Risen Zombie"] = 3022,
									["Infinite Adversary"] = 1383,
									["Master Necromancer"] = 4042,
									["Devouring Ghoul"] = 9641,
								},
								["n_dmg"] = 31915,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 39997,
								["c_max"] = 4042,
								["id"] = 56488,
								["r_dmg"] = 2600,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 14,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[63529] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Salramm the Fleshcrafter"] = 0,
									["Mal'Ganis"] = 0,
									["Chrono-Lord Epoch"] = 0,
									["Meathook"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 63529,
								["r_dmg"] = 0,
								["IMMUNE"] = 8,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[56350] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 3366,
								["g_amt"] = 0,
								["n_max"] = 2336,
								["targets"] = {
									["Skeletal Minion"] = 1534,
									["Bile Golem"] = 2827,
									["Tomb Stalker"] = 6394,
									["Risen Zombie"] = 2247,
									["Dark Necromancer"] = 1655,
									["Infinite Hunter"] = 3550,
									["Mal'Ganis"] = 2087,
									["Crypt Fiend"] = 1399,
									["Skeletal Minion <Master Necromancer>"] = 1372,
									["Master Necromancer"] = 1461,
									["Devouring Ghoul"] = 3233,
									["Chrono-Lord Epoch"] = 1626,
									["Infinite Agent"] = 2811,
									["Infinite Adversary"] = 4512,
									["Salramm the Fleshcrafter"] = 2336,
									["Enraging Ghoul"] = 4727,
									["Meathook"] = 1768,
								},
								["n_dmg"] = 42173,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 30,
								["total"] = 45539,
								["c_max"] = 3366,
								["id"] = 56350,
								["r_dmg"] = 1626,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 29,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[48806] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2470,
								["targets"] = {
									["Mal'Ganis"] = 4855,
									["Chrono-Lord Epoch"] = 2299,
									["Meathook"] = 2408,
								},
								["n_dmg"] = 9562,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 9562,
								["c_max"] = 0,
								["id"] = 48806,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[20467] = {
								["c_amt"] = 13,
								["b_amt"] = 0,
								["c_dmg"] = 16633,
								["g_amt"] = 0,
								["n_max"] = 824,
								["targets"] = {
									["Patchwork Construct"] = 610,
									["Acolyte"] = 606,
									["Bile Golem"] = 4387,
									["Enraging Ghoul"] = 7426,
									["Infinite Hunter"] = 574,
									["Master Necromancer"] = 3607,
									["Tomb Stalker"] = 3075,
									["Infinite Adversary"] = 1596,
									["Meathook"] = 6458,
									["Dark Necromancer"] = 1341,
									["Devouring Ghoul"] = 2707,
								},
								["n_dmg"] = 15754,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 40,
								["total"] = 32387,
								["c_max"] = 1615,
								["id"] = 20467,
								["r_dmg"] = 1116,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 27,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[28730] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Mal'Ganis"] = 0,
									["Chrono-Lord Epoch"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 28730,
								["r_dmg"] = 0,
								["IMMUNE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[67485] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 15830,
								["g_amt"] = 0,
								["n_max"] = 2523,
								["targets"] = {
									["Chrono-Lord Epoch"] = 4197,
									["Acolyte"] = 2875,
									["Bile Golem"] = 1935,
									["Enraging Ghoul"] = 4838,
									["Master Necromancer"] = 3832,
									["Infinite Hunter"] = 2790,
									["Infinite Adversary"] = 3257,
									["Tomb Stalker"] = 3870,
									["Risen Zombie"] = 3582,
									["Meathook"] = 1935,
									["Dark Necromancer"] = 1568,
									["Devouring Ghoul"] = 7276,
								},
								["n_dmg"] = 26125,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 21,
								["total"] = 41955,
								["c_max"] = 2903,
								["id"] = 67485,
								["r_dmg"] = 1674,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 15,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[53739] = {
								["c_amt"] = 27,
								["b_amt"] = 0,
								["c_dmg"] = 15967,
								["g_amt"] = 0,
								["n_max"] = 441,
								["targets"] = {
									["Mal'Ganis"] = 20387,
									["Ghoul Minion"] = 112,
									["Risen Zombie"] = 115,
									["Salramm the Fleshcrafter"] = 17041,
									["Chrono-Lord Epoch"] = 13856,
								},
								["n_dmg"] = 35544,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 142,
								["total"] = 51511,
								["c_max"] = 745,
								["id"] = 53739,
								["r_dmg"] = 12346,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 115,
								["b_dmg"] = 0,
								["r_amt"] = 41,
							},
							[53733] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 13943,
								["g_amt"] = 0,
								["n_max"] = 1425,
								["targets"] = {
									["Salramm the Fleshcrafter"] = 9493,
									["Mal'Ganis"] = 9245,
									["Chrono-Lord Epoch"] = 7895,
								},
								["n_dmg"] = 12690,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 15,
								["total"] = 26633,
								["c_max"] = 3168,
								["id"] = 53733,
								["r_dmg"] = 6305,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 4,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["avoidance"] = {
						["overall"] = {
							["DODGE"] = 0,
							["FULL_ABSORB_AMT"] = 0,
							["BLOCKED_AMT"] = 0,
							["BLOCKED_HITS"] = 0,
							["FULL_ABSORBED"] = 0,
							["ALL"] = 0,
							["PARTIAL_ABSORBED"] = 0,
							["PARRY"] = 0,
							["PARTIAL_ABSORB_AMT"] = 0,
							["ABSORB"] = 0,
							["ABSORB_AMT"] = 0,
							["FULL_HIT"] = 0,
							["HITS"] = 0,
							["FULL_HIT_AMT"] = 0,
						},
					},
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675425153,
					["delay"] = 0,
					["damage_taken"] = 803498.083371,
				}, -- [6]
				{
					["flag_original"] = 2584,
					["totalabsorbed"] = 0.03452,
					["damage_from"] = {
					},
					["targets"] = {
						["Risen Zombie"] = 524,
						["Stratholme Resident"] = 777,
						["Stratholme Citizen"] = 544,
					},
					["serial"] = "Creature-0-4445-595-881-27747-0000DCF82D",
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 1845.03452,
					["aID"] = "27747",
					["dps_started"] = false,
					["total"] = 1845.03452,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "High Elf Mage-Priest",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Stratholme Citizen"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[34232] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 86,
								["targets"] = {
									["Risen Zombie"] = 524,
									["Stratholme Resident"] = 777,
									["Stratholme Citizen"] = 544,
								},
								["n_dmg"] = 1845,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 1845,
								["c_max"] = 0,
								["id"] = 34232,
								["r_dmg"] = 0,
								["MISS"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 25,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["boss_fight_component"] = true,
					["end_time"] = 1675425986,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.03452,
					["start_time"] = 1675425910,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [7]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 32377.058937,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ûrsus"] = 18170,
						["Leayae"] = 77817,
						["Drushnak"] = 8638,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-27729-00005CF82D",
					["damage_from"] = {
						["Shadowfiend <Atb>"] = true,
						["Leayae"] = true,
						["Ýurríi"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Drushnak"] = true,
					},
					["aID"] = "27729",
					["raid_targets"] = {
					},
					["total_without_pet"] = 104625.058937,
					["friendlyfire_total"] = 0,
					["friendlyfire"] = {
					},
					["monster"] = true,
					["end_time"] = 1675425986,
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["nome"] = "Enraging Ghoul",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 22,
								["c_dmg"] = 7450,
								["g_amt"] = 0,
								["n_max"] = 4401,
								["targets"] = {
									["Ûrsus"] = 18170,
									["Leayae"] = 77817,
									["Drushnak"] = 8638,
								},
								["n_dmg"] = 97175,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 199,
								["a_dmg"] = 35408,
								["total"] = 104625,
								["c_max"] = 7450,
								["DODGE"] = 67,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 13,
								["extra"] = {
								},
								["BLOCK"] = 16,
								["PARRY"] = 33,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 13,
								["n_amt"] = 69,
								["b_dmg"] = 11610,
								["r_amt"] = 0,
							}, -- [1]
							[52461] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 52461,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 18,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[1604] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Ûrsus"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1604,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 104625.058937,
					["on_hold"] = false,
					["last_event"] = 0,
					["dps_started"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675425705,
					["delay"] = 0,
					["damage_taken"] = 1637987.058937,
				}, -- [8]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.10784,
					["damage_from"] = {
						["Patchwork Construct"] = true,
						["Acolyte"] = true,
						["Ghoul Minion <Salramm the Fleshcrafter>"] = true,
						["Chrono-Lord Epoch"] = true,
						["Bile Golem"] = true,
						["Ghoul Minion <Salramm the Fleshcrafter> <Salramm the Fleshcrafter>"] = true,
						["Mal'Ganis"] = true,
						["Ghoul Minion"] = true,
						["Infinite Agent"] = true,
						["Risen Zombie"] = true,
						["Infinite Adversary"] = true,
						["Meathook"] = true,
					},
					["targets"] = {
						["Patchwork Construct"] = 80134,
						["Skeletal Minion"] = 14988,
						["Acolyte"] = 114363,
						["Bile Golem"] = 243829,
						["Tomb Stalker"] = 142593,
						["Risen Zombie"] = 44855,
						["Dark Necromancer"] = 52617,
						["Infinite Hunter"] = 171092,
						["Mal'Ganis"] = 310978,
						["Spider"] = 7,
						["Crypt Fiend"] = 42767,
						["Skeletal Minion <Master Necromancer>"] = 17662,
						["Ghoul Minion <Salramm the Fleshcrafter>"] = 1516,
						["Master Necromancer"] = 113303,
						["Chrono-Lord Epoch"] = 279871,
						["Salramm the Fleshcrafter"] = 210089,
						["Infinite Agent"] = 130401,
						["Ghoul Minion"] = 3264,
						["Infinite Adversary"] = 210442,
						["Enraging Ghoul"] = 415993,
						["Meathook"] = 230897,
						["Devouring Ghoul"] = 335381,
					},
					["last_event"] = 0,
					["pets"] = {
						"Treant <Ýurríi>", -- [1]
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire"] = {
						["Leayae"] = {
							["spells"] = {
								[64205] = 0,
							},
							["total"] = 302,
						},
					},
					["classe"] = "DRUID",
					["raid_targets"] = {
					},
					["total_without_pet"] = 3106373.10784,
					["on_hold"] = false,
					["friendlyfire_total"] = 302,
					["dps_started"] = false,
					["end_time"] = 1675425986,
					["spec"] = 102,
					["serial"] = "Player-4477-03859A52",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[48465] = {
								["c_amt"] = 43,
								["b_amt"] = 0,
								["c_dmg"] = 489182,
								["g_amt"] = 0,
								["n_max"] = 7336,
								["targets"] = {
									["Mal'Ganis"] = 132361,
									["Skeletal Minion"] = 273,
									["Chrono-Lord Epoch"] = 95217,
									["Bile Golem"] = 36731,
									["Master Necromancer"] = 18521,
									["Infinite Hunter"] = 6913,
									["Infinite Agent"] = 18732,
									["Infinite Adversary"] = 31276,
									["Tomb Stalker"] = 7278,
									["Salramm the Fleshcrafter"] = 52993,
									["Enraging Ghoul"] = 23090,
									["Meathook"] = 133890,
									["Devouring Ghoul"] = 53540,
								},
								["n_dmg"] = 121633,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 63,
								["total"] = 610815,
								["c_max"] = 15393,
								["id"] = 48465,
								["r_dmg"] = 86807,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 20,
								["b_dmg"] = 0,
								["r_amt"] = 9,
							},
							[48466] = {
								["c_amt"] = 187,
								["b_amt"] = 0,
								["c_dmg"] = 298339,
								["g_amt"] = 0,
								["n_max"] = 1266,
								["targets"] = {
									["Infinite Hunter"] = 45400,
									["Patchwork Construct"] = 16903,
									["Spider"] = 7,
									["Crypt Fiend"] = 24861,
									["Skeletal Minion"] = 13027,
									["Acolyte"] = 64148,
									["Bile Golem"] = 104810,
									["Enraging Ghoul"] = 194158,
									["Skeletal Minion <Master Necromancer>"] = 13302,
									["Master Necromancer"] = 38993,
									["Infinite Adversary"] = 70337,
									["Tomb Stalker"] = 104189,
									["Risen Zombie"] = 10458,
									["Infinite Agent"] = 34929,
									["Dark Necromancer"] = 33364,
									["Devouring Ghoul"] = 141493,
								},
								["n_dmg"] = 612040,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 763,
								["total"] = 910379,
								["c_max"] = 1956,
								["id"] = 48466,
								["r_dmg"] = 10606,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 576,
								["b_dmg"] = 0,
								["r_amt"] = 10,
							},
							[48468] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1426,
								["targets"] = {
									["Patchwork Construct"] = 14754,
									["Chrono-Lord Epoch"] = 20654,
									["Salramm the Fleshcrafter"] = 7251,
									["Mal'Ganis"] = 32521,
									["Meathook"] = 15480,
									["Enraging Ghoul"] = 7822,
								},
								["n_dmg"] = 98482,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 86,
								["total"] = 98482,
								["c_max"] = 0,
								["id"] = 48468,
								["r_dmg"] = 20901,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 86,
								["b_dmg"] = 0,
								["r_amt"] = 21,
							},
							[48461] = {
								["c_amt"] = 48,
								["b_amt"] = 0,
								["c_dmg"] = 344559,
								["g_amt"] = 0,
								["n_max"] = 4701,
								["targets"] = {
									["Chrono-Lord Epoch"] = 98592,
									["Mal'Ganis"] = 79219,
									["Patchwork Construct"] = 21695,
									["Crypt Fiend"] = 17906,
									["Infinite Agent"] = 24890,
									["Infinite Adversary"] = 16648,
									["Bile Golem"] = 37283,
									["Master Necromancer"] = 32492,
									["Infinite Hunter"] = 69669,
									["Salramm the Fleshcrafter"] = 114418,
									["Meathook"] = 81527,
									["Tomb Stalker"] = 31126,
									["Risen Zombie"] = 1511,
									["Enraging Ghoul"] = 53979,
									["Dark Necromancer"] = 19253,
									["Devouring Ghoul"] = 62498,
								},
								["n_dmg"] = 418147,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 176,
								["total"] = 762706,
								["c_max"] = 9876,
								["id"] = 48461,
								["r_dmg"] = 95929,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 128,
								["b_dmg"] = 0,
								["r_amt"] = 23,
							},
							[53307] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 161,
								["targets"] = {
									["Risen Zombie"] = 3036,
								},
								["n_dmg"] = 3036,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 19,
								["total"] = 3036,
								["c_max"] = 0,
								["id"] = 53307,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 19,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[53195] = {
								["c_amt"] = 54,
								["b_amt"] = 0,
								["c_dmg"] = 191983,
								["g_amt"] = 0,
								["n_max"] = 2262,
								["targets"] = {
									["Patchwork Construct"] = 6925,
									["Chrono-Lord Epoch"] = 25723,
									["Mal'Ganis"] = 27912,
									["Skeletal Minion <Master Necromancer>"] = 1855,
									["Acolyte"] = 24398,
									["Bile Golem"] = 27989,
									["Master Necromancer"] = 9610,
									["Infinite Hunter"] = 21323,
									["Infinite Adversary"] = 51693,
									["Infinite Agent"] = 21128,
									["Ghoul Minion"] = 1636,
									["Risen Zombie"] = 6242,
									["Salramm the Fleshcrafter"] = 26995,
									["Enraging Ghoul"] = 74499,
									["Devouring Ghoul"] = 26632,
								},
								["n_dmg"] = 162577,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 151,
								["total"] = 354560,
								["c_max"] = 4629,
								["id"] = 53195,
								["r_dmg"] = 29750,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 97,
								["b_dmg"] = 0,
								["r_amt"] = 13,
							},
							[48463] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 61,
								["g_amt"] = 0,
								["n_max"] = 1143,
								["targets"] = {
									["Risen Zombie"] = 2144,
									["Patchwork Construct"] = 4374,
									["Infinite Adversary"] = 1143,
									["Devouring Ghoul"] = 5754,
								},
								["n_dmg"] = 13354,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 18,
								["total"] = 13415,
								["c_max"] = 61,
								["id"] = 48463,
								["r_dmg"] = 2912,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 17,
								["b_dmg"] = 0,
								["r_amt"] = 4,
							},
							[53190] = {
								["c_amt"] = 134,
								["b_amt"] = 0,
								["c_dmg"] = 152430,
								["g_amt"] = 0,
								["n_max"] = 731,
								["targets"] = {
									["Patchwork Construct"] = 14795,
									["Skeletal Minion"] = 1688,
									["Acolyte"] = 23659,
									["Bile Golem"] = 37016,
									["Risen Zombie"] = 13097,
									["Infinite Hunter"] = 27169,
									["Mal'Ganis"] = 8346,
									["Skeletal Minion <Master Necromancer>"] = 2505,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 1516,
									["Master Necromancer"] = 13687,
									["Chrono-Lord Epoch"] = 9635,
									["Infinite Agent"] = 29487,
									["Ghoul Minion"] = 1628,
									["Infinite Adversary"] = 38391,
									["Enraging Ghoul"] = 60540,
									["Salramm the Fleshcrafter"] = 8432,
									["Devouring Ghoul"] = 43229,
								},
								["n_dmg"] = 182390,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 470,
								["total"] = 334820,
								["c_max"] = 1529,
								["id"] = 53190,
								["r_dmg"] = 17497,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 336,
								["b_dmg"] = 0,
								["r_amt"] = 23,
							},
							[61391] = {
								["c_amt"] = 8,
								["b_amt"] = 0,
								["c_dmg"] = 6370,
								["g_amt"] = 0,
								["n_max"] = 688,
								["targets"] = {
									["Infinite Hunter"] = 618,
									["Patchwork Construct"] = 688,
									["Risen Zombie"] = 8367,
									["Infinite Adversary"] = 954,
									["Infinite Agent"] = 1235,
									["Acolyte"] = 2158,
									["Enraging Ghoul"] = 1905,
									["Devouring Ghoul"] = 2235,
								},
								["n_dmg"] = 11790,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 33,
								["total"] = 18160,
								["c_max"] = 954,
								["id"] = 61391,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 25,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["total"] = 3167042.10784,
					["aID"] = "4477-03859A52",
					["nome"] = "Ýurríi",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675425310,
					["delay"] = 0,
					["damage_taken"] = 134205.10784,
				}, -- [9]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 36800.032347,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Atb"] = 5858,
						["Ûrsus"] = 50355,
						["Leayae"] = 82612,
						["Drushnak"] = 11234,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-28249-00005CF82D",
					["damage_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Ýurríi"] = true,
						["Drushnak"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 150059.032347,
					["fight_component"] = true,
					["friendlyfire_total"] = 0,
					["monster"] = true,
					["end_time"] = 1675425986,
					["aID"] = "28249",
					["dps_started"] = false,
					["nome"] = "Devouring Ghoul",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 12,
								["c_dmg"] = 14853,
								["g_amt"] = 0,
								["n_max"] = 5858,
								["targets"] = {
									["Atb"] = 5858,
									["Ûrsus"] = 39778,
									["Leayae"] = 41596,
									["Drushnak"] = 5462,
								},
								["n_dmg"] = 77841,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 105,
								["a_dmg"] = 20058,
								["total"] = 92694,
								["c_max"] = 7538,
								["DODGE"] = 20,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 17,
								["extra"] = {
								},
								["BLOCK"] = 5,
								["PARRY"] = 17,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 9,
								["n_amt"] = 44,
								["b_dmg"] = 3964,
								["r_amt"] = 0,
							}, -- [1]
							[58758] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5772,
								["targets"] = {
									["Ûrsus"] = 10577,
									["Leayae"] = 41016,
									["Drushnak"] = 5772,
								},
								["n_dmg"] = 57365,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 17,
								["total"] = 57365,
								["c_max"] = 0,
								["id"] = 58758,
								["r_dmg"] = 0,
								["a_dmg"] = 27975,
								["DODGE"] = 3,
								["extra"] = {
								},
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 17,
								["a_amt"] = 6,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 150059.032347,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675425778,
					["delay"] = 0,
					["damage_taken"] = 1375902.032347,
				}, -- [10]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.124249,
					["damage_from"] = {
						["Patchwork Construct"] = true,
						["Skeletal Minion"] = true,
						["Acolyte"] = true,
						["Bile Golem"] = true,
						["Tomb Stalker"] = true,
						["Risen Zombie"] = true,
						["Dark Necromancer"] = true,
						["Infinite Hunter"] = true,
						["Mal'Ganis"] = true,
						["Master Necromancer"] = true,
						["Meathook"] = true,
						["Enraging Ghoul"] = true,
						["Chrono-Lord Epoch"] = true,
						["Salramm the Fleshcrafter"] = true,
						["Infinite Adversary"] = true,
						["Skeletal Minion <Master Necromancer> <Master Necromancer>"] = true,
						["Devouring Ghoul"] = true,
					},
					["targets"] = {
						["Patchwork Construct"] = 67023,
						["Skeletal Minion"] = 9546,
						["Acolyte"] = 86271,
						["Bile Golem"] = 258321,
						["Tomb Stalker"] = 278690,
						["Risen Zombie"] = 48341,
						["Dark Necromancer"] = 63010,
						["Infinite Hunter"] = 129949,
						["Mal'Ganis"] = 162043,
						["Crypt Fiend"] = 30769,
						["Skeletal Minion <Master Necromancer>"] = 18135,
						["Chrono-Lord Epoch"] = 178589,
						["Ghoul Minion <Salramm the Fleshcrafter>"] = 19488,
						["Master Necromancer"] = 151865,
						["Infinite Adversary"] = 229185,
						["Ghoul Minion"] = 8792,
						["Infinite Agent"] = 138808,
						["Rat"] = 14,
						["Salramm the Fleshcrafter"] = 233099,
						["Enraging Ghoul"] = 440038,
						["Meathook"] = 226462,
						["Devouring Ghoul"] = 401220,
					},
					["last_event"] = 0,
					["pets"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire"] = {
						["Leayae"] = {
							["spells"] = {
								[64205] = 0,
							},
							["total"] = 5292,
						},
					},
					["classe"] = "WARRIOR",
					["raid_targets"] = {
					},
					["total_without_pet"] = 3179658.124249,
					["on_hold"] = false,
					["friendlyfire_total"] = 5292,
					["dps_started"] = false,
					["end_time"] = 1675425986,
					["spec"] = 71,
					["serial"] = "Player-4477-03A11F28",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 71,
								["b_amt"] = 6,
								["c_dmg"] = 218673,
								["g_amt"] = 14,
								["n_max"] = 2178,
								["targets"] = {
									["Patchwork Construct"] = 13029,
									["Acolyte"] = 1516,
									["Bile Golem"] = 51299,
									["Tomb Stalker"] = 33987,
									["Risen Zombie"] = 12205,
									["Dark Necromancer"] = 13589,
									["Infinite Hunter"] = 26720,
									["Mal'Ganis"] = 28402,
									["Skeletal Minion <Master Necromancer>"] = 3376,
									["Master Necromancer"] = 15538,
									["Chrono-Lord Epoch"] = 27191,
									["Salramm the Fleshcrafter"] = 32656,
									["Infinite Adversary"] = 24102,
									["Rat"] = 14,
									["Infinite Agent"] = 9260,
									["Enraging Ghoul"] = 25728,
									["Meathook"] = 21739,
									["Devouring Ghoul"] = 36823,
								},
								["n_dmg"] = 138744,
								["n_min"] = 0,
								["g_dmg"] = 19757,
								["counter"] = 174,
								["total"] = 377174,
								["c_max"] = 4467,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 89,
								["b_dmg"] = 8344,
								["r_amt"] = 0,
							}, -- [1]
							[50782] = {
								["c_amt"] = 7,
								["b_amt"] = 0,
								["c_dmg"] = 27236,
								["g_amt"] = 0,
								["n_max"] = 2296,
								["targets"] = {
									["Patchwork Construct"] = 3405,
									["Bile Golem"] = 3492,
									["Master Necromancer"] = 2014,
									["Devouring Ghoul"] = 3653,
									["Mal'Ganis"] = 11528,
									["Tomb Stalker"] = 1930,
									["Salramm the Fleshcrafter"] = 1953,
									["Chrono-Lord Epoch"] = 19366,
									["Infinite Adversary"] = 1074,
									["Meathook"] = 10216,
								},
								["n_dmg"] = 31395,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 58631,
								["c_max"] = 5073,
								["id"] = 50782,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 17,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[47520] = {
								["c_amt"] = 46,
								["b_amt"] = 4,
								["c_dmg"] = 204977,
								["g_amt"] = 0,
								["n_max"] = 2462,
								["targets"] = {
									["Patchwork Construct"] = 7352,
									["Infinite Hunter"] = 9022,
									["Skeletal Minion <Master Necromancer>"] = 4279,
									["Acolyte"] = 18956,
									["Bile Golem"] = 12439,
									["Enraging Ghoul"] = 46644,
									["Master Necromancer"] = 13085,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 4537,
									["Infinite Adversary"] = 19377,
									["Tomb Stalker"] = 26609,
									["Salramm the Fleshcrafter"] = 8916,
									["Infinite Agent"] = 22657,
									["Dark Necromancer"] = 15786,
									["Devouring Ghoul"] = 44572,
								},
								["n_dmg"] = 49254,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 72,
								["total"] = 254231,
								["c_max"] = 5845,
								["id"] = 47520,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 26,
								["b_dmg"] = 7383,
								["r_amt"] = 0,
							},
							[7384] = {
								["c_amt"] = 57,
								["b_amt"] = 0,
								["c_dmg"] = 254816,
								["g_amt"] = 0,
								["n_max"] = 2373,
								["targets"] = {
									["Patchwork Construct"] = 10824,
									["Chrono-Lord Epoch"] = 34529,
									["Mal'Ganis"] = 25302,
									["Acolyte"] = 4911,
									["Bile Golem"] = 28676,
									["Enraging Ghoul"] = 19483,
									["Risen Zombie"] = 1511,
									["Infinite Agent"] = 4805,
									["Infinite Adversary"] = 19701,
									["Tomb Stalker"] = 23952,
									["Salramm the Fleshcrafter"] = 36866,
									["Master Necromancer"] = 14774,
									["Meathook"] = 30558,
									["Devouring Ghoul"] = 23216,
								},
								["n_dmg"] = 24292,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 69,
								["total"] = 279108,
								["c_max"] = 6116,
								["id"] = 7384,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[12723] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 6154,
								["targets"] = {
									["Infinite Hunter"] = 10435,
									["Skeletal Minion <Master Necromancer>"] = 2116,
									["Acolyte"] = 18515,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 3576,
									["Enraging Ghoul"] = 36460,
									["Master Necromancer"] = 9568,
									["Ghoul Minion"] = 1548,
									["Risen Zombie"] = 169,
									["Tomb Stalker"] = 13651,
									["Infinite Adversary"] = 19316,
									["Infinite Agent"] = 4841,
									["Dark Necromancer"] = 7820,
									["Devouring Ghoul"] = 59649,
								},
								["n_dmg"] = 187664,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 60,
								["total"] = 187664,
								["c_max"] = 0,
								["id"] = 12723,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 60,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[47465] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1216,
								["targets"] = {
									["Patchwork Construct"] = 7419,
									["Chrono-Lord Epoch"] = 14124,
									["Mal'Ganis"] = 11830,
									["Acolyte"] = 1678,
									["Bile Golem"] = 22785,
									["Master Necromancer"] = 6027,
									["Infinite Hunter"] = 8133,
									["Infinite Adversary"] = 4033,
									["Meathook"] = 15804,
									["Tomb Stalker"] = 10946,
									["Salramm the Fleshcrafter"] = 14601,
									["Enraging Ghoul"] = 7830,
									["Dark Necromancer"] = 868,
									["Devouring Ghoul"] = 10895,
								},
								["n_dmg"] = 136973,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 144,
								["total"] = 136973,
								["c_max"] = 0,
								["id"] = 47465,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 144,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[47502] = {
								["c_amt"] = 78,
								["b_amt"] = 2,
								["c_dmg"] = 144398,
								["g_amt"] = 0,
								["n_max"] = 1182,
								["targets"] = {
									["Patchwork Construct"] = 5448,
									["Skeletal Minion"] = 4746,
									["Acolyte"] = 24132,
									["Bile Golem"] = 19466,
									["Tomb Stalker"] = 23030,
									["Risen Zombie"] = 21270,
									["Dark Necromancer"] = 8163,
									["Infinite Hunter"] = 12295,
									["Crypt Fiend"] = 884,
									["Skeletal Minion <Master Necromancer>"] = 3666,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 2122,
									["Master Necromancer"] = 9692,
									["Infinite Adversary"] = 12236,
									["Ghoul Minion"] = 934,
									["Salramm the Fleshcrafter"] = 3014,
									["Infinite Agent"] = 12419,
									["Enraging Ghoul"] = 46201,
									["Devouring Ghoul"] = 41982,
								},
								["n_dmg"] = 107302,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 201,
								["total"] = 251700,
								["c_max"] = 2706,
								["id"] = 47502,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 123,
								["b_dmg"] = 3184,
								["r_amt"] = 0,
							},
							[12721] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1503,
								["targets"] = {
									["Patchwork Construct"] = 10181,
									["Skeletal Minion"] = 737,
									["Acolyte"] = 7357,
									["Bile Golem"] = 36285,
									["Tomb Stalker"] = 43132,
									["Dark Necromancer"] = 9509,
									["Infinite Hunter"] = 13421,
									["Mal'Ganis"] = 23548,
									["Crypt Fiend"] = 3475,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 2938,
									["Master Necromancer"] = 14740,
									["Chrono-Lord Epoch"] = 28182,
									["Enraging Ghoul"] = 64927,
									["Infinite Adversary"] = 35256,
									["Infinite Agent"] = 15715,
									["Salramm the Fleshcrafter"] = 40421,
									["Meathook"] = 35521,
									["Devouring Ghoul"] = 57921,
								},
								["n_dmg"] = 443266,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 849,
								["total"] = 443266,
								["c_max"] = 0,
								["id"] = 12721,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 849,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[47486] = {
								["c_amt"] = 24,
								["b_amt"] = 1,
								["c_dmg"] = 121125,
								["g_amt"] = 0,
								["n_max"] = 2748,
								["targets"] = {
									["Patchwork Construct"] = 9365,
									["Chrono-Lord Epoch"] = 6118,
									["Mal'Ganis"] = 9301,
									["Skeletal Minion <Master Necromancer>"] = 2376,
									["Acolyte"] = 4940,
									["Bile Golem"] = 13045,
									["Enraging Ghoul"] = 24825,
									["Infinite Agent"] = 5398,
									["Infinite Adversary"] = 21377,
									["Meathook"] = 18127,
									["Tomb Stalker"] = 14401,
									["Salramm the Fleshcrafter"] = 7903,
									["Master Necromancer"] = 7707,
									["Dark Necromancer"] = 7275,
									["Devouring Ghoul"] = 11644,
								},
								["n_dmg"] = 42677,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 45,
								["total"] = 163802,
								["c_max"] = 5946,
								["id"] = 47486,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 21,
								["b_dmg"] = 1804,
								["r_amt"] = 0,
							},
							[47450] = {
								["c_amt"] = 12,
								["b_amt"] = 0,
								["c_dmg"] = 57368,
								["g_amt"] = 0,
								["n_max"] = 2361,
								["targets"] = {
									["Mal'Ganis"] = 11392,
									["Enraging Ghoul"] = 1837,
									["Chrono-Lord Epoch"] = 22658,
									["Infinite Adversary"] = 4658,
									["Salramm the Fleshcrafter"] = 6733,
									["Bile Golem"] = 1514,
									["Meathook"] = 31986,
								},
								["n_dmg"] = 23410,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 80778,
								["c_max"] = 5249,
								["id"] = 47450,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[50622] = {
								["c_amt"] = 89,
								["b_amt"] = 7,
								["c_dmg"] = 371058,
								["g_amt"] = 0,
								["n_max"] = 2308,
								["targets"] = {
									["Skeletal Minion"] = 4063,
									["Acolyte"] = 2326,
									["Bile Golem"] = 33962,
									["Tomb Stalker"] = 64810,
									["Risen Zombie"] = 12206,
									["Infinite Hunter"] = 33595,
									["Mal'Ganis"] = 12330,
									["Crypt Fiend"] = 17778,
									["Ghoul Minion <Salramm the Fleshcrafter>"] = 6315,
									["Master Necromancer"] = 57056,
									["Meathook"] = 16427,
									["Infinite Adversary"] = 50610,
									["Ghoul Minion"] = 3084,
									["Infinite Agent"] = 43678,
									["Enraging Ghoul"] = 138341,
									["Salramm the Fleshcrafter"] = 18127,
									["Devouring Ghoul"] = 102579,
								},
								["n_dmg"] = 246229,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 229,
								["total"] = 617287,
								["c_max"] = 5326,
								["id"] = 50622,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 140,
								["b_dmg"] = 13059,
								["r_amt"] = 0,
							},
							[26654] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1940,
								["targets"] = {
									["Ghoul Minion"] = 3226,
									["Infinite Adversary"] = 1703,
									["Acolyte"] = 1940,
									["Enraging Ghoul"] = 3414,
									["Master Necromancer"] = 1664,
								},
								["n_dmg"] = 11947,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 11947,
								["c_max"] = 0,
								["id"] = 26654,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[20253] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 595,
								["g_amt"] = 0,
								["n_max"] = 385,
								["targets"] = {
									["Risen Zombie"] = 980,
								},
								["n_dmg"] = 385,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 980,
								["c_max"] = 595,
								["id"] = 20253,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[20647] = {
								["c_amt"] = 34,
								["b_amt"] = 1,
								["c_dmg"] = 205949,
								["g_amt"] = 0,
								["n_max"] = 3640,
								["targets"] = {
									["Mal'Ganis"] = 28410,
									["Crypt Fiend"] = 8632,
									["Skeletal Minion <Master Necromancer>"] = 2322,
									["Bile Golem"] = 35358,
									["Enraging Ghoul"] = 24348,
									["Chrono-Lord Epoch"] = 26421,
									["Infinite Hunter"] = 16328,
									["Infinite Agent"] = 20035,
									["Tomb Stalker"] = 22242,
									["Infinite Adversary"] = 15742,
									["Salramm the Fleshcrafter"] = 61909,
									["Meathook"] = 46084,
									["Devouring Ghoul"] = 8286,
								},
								["n_dmg"] = 110168,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 76,
								["total"] = 316117,
								["c_max"] = 8720,
								["id"] = 20647,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 42,
								["b_dmg"] = 1222,
								["r_amt"] = 0,
							},
							[7922] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Enraging Ghoul"] = 0,
									["Meathook"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 7922,
								["r_dmg"] = 0,
								["IMMUNE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["total"] = 3179658.124249,
					["aID"] = "4477-03A11F28",
					["nome"] = "Ûrsus",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675425214,
					["delay"] = 0,
					["damage_taken"] = 208446.124249,
				}, -- [11]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.015276,
					["damage_from"] = {
						["Atb"] = true,
						["Drushnak"] = true,
					},
					["targets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-4076-00005CF80F",
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.015276,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1675426038,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "Roach",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["total"] = 0.015276,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 35.015276,
					["start_time"] = 1675426035,
					["delay"] = 0,
					["aID"] = "4076",
				}, -- [12]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.020283,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-4075-00015CF80E",
					["damage_from"] = {
						["Ûrsus"] = true,
						["Leayae"] = true,
						["Atb"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.020283,
					["aID"] = "4075",
					["boss_fight_component"] = true,
					["fight_component"] = true,
					["end_time"] = 1675426038,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["nome"] = "Rat",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["total"] = 0.020283,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426035,
					["delay"] = 0,
					["damage_taken"] = 28.020283,
				}, -- [13]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 9136.022784,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Atb"] = 3872,
						["Ûrsus"] = 7129,
						["Leayae"] = 26994,
						["Drushnak"] = 966,
					},
					["pets"] = {
						"Skeletal Minion <Master Necromancer>", -- [1]
					},
					["serial"] = "Creature-0-4445-595-881-27732-00005CF8C0",
					["damage_from"] = {
						["Leayae"] = true,
						["Drushnak"] = true,
						["Ûrsus"] = true,
						["Atb"] = true,
						["Ýurríi"] = true,
					},
					["aID"] = "27732",
					["raid_targets"] = {
					},
					["total_without_pet"] = 31750.022784,
					["monster"] = true,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["total"] = 38961.022784,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["nome"] = "Master Necromancer",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2530,
								["targets"] = {
									["Leayae"] = 1568,
									["Ûrsus"] = 2530,
								},
								["n_dmg"] = 4098,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 18,
								["total"] = 4098,
								["c_max"] = 0,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 4,
								["extra"] = {
								},
								["BLOCK"] = 5,
								["PARRY"] = 7,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[61558] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3960,
								["targets"] = {
									["Leayae"] = 23749,
									["Ûrsus"] = 3903,
								},
								["n_dmg"] = 27652,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 27652,
								["c_max"] = 0,
								["id"] = 61558,
								["r_dmg"] = 20084,
								["extra"] = {
								},
								["a_dmg"] = 6704,
								["c_min"] = 0,
								["successful_casted"] = 8,
								["a_amt"] = 2,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 6,
							},
							[52611] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 52611,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675426038,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 403196.022784,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675425964,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [14]
				{
					["flag_original"] = 8776,
					["totalabsorbed"] = 1826.024713,
					["damage_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Drushnak"] = true,
						["Ýurríi"] = true,
					},
					["targets"] = {
						["Leayae"] = 1635,
						["Ûrsus"] = 778,
					},
					["serial"] = "Creature-0-4445-595-881-28878-0000DCF8DC",
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["classe"] = "PET",
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 2413.024713,
					["aID"] = "28878",
					["fight_component"] = true,
					["total"] = 2413.024713,
					["last_dps"] = 0,
					["last_event"] = 0,
					["nome"] = "Skeletal Minion",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 778,
								["targets"] = {
									["Leayae"] = 1635,
									["Ûrsus"] = 778,
								},
								["n_dmg"] = 2413,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 15,
								["MISS"] = 1,
								["total"] = 2413,
								["c_max"] = 0,
								["DODGE"] = 3,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["BLOCK"] = 4,
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["on_hold"] = false,
					["end_time"] = 1675426038,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 63126.024713,
					["start_time"] = 1675426014,
					["delay"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [15]
				{
					["flag_original"] = 8776,
					["totalabsorbed"] = 2787.037626,
					["on_hold"] = false,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Atb"] = 3872,
						["Ûrsus"] = 696,
						["Leayae"] = 1677,
						["Drushnak"] = 966,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-28878-00005CF8DC",
					["damage_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Ýurríi"] = true,
						["Drushnak"] = true,
					},
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 7211.037626,
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["end_time"] = 1675426038,
					["friendlyfire_total"] = 0,
					["ownerName"] = "Master Necromancer",
					["nome"] = "Skeletal Minion <Master Necromancer>",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 2726,
								["g_amt"] = 0,
								["n_max"] = 1146,
								["targets"] = {
									["Atb"] = 3872,
									["Ûrsus"] = 696,
									["Leayae"] = 1677,
									["Drushnak"] = 966,
								},
								["n_dmg"] = 4485,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 7211,
								["c_max"] = 2726,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 552,
								["BLOCK"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 1,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["total"] = 7211.037626,
					["last_event"] = 0,
					["aID"] = "28878",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 64163.03762600001,
					["start_time"] = 1675426011,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [16]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 12667.043445,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 90312,
						["Ûrsus"] = 3428,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-28199-00005CF8F5",
					["damage_from"] = {
						["Leayae"] = true,
						["Drushnak"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Ýurríi"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 93740.04344500002,
					["fight_component"] = true,
					["friendlyfire_total"] = 0,
					["monster"] = true,
					["end_time"] = 1675426089,
					["aID"] = "28199",
					["dps_started"] = false,
					["nome"] = "Tomb Stalker",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 1,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3428,
								["targets"] = {
									["Leayae"] = 22802,
									["Ûrsus"] = 3428,
								},
								["n_dmg"] = 26230,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 75,
								["MISS"] = 9,
								["total"] = 26230,
								["c_max"] = 0,
								["a_dmg"] = 4170,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 29,
								["extra"] = {
								},
								["BLOCK"] = 15,
								["PARRY"] = 8,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 2,
								["n_amt"] = 14,
								["b_dmg"] = 335,
								["r_amt"] = 0,
							}, -- [1]
							[58782] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7006,
								["targets"] = {
									["Leayae"] = 67510,
								},
								["n_dmg"] = 67510,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 67510,
								["c_max"] = 0,
								["id"] = 58782,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 27004,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 4,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 93740.04344500002,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675425984,
					["delay"] = 0,
					["damage_taken"] = 755994.043445,
				}, -- [17]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 17462.027705,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 34858,
						["Drushnak"] = 6968,
						["Ûrsus"] = 6024,
						["Ýurríi"] = 4322,
						["Atb"] = 13634,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-27731-0001DCF927",
					["damage_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Drushnak"] = true,
						["Ýurríi"] = true,
					},
					["aID"] = "27731",
					["raid_targets"] = {
					},
					["total_without_pet"] = 65806.027705,
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["total"] = 65806.027705,
					["classe"] = "UNKNOW",
					["friendlyfire_total"] = 0,
					["nome"] = "Acolyte",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1153,
								["targets"] = {
									["Ûrsus"] = 1906,
									["Leayae"] = 4797,
									["Atb"] = 1153,
								},
								["n_dmg"] = 7856,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 41,
								["total"] = 7856,
								["c_max"] = 0,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 14,
								["extra"] = {
								},
								["BLOCK"] = 12,
								["PARRY"] = 4,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 11,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[17234] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3215,
								["targets"] = {
									["Leayae"] = 5300,
									["Atb"] = 3215,
								},
								["n_dmg"] = 8515,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 8515,
								["c_max"] = 0,
								["id"] = 17234,
								["r_dmg"] = 8515,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 3215,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["a_amt"] = 1,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 3,
							},
							[15244] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Leayae"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 15244,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["RESIST"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[14145] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 4322,
								["targets"] = {
									["Ûrsus"] = 4118,
									["Leayae"] = 7001,
									["Ýurríi"] = 4322,
								},
								["n_dmg"] = 15441,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 15441,
								["c_max"] = 0,
								["id"] = 14145,
								["r_dmg"] = 8440,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							},
							[58811] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1188,
								["targets"] = {
									["Leayae"] = 1976,
									["Atb"] = 9266,
								},
								["n_dmg"] = 11242,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 11242,
								["c_max"] = 0,
								["id"] = 58811,
								["r_dmg"] = 1069,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[46190] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1010,
								["targets"] = {
									["Leayae"] = 15784,
									["Drushnak"] = 6968,
								},
								["n_dmg"] = 22752,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 26,
								["total"] = 22752,
								["c_max"] = 0,
								["id"] = 46190,
								["r_dmg"] = 908,
								["extra"] = {
								},
								["a_dmg"] = 2517,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 3,
								["n_amt"] = 26,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675426130,
					["on_hold"] = false,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675426032,
					["delay"] = 0,
					["damage_taken"] = 403190.027705,
				}, -- [18]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.011662,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 2922,
						["Ûrsus"] = 9048,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-28200-00005CF927",
					["damage_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Drushnak"] = true,
						["Ýurríi"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 11970.011662,
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["total"] = 11970.011662,
					["friendlyfire_total"] = 0,
					["aID"] = "28200",
					["nome"] = "Dark Necromancer",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2749,
								["targets"] = {
									["Leayae"] = 2922,
									["Ûrsus"] = 5217,
								},
								["n_dmg"] = 8139,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["a_dmg"] = 0,
								["total"] = 8139,
								["c_max"] = 0,
								["MISS"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["BLOCK"] = 2,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[61558] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3831,
								["targets"] = {
									["Ûrsus"] = 3831,
								},
								["n_dmg"] = 3831,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 3831,
								["c_max"] = 0,
								["id"] = 61558,
								["r_dmg"] = 3831,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
							[58770] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58770,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[20812] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 20812,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675426130,
					["on_hold"] = false,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 201598.011662,
					["start_time"] = 1675426109,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [19]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 39385.008072,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 52664,
						["Drushnak"] = 31167,
						["Ûrsus"] = 30791,
						["Atb"] = 7626,
						["Ýurríi"] = 13278,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-26529-00005CF94E",
					["damage_from"] = {
						["Leayae"] = true,
						["Drushnak"] = true,
						["Ûrsus"] = true,
						["Ýurríi"] = true,
						["Atb"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 135526.008072,
					["aID"] = "26529",
					["boss_fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675426218,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["nome"] = "Meathook",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 4,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 6753,
								["targets"] = {
									["Leayae"] = 34864,
								},
								["n_dmg"] = 34864,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 34,
								["total"] = 34864,
								["c_max"] = 0,
								["a_dmg"] = 10058,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 12,
								["MISS"] = 2,
								["extra"] = {
								},
								["PARRY"] = 9,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 3,
								["n_amt"] = 11,
								["b_dmg"] = 12255,
								["r_amt"] = 0,
							}, -- [1]
							[58823] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2656,
								["targets"] = {
									["Atb"] = 7626,
									["Ýurríi"] = 13278,
								},
								["n_dmg"] = 20904,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 20904,
								["c_max"] = 0,
								["id"] = 58823,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 13278,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 5,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[58824] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2363,
								["targets"] = {
									["Ûrsus"] = 30791,
									["Leayae"] = 17800,
									["Drushnak"] = 31167,
								},
								["n_dmg"] = 79758,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 51,
								["total"] = 79758,
								["c_max"] = 0,
								["id"] = 58824,
								["r_dmg"] = 37279,
								["extra"] = {
								},
								["a_dmg"] = 11150,
								["RESIST"] = 4,
								["c_min"] = 0,
								["successful_casted"] = 17,
								["a_amt"] = 6,
								["n_amt"] = 47,
								["b_dmg"] = 0,
								["r_amt"] = 23,
							},
							[58841] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58841,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 135526.008072,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426163,
					["delay"] = 0,
					["damage_taken"] = 842561.008072,
				}, -- [20]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 2304.027527,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 751,
						["Leayae"] = 2768,
						["Lordaeron Footman"] = 889,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-28167-00005CF8DE",
					["damage_from"] = {
						["Atb"] = true,
						["Leayae"] = true,
						["High Elf Mage-Priest"] = true,
						["Ýurríi"] = true,
						["Drushnak"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Lordaeron Footman"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 4408.027527,
					["aID"] = "28167",
					["nome"] = "Stratholme Citizen",
					["fight_component"] = true,
					["total"] = 4408.027527,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 2,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 777,
								["targets"] = {
									["Drushnak"] = 751,
									["Leayae"] = 2768,
									["High Elf Mage-Priest"] = 0,
									["Lordaeron Footman"] = 889,
								},
								["n_dmg"] = 4408,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 28,
								["total"] = 4408,
								["c_max"] = 0,
								["DODGE"] = 4,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 464,
								["extra"] = {
								},
								["BLOCK"] = 1,
								["PARRY"] = 4,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 1,
								["n_amt"] = 19,
								["b_dmg"] = 480,
								["r_amt"] = 0,
							}, -- [1]
							[58813] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58813,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675426218,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426158,
					["delay"] = 0,
					["damage_taken"] = 134648.027527,
				}, -- [21]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 4418.021733000001,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Atb"] = 18840,
					},
					["pets"] = {
					},
					["serial"] = "",
					["damage_from"] = {
					},
					["aID"] = "",
					["raid_targets"] = {
					},
					["total_without_pet"] = 18840.021733,
					["friendlyfire_total"] = 0,
					["nome"] = "[*] Shadow Word: Death",
					["monster"] = true,
					["total"] = 18840.021733,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[32409] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3729,
								["targets"] = {
									["Atb"] = 18840,
								},
								["n_dmg"] = 18840,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 18840,
								["c_max"] = 0,
								["id"] = 32409,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 5987,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 2,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675426218,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 0.021733,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426206,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [22]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 4010.007408,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 4987,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-27734-00005CF9C0",
					["damage_from"] = {
						["Ýurríi"] = true,
						["Ûrsus"] = true,
						["Leayae"] = true,
						["Drushnak"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 4987.007408,
					["monster"] = true,
					["aID"] = "27734",
					["dps_started"] = false,
					["end_time"] = 1675426298,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Crypt Fiend",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 782,
								["targets"] = {
									["Leayae"] = 888,
								},
								["n_dmg"] = 888,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 888,
								["c_max"] = 0,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["MISS"] = 1,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[52496] = {
								["c_amt"] = 0,
								["b_amt"] = 1,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2679,
								["targets"] = {
									["Leayae"] = 4099,
								},
								["n_dmg"] = 4099,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 4099,
								["c_max"] = 0,
								["id"] = 52496,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["MISS"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 7,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 977,
								["r_amt"] = 0,
							},
							[52491] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 52491,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 4987.007408,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426260,
					["delay"] = 0,
					["damage_taken"] = 125999.007408,
				}, -- [23]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 22761.02826,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 63332,
						["Ýurríi"] = 14817,
						["Ûrsus"] = 2838,
						["Drushnak"] = 5044,
						["Atb"] = 8512,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-28201-00005CF9F6",
					["damage_from"] = {
						["Shadowfiend <Atb>"] = true,
						["Leayae"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Drushnak"] = true,
						["Ýurríi"] = true,
					},
					["aID"] = "28201",
					["raid_targets"] = {
					},
					["total_without_pet"] = 94543.02825999999,
					["monster"] = true,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["total"] = 94543.02825999999,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["nome"] = "Bile Golem",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 14,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 4529,
								["targets"] = {
									["Leayae"] = 63332,
								},
								["n_dmg"] = 63332,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 47,
								["total"] = 63332,
								["c_max"] = 0,
								["a_dmg"] = 18121,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 2,
								["DODGE"] = 13,
								["extra"] = {
								},
								["PARRY"] = 5,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 7,
								["n_amt"] = 27,
								["b_dmg"] = 25557,
								["r_amt"] = 0,
							}, -- [1]
							[58810] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3153,
								["targets"] = {
									["Ýurríi"] = 14817,
									["Ûrsus"] = 2838,
									["Drushnak"] = 5044,
									["Atb"] = 8512,
								},
								["n_dmg"] = 31211,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 31211,
								["c_max"] = 0,
								["id"] = 58810,
								["r_dmg"] = 23020,
								["MISS"] = 3,
								["extra"] = {
								},
								["RESIST"] = 1,
								["a_dmg"] = 5038,
								["c_min"] = 0,
								["successful_casted"] = 12,
								["a_amt"] = 2,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 9,
							},
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675426339,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 1042636.02826,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426206,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [24]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 27066.005712,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 6382,
						["Ûrsus"] = 5095,
						["Leayae"] = 47868,
						["Ýurríi"] = 1706,
					},
					["pets"] = {
						"Ghoul Minion <Salramm the Fleshcrafter>", -- [1]
					},
					["serial"] = "Creature-0-4445-595-881-26530-00005CFA8E",
					["damage_from"] = {
						["Leayae"] = true,
						["Drushnak"] = true,
						["Ûrsus"] = true,
						["Atb"] = true,
						["Ýurríi"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 59345.00571200001,
					["aID"] = "26530",
					["boss_fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675426522,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["nome"] = "Salramm the Fleshcrafter",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 3,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5038,
								["targets"] = {
									["Leayae"] = 18301,
								},
								["n_dmg"] = 18301,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 18301,
								["c_max"] = 0,
								["a_dmg"] = 5038,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 4,
								["MISS"] = 2,
								["extra"] = {
								},
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 1,
								["n_amt"] = 7,
								["b_dmg"] = 8259,
								["r_amt"] = 0,
							}, -- [1]
							[58827] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5701,
								["targets"] = {
									["Leayae"] = 25602,
								},
								["n_dmg"] = 25602,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 25602,
								["c_max"] = 0,
								["id"] = 58827,
								["r_dmg"] = 13867,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 9589,
								["c_min"] = 0,
								["successful_casted"] = 7,
								["a_amt"] = 2,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 3,
							},
							[58845] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1703,
								["targets"] = {
									["Drushnak"] = 2516,
									["Ûrsus"] = 1703,
								},
								["n_dmg"] = 4219,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 4219,
								["c_max"] = 0,
								["id"] = 58845,
								["r_dmg"] = 2895,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							},
							[52708] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Leayae"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 52708,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["RESIST"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[52451] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 52451,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[58825] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3965,
								["targets"] = {
									["Ûrsus"] = 3392,
									["Leayae"] = 3965,
									["Drushnak"] = 3866,
								},
								["n_dmg"] = 11223,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 11223,
								["c_max"] = 0,
								["id"] = 58825,
								["r_dmg"] = 7258,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 61051.00571200001,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426455,
					["delay"] = 0,
					["damage_taken"] = 842561.0057120001,
				}, -- [25]
				{
					["flag_original"] = 8776,
					["totalabsorbed"] = 1294.005136,
					["damage_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Drushnak"] = true,
						["Ýurríi"] = true,
					},
					["targets"] = {
						["Ýurríi"] = 1294,
						["Drushnak"] = 1120,
					},
					["serial"] = "Creature-0-4445-595-881-27733-0000DCFAA6",
					["pets"] = {
					},
					["boss_fight_component"] = true,
					["aID"] = "27733",
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 2414.005136,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675426522,
					["last_dps"] = 0,
					["last_event"] = 0,
					["nome"] = "Ghoul Minion",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 569,
								["targets"] = {
									["Ýurríi"] = 1294,
									["Drushnak"] = 1120,
								},
								["n_dmg"] = 2414,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 2414,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["total"] = 2414.005136,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 35171.005136,
					["start_time"] = 1675426511,
					["delay"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [26]
				{
					["flag_original"] = 8776,
					["totalabsorbed"] = 1234.006004,
					["damage_taken"] = 35951.006004,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ýurríi"] = 1706,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-27733-00005CFAA6",
					["damage_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Drushnak"] = true,
						["Ýurríi"] = true,
					},
					["aID"] = "27733",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1706.006004,
					["end_time"] = 1675426522,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["total"] = 1706.006004,
					["friendlyfire_total"] = 0,
					["ownerName"] = "Salramm the Fleshcrafter",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 472,
								["targets"] = {
									["Ýurríi"] = 1706,
								},
								["n_dmg"] = 1706,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 1706,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["nome"] = "Ghoul Minion <Salramm the Fleshcrafter>",
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426512,
					["delay"] = 0,
					["classe"] = "PET",
				}, -- [27]
				{
					["flag_original"] = 2584,
					["totalabsorbed"] = 0.03517699999999999,
					["damage_from"] = {
						["Infinite Agent"] = true,
						["Patchwork Construct"] = true,
						["Chrono-Lord Epoch"] = true,
						["Infinite Hunter"] = true,
					},
					["targets"] = {
						["Patchwork Construct"] = 18431,
						["Enraging Ghoul"] = 3650,
						["Chrono-Lord Epoch"] = 15605,
						["Tomb Stalker"] = 2185,
						["Infinite Agent"] = 6739,
						["Stratholme Citizen"] = 701,
						["Risen Zombie"] = 1799,
						["Infinite Adversary"] = 9988,
						["Mal'Ganis"] = 38660,
						["Infinite Hunter"] = 13999,
					},
					["serial"] = "Creature-0-4445-595-881-26499-00005CFAE2",
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 111757.035177,
					["aID"] = "26499",
					["dps_started"] = false,
					["total"] = 111757.035177,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "Arthas",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 10,
								["b_amt"] = 2,
								["c_dmg"] = 13738,
								["g_amt"] = 0,
								["n_max"] = 954,
								["targets"] = {
									["Patchwork Construct"] = 11679,
									["Enraging Ghoul"] = 3650,
									["Chrono-Lord Epoch"] = 15605,
									["Tomb Stalker"] = 2185,
									["Infinite Agent"] = 6739,
									["Stratholme Citizen"] = 701,
									["Risen Zombie"] = 1799,
									["Infinite Adversary"] = 9988,
									["Mal'Ganis"] = 24180,
									["Infinite Hunter"] = 13999,
								},
								["n_dmg"] = 76787,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 121,
								["total"] = 90525,
								["c_max"] = 1801,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["MISS"] = 9,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 99,
								["b_dmg"] = 1404,
								["r_amt"] = 0,
							}, -- [1]
							[58822] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3764,
								["targets"] = {
									["Mal'Ganis"] = 14480,
									["Patchwork Construct"] = 6752,
								},
								["n_dmg"] = 21232,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 21232,
								["c_max"] = 0,
								["id"] = 58822,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["boss_fight_component"] = true,
					["end_time"] = 1675426602,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 36133.03517699999,
					["start_time"] = 1675426335,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [28]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 15936.019024,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ûrsus"] = 23214,
						["Leayae"] = 29266,
						["Arthas"] = 3830,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-28340-0000DCFAE7",
					["damage_from"] = {
						["Leayae"] = true,
						["Ýurríi"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Drushnak"] = true,
					},
					["aID"] = "28340",
					["raid_targets"] = {
					},
					["total_without_pet"] = 56310.01902399999,
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["total"] = 56310.01902399999,
					["classe"] = "UNKNOW",
					["friendlyfire_total"] = 0,
					["nome"] = "Infinite Hunter",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 4,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 4404,
								["targets"] = {
									["Ûrsus"] = 23214,
									["Leayae"] = 29266,
									["Arthas"] = 3830,
								},
								["n_dmg"] = 56310,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 78,
								["a_dmg"] = 4814,
								["total"] = 56310,
								["c_max"] = 0,
								["DODGE"] = 20,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 8,
								["extra"] = {
								},
								["BLOCK"] = 12,
								["PARRY"] = 7,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 3,
								["n_amt"] = 31,
								["b_dmg"] = 2056,
								["r_amt"] = 0,
							}, -- [1]
							[52636] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 52636,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[58820] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58820,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 17,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675426602,
					["on_hold"] = false,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675426511,
					["delay"] = 0,
					["damage_taken"] = 485086.019024,
				}, -- [29]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 20257.035531,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Arthas"] = 4369,
						["Leayae"] = 59118,
						["Ýurríi"] = 9275,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-28341-00005CFAE7",
					["damage_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
						["Ýurríi"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Drushnak"] = true,
					},
					["aID"] = "28341",
					["raid_targets"] = {
					},
					["total_without_pet"] = 72762.035531,
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["total"] = 72762.035531,
					["classe"] = "UNKNOW",
					["friendlyfire_total"] = 0,
					["nome"] = "Infinite Agent",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7,
								["targets"] = {
									["Leayae"] = 7,
								},
								["n_dmg"] = 7,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 7,
								["c_max"] = 0,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 4,
								["extra"] = {
								},
								["BLOCK"] = 3,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[58817] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5671,
								["targets"] = {
									["Arthas"] = 4369,
									["Leayae"] = 57728,
									["Ýurríi"] = 5671,
								},
								["n_dmg"] = 67768,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 17,
								["total"] = 67768,
								["c_max"] = 0,
								["id"] = 58817,
								["r_dmg"] = 34934,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 20011,
								["c_min"] = 0,
								["successful_casted"] = 17,
								["a_amt"] = 5,
								["n_amt"] = 16,
								["b_dmg"] = 0,
								["r_amt"] = 9,
							},
							[58816] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1897,
								["targets"] = {
									["Drushnak"] = 0,
									["Leayae"] = 1383,
									["Ýurríi"] = 3604,
								},
								["n_dmg"] = 4987,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 4987,
								["c_max"] = 0,
								["id"] = 58816,
								["r_dmg"] = 1707,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["RESIST"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675426602,
					["on_hold"] = false,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675426546,
					["delay"] = 0,
					["damage_taken"] = 493606.0355309999,
				}, -- [30]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 17783.015246,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ûrsus"] = 7397,
						["Leayae"] = 49388,
						["Ýurríi"] = 21827,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-27742-00005CFB45",
					["damage_from"] = {
						["Leayae"] = true,
						["Drushnak"] = true,
						["Ýurríi"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Atb"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 78612.01524600001,
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["total"] = 78612.01524600001,
					["friendlyfire_total"] = 0,
					["aID"] = "27742",
					["nome"] = "Infinite Adversary",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 11,
								["c_dmg"] = 7397,
								["g_amt"] = 0,
								["n_max"] = 4554,
								["targets"] = {
									["Arthas"] = 0,
									["Ûrsus"] = 7397,
									["Leayae"] = 14883,
									["Ýurríi"] = 12485,
								},
								["n_dmg"] = 27368,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 49,
								["a_dmg"] = 4904,
								["total"] = 34765,
								["c_max"] = 7397,
								["MISS"] = 4,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 8,
								["extra"] = {
								},
								["BLOCK"] = 3,
								["PARRY"] = 11,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 2,
								["n_amt"] = 22,
								["b_dmg"] = 5106,
								["r_amt"] = 0,
							}, -- [1]
							[52633] = {
								["c_amt"] = 0,
								["b_amt"] = 3,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9342,
								["targets"] = {
									["Leayae"] = 34505,
									["Ýurríi"] = 9342,
								},
								["n_dmg"] = 43847,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 9,
								["total"] = 43847,
								["c_max"] = 0,
								["id"] = 52633,
								["r_dmg"] = 0,
								["a_dmg"] = 14666,
								["DODGE"] = 2,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 9,
								["a_amt"] = 2,
								["n_amt"] = 6,
								["b_dmg"] = 19727,
								["r_amt"] = 0,
							},
							[58813] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58813,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 5,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675426664,
					["on_hold"] = false,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 621779.015246,
					["start_time"] = 1675426600,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [31]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.015179,
					["damage_from"] = {
						["Leayae"] = true,
						["Ýurríi"] = true,
					},
					["targets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-14881-0000DCF810",
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.015179,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1675426664,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "Spider",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["total"] = 0.015179,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 14.015179,
					["start_time"] = 1675426661,
					["delay"] = 0,
					["aID"] = "14881",
				}, -- [32]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 24794.013145,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 47177,
						["Ýurríi"] = 40972,
						["Atb"] = 3158,
						["Ûrsus"] = 11694,
						["Arthas"] = 5887,
						["Drushnak"] = 2986,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-26532-00005CFBE0",
					["damage_from"] = {
						["Atb"] = true,
						["Leayae"] = true,
						["Ýurríi"] = true,
						["Treant <Ýurríi>"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Drushnak"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 111874.013145,
					["aID"] = "26532",
					["boss_fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675426864,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["nome"] = "Chrono-Lord Epoch",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 3,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8922,
								["targets"] = {
									["Ûrsus"] = 6839,
									["Leayae"] = 40569,
									["Ýurríi"] = 17044,
								},
								["n_dmg"] = 64452,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 64452,
								["c_max"] = 0,
								["a_dmg"] = 26420,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 7,
								["MISS"] = 2,
								["extra"] = {
								},
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 5,
								["n_amt"] = 13,
								["b_dmg"] = 11140,
								["r_amt"] = 0,
							}, -- [1]
							[58848] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Treant"] = 0,
									["Ýurríi"] = 0,
									["Drushnak"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58848,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["RESIST"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[52766] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 52766,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[58830] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7750,
								["targets"] = {
									["Ýurríi"] = 17585,
								},
								["n_dmg"] = 17585,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 17585,
								["c_max"] = 0,
								["id"] = 58830,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 4791,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 2,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[397342] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3241,
								["targets"] = {
									["Leayae"] = 6608,
									["Ýurríi"] = 6343,
									["Atb"] = 3158,
									["Ûrsus"] = 4855,
									["Arthas"] = 5887,
									["Drushnak"] = 2986,
								},
								["n_dmg"] = 29837,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 29837,
								["c_max"] = 0,
								["id"] = 397342,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 12367,
								["c_min"] = 0,
								["successful_casted"] = 11,
								["a_amt"] = 5,
								["n_amt"] = 11,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[52772] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 52772,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 111874.013145,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426810,
					["delay"] = 0,
					["damage_taken"] = 815877.013145,
				}, -- [33]
				{
					["flag_original"] = 4370,
					["totalabsorbed"] = 0.009301,
					["damage_from"] = {
						["Mal'Ganis"] = true,
					},
					["targets"] = {
						["Mal'Ganis"] = 30619,
						["Chrono-Lord Epoch"] = 30050,
					},
					["serial"] = "Creature-0-4445-595-881-1964-00005CFBFF",
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 60669.009301,
					["end_time"] = 1675426864,
					["dps_started"] = false,
					["total"] = 60669.009301,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "Treant <Ýurríi>",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 9,
								["b_amt"] = 0,
								["c_dmg"] = 9738,
								["g_amt"] = 15,
								["n_max"] = 638,
								["targets"] = {
									["Mal'Ganis"] = 30619,
									["Chrono-Lord Epoch"] = 30050,
								},
								["n_dmg"] = 44304,
								["n_min"] = 0,
								["g_dmg"] = 6627,
								["counter"] = 107,
								["total"] = 60669,
								["c_max"] = 1200,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 83,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["boss_fight_component"] = true,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 6310.009301,
					["start_time"] = 1675426799,
					["delay"] = 0,
					["aID"] = "1964",
				}, -- [34]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 35353.007997,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 17845,
						["Drushnak"] = 21501,
						["Atb"] = 11976,
						["Ûrsus"] = 20373,
						["Arthas"] = 22047,
						["Ýurríi"] = 988,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-27736-00005CFC47",
					["damage_from"] = {
						["Leayae"] = true,
						["Ýurríi"] = true,
						["Atb"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Drushnak"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 94730.00799700001,
					["monster"] = true,
					["aID"] = "27736",
					["dps_started"] = false,
					["end_time"] = 1675426999,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Patchwork Construct",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 1,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2346,
								["targets"] = {
									["Leayae"] = 5641,
								},
								["n_dmg"] = 5641,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 5641,
								["c_max"] = 0,
								["a_dmg"] = 2227,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 7,
								["MISS"] = 1,
								["extra"] = {
								},
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 1,
								["n_amt"] = 5,
								["b_dmg"] = 565,
								["r_amt"] = 0,
							}, -- [1]
							[58809] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1398,
								["targets"] = {
									["Leayae"] = 12204,
									["Drushnak"] = 21501,
									["Atb"] = 11976,
									["Ûrsus"] = 20373,
									["Arthas"] = 22047,
									["Ýurríi"] = 988,
								},
								["n_dmg"] = 89089,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 84,
								["total"] = 89089,
								["c_max"] = 0,
								["id"] = 58809,
								["r_dmg"] = 26212,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 4292,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 4,
								["n_amt"] = 83,
								["b_dmg"] = 0,
								["r_amt"] = 27,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 94730.00799700001,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675426948,
					["delay"] = 0,
					["damage_taken"] = 260659.007997,
				}, -- [35]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 18350.008271,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 71388,
						["Ýurríi"] = 17303,
						["Drushnak"] = 21283,
						["Ûrsus"] = 7562,
						["Treant <Ýurríi>"] = 6310,
						["Atb"] = 6596,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-26533-00005CFD11",
					["damage_from"] = {
						["Shadowfiend <Atb>"] = true,
						["Drushnak"] = true,
						["Leayae"] = true,
						["Ýurríi"] = true,
						["Treant <Ýurríi>"] = true,
						["Ûrsus"] = true,
						["Arthas"] = true,
						["Atb"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 130442.008271,
					["aID"] = "26533",
					["boss_fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675427175,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["nome"] = "Mal'Ganis",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 4,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 4918,
								["targets"] = {
									["Leayae"] = 25025,
								},
								["n_dmg"] = 25025,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 18,
								["total"] = 25025,
								["c_max"] = 0,
								["a_dmg"] = 6875,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["DODGE"] = 6,
								["extra"] = {
								},
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 2,
								["n_amt"] = 9,
								["b_dmg"] = 9535,
								["r_amt"] = 0,
							}, -- [1]
							[58850] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9244,
								["targets"] = {
									["Ýurríi"] = 17303,
									["Ûrsus"] = 7562,
									["Drushnak"] = 21283,
									["Atb"] = 6596,
								},
								["n_dmg"] = 52744,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 52744,
								["c_max"] = 0,
								["id"] = 58850,
								["r_dmg"] = 52744,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 7,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 7,
							},
							[58852] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5671,
								["targets"] = {
									["Leayae"] = 46363,
									["Treant <Ýurríi>"] = 6310,
								},
								["n_dmg"] = 52673,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 38,
								["total"] = 52673,
								["c_max"] = 0,
								["id"] = 58852,
								["r_dmg"] = 43839,
								["extra"] = {
								},
								["a_dmg"] = 26888,
								["c_min"] = 0,
								["successful_casted"] = 9,
								["a_amt"] = 6,
								["n_amt"] = 38,
								["b_dmg"] = 0,
								["r_amt"] = 25,
							},
							[52723] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 52723,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[58849] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Ýurríi"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58849,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["RESIST"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 130442.008271,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675427107,
					["delay"] = 0,
					["damage_taken"] = 996973.008271,
				}, -- [36]
				{
					["flag_original"] = 4370,
					["totalabsorbed"] = 0.012959,
					["damage_from"] = {
					},
					["targets"] = {
						["Mal'Ganis"] = 17670,
					},
					["serial"] = "Creature-0-4445-595-881-19668-00005CFD27",
					["pets"] = {
					},
					["boss_fight_component"] = true,
					["aID"] = "19668",
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 17670.012959,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675427175,
					["last_dps"] = 0,
					["last_event"] = 0,
					["nome"] = "Shadowfiend <Atb>",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 6311,
								["g_amt"] = 1,
								["n_max"] = 1648,
								["targets"] = {
									["Mal'Ganis"] = 17670,
								},
								["n_dmg"] = 10128,
								["n_min"] = 0,
								["g_dmg"] = 1231,
								["counter"] = 11,
								["total"] = 17670,
								["c_max"] = 3570,
								["id"] = 1,
								["r_dmg"] = 3955,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["total"] = 17670.012959,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.012959,
					["start_time"] = 1675427158,
					["delay"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [37]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.001894,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 0,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001894,
					["last_dps"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 0.001894,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Cult Conspirator",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Drushnak"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
							[60842] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 60842,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[14873] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Drushnak"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 14873,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["end_time"] = 1675428040,
					["damage_taken"] = 0.001894,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675428037,
					["serial"] = "Creature-0-4460-571-8006-33537-00015CEA0A",
					["aID"] = "33537",
				}, -- [38]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.007845,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["delay"] = 0,
					["pets"] = {
					},
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["aID"] = "33498",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.007845,
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["end_time"] = 1675428040,
					["on_hold"] = false,
					["tipo"] = 1,
					["nome"] = "Maloric",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["total"] = 0.007845,
					["dps_started"] = false,
					["damage_taken"] = 0.007845,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675428037,
					["serial"] = "Creature-0-4448-571-6722-33498-00005CE804",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [39]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.00194,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 0,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.00194,
					["last_dps"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 0.00194,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Skeletal Woodcutter",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Drushnak"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["end_time"] = 1675428040,
					["damage_taken"] = 0.00194,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675428037,
					["serial"] = "Creature-0-4448-571-6722-33499-00005C2323",
					["aID"] = "33499",
				}, -- [40]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.001486,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001486,
					["last_dps"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 0.001486,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Unbound Seer",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["end_time"] = 1675428040,
					["damage_taken"] = 0.001486,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675428037,
					["serial"] = "Creature-0-4448-571-6722-33422-00005CE633",
					["aID"] = "33422",
				}, -- [41]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.076891,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 14673,
						["Hálgân"] = 0,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["aID"] = "33947",
					["raid_targets"] = {
					},
					["total_without_pet"] = 14673.076891,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1675428040,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Angry Oak Spirit",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1404,
								["g_amt"] = 0,
								["n_max"] = 381,
								["targets"] = {
									["Drushnak"] = 11125,
									["Hálgân"] = 0,
								},
								["n_dmg"] = 9721,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 41,
								["total"] = 11125,
								["c_max"] = 707,
								["DODGE"] = 5,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["MISS"] = 2,
								["r_amt"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 30,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
							[35361] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 59,
								["targets"] = {
									["Drushnak"] = 3548,
								},
								["n_dmg"] = 3548,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 66,
								["total"] = 3548,
								["c_max"] = 0,
								["id"] = 35361,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 5,
								["c_min"] = 0,
								["successful_casted"] = 10,
								["a_amt"] = 0,
								["n_amt"] = 61,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["total"] = 14673.076891,
					["last_dps"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 241754.076891,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675427949,
					["serial"] = "Creature-0-4448-571-6722-33947-00005CD5B4",
					["on_hold"] = false,
				}, -- [42]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.03710400000000001,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 0,
						["Dappled Stag"] = 5409,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
						["Dappled Stag"] = true,
					},
					["aID"] = "31233",
					["raid_targets"] = {
					},
					["total_without_pet"] = 5409.037104,
					["on_hold"] = false,
					["damage_taken"] = 4581.037104,
					["dps_started"] = false,
					["end_time"] = 1675428040,
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["nome"] = "Sinewy Wolf",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 653,
								["g_amt"] = 0,
								["n_max"] = 328,
								["targets"] = {
									["Drushnak"] = 0,
									["Dappled Stag"] = 5038,
								},
								["n_dmg"] = 4385,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 5038,
								["c_max"] = 653,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 15,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
							[32919] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 371,
								["targets"] = {
									["Drushnak"] = 0,
									["Dappled Stag"] = 371,
								},
								["n_dmg"] = 371,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 371,
								["c_max"] = 0,
								["id"] = 32919,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[59008] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Dappled Stag"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 59008,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["total"] = 5409.037104,
					["last_dps"] = 0,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675428010,
					["serial"] = "Creature-0-4448-571-6722-31233-00005CD46F",
					["friendlyfire_total"] = 0,
				}, -- [43]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.00897,
					["damage_from"] = {
					},
					["targets"] = {
						["Drushnak"] = 0,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["aID"] = "31228",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.00897,
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["end_time"] = 1675428040,
					["on_hold"] = false,
					["tipo"] = 1,
					["nome"] = "Grove Walker",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Drushnak"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
							[35361] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Drushnak"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 35361,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["total"] = 0.00897,
					["dps_started"] = false,
					["damage_taken"] = 0.00897,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675428037,
					["serial"] = "Creature-0-4448-571-6722-31228-00005CB784",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [44]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.105084,
					["damage_from"] = {
						["Sunreaver Hawkstrider <Drushnak>"] = true,
						["Kadi"] = true,
						["Drushnak"] = true,
					},
					["targets"] = {
						["Sunreaver Hawkstrider <Drushnak>"] = 117469,
						["Sunreaver Hawkstrider"] = 27765,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["aID"] = "33229",
					["raid_targets"] = {
					},
					["total_without_pet"] = 145234.105084,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 145234.105084,
					["damage_taken"] = 90500.10508399998,
					["tipo"] = 1,
					["nome"] = "Melee Target",
					["spells"] = {
						["_ActorTable"] = {
							[62709] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 21358,
								["targets"] = {
									["Sunreaver Hawkstrider <Drushnak>"] = 117469,
									["Sunreaver Hawkstrider"] = 27765,
								},
								["n_dmg"] = 145234,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 145234,
								["c_max"] = 0,
								["id"] = 62709,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 14,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["classe"] = "UNKNOW",
					["end_time"] = 1675428040,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675427987,
					["serial"] = "Creature-0-4460-571-8006-33229-00015ACA36",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [45]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.029357,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["targets"] = {
					},
					["delay"] = 0,
					["pets"] = {
					},
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["aID"] = "33243",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.029357,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 0.029357,
					["damage_taken"] = 10800.029357,
					["tipo"] = 1,
					["nome"] = "Ranged Target",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["classe"] = "UNKNOW",
					["end_time"] = 1675428040,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675428037,
					["serial"] = "Creature-0-4460-571-8006-33243-00005ACA36",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [46]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.006546,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["targets"] = {
					},
					["delay"] = 0,
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["aID"] = "1412",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006546,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["total"] = 0.006546,
					["friendlyfire"] = {
					},
					["tipo"] = 1,
					["nome"] = "Squirrel",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675454529,
					["on_hold"] = false,
					["dps_started"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 606.0065460000001,
					["start_time"] = 1675454526,
					["serial"] = "Creature-0-4457-571-31259-1412-00005D6802",
					["classe"] = "UNKNOW",
				}, -- [47]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.011911,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["targets"] = {
					},
					["delay"] = 0,
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["aID"] = "721",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.011911,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["total"] = 0.011911,
					["friendlyfire"] = {
					},
					["tipo"] = 1,
					["nome"] = "Rabbit",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675454547,
					["on_hold"] = false,
					["dps_started"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 1237.011911,
					["start_time"] = 1675454544,
					["serial"] = "Creature-0-4457-571-31259-721-00005D3670",
					["classe"] = "UNKNOW",
				}, -- [48]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.191238,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["targets"] = {
						["Drushnak"] = 15788,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["aID"] = "30160",
					["raid_targets"] = {
					},
					["total_without_pet"] = 15788.191238,
					["total"] = 15788.191238,
					["serial"] = "Creature-0-4448-571-6723-30160-00005DEE34",
					["dps_started"] = false,
					["end_time"] = 1675488910,
					["classe"] = "UNKNOW",
					["damage_taken"] = 458274.191238,
					["nome"] = "Brittle Revenant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 3557,
								["g_amt"] = 0,
								["n_max"] = 412,
								["targets"] = {
									["Drushnak"] = 15788,
								},
								["n_dmg"] = 12231,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 53,
								["total"] = 15788,
								["c_max"] = 809,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 3,
								["DODGE"] = 8,
								["extra"] = {
								},
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 34,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675488827,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [49]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.026226,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["targets"] = {
						["Drushnak"] = 709,
					},
					["pets"] = {
					},
					["damage_taken"] = 73817.026226,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["aID"] = "30387",
					["raid_targets"] = {
					},
					["total_without_pet"] = 709.026226,
					["classe"] = "UNKNOW",
					["end_time"] = 1675489062,
					["dps_started"] = false,
					["total"] = 709.026226,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "Seething Revenant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Drushnak"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[56620] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 56620,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[56657] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 243,
								["targets"] = {
									["Drushnak"] = 709,
								},
								["n_dmg"] = 709,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 709,
								["c_max"] = 0,
								["id"] = 56657,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["friendlyfire"] = {
					},
					["serial"] = "Creature-0-4448-571-6723-30387-00005DE44B",
					["monster"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675489054,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [50]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.09910899999999997,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Eisenfell"] = 177,
						["Drushnak"] = 6087,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_from"] = {
						["Wirbelwind"] = true,
						["Drushnak"] = true,
					},
					["aID"] = "30144",
					["raid_targets"] = {
					},
					["total_without_pet"] = 6264.099109000001,
					["damage_taken"] = 243110.099109,
					["friendlyfire_total"] = 0,
					["monster"] = true,
					["end_time"] = 1675489163,
					["classe"] = "UNKNOW",
					["total"] = 6264.099109000001,
					["nome"] = "Restless Frostborn Ghost",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1369,
								["g_amt"] = 0,
								["n_max"] = 392,
								["targets"] = {
									["Wirbelwind"] = 0,
									["Drushnak"] = 5486,
								},
								["n_dmg"] = 4117,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 29,
								["total"] = 5486,
								["c_max"] = 770,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 14,
								["extra"] = {
								},
								["b_dmg"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 12,
								["r_amt"] = 0,
								["a_dmg"] = 0,
							}, -- [1]
							[57456] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 106,
								["targets"] = {
									["Eisenfell"] = 177,
									["Drushnak"] = 601,
								},
								["n_dmg"] = 778,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 778,
								["c_max"] = 0,
								["id"] = 57456,
								["r_dmg"] = 177,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 12,
								["b_dmg"] = 0,
								["r_amt"] = 2,
							},
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["last_dps"] = 0,
					["friendlyfire"] = {
					},
					["serial"] = "Creature-0-4448-571-6723-30144-00005DCDE9",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675489106,
					["delay"] = 0,
					["tipo"] = 1,
				}, -- [51]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 163.128377,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Eisenfell"] = 986,
						["Wirbelwind"] = 201,
						["Drushnak"] = 18332,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_from"] = {
						["Eisenfell"] = true,
						["Wirbelwind"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 19519.12837700001,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["monster"] = true,
					["end_time"] = 1675489170,
					["aID"] = "29974",
					["total"] = 19519.12837700001,
					["nome"] = "Niffelem Forefather",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1841,
								["g_amt"] = 0,
								["n_max"] = 501,
								["targets"] = {
									["Eisenfell"] = 345,
									["Wirbelwind"] = 201,
									["Drushnak"] = 14173,
								},
								["n_dmg"] = 12878,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 54,
								["total"] = 14719,
								["c_max"] = 927,
								["DODGE"] = 15,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["b_dmg"] = 0,
								["a_amt"] = 0,
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 31,
								["r_amt"] = 0,
								["MISS"] = 3,
							}, -- [1]
							[57454] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1428,
								["targets"] = {
									["Eisenfell"] = 641,
									["Drushnak"] = 4159,
								},
								["n_dmg"] = 4800,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 4800,
								["c_max"] = 0,
								["id"] = 57454,
								["r_dmg"] = 641,
								["r_amt"] = 1,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 5,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["damage_taken"] = 419133.128377,
					["friendlyfire"] = {
					},
					["serial"] = "Creature-0-4448-571-6723-29974-00005DE9EF",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675489069,
					["delay"] = 0,
					["tipo"] = 1,
				}, -- [52]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 140.066392,
					["damage_from"] = {
						["Eisenfell"] = true,
						["Drushnak"] = true,
					},
					["targets"] = {
						["Eisenfell"] = 140,
						["Drushnak"] = 5034,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 5174.066392000001,
					["damage_taken"] = 137766.066392,
					["aID"] = "30135",
					["dps_started"] = false,
					["total"] = 5174.066392000001,
					["friendlyfire_total"] = 0,
					["last_dps"] = 0,
					["nome"] = "Restless Frostborn Warrior",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1394,
								["g_amt"] = 0,
								["n_max"] = 402,
								["targets"] = {
									["Eisenfell"] = 140,
									["Drushnak"] = 4478,
								},
								["n_dmg"] = 3224,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 19,
								["total"] = 4618,
								["c_max"] = 734,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 2,
								["DODGE"] = 4,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[57456] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 156,
								["targets"] = {
									["Drushnak"] = 556,
								},
								["n_dmg"] = 556,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 556,
								["c_max"] = 0,
								["id"] = 57456,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["end_time"] = 1675489180,
					["tipo"] = 1,
					["serial"] = "Creature-0-4448-571-6723-30135-00005DDA8D",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675489144,
					["delay"] = 0,
					["monster"] = true,
				}, -- [53]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.147045,
					["damage_from"] = {
						["Ethereal Frostworg"] = true,
						["Wirbelwind"] = true,
						["Drushnak"] = true,
					},
					["targets"] = {
						["Drushnak"] = 16701,
						["Ethereal Frostworg"] = 1157,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 17858.147045,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["fight_component"] = true,
					["total"] = 17858.147045,
					["aID"] = "30422",
					["damage_taken"] = 267289.147045,
					["nome"] = "Disembodied Jormungar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 2,
								["c_dmg"] = 792,
								["g_amt"] = 0,
								["n_max"] = 424,
								["targets"] = {
									["Ethereal Frostworg"] = 1157,
									["Wirbelwind"] = 0,
									["Drushnak"] = 16701,
								},
								["n_dmg"] = 17066,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 72,
								["a_dmg"] = 0,
								["total"] = 17858,
								["c_max"] = 792,
								["BLOCK"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 14,
								["MISS"] = 3,
								["extra"] = {
								},
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 50,
								["b_dmg"] = 328,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1675489457,
					["on_hold"] = false,
					["serial"] = "Creature-0-4448-571-6723-30422-00005DED14",
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1675489309,
					["delay"] = 0,
					["tipo"] = 1,
				}, -- [54]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.048938,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 5194,
						["Ethereal Frostworg"] = 4866,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4448-571-6723-30422-00005DEE49",
					["damage_from"] = {
						["Ethereal Frostworg"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 10060.048938,
					["total"] = 10060.048938,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675489583,
					["classe"] = "UNKNOW",
					["aID"] = "30422",
					["nome"] = "Roaming Jormungar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1777,
								["g_amt"] = 0,
								["n_max"] = 417,
								["targets"] = {
									["Ethereal Frostworg"] = 4866,
									["Drushnak"] = 5194,
								},
								["n_dmg"] = 8283,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 35,
								["total"] = 10060,
								["c_max"] = 620,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 4,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 25,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["monster"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675489491,
					["delay"] = 0,
					["damage_taken"] = 187043.048938,
				}, -- [55]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.087861,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ethereal Frostworg"] = 7999,
						["Drushnak"] = 3339,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["damage_from"] = {
						["Ethereal Frostworg"] = true,
						["Drushnak"] = true,
					},
					["aID"] = "30222",
					["raid_targets"] = {
					},
					["total_without_pet"] = 11338.087861,
					["fight_component"] = true,
					["monster"] = true,
					["dps_started"] = false,
					["total"] = 11338.087861,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-4448-571-6723-30222-00005DF158",
					["nome"] = "Stormforged Infiltrator",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1162,
								["g_amt"] = 0,
								["n_max"] = 360,
								["targets"] = {
									["Ethereal Frostworg"] = 7999,
									["Drushnak"] = 3339,
								},
								["n_dmg"] = 10176,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 49,
								["total"] = 11338,
								["c_max"] = 588,
								["DODGE"] = 9,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["r_amt"] = 0,
								["a_amt"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 34,
								["MISS"] = 2,
								["a_dmg"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675489630,
					["damage_taken"] = 202785.087861,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1675489507,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [56]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.113865,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 7986,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 7986.113865,
					["on_hold"] = false,
					["last_dps"] = 0,
					["monster"] = true,
					["total"] = 7986.113865,
					["serial"] = "Creature-0-4448-571-6723-30291-00005DEC67",
					["aID"] = "30291",
					["nome"] = "Ravenous Jormungar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 432,
								["targets"] = {
									["Drushnak"] = 7986,
								},
								["n_dmg"] = 7986,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 45,
								["total"] = 7986,
								["c_max"] = 0,
								["MISS"] = 3,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["DODGE"] = 16,
								["extra"] = {
								},
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 23,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["end_time"] = 1675489858,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 283073.113865,
					["start_time"] = 1675489786,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [57]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.124292,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 15048,
					},
					["fight_component"] = true,
					["pets"] = {
					},
					["total"] = 15048.124292,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 15048.124292,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["tipo"] = 1,
					["dps_started"] = false,
					["end_time"] = 1675489873,
					["aID"] = "30325",
					["classe"] = "UNKNOW",
					["nome"] = "Viscous Oil",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 3112,
								["g_amt"] = 0,
								["n_max"] = 415,
								["targets"] = {
									["Drushnak"] = 15048,
								},
								["n_dmg"] = 11936,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 52,
								["total"] = 15048,
								["c_max"] = 806,
								["MISS"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 11,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["extra"] = {
								},
								["n_amt"] = 34,
								["r_amt"] = 0,
								["a_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["serial"] = "Creature-0-4448-571-6723-30325-00005DED19",
					["on_hold"] = false,
					["last_dps"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 333908.124292,
					["start_time"] = 1675489780,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [58]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.07090800000000003,
					["damage_taken"] = 160499.070908,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Melee Target"] = 17000,
						["Charge Target"] = 63750,
						["Argent Valiant <Drushnak>"] = 17850,
					},
					["pets"] = {
					},
					["serial"] = "Vehicle-0-4460-571-8006-33844-00005DF449",
					["damage_from"] = {
						["Melee Target"] = true,
						["Argent Valiant <Drushnak>"] = true,
					},
					["aID"] = "",
					["raid_targets"] = {
					},
					["total_without_pet"] = 98600.070908,
					["total"] = 98600.070908,
					["last_dps"] = 0,
					["fight_component"] = true,
					["end_time"] = 1675490435,
					["friendlyfire_total"] = 0,
					["ownerName"] = "Drushnak",
					["nome"] = "Sunreaver Hawkstrider <Drushnak>",
					["spells"] = {
						["_ActorTable"] = {
							[62874] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8500,
								["targets"] = {
									["Melee Target"] = 17000,
									["Charge Target"] = 63750,
									["Argent Valiant <Drushnak>"] = 17850,
								},
								["n_dmg"] = 98600,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 98600,
								["c_max"] = 0,
								["id"] = 62874,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 14,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["last_event"] = 0,
					["classe"] = "PET",
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1675490392,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [59]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.07586900000000002,
					["damage_from"] = {
						["Sunreaver Hawkstrider <Drushnak>"] = true,
						["Kadi"] = true,
						["Sunreaver Hawkstrider"] = true,
						["Drushnak"] = true,
					},
					["targets"] = {
					},
					["serial"] = "Creature-0-4460-571-8006-33272-00005ACA35",
					["pets"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.07586900000000002,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 0.07586900000000002,
					["damage_taken"] = 111728.075869,
					["last_event"] = 0,
					["nome"] = "Charge Target",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["aID"] = "33272",
					["end_time"] = 1675490487,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1675490484,
					["delay"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [60]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.05712099999999999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 2646,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4460-571-8006-31718-00005DF1A0",
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 2646.057121,
					["classe"] = "UNKNOW",
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["end_time"] = 1675490591,
					["aID"] = "31718",
					["dps_started"] = false,
					["nome"] = "Frostbrood Whelp",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 416,
								["targets"] = {
									["Drushnak"] = 2646,
								},
								["n_dmg"] = 2646,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 2646,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["DODGE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["total"] = 2646.057121,
					["on_hold"] = false,
					["last_event"] = 0,
					["monster"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 165670.057121,
					["start_time"] = 1675490573,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [61]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.036775,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 1089,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4460-571-8006-31783-00005DF11C",
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 1089.036775,
					["classe"] = "UNKNOW",
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["end_time"] = 1675490608,
					["aID"] = "31783",
					["dps_started"] = false,
					["nome"] = "Vrykul Necrolord",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 403,
								["targets"] = {
									["Drushnak"] = 1089,
								},
								["n_dmg"] = 1089,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 1089,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["total"] = 1089.036775,
					["on_hold"] = false,
					["last_event"] = 0,
					["monster"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 73800.036775,
					["start_time"] = 1675490598,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [62]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.09957199999999998,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 4228,
					},
					["pets"] = {
					},
					["monster"] = true,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 4228.099572,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["total"] = 4228.099572,
					["aID"] = "29880",
					["fight_component"] = true,
					["nome"] = "Jotunheim Warrior",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 729,
								["g_amt"] = 0,
								["n_max"] = 395,
								["targets"] = {
									["Drushnak"] = 4228,
								},
								["n_dmg"] = 3499,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 4228,
								["c_max"] = 729,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675491016,
					["on_hold"] = false,
					["last_event"] = 0,
					["serial"] = "Creature-0-4460-571-8006-29880-00005DAF19",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 212042.099572,
					["start_time"] = 1675490995,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [63]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.191629,
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["targets"] = {
						["Drushnak"] = 38418,
					},
					["pets"] = {
					},
					["monster"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["aID"] = "30037",
					["raid_targets"] = {
					},
					["total_without_pet"] = 38418.19162900001,
					["end_time"] = 1675491092,
					["serial"] = "Creature-0-4460-571-8006-30037-00005DF2CA",
					["dps_started"] = false,
					["total"] = 38418.19162900001,
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["nome"] = "Mjordin Combatant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1378,
								["g_amt"] = 0,
								["n_max"] = 426,
								["targets"] = {
									["Drushnak"] = 19656,
								},
								["n_dmg"] = 18278,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 90,
								["total"] = 19656,
								["c_max"] = 724,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 26,
								["MISS"] = 4,
								["extra"] = {
								},
								["PARRY"] = 6,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 52,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[49807] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 49807,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 5,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[61344] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 420,
								["targets"] = {
									["Drushnak"] = 1896,
								},
								["n_dmg"] = 1896,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 1896,
								["c_max"] = 0,
								["id"] = 61344,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[50370] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Drushnak"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["a_dmg"] = 0,
								["id"] = 50370,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["MISS"] = 1,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 8,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[32736] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 399,
								["targets"] = {
									["Drushnak"] = 1720,
								},
								["n_dmg"] = 1720,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 9,
								["total"] = 1720,
								["c_max"] = 0,
								["id"] = 32736,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["DODGE"] = 3,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 9,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[61343] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 408,
								["targets"] = {
									["Drushnak"] = 2122,
								},
								["n_dmg"] = 2122,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 2122,
								["c_max"] = 0,
								["id"] = 61343,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 6,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[15578] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 620,
								["targets"] = {
									["Drushnak"] = 2622,
								},
								["n_dmg"] = 2622,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 2622,
								["c_max"] = 0,
								["id"] = 15578,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 7,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[61227] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 639,
								["targets"] = {
									["Drushnak"] = 10402,
								},
								["n_dmg"] = 10402,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 10402,
								["c_max"] = 0,
								["a_dmg"] = 0,
								["id"] = 61227,
								["r_dmg"] = 0,
								["DODGE"] = 5,
								["b_dmg"] = 0,
								["a_amt"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 24,
								["extra"] = {
								},
								["n_amt"] = 17,
								["r_amt"] = 0,
								["MISS"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["friendlyfire"] = {
					},
					["damage_taken"] = 938434.191629,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1675490831,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [64]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.6427059999999999,
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Jotunheim Proto-Drake"] = 10483200,
					},
					["last_event"] = 0,
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["damage_from"] = {
					},
					["aID"] = "",
					["raid_targets"] = {
					},
					["total_without_pet"] = 10483200.642706,
					["total"] = 10483200.642706,
					["dps_started"] = false,
					["end_time"] = 1675491390,
					["ownerName"] = "Drushnak",
					["nome"] = "Jotunheim Rapid-Fire Harpoon <Drushnak>",
					["spells"] = {
						["_ActorTable"] = {
							[56578] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 32760,
								["targets"] = {
									["Jotunheim Proto-Drake"] = 10483200,
								},
								["n_dmg"] = 10483200,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 320,
								["total"] = 10483200,
								["c_max"] = 0,
								["id"] = 56578,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 320,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["classe"] = "PET",
					["serial"] = "Vehicle-0-4460-571-8006-30337-00005D6602",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.6427059999999999,
					["start_time"] = 1675491251,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [65]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.6303319999999998,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_from"] = {
						["Jotunheim Rapid-Fire Harpoon <Drushnak>"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.6303319999999998,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["end_time"] = 1675491390,
					["aID"] = "",
					["monster"] = true,
					["nome"] = "Jotunheim Proto-Drake",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["total"] = 0.6303319999999998,
					["on_hold"] = false,
					["last_event"] = 0,
					["serial"] = "Vehicle-0-4460-571-8006-30330-00005D6623",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 10483200.630332,
					["start_time"] = 1675491387,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [66]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.188509,
					["damage_from"] = {
						["Corrupted Scarlet Onslaught"] = true,
						["Drushnak"] = true,
					},
					["targets"] = {
						["Fatnutz"] = 0,
						["Corrupted Scarlet Onslaught"] = 922,
						["Drushnak"] = 69755,
					},
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 70677.188509,
					["fight_component"] = true,
					["serial"] = "Creature-0-4460-571-8006-29333-00005DF4BA",
					["monster"] = true,
					["total"] = 70677.188509,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["nome"] = "Onslaught Gryphon Rider",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 10,
								["b_amt"] = 0,
								["c_dmg"] = 6837,
								["g_amt"] = 0,
								["n_max"] = 463,
								["targets"] = {
									["Fatnutz"] = 0,
									["Corrupted Scarlet Onslaught"] = 846,
									["Drushnak"] = 48483,
								},
								["n_dmg"] = 42492,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 201,
								["total"] = 49329,
								["c_max"] = 806,
								["MISS"] = 9,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 56,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["PARRY"] = 6,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 120,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[40652] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 83,
								["targets"] = {
									["Fatnutz"] = 0,
									["Corrupted Scarlet Onslaught"] = 76,
									["Drushnak"] = 1335,
								},
								["n_dmg"] = 1411,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 33,
								["total"] = 1411,
								["c_max"] = 0,
								["a_dmg"] = 0,
								["id"] = 40652,
								["r_dmg"] = 0,
								["DODGE"] = 9,
								["MISS"] = 1,
								["extra"] = {
								},
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 30,
								["a_amt"] = 0,
								["n_amt"] = 21,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[54617] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1019,
								["targets"] = {
									["Drushnak"] = 19937,
								},
								["n_dmg"] = 19937,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 23,
								["total"] = 19937,
								["c_max"] = 0,
								["id"] = 54617,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 22,
								["a_amt"] = 0,
								["n_amt"] = 22,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["end_time"] = 1675491774,
					["friendlyfire"] = {
					},
					["aID"] = "29333",
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 736838.1885090001,
					["start_time"] = 1675491417,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [67]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.041839,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ebon Blade Vindicator"] = 716,
						["Ebon Blade Winged Defender"] = 530,
						["Ebon Blade Defender"] = 4053,
						["Vile"] = 5864,
						["Drushnak"] = 2522,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4460-571-8006-31438-00005F49B0",
					["damage_from"] = {
						["Ebon Blade Defender"] = true,
						["Vile"] = true,
						["Ebon Blade Winged Defender"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 13685.041839,
					["aID"] = "31438",
					["fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675577964,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["nome"] = "Shadow Vault Abomination",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 348,
								["targets"] = {
									["Ebon Blade Defender"] = 2205,
									["Vile"] = 908,
									["Ebon Blade Winged Defender"] = 247,
									["Drushnak"] = 0,
								},
								["n_dmg"] = 3360,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 3360,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 11,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[16790] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Ebon Blade Winged Defender"] = 0,
									["Ebon Blade Defender"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 16790,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[5568] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 395,
								["targets"] = {
									["Ebon Blade Defender"] = 1848,
									["Ebon Blade Vindicator"] = 716,
									["Ebon Blade Winged Defender"] = 283,
									["Vile"] = 342,
								},
								["n_dmg"] = 3189,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 3189,
								["c_max"] = 0,
								["id"] = 5568,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[55065] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 4614,
								["targets"] = {
									["Vile"] = 4614,
									["Ebon Blade Winged Defender"] = 0,
									["Drushnak"] = 2522,
								},
								["n_dmg"] = 7136,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 7136,
								["c_max"] = 0,
								["id"] = 55065,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["total"] = 13685.041839,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 28344.041839,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675577940,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [68]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.04204500000000001,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ebon Blade Vindicator"] = 573,
						["Ebon Blade Winged Defender"] = 1206,
						["Ebon Blade Defender"] = 10796,
						["Vile"] = 3496,
						["Drushnak"] = 681,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4460-571-8006-31266-00005F4A4F",
					["damage_from"] = {
						["Ebon Blade Vindicator"] = true,
						["Ebon Blade Winged Defender"] = true,
						["Ebon Blade Defender"] = true,
						["Vile"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 16752.042045,
					["aID"] = "31266",
					["fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675577964,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["nome"] = "Shadow Vault Assaulter",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 4,
								["b_amt"] = 1,
								["c_dmg"] = 4615,
								["g_amt"] = 0,
								["n_max"] = 683,
								["targets"] = {
									["Ebon Blade Vindicator"] = 573,
									["Ebon Blade Winged Defender"] = 1206,
									["Ebon Blade Defender"] = 10796,
									["Vile"] = 3496,
									["Drushnak"] = 681,
								},
								["n_dmg"] = 12137,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 16752,
								["c_max"] = 1428,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 21,
								["b_dmg"] = 480,
								["r_amt"] = 0,
							}, -- [1]
							[58905] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 58905,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 16752.042045,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 96804.042045,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675577921,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [69]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.05488,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ebon Blade Defender"] = 5229,
						["Ebon Blade Vindicator"] = 0,
						["Ebon Blade Winged Defender"] = 2240,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4460-571-8006-31251-00005F45FE",
					["damage_from"] = {
						["Ebon Blade Defender"] = true,
						["Ebon Blade Winged Defender"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 7469.054880000001,
					["aID"] = "31251",
					["fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675577964,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["nome"] = "Shadow Vault Skirmisher",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 1117,
								["g_amt"] = 0,
								["n_max"] = 653,
								["targets"] = {
									["Ebon Blade Defender"] = 3324,
									["Ebon Blade Vindicator"] = 0,
									["Ebon Blade Winged Defender"] = 1823,
								},
								["n_dmg"] = 4030,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 5147,
								["c_max"] = 1117,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
							[52207] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 185,
								["targets"] = {
									["Ebon Blade Winged Defender"] = 417,
									["Ebon Blade Defender"] = 1905,
								},
								["n_dmg"] = 2322,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 2322,
								["c_max"] = 0,
								["id"] = 52207,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 14,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["total"] = 7469.054880000001,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 29212.05488,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675577930,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [70]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.016797,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4448-571-6722-33289-00005F4D01",
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.016797,
					["aID"] = "33289",
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 0.016797,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["nome"] = "Lord Everblaze",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Drushnak"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["DODGE"] = 2,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["end_time"] = 1675578873,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 35065.016797,
					["start_time"] = 1675578870,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [71]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.008641,
					["total"] = 43030.00864099999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Sunreaver Hawkstrider <Drushnak>"] = 43030,
					},
					["pets"] = {
					},
					["damage_from"] = {
						["Sunreaver Hawkstrider <Drushnak>"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire"] = {
						["Sunreaver Hawkstrider <Drushnak>"] = {
							["total"] = 0,
							["spells"] = {
								0, -- [1]
							},
						},
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 43030.00864099999,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["end_time"] = 1675579960,
					["tipo"] = 1,
					["ownerName"] = "Drushnak",
					["nome"] = "Argent Valiant <Drushnak>",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3251,
								["targets"] = {
									["Sunreaver Hawkstrider <Drushnak>"] = 15280,
								},
								["n_dmg"] = 15280,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 15280,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[65147] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2000,
								["targets"] = {
									["Sunreaver Hawkstrider <Drushnak>"] = 4800,
								},
								["n_dmg"] = 4800,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 4800,
								["c_max"] = 0,
								["id"] = 65147,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[63010] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8500,
								["targets"] = {
									["Sunreaver Hawkstrider <Drushnak>"] = 22950,
								},
								["n_dmg"] = 22950,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 22950,
								["c_max"] = 0,
								["id"] = 63010,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[1604] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Sunreaver Hawkstrider"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1604,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["aID"] = "33448",
					["monster"] = true,
					["serial"] = "Creature-0-4460-571-8006-33448-00005F520E",
					["last_dps"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1675579927,
					["delay"] = 0,
					["damage_taken"] = 29850.008641,
				}, -- [72]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.033332,
					["damage_from"] = {
						["Undercity Valiant"] = true,
						["Orgrimmar Valiant"] = true,
						["Sen'jin Valiant"] = true,
						["Thunder Bluff Valiant"] = true,
					},
					["targets"] = {
						["Undercity Valiant"] = 48450,
						["Orgrimmar Valiant"] = 22950,
						["Sen'jin Valiant"] = 5950,
						["Thunder Bluff Valiant"] = 51000,
					},
					["serial"] = "Vehicle-0-5563-571-5-33320-000060B007",
					["pets"] = {
					},
					["last_dps"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 128350.033332,
					["classe"] = "PET",
					["dps_started"] = false,
					["total"] = 128350.033332,
					["friendlyfire"] = {
					},
					["ownerName"] = "Drushnak",
					["nome"] = "Orgrimmar Wolf <Drushnak>",
					["spells"] = {
						["_ActorTable"] = {
							[62874] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8500,
								["targets"] = {
									["Undercity Valiant"] = 48450,
									["Orgrimmar Valiant"] = 22950,
									["Sen'jin Valiant"] = 5950,
									["Thunder Bluff Valiant"] = 51000,
								},
								["n_dmg"] = 128350,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 19,
								["total"] = 128350,
								["c_max"] = 0,
								["id"] = 62874,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 19,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["end_time"] = 1675669606,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 285175.033332,
					["start_time"] = 1675669556,
					["delay"] = 0,
					["aID"] = "",
				}, -- [73]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.021564,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Orgrimmar Wolf <Drushnak>"] = 90891,
						["Thunder Bluff Kodo"] = 29755,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-33383-000060AA64",
					["damage_from"] = {
						["Orgrimmar Wolf <Drushnak>"] = true,
						["Orgrimmar Wolf"] = true,
						["Basicstyle"] = true,
						["Cøtillion"] = true,
						["Thunder Bluff Kodo"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 120646.021564,
					["on_hold"] = false,
					["fight_component"] = true,
					["monster"] = true,
					["total"] = 120646.021564,
					["classe"] = "UNKNOW",
					["aID"] = "33383",
					["nome"] = "Thunder Bluff Valiant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3251,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 49091,
									["Thunder Bluff Kodo"] = 14305,
								},
								["n_dmg"] = 63396,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 63396,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 27,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[65147] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2000,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 11200,
									["Thunder Bluff Kodo"] = 1000,
								},
								["n_dmg"] = 12200,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 12200,
								["c_max"] = 0,
								["id"] = 65147,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 9,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[63010] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8500,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 30600,
									["Thunder Bluff Kodo"] = 14450,
								},
								["n_dmg"] = 45050,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 45050,
								["c_max"] = 0,
								["id"] = 63010,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 8,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[1604] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Orgrimmar Wolf"] = 0,
									["Thunder Bluff Kodo"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1604,
								["r_dmg"] = 0,
								["IMMUNE"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["end_time"] = 1675669606,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 161025.021564,
					["start_time"] = 1675669454,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [74]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.021901,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Orgrimmar Wolf <Drushnak>"] = 90130,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-33384-000060ADE9",
					["damage_from"] = {
						["Orgrimmar Wolf <Drushnak>"] = true,
						["Drushnak"] = true,
					},
					["aID"] = "33384",
					["raid_targets"] = {
					},
					["total_without_pet"] = 90130.021901,
					["fight_component"] = true,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 90130.021901,
					["friendlyfire_total"] = 0,
					["end_time"] = 1675669700,
					["nome"] = "Undercity Valiant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 1,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3251,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 31380,
								},
								["n_dmg"] = 31380,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 31380,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 13,
								["b_dmg"] = 170,
								["r_amt"] = 0,
							}, -- [1]
							[65147] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2000,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 22200,
								},
								["n_dmg"] = 22200,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 15,
								["total"] = 22200,
								["c_max"] = 0,
								["id"] = 65147,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 14,
								["a_amt"] = 0,
								["n_amt"] = 15,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[63010] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8500,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 36550,
								},
								["n_dmg"] = 36550,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 36550,
								["c_max"] = 0,
								["id"] = 63010,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 7,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 86900.021901,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675669613,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [75]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.012086,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Orgrimmar Wolf <Drushnak>"] = 51151,
						["Thunder Bluff Kodo"] = 27403,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-33306-000060AEF3",
					["damage_from"] = {
						["Orgrimmar Wolf <Drushnak>"] = true,
						["Basicstyle"] = true,
						["Thunder Bluff Kodo"] = true,
						["Drushnak"] = true,
					},
					["aID"] = "33306",
					["raid_targets"] = {
					},
					["total_without_pet"] = 78554.012086,
					["fight_component"] = true,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 78554.012086,
					["friendlyfire_total"] = 0,
					["end_time"] = 1675669772,
					["nome"] = "Orgrimmar Valiant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 1,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3251,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 15451,
									["Thunder Bluff Kodo"] = 11053,
								},
								["n_dmg"] = 26504,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 26504,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 3096,
								["r_amt"] = 0,
							}, -- [1]
							[65147] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2000,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 10200,
									["Thunder Bluff Kodo"] = 7000,
								},
								["n_dmg"] = 17200,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 17200,
								["c_max"] = 0,
								["id"] = 65147,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 12,
								["a_amt"] = 0,
								["n_amt"] = 11,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[63010] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8500,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 25500,
									["Thunder Bluff Kodo"] = 9350,
								},
								["n_dmg"] = 34850,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 34850,
								["c_max"] = 0,
								["id"] = 63010,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 5,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[1604] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Thunder Bluff Kodo"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1604,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 103050.012086,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675669717,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [76]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.010227,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Orgrimmar Wolf <Drushnak>"] = 53003,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-33285-000060AFA6",
					["damage_from"] = {
						["Orgrimmar Wolf <Drushnak>"] = true,
						["Cøtillion"] = true,
						["Orgrimmar Wolf"] = true,
						["Drushnak"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 53003.01022700001,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1675669877,
					["aID"] = "33285",
					["fight_component"] = true,
					["nome"] = "Sen'jin Valiant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 3251,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 9753,
								},
								["n_dmg"] = 9753,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 9753,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[65147] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2000,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 8400,
								},
								["n_dmg"] = 8400,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 8400,
								["c_max"] = 0,
								["id"] = 65147,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 6,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[63010] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8500,
								["targets"] = {
									["Orgrimmar Wolf <Drushnak>"] = 34850,
								},
								["n_dmg"] = 34850,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 34850,
								["c_max"] = 0,
								["id"] = 63010,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 5,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 53003.01022700001,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 29975.010227,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675669835,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [77]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.051719,
					["damage_from"] = {
						["Drushnak"] = true,
						["Corrupted Scarlet Onslaught"] = true,
					},
					["targets"] = {
						["Drushnak"] = 2408,
						["Corrupted Scarlet Onslaught"] = 21351,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 23759.051719,
					["damage_taken"] = 36908.051719,
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1675670970,
					["aID"] = "29330",
					["classe"] = "UNKNOW",
					["nome"] = "Onslaught Harbor Guard",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 3,
								["b_amt"] = 2,
								["c_dmg"] = 2507,
								["g_amt"] = 0,
								["n_max"] = 487,
								["targets"] = {
									["Drushnak"] = 1074,
									["Corrupted Scarlet Onslaught"] = 21351,
								},
								["n_dmg"] = 19918,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 70,
								["total"] = 22425,
								["c_max"] = 931,
								["a_dmg"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 6,
								["DODGE"] = 9,
								["extra"] = {
								},
								["PARRY"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 49,
								["b_dmg"] = 657,
								["r_amt"] = 0,
							}, -- [1]
							[6660] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 480,
								["targets"] = {
									["Drushnak"] = 1334,
								},
								["n_dmg"] = 1334,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 1334,
								["c_max"] = 0,
								["id"] = 6660,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["total"] = 23759.051719,
					["last_event"] = 0,
					["serial"] = "Creature-0-5563-571-5-29330-00005FC5E6",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675670853,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [78]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.04516199999999999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Imèx"] = 0,
						["Vallbo"] = 1330,
						["Drushnak"] = 6051,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-32255-000060AD2D",
					["damage_from"] = {
						["Vallbo"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 7381.045162,
					["on_hold"] = false,
					["fight_component"] = true,
					["monster"] = true,
					["total"] = 7381.045162,
					["classe"] = "UNKNOW",
					["aID"] = "32255",
					["nome"] = "Converted Hero",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1771,
								["g_amt"] = 0,
								["n_max"] = 396,
								["targets"] = {
									["Imèx"] = 0,
									["Vallbo"] = 1330,
									["Drushnak"] = 4465,
								},
								["n_dmg"] = 4024,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 18,
								["total"] = 5795,
								["c_max"] = 765,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 14,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[19643] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 591,
								["targets"] = {
									["Imèx"] = 0,
									["Drushnak"] = 1586,
									["Vallbo"] = 0,
								},
								["n_dmg"] = 1586,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 1586,
								["c_max"] = 0,
								["id"] = 19643,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[61578] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 61578,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 6,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["end_time"] = 1675671928,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 160450.045162,
					["start_time"] = 1675671903,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [79]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.040753,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Campaign Warhorse <Drushnak>"] = 32326,
						["Campaign Warhorse"] = 738,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-33438-000060BAAA",
					["damage_from"] = {
						["Campaign Warhorse <Drushnak>"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 33064.04075299999,
					["on_hold"] = false,
					["fight_component"] = true,
					["monster"] = true,
					["total"] = 33064.04075299999,
					["classe"] = "UNKNOW",
					["aID"] = "33438",
					["nome"] = "Boneguard Footman",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 1,
								["c_dmg"] = 492,
								["g_amt"] = 0,
								["n_max"] = 2461,
								["targets"] = {
									["Campaign Warhorse <Drushnak>"] = 32326,
									["Campaign Warhorse"] = 738,
								},
								["n_dmg"] = 32572,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 30,
								["total"] = 33064,
								["c_max"] = 492,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["MISS"] = 2,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 25,
								["b_dmg"] = 2306,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["end_time"] = 1675672303,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 195000.040753,
					["start_time"] = 1675672266,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [80]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.017055,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Campaign Warhorse <Drushnak>"] = 34784,
						["Campaign Warhorse"] = 29758,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-34127-000060BAAA",
					["damage_from"] = {
						["Campaign Warhorse <Drushnak>"] = true,
						["Nadage"] = true,
						["Campaign Warhorse"] = true,
						["Xphelan"] = true,
						["Drushnak"] = true,
					},
					["aID"] = "34127",
					["raid_targets"] = {
					},
					["total_without_pet"] = 64542.017055,
					["fight_component"] = true,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 64542.017055,
					["friendlyfire_total"] = 0,
					["end_time"] = 1675672303,
					["nome"] = "Boneguard Commander",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 1,
								["c_dmg"] = 11312,
								["g_amt"] = 0,
								["n_max"] = 3328,
								["targets"] = {
									["Campaign Warhorse <Drushnak>"] = 8984,
									["Campaign Warhorse"] = 19808,
								},
								["n_dmg"] = 17480,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 28792,
								["c_max"] = 6654,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 14,
								["b_dmg"] = 178,
								["r_amt"] = 0,
							}, -- [1]
							[65147] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2000,
								["targets"] = {
									["Campaign Warhorse"] = 4000,
									["Campaign Warhorse <Drushnak>"] = 8800,
								},
								["n_dmg"] = 12800,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 12800,
								["c_max"] = 0,
								["id"] = 65147,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 7,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[63010] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8500,
								["targets"] = {
									["Campaign Warhorse"] = 5950,
									["Campaign Warhorse <Drushnak>"] = 17000,
								},
								["n_dmg"] = 22950,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 22950,
								["c_max"] = 0,
								["id"] = 63010,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[1604] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Campaign Warhorse"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1604,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 224000.017055,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675672230,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [81]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.09660699999999998,
					["damage_from"] = {
						["Boneguard Lieutenant"] = true,
						["Boneguard Footman"] = true,
						["Boneguard Commander"] = true,
						["Boneguard Scout"] = true,
					},
					["targets"] = {
						["Boneguard Commander"] = 18000,
						["Boneguard Footman"] = 45000,
					},
					["serial"] = "Vehicle-0-5563-571-5-33531-000060BAA5",
					["pets"] = {
					},
					["damage_taken"] = 104984.096607,
					["friendlyfire_total"] = 0,
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 63000.096607,
					["end_time"] = 1675672303,
					["dps_started"] = false,
					["total"] = 63000.096607,
					["friendlyfire"] = {
					},
					["ownerName"] = "Drushnak",
					["nome"] = "Campaign Warhorse <Drushnak>",
					["spells"] = {
						["_ActorTable"] = {
							[64591] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 45000,
								["targets"] = {
									["Boneguard Commander"] = 18000,
									["Boneguard Footman"] = 45000,
								},
								["n_dmg"] = 63000,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 63000,
								["c_max"] = 0,
								["id"] = 64591,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["aID"] = "",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675672298,
					["delay"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [82]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.07634,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Campaign Warhorse <Drushnak>"] = 17002,
						["Campaign Warhorse <Xphelan>"] = 92,
						["Campaign Warhorse"] = 1838,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-33550-000060BA38",
					["damage_from"] = {
						["Xphelan"] = true,
						["Nadage"] = true,
						["Drushnak"] = true,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 18932.07634,
					["on_hold"] = false,
					["fight_component"] = true,
					["monster"] = true,
					["total"] = 18932.07634,
					["classe"] = "UNKNOW",
					["aID"] = "33550",
					["nome"] = "Boneguard Scout",
					["spells"] = {
						["_ActorTable"] = {
							[63233] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 919,
								["targets"] = {
									["Campaign Warhorse <Drushnak>"] = 17002,
									["Campaign Warhorse <Xphelan>"] = 92,
									["Campaign Warhorse"] = 1838,
								},
								["n_dmg"] = 18932,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 32,
								["total"] = 18932,
								["c_max"] = 0,
								["id"] = 63233,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 30,
								["a_amt"] = 0,
								["n_amt"] = 32,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["end_time"] = 1675672303,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 310000.07634,
					["start_time"] = 1675672213,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [83]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.010732,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Campaign Warhorse <Drushnak>"] = 20872,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-5-33429-000060BA38",
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 20872.010732,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1675672516,
					["aID"] = "33429",
					["fight_component"] = true,
					["nome"] = "Boneguard Lieutenant",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 1,
								["c_dmg"] = 3445,
								["g_amt"] = 0,
								["n_max"] = 2461,
								["targets"] = {
									["Campaign Warhorse <Drushnak>"] = 20022,
									["Campaign Warhorse"] = 0,
								},
								["n_dmg"] = 16577,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 20022,
								["c_max"] = 3445,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 2306,
								["r_amt"] = 0,
							}, -- [1]
							[63010] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 850,
								["targets"] = {
									["Campaign Warhorse <Drushnak>"] = 850,
								},
								["n_dmg"] = 850,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 850,
								["c_max"] = 0,
								["id"] = 63010,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 20872.010732,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 246000.010732,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675672485,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [84]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.007919,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-10-30445-000060626B",
					["damage_from"] = {
						["Drushnak"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.007919,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1675673961,
					["aID"] = "30445",
					["fight_component"] = true,
					["nome"] = "Ice Steppe Bull",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["total"] = 0.007919,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 12565.007919,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675673958,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [85]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 132370,
					["targets_overheal"] = {
						["Shadowfiend <Atb>"] = 0,
						["Drushnak"] = 0,
						["Treant <Ýurríi>"] = 0,
						["Leayae"] = 0,
						["Atb"] = 0,
						["Ûrsus"] = 0,
						["Arthas"] = 0,
						["Ýurríi"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "PALADIN",
					["totalover"] = 300530.126543,
					["total_without_pet"] = 322245.126543,
					["total"] = 322245.126543,
					["targets_absorbs"] = {
						["Leayae"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["isTank"] = true,
					["serial"] = "Player-4477-03B0B4D0",
					["totalabsorb"] = 102883.126543,
					["last_hps"] = 0,
					["targets"] = {
						["Atb"] = 0,
						["Treant <Ýurríi>"] = 0,
						["Leayae"] = 0,
						["Drushnak"] = 0,
						["Ûrsus"] = 0,
						["Arthas"] = 2520,
						["Ýurríi"] = 0,
					},
					["totalover_without_pet"] = 0.126543,
					["healing_taken"] = 782771.126543,
					["start_time"] = 1675425291,
					["fight_component"] = true,
					["end_time"] = 1675425986,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-03B0B4D0",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[20267] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Shadowfiend <Atb>"] = 2176,
									["Drushnak"] = 89439,
									["Treant <Ýurríi>"] = 7314,
									["Leayae"] = 64131,
									["Atb"] = 9939,
									["Ûrsus"] = 64138,
									["Arthas"] = 39564,
									["Ýurríi"] = 23829,
								},
								["n_max"] = 1260,
								["targets"] = {
									["Shadowfiend <Atb>"] = 0,
									["Drushnak"] = 37375,
									["Treant <Ýurríi>"] = 1248,
									["Leayae"] = 109289,
									["Atb"] = 6206,
									["Ûrsus"] = 47876,
									["Arthas"] = 2520,
									["Ýurríi"] = 14848,
								},
								["n_min"] = 0,
								["counter"] = 769,
								["overheal"] = 300530,
								["total"] = 219362,
								["c_max"] = 0,
								["id"] = 20267,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 769,
								["n_curado"] = 219362,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[58597] = {
								["c_amt"] = 0,
								["totalabsorb"] = 97344,
								["targets_overheal"] = {
								},
								["n_max"] = 1448,
								["targets"] = {
									["Leayae"] = 97344,
								},
								["n_min"] = 0,
								["counter"] = 141,
								["overheal"] = 0,
								["total"] = 97344,
								["c_max"] = 0,
								["id"] = 58597,
								["targets_absorbs"] = {
									["Leayae"] = 97344,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 141,
								["n_curado"] = 97344,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[31852] = {
								["c_amt"] = 0,
								["totalabsorb"] = 2572,
								["targets_overheal"] = {
								},
								["n_max"] = 1292,
								["targets"] = {
									["Leayae"] = 2572,
								},
								["n_min"] = 0,
								["counter"] = 2,
								["overheal"] = 0,
								["total"] = 2572,
								["c_max"] = 0,
								["id"] = 31852,
								["targets_absorbs"] = {
									["Leayae"] = 2572,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 2,
								["n_curado"] = 2572,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[60218] = {
								["c_amt"] = 0,
								["totalabsorb"] = 2967,
								["targets_overheal"] = {
								},
								["n_max"] = 140,
								["targets"] = {
									["Leayae"] = 2967,
								},
								["n_min"] = 0,
								["counter"] = 22,
								["overheal"] = 0,
								["total"] = 2967,
								["c_max"] = 0,
								["id"] = 60218,
								["targets_absorbs"] = {
									["Leayae"] = 2967,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 22,
								["n_curado"] = 2967,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Leayae",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 66,
					["totaldenied"] = 0.126543,
					["delay"] = 0,
					["healing_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
					},
				}, -- [1]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
						["Leayae"] = 0,
						["Drushnak"] = 0,
						["Treant <Ýurríi>"] = 0,
						["Ûrsus"] = 0,
						["Atb"] = 0,
						["Ýurríi"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
						"Shadowfiend <Atb>", -- [1]
					},
					["iniciar_hps"] = false,
					["classe"] = "PRIEST",
					["totalover"] = 479970.090568,
					["total_without_pet"] = 1040552.090568,
					["total"] = 1040552.090568,
					["targets_absorbs"] = {
						["Leayae"] = 0,
						["Ýurríi"] = 0,
						["Ûrsus"] = 0,
						["Drushnak"] = 0,
						["Atb"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-01EA8AA3",
					["totalabsorb"] = 439448.090568,
					["last_hps"] = 0,
					["targets"] = {
						["Leayae"] = 0,
						["Drushnak"] = 0,
						["Ûrsus"] = 0,
						["Atb"] = 0,
						["Ýurríi"] = 0,
					},
					["totalover_without_pet"] = 0.09056800000000001,
					["healing_taken"] = 100783.090568,
					["start_time"] = 1675425276,
					["fight_component"] = true,
					["end_time"] = 1675425986,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-01EA8AA3",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[56160] = {
								["c_amt"] = 19,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Leayae"] = 12587,
									["Drushnak"] = 8801,
									["Ûrsus"] = 2628,
									["Atb"] = 3452,
									["Ýurríi"] = 9458,
								},
								["n_max"] = 1650,
								["targets"] = {
									["Leayae"] = 36641,
									["Drushnak"] = 7258,
									["Ûrsus"] = 14462,
									["Atb"] = 8135,
									["Ýurríi"] = 12240,
								},
								["n_min"] = 0,
								["counter"] = 67,
								["overheal"] = 36926,
								["total"] = 78736,
								["c_max"] = 2357,
								["id"] = 56160,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 28134,
								["n_amt"] = 48,
								["n_curado"] = 50602,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[48068] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Leayae"] = 28574,
									["Ýurríi"] = 3798,
									["Ûrsus"] = 6317,
									["Drushnak"] = 4957,
									["Atb"] = 3798,
								},
								["n_max"] = 2071,
								["targets"] = {
									["Leayae"] = 31084,
									["Ýurríi"] = 5700,
									["Ûrsus"] = 21966,
									["Drushnak"] = 3919,
									["Atb"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 59,
								["overheal"] = 47444,
								["total"] = 62669,
								["c_max"] = 0,
								["id"] = 48068,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 59,
								["n_curado"] = 62669,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[48076] = {
								["c_amt"] = 52,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Leayae"] = 38674,
									["Atb"] = 64816,
									["Treant <Ýurríi>"] = 6498,
									["Ûrsus"] = 33558,
									["Drushnak"] = 60043,
									["Ýurríi"] = 32191,
								},
								["n_max"] = 2096,
								["targets"] = {
									["Leayae"] = 34540,
									["Atb"] = 20840,
									["Treant <Ýurríi>"] = 0,
									["Ûrsus"] = 28300,
									["Drushnak"] = 7517,
									["Ýurríi"] = 20016,
								},
								["n_min"] = 0,
								["counter"] = 156,
								["overheal"] = 235780,
								["total"] = 111213,
								["c_max"] = 2933,
								["id"] = 48076,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 34348,
								["n_amt"] = 104,
								["n_curado"] = 76865,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[48120] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Atb"] = 4737,
								},
								["n_max"] = 5726,
								["targets"] = {
									["Leayae"] = 10908,
									["Atb"] = 5794,
								},
								["n_min"] = 0,
								["counter"] = 4,
								["overheal"] = 4737,
								["total"] = 16702,
								["c_max"] = 0,
								["id"] = 48120,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 4,
								["n_curado"] = 16702,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[47753] = {
								["c_amt"] = 0,
								["totalabsorb"] = 75702,
								["targets_overheal"] = {
								},
								["n_max"] = 3175,
								["targets"] = {
									["Leayae"] = 40870,
									["Ýurríi"] = 5262,
									["Ûrsus"] = 11207,
									["Atb"] = 7797,
									["Drushnak"] = 10566,
								},
								["n_min"] = 0,
								["counter"] = 92,
								["overheal"] = 0,
								["total"] = 75702,
								["c_max"] = 0,
								["id"] = 47753,
								["targets_absorbs"] = {
									["Leayae"] = 40870,
									["Ýurríi"] = 5262,
									["Ûrsus"] = 11207,
									["Atb"] = 7797,
									["Drushnak"] = 10566,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 92,
								["n_curado"] = 75702,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[48300] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Atb"] = 3936,
								},
								["n_max"] = 272,
								["targets"] = {
									["Atb"] = 5174,
								},
								["n_min"] = 0,
								["counter"] = 56,
								["overheal"] = 3936,
								["total"] = 5174,
								["c_max"] = 0,
								["id"] = 48300,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 56,
								["n_curado"] = 5174,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[48071] = {
								["c_amt"] = 3,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 5212,
								["targets"] = {
									["Ûrsus"] = 9667,
									["Leayae"] = 33101,
									["Ýurríi"] = 4887,
								},
								["n_min"] = 0,
								["counter"] = 8,
								["overheal"] = 0,
								["total"] = 47655,
								["c_max"] = 7822,
								["id"] = 48071,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 22739,
								["n_amt"] = 5,
								["n_curado"] = 24916,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[60530] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Atb"] = 3937,
									["Ûrsus"] = 1969,
								},
								["n_max"] = 985,
								["targets"] = {
									["Atb"] = 0,
									["Ûrsus"] = 3938,
								},
								["n_min"] = 0,
								["counter"] = 10,
								["overheal"] = 5906,
								["total"] = 3938,
								["c_max"] = 0,
								["id"] = 60530,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 10,
								["n_curado"] = 3938,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[48072] = {
								["c_amt"] = 11,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Leayae"] = 10954,
									["Drushnak"] = 7542,
									["Ûrsus"] = 12166,
									["Atb"] = 9322,
									["Ýurríi"] = 17418,
								},
								["n_max"] = 4090,
								["targets"] = {
									["Leayae"] = 11724,
									["Atb"] = 10830,
									["Ûrsus"] = 9957,
									["Ýurríi"] = 2699,
									["Drushnak"] = 10477,
								},
								["n_min"] = 0,
								["counter"] = 20,
								["overheal"] = 57402,
								["total"] = 45687,
								["c_max"] = 6052,
								["id"] = 48072,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 26778,
								["n_amt"] = 9,
								["n_curado"] = 18909,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[52985] = {
								["c_amt"] = 13,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Drushnak"] = 4136,
									["Leayae"] = 3796,
									["Ýurríi"] = 3019,
								},
								["n_max"] = 3987,
								["targets"] = {
									["Drushnak"] = 10599,
									["Ûrsus"] = 26535,
									["Leayae"] = 95147,
									["Ýurríi"] = 18848,
								},
								["n_min"] = 0,
								["counter"] = 38,
								["overheal"] = 10951,
								["total"] = 151129,
								["c_max"] = 5853,
								["id"] = 52985,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 66344,
								["n_amt"] = 25,
								["n_curado"] = 84785,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[33110] = {
								["c_amt"] = 6,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Leayae"] = 43337,
									["Ýurríi"] = 2623,
									["Ûrsus"] = 2659,
									["Drushnak"] = 9589,
									["Atb"] = 6955,
								},
								["n_max"] = 4079,
								["targets"] = {
									["Leayae"] = 38240,
									["Ýurríi"] = 5534,
									["Ûrsus"] = 17736,
									["Drushnak"] = 2647,
									["Atb"] = 9361,
								},
								["n_min"] = 0,
								["counter"] = 31,
								["overheal"] = 65163,
								["total"] = 73518,
								["c_max"] = 6118,
								["id"] = 33110,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 14559,
								["n_amt"] = 25,
								["n_curado"] = 58959,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[48066] = {
								["c_amt"] = 0,
								["totalabsorb"] = 363746,
								["targets_overheal"] = {
								},
								["n_max"] = 7446,
								["targets"] = {
									["Leayae"] = 237470,
									["Ýurríi"] = 38518,
									["Ûrsus"] = 29969,
									["Drushnak"] = 32315,
									["Atb"] = 25474,
								},
								["n_min"] = 0,
								["counter"] = 261,
								["overheal"] = 0,
								["total"] = 363746,
								["c_max"] = 0,
								["id"] = 48066,
								["targets_absorbs"] = {
									["Leayae"] = 237470,
									["Ýurríi"] = 38518,
									["Ûrsus"] = 29969,
									["Drushnak"] = 32315,
									["Atb"] = 25474,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 261,
								["n_curado"] = 363746,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[56161] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Leayae"] = 2695,
									["Drushnak"] = 1754,
									["Ûrsus"] = 3349,
									["Atb"] = 1927,
									["Ýurríi"] = 2000,
								},
								["n_max"] = 667,
								["targets"] = {
									["Leayae"] = 874,
									["Atb"] = 1172,
									["Ûrsus"] = 178,
									["Ýurríi"] = 1116,
									["Drushnak"] = 1343,
								},
								["n_min"] = 0,
								["counter"] = 30,
								["overheal"] = 11725,
								["total"] = 4683,
								["c_max"] = 0,
								["id"] = 56161,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 30,
								["n_curado"] = 4683,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Atb",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 256,
					["totaldenied"] = 0.09056800000000001,
					["delay"] = 0,
					["healing_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
					},
				}, -- [2]
				{
					["flag_original"] = 1297,
					["targets_overheal"] = {
						["Campaign Warhorse <Drushnak>"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "ROGUE",
					["totalover"] = 0.109322,
					["total_without_pet"] = 4383.109322,
					["total"] = 4383.109322,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-04D9C2D1",
					["totalabsorb"] = 0.109322,
					["last_hps"] = 0,
					["targets"] = {
						["Drushnak"] = 4383,
						["Campaign Warhorse <Drushnak>"] = 0,
					},
					["totalover_without_pet"] = 0.109322,
					["healing_taken"] = 128767.109322,
					["start_time"] = 1675425975,
					["fight_component"] = true,
					["end_time"] = 1675425986,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-04D9C2D1",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[43185] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 4383,
								["targets"] = {
									["Drushnak"] = 4383,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 0,
								["total"] = 4383,
								["c_max"] = 0,
								["id"] = 43185,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 1,
								["n_curado"] = 4383,
								["absorbed"] = 0,
							},
							[64077] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Campaign Warhorse <Drushnak>"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Campaign Warhorse <Drushnak>"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 64077,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Drushnak",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 259,
					["totaldenied"] = 0.109322,
					["delay"] = 0,
					["healing_from"] = {
						["Drushnak"] = true,
						["Ýurríi"] = true,
						["Leayae"] = true,
						["Atb"] = true,
					},
				}, -- [3]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
						["Drushnak"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
						"Treant <Ýurríi>", -- [1]
					},
					["iniciar_hps"] = false,
					["classe"] = "DRUID",
					["totalover"] = 5459.092014,
					["total_without_pet"] = 2358.092014000001,
					["total"] = 2358.092014000001,
					["targets_absorbs"] = {
						["Ýurríi"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-03859A52",
					["totalabsorb"] = 1990.092014,
					["last_hps"] = 0,
					["targets"] = {
						["Drushnak"] = 0,
						["Ýurríi"] = 0,
					},
					["totalover_without_pet"] = 0.092014,
					["healing_taken"] = 131658.092014,
					["start_time"] = 1675425966,
					["fight_component"] = true,
					["end_time"] = 1675425986,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-03859A52",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[69366] = {
								["c_amt"] = 0,
								["totalabsorb"] = 1990,
								["targets_overheal"] = {
								},
								["n_max"] = 398,
								["targets"] = {
									["Ýurríi"] = 1990,
								},
								["n_min"] = 0,
								["counter"] = 5,
								["overheal"] = 0,
								["total"] = 1990,
								["c_max"] = 0,
								["id"] = 69366,
								["targets_absorbs"] = {
									["Ýurríi"] = 1990,
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 5,
								["n_curado"] = 1990,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[48451] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Drushnak"] = 2946,
								},
								["n_max"] = 368,
								["targets"] = {
									["Drushnak"] = 368,
								},
								["n_min"] = 0,
								["counter"] = 9,
								["overheal"] = 2946,
								["total"] = 368,
								["c_max"] = 0,
								["id"] = 48451,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 9,
								["n_curado"] = 368,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[33778] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Drushnak"] = 2513,
								},
								["n_max"] = 0,
								["targets"] = {
									["Drushnak"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 2513,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 33778,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 1,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Ýurríi",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 102,
					["totaldenied"] = 0.092014,
					["delay"] = 0,
					["healing_from"] = {
						["Ýurríi"] = true,
						["Leayae"] = true,
						["Atb"] = true,
					},
				}, -- [4]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "WARRIOR",
					["totalover"] = 0.109368,
					["total_without_pet"] = 0.109368,
					["total"] = 0.109368,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4477-03A11F28",
					["totalabsorb"] = 0.109368,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.109368,
					["healing_taken"] = 221791.109368,
					["start_time"] = 1675425983,
					["fight_component"] = true,
					["end_time"] = 1675425986,
					["heal_enemy_amt"] = 0,
					["aID"] = "4477-03A11F28",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["nome"] = "Ûrsus",
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["spec"] = 71,
					["totaldenied"] = 0.109368,
					["delay"] = 0,
					["healing_from"] = {
						["Leayae"] = true,
						["Atb"] = true,
					},
				}, -- [5]
				{
					["flag_original"] = 2584,
					["targets_overheal"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 0.025063,
					["total_without_pet"] = 0.025063,
					["total"] = 0.025063,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4445-595-881-26499-00005CFAE2",
					["totalabsorb"] = 0.025063,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.025063,
					["healing_taken"] = 2520.025063,
					["fight_component"] = true,
					["end_time"] = 1675426602,
					["aID"] = "26499",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["healing_from"] = {
						["Leayae"] = true,
					},
					["last_event"] = 0,
					["totaldenied"] = 0.025063,
					["custom"] = 0,
					["tipo"] = 2,
					["heal_enemy_amt"] = 0,
					["start_time"] = 1675426599,
					["delay"] = 0,
					["nome"] = "Arthas",
				}, -- [6]
				{
					["flag_original"] = 4370,
					["targets_overheal"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.013078,
					["total_without_pet"] = 0.013078,
					["total"] = 0.013078,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4445-595-881-1964-00015CFBFF",
					["totalabsorb"] = 0.013078,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.013078,
					["healing_taken"] = 1248.013078,
					["end_time"] = 1675426864,
					["healing_from"] = {
						["Leayae"] = true,
					},
					["nome"] = "Treant <Ýurríi>",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["classe"] = "PET",
					["custom"] = 0,
					["tipo"] = 2,
					["aID"] = "1964",
					["totaldenied"] = 0.013078,
					["delay"] = 0,
					["start_time"] = 1675426861,
				}, -- [7]
				{
					["flag_original"] = 4370,
					["targets_overheal"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.010151,
					["total_without_pet"] = 0.010151,
					["total"] = 0.010151,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4445-595-881-19668-00005CFD27",
					["totalabsorb"] = 0.010151,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.010151,
					["healing_taken"] = 0.010151,
					["end_time"] = 1675427175,
					["healing_from"] = {
					},
					["nome"] = "Shadowfiend <Atb>",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["classe"] = "PET",
					["custom"] = 0,
					["tipo"] = 2,
					["aID"] = "19668",
					["totaldenied"] = 0.010151,
					["delay"] = 0,
					["start_time"] = 1675427172,
				}, -- [8]
				{
					["flag_original"] = 68168,
					["targets_overheal"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "UNKNOW",
					["totalover"] = 0.010108,
					["total_without_pet"] = 0.010108,
					["monster"] = true,
					["total"] = 0.010108,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
						[52724] = 2967,
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4445-595-881-26533-00005CFD11",
					["totalabsorb"] = 0.010108,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.010108,
					["healing_taken"] = 0.010108,
					["end_time"] = 1675427175,
					["aID"] = "26533",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["healing_from"] = {
					},
					["last_event"] = 0,
					["start_time"] = 1675427172,
					["custom"] = 0,
					["tipo"] = 2,
					["heal_enemy_amt"] = 2967,
					["totaldenied"] = 0.010108,
					["delay"] = 0,
					["nome"] = "Mal'Ganis",
				}, -- [9]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["received"] = 165114.100856,
					["resource"] = 0.199696,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Leayae"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "PALADIN",
					["totalover"] = 0.003836,
					["fight_component"] = true,
					["total"] = 164230.100856,
					["aID"] = "4477-03B0B4D0",
					["passiveover"] = 0.003836,
					["nome"] = "Leayae",
					["spells"] = {
						["_ActorTable"] = {
							[63654] = {
								["total"] = 3477,
								["id"] = 63654,
								["totalover"] = 0,
								["targets"] = {
									["Leayae"] = 0,
								},
								["counter"] = 29,
							},
							[43186] = {
								["total"] = 8509,
								["id"] = 43186,
								["totalover"] = 0,
								["targets"] = {
									["Leayae"] = 0,
								},
								["counter"] = 2,
							},
							[28730] = {
								["total"] = 1918,
								["id"] = 28730,
								["totalover"] = 0,
								["targets"] = {
									["Leayae"] = 0,
								},
								["counter"] = 7,
							},
							[54428] = {
								["total"] = 55120,
								["id"] = 54428,
								["totalover"] = 0,
								["targets"] = {
									["Leayae"] = 0,
								},
								["counter"] = 182,
							},
							[31786] = {
								["total"] = 19252,
								["id"] = 31786,
								["totalover"] = 0,
								["targets"] = {
									["Leayae"] = 0,
								},
								["counter"] = 115,
							},
							[57319] = {
								["total"] = 75954,
								["id"] = 57319,
								["totalover"] = 0,
								["targets"] = {
									["Leayae"] = 0,
								},
								["counter"] = 661,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["spec"] = 66,
					["alternatepower"] = 0.100856,
					["tipo"] = 3,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["isTank"] = true,
					["serial"] = "Player-4477-03B0B4D0",
					["flag_original"] = 132370,
				}, -- [1]
				{
					["flag_original"] = 1297,
					["resource"] = 2.993762,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Drushnak"] = 1885,
					},
					["pets"] = {
					},
					["powertype"] = 3,
					["aID"] = "4477-04D9C2D1",
					["passiveover"] = 0.007693,
					["fight_component"] = true,
					["alternatepower"] = 1.68567,
					["received"] = 14343.68566999999,
					["nome"] = "Drushnak",
					["spells"] = {
						["_ActorTable"] = {
							[51637] = {
								["total"] = 5367,
								["id"] = 51637,
								["totalover"] = 0,
								["targets"] = {
									["Drushnak"] = 585,
								},
								["counter"] = 2705,
							},
							[14181] = {
								["total"] = 8975,
								["id"] = 14181,
								["totalover"] = 0,
								["targets"] = {
									["Drushnak"] = 1300,
								},
								["counter"] = 359,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["classe"] = "ROGUE",
					["totalover"] = 0.007693,
					["total"] = 14343.68566999999,
					["tipo"] = 3,
					["spec"] = 259,
					["boss_fight_component"] = true,
					["serial"] = "Player-4477-04D9C2D1",
					["last_event"] = 0,
				}, -- [2]
				{
					["received"] = 56470.083895,
					["resource"] = 0.174671,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ýurríi"] = 0,
						["Leayae"] = 0,
						["Atb"] = 0,
					},
					["pets"] = {
						"Shadowfiend <Atb>", -- [1]
					},
					["powertype"] = 0,
					["classe"] = "PRIEST",
					["totalover"] = 0.004218,
					["fight_component"] = true,
					["total"] = 60417.08389499999,
					["flag_original"] = 1298,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[55382] = {
								["total"] = 8400,
								["id"] = 55382,
								["totalover"] = 0,
								["targets"] = {
									["Atb"] = 0,
								},
								["counter"] = 14,
							},
							[47755] = {
								["total"] = 19416,
								["id"] = 47755,
								["totalover"] = 0,
								["targets"] = {
									["Atb"] = 0,
								},
								["counter"] = 32,
							},
							[64904] = {
								["total"] = 7275,
								["id"] = 64904,
								["totalover"] = 0,
								["targets"] = {
									["Ýurríi"] = 0,
									["Leayae"] = 0,
									["Atb"] = 0,
								},
								["counter"] = 12,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["spec"] = 256,
					["passiveover"] = 0.004218,
					["alternatepower"] = 0.08389500000000001,
					["tipo"] = 3,
					["last_event"] = 0,
					["nome"] = "Atb",
					["serial"] = "Player-4477-01EA8AA3",
					["aID"] = "4477-01EA8AA3",
				}, -- [3]
				{
					["received"] = 60033.10828900001,
					["resource"] = 0.195337,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ýurríi"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "DRUID",
					["totalover"] = 0.008499,
					["fight_component"] = true,
					["total"] = 56970.10828900001,
					["flag_original"] = 1298,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[63654] = {
								["total"] = 887,
								["id"] = 63654,
								["totalover"] = 0,
								["targets"] = {
									["Ýurríi"] = 887,
								},
								["counter"] = 2,
							},
							[53506] = {
								["total"] = 40650,
								["id"] = 53506,
								["totalover"] = 0,
								["targets"] = {
									["Ýurríi"] = 0,
								},
								["counter"] = 91,
							},
							[29166] = {
								["total"] = 14943,
								["id"] = 29166,
								["totalover"] = 0,
								["targets"] = {
									["Ýurríi"] = 14943,
								},
								["counter"] = 19,
							},
							[17057] = {
								["total"] = 0,
								["id"] = 17057,
								["totalover"] = 0,
								["targets"] = {
									["Ýurríi"] = 0,
								},
								["counter"] = 0,
							},
							[64372] = {
								["total"] = 490,
								["id"] = 64372,
								["totalover"] = 0,
								["targets"] = {
									["Ýurríi"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["spec"] = 102,
					["passiveover"] = 0.008499,
					["alternatepower"] = 0.108289,
					["tipo"] = 3,
					["last_event"] = 0,
					["nome"] = "Ýurríi",
					["serial"] = "Player-4477-03859A52",
					["aID"] = "4477-03859A52",
				}, -- [4]
				{
					["flag_original"] = 1298,
					["resource"] = 0.122874,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ûrsus"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["aID"] = "4477-03A11F28",
					["passiveover"] = 0.004774,
					["fight_component"] = true,
					["alternatepower"] = 0.05345799999999999,
					["received"] = 618.553458,
					["nome"] = "Ûrsus",
					["spec"] = 71,
					["grupo"] = true,
					["boss_fight_component"] = true,
					["classe"] = "WARRIOR",
					["totalover"] = 0.004774,
					["last_event"] = 0,
					["tipo"] = 3,
					["total"] = 618.553458,
					["serial"] = "Player-4477-03A11F28",
					["spells"] = {
						["_ActorTable"] = {
							[63653] = {
								["total"] = 8,
								["id"] = 63653,
								["totalover"] = 0,
								["targets"] = {
									["Ûrsus"] = 8,
								},
								["counter"] = 1,
							},
							[2687] = {
								["total"] = 330,
								["id"] = 2687,
								["totalover"] = 0,
								["targets"] = {
									["Ûrsus"] = 0,
								},
								["counter"] = 11,
							},
							[58362] = {
								["total"] = 120,
								["id"] = 58362,
								["totalover"] = 0,
								["targets"] = {
									["Ûrsus"] = 0,
								},
								["counter"] = 12,
							},
							[29131] = {
								["total"] = 160.5,
								["id"] = 29131,
								["totalover"] = 0,
								["targets"] = {
									["Ûrsus"] = 0,
								},
								["counter"] = 107,
							},
						},
						["tipo"] = 7,
					},
				}, -- [5]
				{
					["received"] = 0.006957,
					["resource"] = 0.019217,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Atb"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "PET",
					["totalover"] = 0.003892,
					["total"] = 12060.006957,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							[34650] = {
								["total"] = 12060,
								["id"] = 34650,
								["totalover"] = 0,
								["targets"] = {
									["Atb"] = 0,
								},
								["counter"] = 10,
							},
						},
						["tipo"] = 7,
					},
					["passiveover"] = 0.003892,
					["alternatepower"] = 0.006957,
					["aID"] = "19668",
					["tipo"] = 3,
					["flag_original"] = 4370,
					["last_event"] = 0,
					["serial"] = "Creature-0-4445-595-881-19668-00005CFD27",
					["nome"] = "Shadowfiend <Atb>",
				}, -- [6]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[48817] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 53,
								["id"] = 48817,
								["uptime"] = 33,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48819] = {
								["refreshamt"] = 0,
								["activedamt"] = -2,
								["appliedamt"] = 209,
								["id"] = 48819,
								["uptime"] = 336,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48827] = {
								["actived_at"] = 5026279455,
								["refreshamt"] = 0,
								["activedamt"] = -3,
								["appliedamt"] = 44,
								["id"] = 48827,
								["uptime"] = 156,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[25771] = {
								["actived_at"] = 1675426322,
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 3,
								["id"] = 25771,
								["uptime"] = 60,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53742] = {
								["refreshamt"] = 129,
								["activedamt"] = 1,
								["appliedamt"] = 19,
								["id"] = 53742,
								["uptime"] = 184,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[10308] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = 10308,
								["uptime"] = 4,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[63529] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 43,
								["id"] = 63529,
								["uptime"] = 55,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20185] = {
								["refreshamt"] = 27,
								["activedamt"] = 0,
								["appliedamt"] = 28,
								["id"] = 20185,
								["uptime"] = 471,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[28730] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 18,
								["id"] = 28730,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[62124] = {
								["actived_at"] = 1675426309,
								["refreshamt"] = 0,
								["activedamt"] = -1,
								["appliedamt"] = 21,
								["id"] = 62124,
								["uptime"] = 60,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54499] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 21,
								["id"] = 54499,
								["uptime"] = 99,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[31790] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 19,
								["id"] = 31790,
								["uptime"] = 28,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[35481] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 35481,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57399] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 57399,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59757] = {
								["refreshamt"] = 0,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 59757,
								["uptime"] = 61,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54861] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 54861,
								["uptime"] = 13,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54428] = {
								["refreshamt"] = 1,
								["activedamt"] = 16,
								["appliedamt"] = 16,
								["id"] = 54428,
								["uptime"] = 609,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48942] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 48942,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20132] = {
								["refreshamt"] = 2,
								["activedamt"] = 12,
								["appliedamt"] = 12,
								["id"] = 20132,
								["uptime"] = 81,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[25899] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 25899,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[31884] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 31884,
								["uptime"] = 80,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57940] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 57940,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53601] = {
								["refreshamt"] = 2,
								["activedamt"] = 16,
								["appliedamt"] = 16,
								["id"] = 53601,
								["uptime"] = 553,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48952] = {
								["refreshamt"] = 8,
								["activedamt"] = 22,
								["appliedamt"] = 22,
								["id"] = 48952,
								["uptime"] = 222,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53758] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 53758,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[348704] = {
								["refreshamt"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = 348704,
								["uptime"] = 192,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[25780] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 25780,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[58597] = {
								["refreshamt"] = 10,
								["activedamt"] = 74,
								["appliedamt"] = 74,
								["id"] = 58597,
								["uptime"] = 268,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[64205] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 64205,
								["uptime"] = 40,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[498] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 498,
								["uptime"] = 36,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[28093] = {
								["refreshamt"] = 0,
								["activedamt"] = 15,
								["appliedamt"] = 15,
								["id"] = 28093,
								["uptime"] = 202,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[70940] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 70940,
								["uptime"] = 24,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20375] = {
								["refreshamt"] = 0,
								["activedamt"] = 17,
								["appliedamt"] = 17,
								["id"] = 20375,
								["uptime"] = 679,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60218] = {
								["refreshamt"] = 0,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 60218,
								["uptime"] = 59,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60795] = {
								["refreshamt"] = 69,
								["activedamt"] = 39,
								["appliedamt"] = 39,
								["id"] = 60795,
								["uptime"] = 492,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["dispell"] = 10.035691,
					["cooldowns_defensive"] = 3.014846,
					["pets"] = {
					},
					["tipo"] = 4,
					["cc_done_spells"] = {
						["_ActorTable"] = {
							[10308] = {
								["id"] = 10308,
								["targets"] = {
									["Devouring Ghoul"] = 1,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 9,
					},
					["aID"] = "4477-03B0B4D0",
					["cooldowns_defensive_targets"] = {
						["Leayae"] = 3,
					},
					["dispell_oque"] = {
						[58810] = 1,
						[394608] = 8,
						[58770] = 1,
					},
					["dispell_spells"] = {
						["_ActorTable"] = {
							[4987] = {
								["dispell"] = 8,
								["id"] = 4987,
								["dispell_oque"] = {
									[58810] = 1,
									[394608] = 6,
									[58770] = 1,
								},
								["targets"] = {
									["Ûrsus"] = 1,
									["Leayae"] = 6,
									["Atb"] = 1,
								},
								["counter"] = 0,
							},
							[10872] = {
								["dispell"] = 2,
								["id"] = 10872,
								["dispell_oque"] = {
									[394608] = 2,
								},
								["targets"] = {
									["Leayae"] = 2,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 9708,
					["fight_component"] = true,
					["debuff_uptime"] = 1496,
					["classe"] = "PALADIN",
					["cc_done"] = 1.007636,
					["buff_uptime_targets"] = {
					},
					["spec"] = 66,
					["grupo"] = true,
					["dispell_targets"] = {
						["Ûrsus"] = 1,
						["Leayae"] = 8,
						["Atb"] = 1,
					},
					["spell_cast"] = {
						[20424] = 372,
						[48817] = 12,
						[20271] = 55,
						[48819] = 43,
						[31789] = 11,
						[10308] = 1,
						[48952] = 25,
						[62124] = 23,
						[498] = 3,
						[53601] = 6,
						[43186] = 2,
						[64205] = 4,
						[61411] = 90,
						[56488] = 4,
						[4987] = 7,
						[31884] = 3,
						[59757] = 6,
						[1038] = 1,
						[56350] = 9,
						[48806] = 4,
						[53595] = 105,
						[54428] = 6,
						[20375] = 2,
						[28730] = 7,
						[48827] = 23,
					},
					["nome"] = "Leayae",
					["debuff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["cc_done_targets"] = {
						["Devouring Ghoul"] = 1,
					},
					["cooldowns_defensive_spells"] = {
						["_ActorTable"] = {
							[498] = {
								["id"] = 498,
								["targets"] = {
									["Leayae"] = 3,
								},
								["counter"] = 3,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4477-03B0B4D0",
					["boss_fight_component"] = true,
				}, -- [1]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[48467] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 116,
								["id"] = 48467,
								["uptime"] = 156,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[61391] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 31,
								["id"] = 61391,
								["uptime"] = 26,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48468] = {
								["refreshamt"] = 3,
								["activedamt"] = 0,
								["appliedamt"] = 10,
								["id"] = 48468,
								["uptime"] = 176,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48463] = {
								["actived_at"] = 1675425989,
								["refreshamt"] = 0,
								["activedamt"] = -1,
								["appliedamt"] = 7,
								["id"] = 48463,
								["uptime"] = 34,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[770] = {
								["actived_at"] = 1675426863,
								["refreshamt"] = 0,
								["activedamt"] = -1,
								["appliedamt"] = 3,
								["id"] = 770,
								["uptime"] = 172,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60433] = {
								["refreshamt"] = 196,
								["activedamt"] = 0,
								["appliedamt"] = 31,
								["id"] = 60433,
								["uptime"] = 382,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[48470] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 48470,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53307] = {
								["refreshamt"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = 53307,
								["uptime"] = 465,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[35483] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 35483,
								["uptime"] = 4,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[29166] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 29166,
								["uptime"] = 19,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[24858] = {
								["refreshamt"] = 0,
								["activedamt"] = 21,
								["appliedamt"] = 21,
								["id"] = 24858,
								["uptime"] = 867,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[24907] = {
								["refreshamt"] = 0,
								["activedamt"] = 21,
								["appliedamt"] = 21,
								["id"] = 24907,
								["uptime"] = 867,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[65006] = {
								["refreshamt"] = 443,
								["activedamt"] = 24,
								["appliedamt"] = 24,
								["id"] = 65006,
								["uptime"] = 507,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[10060] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 10060,
								["uptime"] = 60,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57940] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 57940,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48517] = {
								["refreshamt"] = 0,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 48517,
								["uptime"] = 73,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48518] = {
								["refreshamt"] = 0,
								["activedamt"] = 22,
								["appliedamt"] = 22,
								["id"] = 48518,
								["uptime"] = 204,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53201] = {
								["refreshamt"] = 0,
								["activedamt"] = 9,
								["appliedamt"] = 9,
								["id"] = 53201,
								["uptime"] = 90,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[54861] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 54861,
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[16870] = {
								["refreshamt"] = 2,
								["activedamt"] = 26,
								["appliedamt"] = 26,
								["id"] = 16870,
								["uptime"] = 79,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[16886] = {
								["refreshamt"] = 97,
								["activedamt"] = 57,
								["appliedamt"] = 57,
								["id"] = 16886,
								["uptime"] = 296,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60494] = {
								["refreshamt"] = 0,
								["activedamt"] = 19,
								["appliedamt"] = 19,
								["id"] = 60494,
								["uptime"] = 187,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48467] = {
								["actived_at"] = 1675426082,
								["refreshamt"] = 0,
								["activedamt"] = 22,
								["appliedamt"] = 22,
								["id"] = 48467,
								["uptime"] = 153,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[43183] = {
								["refreshamt"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["uptime"] = 0,
								["id"] = 43183,
								["actived_at"] = 3350852990,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48421] = {
								["refreshamt"] = 0,
								["activedamt"] = 21,
								["appliedamt"] = 21,
								["id"] = 48421,
								["uptime"] = 867,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57399] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 57399,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["dispell"] = 5.018356,
					["cooldowns_defensive"] = 2.009664,
					["buff_uptime"] = 7356,
					["last_event"] = 0,
					["cc_done_spells"] = {
						["_ActorTable"] = {
							[61391] = {
								["id"] = 61391,
								["targets"] = {
									["Enraging Ghoul"] = 2,
									["Patchwork Construct"] = 1,
									["Devouring Ghoul"] = 2,
									["Infinite Agent"] = 2,
									["Infinite Adversary"] = 1,
									["Acolyte"] = 3,
									["Risen Zombie"] = 19,
									["Infinite Hunter"] = 1,
								},
								["counter"] = 31,
							},
						},
						["tipo"] = 9,
					},
					["aID"] = "4477-03859A52",
					["cooldowns_defensive_targets"] = {
						["Ýurríi"] = 2,
					},
					["dispell_targets"] = {
						["Ûrsus"] = 1,
						["Ýurríi"] = 3,
						["Drushnak"] = 1,
					},
					["dispell_spells"] = {
						["_ActorTable"] = {
							[2782] = {
								["dispell"] = 3,
								["id"] = 2782,
								["dispell_oque"] = {
									[58845] = 2,
									[52772] = 1,
								},
								["targets"] = {
									["Ûrsus"] = 1,
									["Ýurríi"] = 1,
									["Drushnak"] = 1,
								},
								["counter"] = 0,
							},
							[10872] = {
								["dispell"] = 2,
								["id"] = 10872,
								["dispell_oque"] = {
									[394608] = 1,
									[58810] = 1,
								},
								["targets"] = {
									["Ýurríi"] = 2,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["debuff_uptime"] = 946,
					["classe"] = "DRUID",
					["cc_done"] = 31.018507,
					["nome"] = "Ýurríi",
					["spec"] = 102,
					["grupo"] = true,
					["dispell_oque"] = {
						[52772] = 1,
						[58810] = 1,
						[58845] = 2,
						[394608] = 1,
					},
					["cc_done_targets"] = {
						["Enraging Ghoul"] = 2,
						["Patchwork Construct"] = 1,
						["Devouring Ghoul"] = 2,
						["Infinite Agent"] = 2,
						["Infinite Adversary"] = 1,
						["Acolyte"] = 3,
						["Risen Zombie"] = 19,
						["Infinite Hunter"] = 1,
					},
					["boss_fight_component"] = true,
					["buff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["spell_cast"] = {
						[29166] = 2,
						[24858] = 1,
						[2782] = 3,
						[48451] = 1,
						[2893] = 1,
						[48517] = 5,
						[48518] = 19,
						[53201] = 9,
						[48461] = 176,
						[33831] = 2,
						[61391] = 4,
						[48465] = 63,
						[397567] = 1,
						[48467] = 22,
						[48468] = 13,
						[770] = 3,
						[48463] = 7,
					},
					["cooldowns_defensive_spells"] = {
						["_ActorTable"] = {
							[29166] = {
								["id"] = 29166,
								["targets"] = {
									["Ýurríi"] = 2,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4477-03859A52",
					["debuff_uptime_targets"] = {
					},
				}, -- [2]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[48125] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 9,
								["id"] = 48125,
								["uptime"] = 161,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53023] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 36,
								["id"] = 53023,
								["uptime"] = 132,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48300] = {
								["refreshamt"] = 3,
								["activedamt"] = 0,
								["appliedamt"] = 6,
								["id"] = 48300,
								["uptime"] = 175,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[6788] = {
								["actived_at"] = 3350853113,
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 67,
								["id"] = 6788,
								["uptime"] = 606,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["dispell"] = 38.049967,
					["cooldowns_defensive"] = 2.0115,
					["buff_uptime"] = 8891,
					["nome"] = "Atb",
					["classe"] = "PRIEST",
					["cooldowns_defensive_targets"] = {
						["[*] raid wide cooldown"] = 2,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[8220] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 8220,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48162] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 48162,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[56161] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 56161,
								["uptime"] = 21,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[64904] = {
								["refreshamt"] = 3,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 64904,
								["uptime"] = 11,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[63944] = {
								["refreshamt"] = 30,
								["activedamt"] = 21,
								["appliedamt"] = 21,
								["id"] = 63944,
								["uptime"] = 862,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[15359] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 15359,
								["uptime"] = 18,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48074] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 48074,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48168] = {
								["refreshamt"] = 2,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 48168,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48170] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 48170,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[64911] = {
								["refreshamt"] = 25,
								["activedamt"] = 45,
								["appliedamt"] = 45,
								["id"] = 64911,
								["uptime"] = 252,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59891] = {
								["refreshamt"] = 30,
								["activedamt"] = 40,
								["appliedamt"] = 40,
								["id"] = 59891,
								["uptime"] = 276,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57940] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 57940,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[41635] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 41635,
								["uptime"] = 13,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57821] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 57821,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[586] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 586,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60530] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 60530,
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[14751] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 14751,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[64901] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 64901,
								["uptime"] = 9,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48068] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 48068,
								["uptime"] = 9,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47753] = {
								["refreshamt"] = 3,
								["activedamt"] = 14,
								["appliedamt"] = 14,
								["id"] = 47753,
								["uptime"] = 52,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[45242] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 45242,
								["uptime"] = 24,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[552] = {
								["refreshamt"] = 0,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = 552,
								["uptime"] = 62,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60062] = {
								["refreshamt"] = 0,
								["activedamt"] = 14,
								["appliedamt"] = 14,
								["id"] = 60062,
								["uptime"] = 102,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48066] = {
								["refreshamt"] = 0,
								["activedamt"] = 10,
								["appliedamt"] = 10,
								["id"] = 48066,
								["uptime"] = 175,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57399] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 57399,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["dispell_spells"] = {
						["_ActorTable"] = {
							[397567] = {
								["dispell"] = 1,
								["id"] = 397567,
								["dispell_oque"] = {
									[394608] = 1,
								},
								["targets"] = {
									["Leayae"] = 1,
								},
								["counter"] = 0,
							},
							[988] = {
								["dispell"] = 3,
								["id"] = 988,
								["dispell_oque"] = {
									[58816] = 1,
									[58811] = 2,
								},
								["targets"] = {
									["Leayae"] = 2,
									["Ýurríi"] = 1,
								},
								["counter"] = 0,
							},
							[552] = {
								["dispell"] = 33,
								["id"] = 552,
								["dispell_oque"] = {
									[394608] = 28,
									[58810] = 5,
								},
								["targets"] = {
									["Leayae"] = 13,
									["Drushnak"] = 3,
									["Ûrsus"] = 4,
									["Atb"] = 7,
									["Ýurríi"] = 6,
								},
								["counter"] = 0,
							},
							[10872] = {
								["dispell"] = 1,
								["id"] = 10872,
								["dispell_oque"] = {
									[394608] = 1,
								},
								["targets"] = {
									["Atb"] = 1,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["aID"] = "4477-01EA8AA3",
					["fight_component"] = true,
					["debuff_uptime"] = 1074,
					["cooldowns_defensive_spells"] = {
						["_ActorTable"] = {
							[64901] = {
								["id"] = 64901,
								["targets"] = {
									["[*] raid wide cooldown"] = 2,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
						"Shadowfiend <Atb>", -- [1]
					},
					["debuff_uptime_targets"] = {
					},
					["spec"] = 256,
					["grupo"] = true,
					["spell_cast"] = {
						[988] = 3,
						[48068] = 20,
						[586] = 1,
						[48071] = 8,
						[48072] = 4,
						[34433] = 2,
						[48168] = 1,
						[48078] = 39,
						[10060] = 4,
						[48113] = 12,
						[397567] = 3,
						[64901] = 2,
						[52985] = 38,
						[53000] = 17,
						[48120] = 2,
						[14751] = 3,
						[48158] = 8,
						[48123] = 10,
						[552] = 33,
						[48125] = 10,
						[53023] = 37,
						[48127] = 11,
						[48066] = 67,
						[48300] = 9,
					},
					["last_event"] = 0,
					["dispell_oque"] = {
						[58811] = 2,
						[58810] = 5,
						[394608] = 30,
						[58816] = 1,
					},
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["boss_fight_component"] = true,
					["serial"] = "Player-4477-01EA8AA3",
					["dispell_targets"] = {
						["Leayae"] = 16,
						["Drushnak"] = 3,
						["Ûrsus"] = 4,
						["Atb"] = 8,
						["Ýurríi"] = 7,
					},
				}, -- [3]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[46857] = {
								["refreshamt"] = 256,
								["activedamt"] = 0,
								["appliedamt"] = 63,
								["id"] = 46857,
								["uptime"] = 629,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[20253] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = 20253,
								["uptime"] = 2,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47465] = {
								["refreshamt"] = 5,
								["activedamt"] = 0,
								["appliedamt"] = 31,
								["id"] = 47465,
								["uptime"] = 466,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47502] = {
								["refreshamt"] = 100,
								["activedamt"] = 0,
								["appliedamt"] = 84,
								["id"] = 47502,
								["uptime"] = 456,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[7922] = {
								["actived_at"] = 1675426636,
								["refreshamt"] = 0,
								["activedamt"] = -1,
								["appliedamt"] = 11,
								["id"] = 7922,
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[12721] = {
								["refreshamt"] = 274,
								["activedamt"] = 0,
								["appliedamt"] = 112,
								["id"] = 12721,
								["uptime"] = 603,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47486] = {
								["refreshamt"] = 8,
								["activedamt"] = 0,
								["appliedamt"] = 37,
								["id"] = 47486,
								["uptime"] = 299,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "WARRIOR",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[57522] = {
								["refreshamt"] = 323,
								["activedamt"] = 23,
								["appliedamt"] = 23,
								["id"] = 57522,
								["uptime"] = 748,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60437] = {
								["refreshamt"] = 0,
								["activedamt"] = 21,
								["appliedamt"] = 21,
								["id"] = 60437,
								["uptime"] = 200,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[12328] = {
								["refreshamt"] = 0,
								["activedamt"] = 16,
								["appliedamt"] = 16,
								["id"] = 12328,
								["uptime"] = 113,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[46924] = {
								["refreshamt"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = 46924,
								["uptime"] = 66,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60503] = {
								["refreshamt"] = 6,
								["activedamt"] = 75,
								["appliedamt"] = 75,
								["id"] = 60503,
								["uptime"] = 199,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[64937] = {
								["refreshamt"] = 1,
								["activedamt"] = 10,
								["appliedamt"] = 10,
								["id"] = 64937,
								["uptime"] = 51,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[65156] = {
								["refreshamt"] = 0,
								["activedamt"] = 16,
								["appliedamt"] = 16,
								["id"] = 65156,
								["uptime"] = 126,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60229] = {
								["refreshamt"] = 0,
								["activedamt"] = 22,
								["appliedamt"] = 22,
								["id"] = 60229,
								["uptime"] = 303,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[2457] = {
								["refreshamt"] = 0,
								["appliedamt"] = 5,
								["activedamt"] = 5,
								["uptime"] = 0,
								["id"] = 2457,
								["actived_at"] = 8377132807,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57940] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 57940,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59620] = {
								["refreshamt"] = 24,
								["activedamt"] = 25,
								["appliedamt"] = 25,
								["id"] = 59620,
								["uptime"] = 381,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[1719] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 1719,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[47440] = {
								["refreshamt"] = 1,
								["activedamt"] = 21,
								["appliedamt"] = 21,
								["id"] = 47440,
								["uptime"] = 761,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[29131] = {
								["refreshamt"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = 29131,
								["uptime"] = 110,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[18499] = {
								["refreshamt"] = 0,
								["activedamt"] = 10,
								["appliedamt"] = 10,
								["id"] = 18499,
								["uptime"] = 95,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[52437] = {
								["refreshamt"] = 29,
								["activedamt"] = 53,
								["appliedamt"] = 53,
								["id"] = 52437,
								["uptime"] = 206,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[2458] = {
								["refreshamt"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = 2458,
								["uptime"] = 30,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[35480] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 35480,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 2470,
					["boss_fight_component"] = true,
					["nome"] = "Ûrsus",
					["spec"] = 71,
					["grupo"] = true,
					["spell_cast"] = {
						[20252] = 2,
						[12328] = 14,
						[46924] = 11,
						[2687] = 11,
						[47486] = 45,
						[11578] = 13,
						[47520] = 37,
						[50622] = 77,
						[2457] = 5,
						[47465] = 36,
						[1719] = 3,
						[47502] = 48,
						[47450] = 24,
						[18499] = 10,
						[7384] = 69,
						[47475] = 24,
						[2458] = 5,
						[47440] = 6,
					},
					["debuff_uptime_targets"] = {
					},
					["buff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["buff_uptime"] = 5151,
					["last_event"] = 0,
					["serial"] = "Player-4477-03A11F28",
					["aID"] = "4477-03A11F28",
				}, -- [4]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[48672] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 5,
								["id"] = 48672,
								["uptime"] = 72,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57970] = {
								["refreshamt"] = 2627,
								["activedamt"] = -46,
								["appliedamt"] = 416,
								["id"] = 57970,
								["uptime"] = 2242,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[2094] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = 2094,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[51724] = {
								["refreshamt"] = 0,
								["appliedamt"] = 0,
								["activedamt"] = -38,
								["uptime"] = 0,
								["id"] = 51724,
								["actived_at"] = 63674952769,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[1776] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 18,
								["id"] = 1776,
								["uptime"] = 21,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[1833] = {
								["actived_at"] = 191024682219,
								["refreshamt"] = 0,
								["activedamt"] = -114,
								["appliedamt"] = 24,
								["id"] = 1833,
								["uptime"] = 93,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["dispell"] = 1.003066,
					["cooldowns_defensive"] = 7.047198,
					["pets"] = {
						"Sunreaver Hawkstrider <Drushnak>", -- [1]
						"Argent Valiant <Drushnak>", -- [2]
						"Orgrimmar Wolf <Drushnak>", -- [3]
						"Campaign Warhorse <Drushnak>", -- [4]
					},
					["classe"] = "ROGUE",
					["interrupt_spells"] = {
						["_ActorTable"] = {
							[1766] = {
								["id"] = 1766,
								["interrompeu_oque"] = {
									[60814] = 1,
									[9613] = 1,
									[57454] = 5,
								},
								["targets"] = {
									["Frostbrood Whelp"] = 1,
									["Niffelem Forefather"] = 5,
									["Vrykul Necrolord"] = 1,
								},
								["counter"] = 7,
							},
						},
						["tipo"] = 9,
					},
					["dispell_targets"] = {
						["Drushnak"] = 1,
					},
					["interrompeu_oque"] = {
						[60814] = 1,
						[9613] = 1,
						[57454] = 5,
					},
					["debuff_uptime"] = 2438,
					["buff_uptime_targets"] = {
					},
					["spec"] = 259,
					["cc_break"] = 10.053005,
					["cc_done_targets"] = {
						["Ravenous Jormungar"] = 1,
						["Lord Everblaze"] = 1,
						["Vrykul Necrolord"] = 1,
						["Disembodied Jormungar"] = 12,
						["Bile Golem"] = 1,
						["Jotunheim Warrior"] = 1,
						["Stormforged Infiltrator"] = 10,
						["Infinite Adversary"] = 1,
						["Mjordin Combatant"] = 1,
						["Roaming Jormungar"] = 8,
						["Infinite Agent"] = 2,
						["Risen Zombie"] = 2,
						["Niffelem Forefather"] = 1,
						["Infinite Hunter"] = 1,
					},
					["serial"] = "Player-4477-04D9C2D1",
					["cc_break_spells"] = {
						["_ActorTable"] = {
							[57970] = {
								["cc_break_oque"] = {
									[1776] = 7,
								},
								["id"] = 57970,
								["cc_break"] = 7,
								["targets"] = {
									["Ravenous Jormungar"] = 1,
									["Lord Everblaze"] = 1,
									["Jotunheim Warrior"] = 1,
									["Disembodied Jormungar"] = 4,
								},
								["counter"] = 0,
							},
							[57993] = {
								["cc_break_oque"] = {
									[1776] = 2,
								},
								["id"] = 57993,
								["cc_break"] = 2,
								["targets"] = {
									["Vrykul Necrolord"] = 1,
									["Niffelem Forefather"] = 1,
								},
								["counter"] = 0,
							},
							["DEBUFF"] = {
								["cc_break_oque"] = {
									[1776] = 1,
								},
								["id"] = "DEBUFF",
								["targets"] = {
									["Disembodied Jormungar"] = 1,
								},
								["cc_break"] = 1,
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime_targets"] = {
					},
					["buff_uptime"] = 20019,
					["cc_done_spells"] = {
						["_ActorTable"] = {
							[1833] = {
								["id"] = 1833,
								["targets"] = {
									["Stormforged Infiltrator"] = 10,
									["Roaming Jormungar"] = 8,
									["Risen Zombie"] = 1,
									["Infinite Adversary"] = 1,
									["Infinite Agent"] = 2,
									["Bile Golem"] = 1,
									["Infinite Hunter"] = 1,
								},
								["counter"] = 24,
							},
							[2094] = {
								["id"] = 2094,
								["targets"] = {
									["Risen Zombie"] = 1,
								},
								["counter"] = 1,
							},
							[1776] = {
								["id"] = 1776,
								["targets"] = {
									["Ravenous Jormungar"] = 1,
									["Lord Everblaze"] = 1,
									["Vrykul Necrolord"] = 1,
									["Disembodied Jormungar"] = 12,
									["Jotunheim Warrior"] = 1,
									["Niffelem Forefather"] = 1,
									["Mjordin Combatant"] = 1,
								},
								["counter"] = 18,
							},
						},
						["tipo"] = 9,
					},
					["cooldowns_defensive_targets"] = {
						["Drushnak"] = 7,
					},
					["dispell_oque"] = {
						[394608] = 1,
					},
					["dispell_spells"] = {
						["_ActorTable"] = {
							[10872] = {
								["dispell"] = 1,
								["id"] = 10872,
								["dispell_oque"] = {
									[394608] = 1,
								},
								["targets"] = {
									["Drushnak"] = 1,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["interrupt"] = 7.032161,
					["fight_component"] = true,
					["aID"] = "4477-04D9C2D1",
					["cooldowns_defensive_spells"] = {
						["_ActorTable"] = {
							[26669] = {
								["id"] = 26669,
								["targets"] = {
									["Drushnak"] = 5,
								},
								["counter"] = 5,
							},
							[31224] = {
								["id"] = 31224,
								["targets"] = {
									["Drushnak"] = 1,
								},
								["counter"] = 1,
							},
							[26889] = {
								["id"] = 26889,
								["targets"] = {
									["Drushnak"] = 1,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 9,
					},
					["cc_done"] = 43.21804800000001,
					["boss_fight_component"] = true,
					["grupo"] = true,
					["spell_cast"] = {
						[26669] = 5,
						[2094] = 1,
						[56350] = 1,
						[1766] = 11,
						[48666] = 659,
						[1833] = 26,
						[6774] = 180,
						[48672] = 5,
						[1776] = 19,
						[56488] = 1,
						[921] = 13,
						[43185] = 1,
						[26889] = 1,
						[1784] = 1,
						[31224] = 1,
						[64588] = 24,
						[51723] = 92,
						[51662] = 8,
						[62544] = 34,
					},
					["cc_break_oque"] = {
						[1776] = 10,
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["nome"] = "Drushnak",
					["cc_break_targets"] = {
						["Ravenous Jormungar"] = 1,
						["Lord Everblaze"] = 1,
						["Vrykul Necrolord"] = 1,
						["Disembodied Jormungar"] = 5,
						["Niffelem Forefather"] = 1,
						["Jotunheim Warrior"] = 1,
					},
					["interrupt_targets"] = {
						["Frostbrood Whelp"] = 1,
						["Niffelem Forefather"] = 5,
						["Vrykul Necrolord"] = 1,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[64373] = {
								["refreshamt"] = 0,
								["activedamt"] = 47,
								["appliedamt"] = 47,
								["id"] = 64373,
								["uptime"] = 495,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[60065] = {
								["refreshamt"] = 0,
								["activedamt"] = 107,
								["appliedamt"] = 107,
								["id"] = 60065,
								["uptime"] = 555,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[63848] = {
								["refreshamt"] = 4,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = 63848,
								["uptime"] = 211,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[48101] = {
								["refreshamt"] = 0,
								["activedamt"] = 45,
								["appliedamt"] = 45,
								["id"] = 48101,
								["uptime"] = 199,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[26888] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = 26888,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57993] = {
								["refreshamt"] = 16,
								["activedamt"] = 312,
								["appliedamt"] = 312,
								["id"] = 57993,
								["uptime"] = 604,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[63606] = {
								["refreshamt"] = 0,
								["activedamt"] = 18,
								["appliedamt"] = 18,
								["id"] = 63606,
								["uptime"] = 176,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[43180] = {
								["counter"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["actived_at"] = 1675743985,
								["id"] = 43180,
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							[60233] = {
								["refreshamt"] = 0,
								["activedamt"] = 214,
								["appliedamt"] = 214,
								["id"] = 60233,
								["uptime"] = 1343,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57940] = {
								["refreshamt"] = 0,
								["activedamt"] = 488,
								["appliedamt"] = 488,
								["id"] = 57940,
								["uptime"] = 3833,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[55775] = {
								["refreshamt"] = 0,
								["activedamt"] = 179,
								["appliedamt"] = 179,
								["id"] = 55775,
								["uptime"] = 1108,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[63431] = {
								["refreshamt"] = 0,
								["activedamt"] = 39,
								["appliedamt"] = 39,
								["id"] = 63431,
								["uptime"] = 136,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[63432] = {
								["actived_at"] = 6702688253,
								["refreshamt"] = 0,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 63432,
								["uptime"] = 118,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57822] = {
								["refreshamt"] = 0,
								["activedamt"] = 535,
								["appliedamt"] = 535,
								["id"] = 57822,
								["uptime"] = 4064,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[26669] = {
								["refreshamt"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = 26669,
								["uptime"] = 60,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[57111] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 57111,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[32243] = {
								["refreshamt"] = 0,
								["appliedamt"] = 17,
								["activedamt"] = 17,
								["uptime"] = 0,
								["id"] = 32243,
								["actived_at"] = 28486388687,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[59620] = {
								["refreshamt"] = 20,
								["activedamt"] = 101,
								["appliedamt"] = 101,
								["id"] = 59620,
								["uptime"] = 555,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[1784] = {
								["refreshamt"] = 0,
								["activedamt"] = 35,
								["appliedamt"] = 35,
								["id"] = 1784,
								["uptime"] = 106,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[31224] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 31224,
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[53760] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 53760,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[58427] = {
								["refreshamt"] = 0,
								["activedamt"] = 191,
								["appliedamt"] = 191,
								["id"] = 58427,
								["uptime"] = 1575,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[35480] = {
								["refreshamt"] = 0,
								["activedamt"] = 20,
								["appliedamt"] = 20,
								["id"] = 35480,
								["uptime"] = 871,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[6774] = {
								["refreshamt"] = 14,
								["activedamt"] = 316,
								["appliedamt"] = 316,
								["id"] = 6774,
								["uptime"] = 2263,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
				}, -- [5]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["aID"] = "27737",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 256,
					["spellschool"] = 1,
					["boss_fight_component"] = true,
					["nome"] = "You're Infected!",
					["damage_spellid"] = 394608,
					["debuff_uptime_targets"] = {
						["Leayae"] = {
							["uptime"] = 130,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Drushnak"] = {
							["uptime"] = 34,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Ûrsus"] = {
							["uptime"] = 34,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Atb"] = {
							["uptime"] = 42,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Ýurríi"] = {
							["uptime"] = 16,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
					["last_event"] = 0,
					["damage_twin"] = "Risen Zombie",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-27737-00005CF870",
					["classe"] = "UNKNOW",
				}, -- [6]
				{
					["flag_original"] = 2584,
					["aID"] = "27747",
					["boss_fight_component"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["nome"] = "High Elf Mage-Priest",
					["last_event"] = 0,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-4445-595-881-27747-0000DCF82D",
					["spell_cast"] = {
						[34232] = 26,
					},
				}, -- [7]
				{
					["flag_original"] = 2584,
					["aID"] = "27745",
					["boss_fight_component"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["nome"] = "Lordaeron Footman",
					["last_event"] = 0,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-4445-595-881-27745-0000DCF82D",
					["spell_cast"] = {
						[25710] = 20,
						[52317] = 7,
					},
				}, -- [8]
				{
					["flag_original"] = 2632,
					["nome"] = "Devouring Ghoul",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["spell_cast"] = {
						[58758] = 17,
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["aID"] = "28249",
					["pets"] = {
					},
					["fight_component"] = true,
					["serial"] = "Creature-0-4445-595-881-28249-0000DCF82D",
					["classe"] = "UNKNOW",
				}, -- [9]
				{
					["flag_original"] = 68168,
					["nome"] = "Enraging Ghoul",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["spell_cast"] = {
						[52461] = 18,
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["aID"] = "27729",
					["pets"] = {
					},
					["fight_component"] = true,
					["serial"] = "Creature-0-4445-595-881-27729-00005CF82D",
					["classe"] = "UNKNOW",
				}, -- [10]
				{
					["monster"] = true,
					["nome"] = "Master Necromancer",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["aID"] = "27732",
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["spell_cast"] = {
						[61558] = 8,
						[52611] = 4,
					},
					["flag_original"] = 2632,
					["serial"] = "Creature-0-4445-595-881-27732-00005CF8C0",
					["last_event"] = 0,
				}, -- [11]
				{
					["monster"] = true,
					["nome"] = "Acolyte",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["aID"] = "27731",
					["spell_cast"] = {
						[17234] = 4,
						[15244] = 1,
						[14145] = 4,
						[58811] = 3,
						[46190] = 3,
					},
					["flag_original"] = 2632,
					["serial"] = "Creature-0-4445-595-881-27731-00005CF927",
					["classe"] = "UNKNOW",
				}, -- [12]
				{
					["fight_component"] = true,
					["nome"] = "Dark Necromancer",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 2632,
					["spell_cast"] = {
						[61558] = 1,
						[58770] = 2,
						[20812] = 1,
					},
					["classe"] = "UNKNOW",
					["aID"] = "28200",
					["last_event"] = 0,
					["pets"] = {
					},
					["monster"] = true,
					["serial"] = "Creature-0-4445-595-881-28200-00005CF927",
					["tipo"] = 4,
				}, -- [13]
				{
					["flag_original"] = 2632,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["aID"] = "27737",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 50,
					["spellschool"] = 1,
					["boss_fight_component"] = true,
					["nome"] = "Dazed",
					["damage_spellid"] = 1604,
					["debuff_uptime_targets"] = {
						["Ýurríi"] = {
							["uptime"] = 4,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Ûrsus"] = {
							["uptime"] = 8,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Drushnak"] = {
							["uptime"] = 38,
							["appliedamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Atb"] = {
							["uptime"] = 0,
							["appliedamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
					["last_event"] = 0,
					["damage_twin"] = "Risen Zombie",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-27737-00005CF95C",
					["classe"] = "UNKNOW",
				}, -- [14]
				{
					["flag_original"] = 68168,
					["boss_fight_component"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["aID"] = "26529",
					["nome"] = "Meathook",
					["tipo"] = 4,
					["last_event"] = 0,
					["spell_cast"] = {
						[58823] = 2,
						[58824] = 17,
						[58841] = 3,
					},
					["serial"] = "Creature-0-4445-595-881-26529-00005CF94E",
					["classe"] = "UNKNOW",
				}, -- [15]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 10,
					["spellschool"] = 1,
					["nome"] = "Constricting Chains",
					["aID"] = "26529",
					["damage_spellid"] = 58823,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["damage_twin"] = "Meathook",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-26529-00005CF94E",
					["debuff_uptime_targets"] = {
						["Atb"] = {
							["uptime"] = 5,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Ýurríi"] = {
							["uptime"] = 5,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [16]
				{
					["fight_component"] = true,
					["nome"] = "Crypt Fiend",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 2632,
					["spell_cast"] = {
						[52496] = 7,
						[52491] = 2,
					},
					["aID"] = "27734",
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["monster"] = true,
					["serial"] = "Creature-0-4445-595-881-27734-00005CF9C0",
					["last_event"] = 0,
				}, -- [17]
				{
					["monster"] = true,
					["nome"] = "Bile Golem",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["aID"] = "28201",
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["spell_cast"] = {
						[58810] = 12,
					},
					["flag_original"] = 68168,
					["serial"] = "Creature-0-4445-595-881-28201-00005CF9F6",
					["last_event"] = 0,
				}, -- [18]
				{
					["flag_original"] = 2632,
					["boss_fight_component"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["aID"] = "26530",
					["nome"] = "Salramm the Fleshcrafter",
					["tipo"] = 4,
					["last_event"] = 0,
					["spell_cast"] = {
						[58827] = 7,
						[58845] = 2,
						[52708] = 2,
						[52451] = 3,
						[58825] = 1,
					},
					["serial"] = "Creature-0-4445-595-881-26530-00005CFA8E",
					["classe"] = "UNKNOW",
				}, -- [19]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 9,
					["spellschool"] = 32,
					["nome"] = "Curse of Twisted Flesh",
					["aID"] = "26530",
					["damage_spellid"] = 58845,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["damage_twin"] = "Salramm the Fleshcrafter",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-26530-00005CFA8E",
					["debuff_uptime_targets"] = {
						["Drushnak"] = {
							["uptime"] = 6,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Ûrsus"] = {
							["uptime"] = 3,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [20]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 8,
					["spellschool"] = 32,
					["nome"] = "Steal Flesh",
					["aID"] = "26530",
					["damage_spellid"] = 52708,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["damage_twin"] = "Salramm the Fleshcrafter",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-26530-00005CFA8E",
					["debuff_uptime_targets"] = {
						["Ýurríi"] = {
							["uptime"] = 8,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [21]
				{
					["monster"] = true,
					["nome"] = "Infinite Hunter",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["aID"] = "28340",
					["spell_cast"] = {
						[52636] = 3,
						[58820] = 17,
					},
					["flag_original"] = 2632,
					["serial"] = "Creature-0-4445-595-881-28340-0000DCFAE7",
					["classe"] = "UNKNOW",
				}, -- [22]
				{
					["fight_component"] = true,
					["nome"] = "Infinite Adversary",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["aID"] = "28340",
					["spell_cast"] = {
						[58813] = 6,
						[52633] = 9,
					},
					["flag_original"] = 2632,
					["serial"] = "Creature-0-4445-595-881-28340-00005CFAE7",
					["classe"] = "UNKNOW",
				}, -- [23]
				{
					["monster"] = true,
					["nome"] = "Infinite Agent",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["aID"] = "28341",
					["spell_cast"] = {
						[58817] = 17,
						[58816] = 3,
					},
					["flag_original"] = 68168,
					["serial"] = "Creature-0-4445-595-881-28341-00005CFAE7",
					["classe"] = "UNKNOW",
				}, -- [24]
				{
					["flag_original"] = 68168,
					["boss_fight_component"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["aID"] = "26532",
					["nome"] = "Chrono-Lord Epoch",
					["tipo"] = 4,
					["last_event"] = 0,
					["spell_cast"] = {
						[58848] = 1,
						[52766] = 1,
						[58830] = 1,
						[397342] = 11,
						[52772] = 2,
					},
					["serial"] = "Creature-0-4445-595-881-26532-00005CFBE0",
					["classe"] = "UNKNOW",
				}, -- [25]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 13,
					["spellschool"] = 1,
					["nome"] = "Curse of Exertion",
					["aID"] = "26532",
					["damage_spellid"] = 52772,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["damage_twin"] = "Chrono-Lord Epoch",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-26532-00005CFBE0",
					["debuff_uptime_targets"] = {
						["Ûrsus"] = {
							["uptime"] = 10,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Ýurríi"] = {
							["uptime"] = 3,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [26]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 5,
					["spellschool"] = 64,
					["nome"] = "Time Stop",
					["aID"] = "26532",
					["damage_spellid"] = 58848,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["damage_twin"] = "Chrono-Lord Epoch",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-26532-00005CFBE0",
					["debuff_uptime_targets"] = {
						["Ûrsus"] = {
							["uptime"] = 1,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Leayae"] = {
							["uptime"] = 2,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Atb"] = {
							["uptime"] = 2,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [27]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 4,
					["spellschool"] = 1,
					["nome"] = "Wounding Strike",
					["aID"] = "26532",
					["damage_spellid"] = 58830,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["damage_twin"] = "Chrono-Lord Epoch",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-26532-00005CFBE0",
					["debuff_uptime_targets"] = {
						["Ýurríi"] = {
							["uptime"] = 4,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [28]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 64,
					["nome"] = "Time Warp",
					["aID"] = "26532",
					["damage_spellid"] = 52766,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["damage_twin"] = "Chrono-Lord Epoch",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-26532-00005CFBE0",
					["debuff_uptime_targets"] = {
						["Leayae"] = {
							["uptime"] = 0,
							["appliedamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Atb"] = {
							["uptime"] = 0,
							["appliedamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Ûrsus"] = {
							["uptime"] = 0,
							["appliedamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Ýurríi"] = {
							["uptime"] = 0,
							["appliedamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Drushnak"] = {
							["uptime"] = 0,
							["appliedamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [29]
				{
					["fight_component"] = true,
					["nome"] = "Arthas",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 2584,
					["spell_cast"] = {
						[58822] = 7,
					},
					["aID"] = "26499",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["serial"] = "Creature-0-4445-595-881-26499-00005CFC5F",
					["last_event"] = 0,
				}, -- [30]
				{
					["flag_original"] = 68168,
					["boss_fight_component"] = true,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["aID"] = "26533",
					["nome"] = "Mal'Ganis",
					["tipo"] = 4,
					["last_event"] = 0,
					["spell_cast"] = {
						[58850] = 7,
						[58852] = 9,
						[52723] = 2,
						[58849] = 4,
					},
					["serial"] = "Creature-0-4445-595-881-26533-00005CFD11",
					["classe"] = "UNKNOW",
				}, -- [31]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 41,
					["spellschool"] = 32,
					["nome"] = "Carrion Swarm",
					["aID"] = "26533",
					["damage_spellid"] = 58852,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["damage_twin"] = "Mal'Ganis",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-26533-00005CFD11",
					["debuff_uptime_targets"] = {
						["Leayae"] = {
							["uptime"] = 41,
							["appliedamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [32]
				{
					["flag_original"] = 4370,
					["classe"] = "PET",
					["nome"] = "Shadowfiend <Atb>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["spell_cast"] = {
						[63619] = 1,
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["aID"] = "19668",
					["serial"] = "Creature-0-4445-595-881-19668-00005CFD27",
					["boss_fight_component"] = true,
				}, -- [33]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 24,
					["spellschool"] = 32,
					["nome"] = "Sleep",
					["aID"] = "26533",
					["damage_spellid"] = 58849,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["damage_twin"] = "Mal'Ganis",
					["tipo"] = 4,
					["serial"] = "Creature-0-4445-595-881-26533-00005CFD11",
					["debuff_uptime_targets"] = {
						["Ûrsus"] = {
							["uptime"] = 16,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["Ýurríi"] = {
							["uptime"] = 8,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
				}, -- [34]
				{
					["monster"] = true,
					["nome"] = "Cult Conspirator",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[60842] = 0,
						[14873] = 0,
					},
					["tipo"] = 4,
					["aID"] = "33537",
					["last_event"] = 0,
					["pets"] = {
					},
					["fight_component"] = true,
					["serial"] = "Creature-0-4460-571-8006-33537-0000DCEA0A",
					["classe"] = "UNKNOW",
				}, -- [35]
				{
					["fight_component"] = true,
					["nome"] = "Angry Oak Spirit",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["last_event"] = 0,
					["spell_cast"] = {
						[35361] = 10,
					},
					["aID"] = "33947",
					["serial"] = "Creature-0-4448-571-6722-33947-00005CD5B4",
					["flag_original"] = 68168,
				}, -- [36]
				{
					["flag_original"] = 68168,
					["nome"] = "Sinewy Wolf",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["last_event"] = 0,
					["spell_cast"] = {
						[32919] = 1,
					},
					["aID"] = "31233",
					["serial"] = "Creature-0-4448-571-6722-31233-00005CD46F",
					["fight_component"] = true,
				}, -- [37]
				{
					["flag_original"] = 68136,
					["aID"] = "33229",
					["nome"] = "Melee Target",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["fight_component"] = true,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["spell_cast"] = {
						[62709] = 14,
					},
					["serial"] = "Creature-0-4460-571-8006-33229-00015ACA36",
					["last_event"] = 0,
				}, -- [38]
				{
					["fight_component"] = true,
					["nome"] = "Seething Revenant",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[56620] = 3,
					},
					["aID"] = "30387",
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["monster"] = true,
					["serial"] = "Creature-0-4448-571-6723-30387-00005DE44B",
					["tipo"] = 4,
				}, -- [39]
				{
					["flag_original"] = 4369,
					["last_event"] = 0,
					["ownerName"] = "Drushnak",
					["nome"] = "Sunreaver Hawkstrider <Drushnak>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["classe"] = "PET",
					["spell_cast"] = {
						[62575] = 25,
						[62960] = 6,
					},
					["serial"] = "Vehicle-0-4460-571-8006-33844-00005DF449",
					["aID"] = "",
				}, -- [40]
				{
					["monster"] = true,
					["nome"] = "Mjordin Combatant",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["spell_cast"] = {
						[15578] = 7,
						[61227] = 24,
						[32736] = 9,
						[61343] = 6,
						[49807] = 5,
						[50370] = 8,
					},
					["aID"] = "30037",
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["flag_original"] = 68168,
					["pets"] = {
					},
					["serial"] = "Creature-0-4460-571-8006-30037-00005DF2D9",
					["last_event"] = 0,
				}, -- [41]
				{
					["monster"] = true,
					["nome"] = "Onslaught Gryphon Rider",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["spell_cast"] = {
						[40652] = 30,
						[54617] = 22,
					},
					["aID"] = "29333",
					["tipo"] = 4,
					["last_event"] = 0,
					["flag_original"] = 68168,
					["pets"] = {
					},
					["serial"] = "Creature-0-4460-571-8006-29333-00005DF93F",
					["classe"] = "UNKNOW",
				}, -- [42]
				{
					["fight_component"] = true,
					["nome"] = "Shadow Vault Abomination",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[5568] = 2,
						[55065] = 2,
					},
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["pets"] = {
					},
					["aID"] = "31438",
					["serial"] = "Creature-0-4460-571-8006-31438-00005F49B0",
					["monster"] = true,
				}, -- [43]
				{
					["flag_original"] = 68168,
					["last_event"] = 0,
					["ownerName"] = "Drushnak",
					["nome"] = "Argent Valiant <Drushnak>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["tipo"] = 4,
					["pets"] = {
					},
					["fight_component"] = true,
					["aID"] = "33448",
					["spell_cast"] = {
						[65147] = 3,
						[63010] = 3,
					},
					["serial"] = "Creature-0-4460-571-8006-33448-00005F520E",
					["classe"] = "UNKNOW",
				}, -- [44]
				{
					["flag_original"] = 2632,
					["nome"] = "Niffelem Forefather",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["spell_cast"] = {
						[57454] = 5,
					},
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["aID"] = "29974",
					["fight_component"] = true,
					["pets"] = {
					},
					["serial"] = "Creature-0-5563-571-10-29974-00006075D7",
					["last_event"] = 0,
				}, -- [45]
				{
					["monster"] = true,
					["nome"] = "Thunder Bluff Valiant",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["aID"] = "33383",
					["spell_cast"] = {
						[65147] = 9,
						[63010] = 8,
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-5563-571-5-33383-000060AA64",
					["flag_original"] = 68168,
				}, -- [46]
				{
					["flag_original"] = 4369,
					["aID"] = "",
					["ownerName"] = "Drushnak",
					["nome"] = "Orgrimmar Wolf <Drushnak>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["spell_cast"] = {
						[62960] = 17,
						[62575] = 39,
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Vehicle-0-5563-571-5-33320-000060B007",
					["classe"] = "PET",
				}, -- [47]
				{
					["fight_component"] = true,
					["nome"] = "Undercity Valiant",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[65147] = 14,
						[63010] = 7,
					},
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["last_event"] = 0,
					["pets"] = {
					},
					["aID"] = "33384",
					["serial"] = "Creature-0-5563-571-5-33384-000060ADE9",
					["monster"] = true,
				}, -- [48]
				{
					["fight_component"] = true,
					["nome"] = "Orgrimmar Valiant",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[65147] = 12,
						[63010] = 5,
					},
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["last_event"] = 0,
					["pets"] = {
					},
					["aID"] = "33306",
					["serial"] = "Creature-0-5563-571-5-33306-000060AEF3",
					["monster"] = true,
				}, -- [49]
				{
					["fight_component"] = true,
					["nome"] = "Sen'jin Valiant",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[65147] = 6,
						[63010] = 5,
					},
					["aID"] = "33285",
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["tipo"] = 4,
					["serial"] = "Creature-0-5563-571-5-33285-000060AFA6",
					["monster"] = true,
				}, -- [50]
				{
					["fight_component"] = true,
					["nome"] = "Onslaught Harbor Guard",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 2632,
					["spell_cast"] = {
						[6660] = 3,
					},
					["aID"] = "29330",
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["tipo"] = 4,
					["serial"] = "Creature-0-5563-571-5-29330-000060B0E0",
					["monster"] = true,
				}, -- [51]
				{
					["fight_component"] = true,
					["nome"] = "Shadow Vault Assaulter",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[58905] = 1,
					},
					["aID"] = "31266",
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["tipo"] = 4,
					["serial"] = "Creature-0-5563-571-5-31266-000060B851",
					["monster"] = true,
				}, -- [52]
				{
					["monster"] = true,
					["nome"] = "Converted Hero",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["aID"] = "32255",
					["spell_cast"] = {
						[19643] = 4,
						[61578] = 6,
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-5563-571-5-32255-000060AD2D",
					["flag_original"] = 68168,
				}, -- [53]
				{
					["flag_original"] = 4369,
					["aID"] = "",
					["ownerName"] = "Drushnak",
					["nome"] = "Campaign Warhorse <Drushnak>",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["spell_cast"] = {
						[64595] = 22,
						[62563] = 2,
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Vehicle-0-5563-571-5-33531-000060BAA5",
					["classe"] = "PET",
				}, -- [54]
				{
					["fight_component"] = true,
					["nome"] = "Boneguard Commander",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 2632,
					["spell_cast"] = {
						[65147] = 7,
						[63010] = 3,
					},
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["last_event"] = 0,
					["pets"] = {
					},
					["aID"] = "34127",
					["serial"] = "Creature-0-5563-571-5-34127-000060BAAA",
					["monster"] = true,
				}, -- [55]
				{
					["monster"] = true,
					["nome"] = "Boneguard Scout",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["aID"] = "33550",
					["spell_cast"] = {
						[63233] = 30,
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-5563-571-5-33550-000060BABF",
					["flag_original"] = 68168,
				}, -- [56]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["spells_cast_timeline"] = {
		},
		["tempo_start"] = 1675425808,
		["cleu_timeline"] = {
		},
		["alternate_power"] = {
		},
		["combat_counter"] = 328,
		["totals"] = {
			42272804.880954, -- [1]
			1369538.026456998, -- [2]
			{
				618.5364040000001, -- [1]
				[0] = 293677.2114830001,
				["alternatepower"] = 0,
				[3] = 14343.67797699999,
				[6] = -0.05816900000000658,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 14.068422,
				["dispell"] = 54.10708,
				["interrupt"] = 7.032161,
				["debuff_uptime"] = 0,
				["cc_break"] = 10.053005,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "13:05:40",
		["end_time"] = 708947.517,
		["cleu_events"] = {
			["n"] = 1,
		},
		["totals_grupo"] = {
			28866311.13548701, -- [1]
			1369538.49897, -- [2]
			{
				618.548684, -- [1]
				[0] = 281617.276487,
				["alternatepower"] = 0,
				[3] = 14343.67797699999,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 14.068422,
				["dispell"] = 54.10708,
				["interrupt"] = 7.032161,
				["debuff_uptime"] = 0,
				["cc_break"] = 10.053005,
				["dead"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["frags"] = {
		},
		["hasSaved"] = true,
		["segments_added"] = {
			{
				["elapsed"] = 8.116999999969266,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "12:46:22",
			}, -- [1]
			{
				["elapsed"] = 17.84999999997672,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "12:45:13",
			}, -- [2]
			{
				["elapsed"] = 3.400000000023283,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "12:44:57",
			}, -- [3]
			{
				["elapsed"] = 5.550000000046566,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "12:44:36",
			}, -- [4]
			{
				["elapsed"] = 4.866000000038184,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "12:44:09",
			}, -- [5]
			{
				["elapsed"] = 11.31599999999162,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "12:43:32",
			}, -- [6]
			{
				["elapsed"] = 5.549999999930151,
				["type"] = 0,
				["name"] = "Onslaught Gryphon Rider",
				["clock"] = "12:43:16",
			}, -- [7]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:39:10",
			}, -- [8]
			{
				["elapsed"] = 1.001000000047498,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:39:09",
			}, -- [9]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:39:08",
			}, -- [10]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:39:05",
			}, -- [11]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:39:04",
			}, -- [12]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:39:03",
			}, -- [13]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:39:00",
			}, -- [14]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:59",
			}, -- [15]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:56",
			}, -- [16]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:53",
			}, -- [17]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:52",
			}, -- [18]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:48",
			}, -- [19]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:44",
			}, -- [20]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:40",
			}, -- [21]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:36",
			}, -- [22]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:35",
			}, -- [23]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:32",
			}, -- [24]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:30",
			}, -- [25]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:29",
			}, -- [26]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:27",
			}, -- [27]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:24",
			}, -- [28]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:20",
			}, -- [29]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:18",
			}, -- [30]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:17",
			}, -- [31]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:16",
			}, -- [32]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:14",
			}, -- [33]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:10",
			}, -- [34]
			{
				["elapsed"] = 1.016000000061467,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:07",
			}, -- [35]
			{
				["elapsed"] = 1,
				["type"] = 0,
				["name"] = "Jotunheim Proto-Drake",
				["clock"] = "12:38:06",
			}, -- [36]
			{
				["elapsed"] = 15.75,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "12:37:16",
			}, -- [37]
			{
				["elapsed"] = 14.31700000003912,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "12:36:35",
			}, -- [38]
			{
				["elapsed"] = 11.5010000000475,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "12:35:43",
			}, -- [39]
			{
				["elapsed"] = 14.09999999997672,
				["type"] = 0,
				["name"] = "Mjordin Combatant",
				["clock"] = "12:35:13",
			}, -- [40]
		},
		["data_fim"] = "12:46:30",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage_section"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage"] = {
			},
		},
		["start_time"] = 704901.8020000007,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["last_events_tables"] = {
		},
	},
	["force_font_outline"] = "",
	["last_day"] = "08",
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["verticalSnap"] = true,
			["isLocked"] = false,
			["is_open"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
			},
			["snap"] = {
				[4] = 2,
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -359.12353515625,
					["x"] = 610.7657470703125,
					["w"] = 166.1976318359375,
					["h"] = 135.0862884521484,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["modo"] = 4,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = true,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["isLocked"] = false,
			["is_open"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
				[2] = 1,
			},
			["segment"] = 0,
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -226.5557556152344,
					["x"] = 610.7657470703125,
					["w"] = 166.1976318359375,
					["h"] = 90.04927825927734,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-4477-04DB2B0D"] = 252,
		["Player-4477-037193FC"] = 264,
		["Player-4477-04D9C2D1"] = 259,
	},
}
