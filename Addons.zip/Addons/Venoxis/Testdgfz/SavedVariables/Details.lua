
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 3,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00355,
							["on_hold"] = false,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 62,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 62.00355,
							["aID"] = "4477-04C42EFC",
							["dps_started"] = false,
							["total"] = 62.00355,
							["classe"] = "ROGUE",
							["serial"] = "Player-4477-04C42EFC",
							["nome"] = "Testdgfz",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 9,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 25,
										},
										["n_dmg"] = 16,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 25,
										["c_max"] = 9,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 9,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Scheckiger Eber"] = 15,
										},
										["n_dmg"] = 15,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Scheckiger Eber"] = 22,
										},
										["n_dmg"] = 22,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["end_time"] = 1669212280,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 6.003550000000001,
							["start_time"] = 1669212274,
							["delay"] = 0,
							["last_event"] = 1669212280,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.001051,
							["damage_from"] = {
								["Testdgfz"] = true,
							},
							["targets"] = {
								["Testdgfz"] = 6,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6.001051,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212280,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["Testdgfz"] = 6,
										},
										["n_dmg"] = 6,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 6,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "3098",
							["total"] = 6.001051,
							["serial"] = "Creature-0-4479-1-117-3098-00007E26FD",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212280,
							["damage_taken"] = 62.001051,
							["start_time"] = 1669212276,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 3,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 3,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 3,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Testdgfz",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 2,
							},
							["tipo"] = 4,
							["aID"] = "4477-04C42EFC",
							["serial"] = "Player-4477-04C42EFC",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 3,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Testdgfz"] = true,
				},
				["raid_roster_indexed"] = {
					"Testdgfz", -- [1]
				},
				["CombatStartedAt"] = 1021167.329,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 6,
				["playing_solo"] = true,
				["totals"] = {
					68, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:04:41",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 6.283999999985099,
				["CombatEndedAt"] = 1021173.613,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:04:35",
				["end_time"] = 1021173.613,
				["combat_id"] = 3,
				["tempo_start"] = 1669212274,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					62, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Testdgfz"] = 62.00355,
						}, -- [1]
					},
				},
				["start_time"] = 1021167.329,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [1]
			{
				{
					["combatId"] = 2,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001624,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 42,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 42.001624,
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1669212262,
							["friendlyfire_total"] = 0,
							["aID"] = "4477-04C42EFC",
							["nome"] = "Testdgfz",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 14,
										},
										["n_dmg"] = 14,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 14,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Scheckiger Eber"] = 7,
										},
										["n_dmg"] = 7,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 7,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[2098] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 21,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Scheckiger Eber"] = 21,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 21,
										["c_max"] = 21,
										["id"] = 2098,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 21,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["total"] = 42.001624,
							["serial"] = "Player-4477-04C42EFC",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212262,
							["damage_taken"] = 3.001624,
							["start_time"] = 1669212259,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.006153,
							["damage_from"] = {
								["Testdgfz"] = true,
							},
							["targets"] = {
								["Testdgfz"] = 3,
							},
							["pets"] = {
							},
							["total"] = 3.006153,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 3.006153,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212262,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["Testdgfz"] = 3,
										},
										["n_dmg"] = 3,
										["n_min"] = 1,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "3098",
							["serial"] = "Creature-0-4479-1-117-3098-00007E1281",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212261,
							["damage_taken"] = 42.006153,
							["start_time"] = 1669212259,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 2,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 2,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 2,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Testdgfz",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["spell_cast"] = {
								[1752] = 1,
								[2098] = 1,
							},
							["tipo"] = 4,
							["aID"] = "4477-04C42EFC",
							["serial"] = "Player-4477-04C42EFC",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 2,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Testdgfz"] = true,
				},
				["raid_roster_indexed"] = {
					"Testdgfz", -- [1]
				},
				["CombatStartedAt"] = 1021152.396,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 5,
				["playing_solo"] = true,
				["totals"] = {
					45, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:04:23",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 3.483000000007451,
				["CombatEndedAt"] = 1021155.879,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:04:20",
				["end_time"] = 1021155.879,
				["combat_id"] = 2,
				["tempo_start"] = 1669212259,
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					42, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Testdgfz"] = 42.001624,
						}, -- [1]
					},
				},
				["start_time"] = 1021152.396,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [2]
			{
				{
					["combatId"] = 1,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.008441,
							["damage_from"] = {
								["Testdgfz"] = true,
							},
							["targets"] = {
								["Testdgfz"] = 2,
							},
							["pets"] = {
							},
							["total"] = 2.008441,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2.008441,
							["friendlyfire"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1669212255,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["nome"] = "Scheckiger Eber",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1,
										["targets"] = {
											["Testdgfz"] = 2,
										},
										["n_dmg"] = 2,
										["n_min"] = 1,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "3098",
							["serial"] = "Creature-0-4479-1-117-3098-00007E127B",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212252,
							["damage_taken"] = 43.00844100000001,
							["start_time"] = 1669212250,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00486,
							["damage_from"] = {
								["Scheckiger Eber"] = true,
							},
							["targets"] = {
								["Scheckiger Eber"] = 43,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 43.00486,
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1669212255,
							["friendlyfire_total"] = 0,
							["aID"] = "4477-04C42EFC",
							["nome"] = "Testdgfz",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 4,
										["g_amt"] = 1,
										["n_max"] = 5,
										["targets"] = {
											["Scheckiger Eber"] = 21,
										},
										["n_dmg"] = 12,
										["n_min"] = 3,
										["g_dmg"] = 5,
										["counter"] = 6,
										["total"] = 21,
										["c_max"] = 4,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 4,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Scheckiger Eber"] = 22,
										},
										["n_dmg"] = 22,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["total"] = 43.00486,
							["serial"] = "Player-4477-04C42EFC",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1669212254,
							["damage_taken"] = 2.00486,
							["start_time"] = 1669212250,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 1,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 1,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 1,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Testdgfz",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["spell_cast"] = {
								[1752] = 2,
							},
							["tipo"] = 4,
							["aID"] = "4477-04C42EFC",
							["serial"] = "Player-4477-04C42EFC",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 1,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Testdgfz"] = true,
				},
				["raid_roster_indexed"] = {
					"Testdgfz", -- [1]
				},
				["tempo_start"] = 1669212250,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 4,
				["playing_solo"] = true,
				["totals"] = {
					45, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					43, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:04:15",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Scheckiger Eber",
				["TotalElapsedCombatTime"] = 1021148.212,
				["CombatEndedAt"] = 1021148.212,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Testdgfz"] = 43.00486,
						}, -- [1]
					},
				},
				["end_time"] = 1021148.212,
				["combat_id"] = 1,
				["cleu_events"] = {
					["n"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["overall_added"] = true,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "15:04:11",
				["start_time"] = 1021143.362,
				["TimeData"] = {
				},
				["frags"] = {
					["Scheckiger Eber"] = 1,
				},
			}, -- [3]
		},
	},
	["ocd_tracker"] = {
		["enabled"] = false,
		["current_cooldowns"] = {
		},
		["lines_per_column"] = 12,
		["show_options"] = false,
		["filters"] = {
			["defensive-raid"] = false,
			["ofensive"] = true,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["width"] = 120,
		["height"] = 18,
		["framme_locked"] = false,
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["cooldowns"] = {
		},
		["pos"] = {
		},
	},
	["last_version"] = "3.4.0 10259",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["on_death_menu"] = false,
	["cached_talents"] = {
	},
	["last_instance_id"] = 0,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Testdgfz-Venoxis",
	["last_realversion"] = 146,
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["disable_gouge"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["useclasscolors"] = false,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["last_section_selected"] = "main",
			["author"] = "Terciob",
			["window_scale"] = 1,
			["hide_on_combat"] = false,
			["show_icon"] = 5,
			["opened"] = 0,
			["encounter_timers_dbm"] = {
			},
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["grow_direction"] = "right",
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["scale"] = 1,
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 338.4489600712638,
				["radius"] = 160,
				["hide"] = false,
			},
			["point"] = "CENTER",
			["arrow_anchor_x"] = 0,
			["y"] = -1.52587890625e-05,
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_height"] = 20,
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["use_spark"] = true,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["main_frame_strata"] = "LOW",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -1.52587890625e-05,
				["x"] = -3.0517578125e-05,
				["update_speed"] = 0.05,
				["size"] = 32,
				["attribute_type"] = 1,
			},
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["arrow_anchor_y"] = 0,
			["font_size"] = 10,
			["main_frame_locked"] = false,
			["author"] = "Details! Team",
		},
	},
	["last_day"] = "23",
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = false,
			["isLocked"] = false,
			["snap"] = {
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 0,
					["x"] = 6.103515625e-05,
					["w"] = 310.0000610351563,
					["h"] = 157.9999847412109,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["last_instance_time"] = 0,
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["cached_roles"] = {
	},
	["ignore_nicktag"] = false,
	["combat_id"] = 3,
	["savedStyles"] = {
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1670508228,
		["last_version"] = 15,
	},
	["combat_counter"] = 6,
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.022353,
					["aID"] = "3098",
					["damage_from"] = {
						["Testdgfz"] = true,
					},
					["targets"] = {
						["Testdgfz"] = 11,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 11.022353,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1669212255,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["nome"] = "Scheckiger Eber",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["Testdgfz"] = 11,
								},
								["n_dmg"] = 11,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 11,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 7,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire"] = {
					},
					["total"] = 11.022353,
					["serial"] = "Creature-0-4479-1-117-3098-00007E127B",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 147.022353,
					["start_time"] = 1669212240,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [1]
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.012418,
					["aID"] = "4477-04C42EFC",
					["damage_from"] = {
						["Scheckiger Eber"] = true,
					},
					["targets"] = {
						["Scheckiger Eber"] = 147,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 147.012418,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1669212255,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "Testdgfz",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 13,
								["g_amt"] = 1,
								["n_max"] = 5,
								["targets"] = {
									["Scheckiger Eber"] = 60,
								},
								["n_dmg"] = 42,
								["n_min"] = 0,
								["g_dmg"] = 5,
								["counter"] = 18,
								["total"] = 60,
								["c_max"] = 9,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 4,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 11,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[1752] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["Scheckiger Eber"] = 44,
								},
								["n_dmg"] = 44,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 44,
								["c_max"] = 0,
								["id"] = 1752,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[2098] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 21,
								["g_amt"] = 0,
								["n_max"] = 12,
								["targets"] = {
									["Scheckiger Eber"] = 43,
								},
								["n_dmg"] = 22,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 43,
								["c_max"] = 21,
								["id"] = 2098,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["grupo"] = true,
					["total"] = 147.012418,
					["serial"] = "Player-4477-04C42EFC",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 11.012418,
					["start_time"] = 1669212238,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [2]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["last_event"] = 0,
					["nome"] = "Testdgfz",
					["grupo"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						[1752] = 5,
						[2098] = 3,
					},
					["aID"] = "4477-04C42EFC",
					["classe"] = "ROGUE",
					["serial"] = "Player-4477-04C42EFC",
					["tipo"] = 4,
				}, -- [1]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["tempo_start"] = 1669212250,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["combat_counter"] = 3,
		["spells_cast_timeline"] = {
		},
		["totals"] = {
			158.025679, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "15:04:11",
		["end_time"] = 1021173.613,
		["cleu_events"] = {
			["n"] = 1,
		},
		["segments_added"] = {
			{
				["elapsed"] = 6.283999999985099,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:04:35",
			}, -- [1]
			{
				["elapsed"] = 3.483000000007451,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:04:20",
			}, -- [2]
			{
				["elapsed"] = 4.850000000093132,
				["type"] = 0,
				["name"] = "Scheckiger Eber",
				["clock"] = "15:04:11",
			}, -- [3]
		},
		["totals_grupo"] = {
			147.010034, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["frags"] = {
		},
		["data_fim"] = "15:04:41",
		["overall_enemy_name"] = "Scheckiger Eber",
		["CombatSkillCache"] = {
		},
		["cleu_timeline"] = {
		},
		["start_time"] = 1021158.996,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
			["damage"] = {
			},
		},
	},
	["character_data"] = {
		["logons"] = 1,
	},
	["force_font_outline"] = "",
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
	},
}
