
EncounterDetailsDB = {
	["emotes"] = {
		{
			{
				45.45100000000093, -- [1]
				"%s overcharges a Tempest Minion!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [1]
			{
				53.41800000000512, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [2]
			{
				60.0679999999993, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [3]
			{
				87.58499999999185, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [4]
			{
				90.80199999999604, -- [1]
				"%s overcharges a Tempest Minion!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [5]
			{
				106.8360000000102, -- [1]
				"A Tempest Minion appears to defend Emalon!", -- [2]
				"Emalon the Storm Watcher", -- [3]
				1, -- [4]
			}, -- [6]
			["boss"] = "Emalon the Storm Watcher",
		}, -- [1]
		{
			{
				46.70100000000093, -- [1]
				"%s lunges for Tonyhawkings!", -- [2]
				"Archavon the Stone Watcher", -- [3]
				1, -- [4]
			}, -- [1]
			["boss"] = "Archavon the Stone Watcher",
		}, -- [2]
	},
	["encounter_spells"] = {
		[64363] = {
			["school"] = 8,
			["token"] = {
				["SPELL_CAST_SUCCESS"] = true,
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Tempest Minion",
		},
		[64216] = {
			["school"] = 8,
			["token"] = {
				["SPELL_CAST_START"] = true,
				["SPELL_CAST_SUCCESS"] = true,
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Emalon the Storm Watcher",
		},
		[58695] = {
			["school"] = 1,
			["token"] = {
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Archavon the Stone Watcher",
		},
		[64213] = {
			["school"] = 8,
			["token"] = {
				["SPELL_CAST_START"] = true,
				["SPELL_CAST_SUCCESS"] = true,
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Emalon the Storm Watcher",
		},
		[58696] = {
			["school"] = 1,
			["token"] = {
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Archavon the Stone Watcher",
		},
		[64218] = {
			["school"] = 8,
			["token"] = {
				["SPELL_CAST_SUCCESS"] = true,
				["SPELL_HEAL"] = true,
			},
			["source"] = "Emalon the Storm Watcher",
		},
		[64217] = {
			["school"] = 1,
			["type"] = "BUFF",
			["token"] = {
				["SPELL_AURA_APPLIED"] = true,
			},
			["source"] = "Tempest Minion",
		},
		[58960] = {
			["school"] = 1,
			["token"] = {
				["SPELL_CAST_SUCCESS"] = true,
			},
			["source"] = "Archavon the Stone Watcher",
		},
		[1604] = {
			["school"] = 1,
			["type"] = "DEBUFF",
			["token"] = {
				["SPELL_AURA_APPLIED"] = true,
			},
			["source"] = "Tempest Minion",
		},
		[58963] = {
			["school"] = 1,
			["token"] = {
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Archavon the Stone Watcher",
		},
		[58666] = {
			["school"] = 1,
			["token"] = {
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Archavon the Stone Watcher",
		},
		[48210] = {
			["school"] = 32,
			["token"] = {
				["SPELL_HEAL"] = true,
			},
			["source"] = "Archavon the Stone Watcher",
		},
		[58663] = {
			["school"] = 1,
			["type"] = "DEBUFF",
			["token"] = {
				["SPELL_AURA_APPLIED"] = true,
				["SPELL_CAST_START"] = true,
				["SPELL_CAST_SUCCESS"] = true,
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Archavon the Stone Watcher",
		},
		[59638] = {
			["school"] = 16,
			["token"] = {
				["SPELL_DAMAGE"] = true,
			},
			["source"] = "Mirror Image",
		},
		[58678] = {
			["school"] = 1,
			["type"] = "DEBUFF",
			["token"] = {
				["SPELL_AURA_APPLIED"] = true,
				["SPELL_CAST_START"] = true,
				["SPELL_CAST_SUCCESS"] = true,
			},
			["source"] = "Archavon the Stone Watcher",
		},
		[58965] = {
			["school"] = 8,
			["type"] = "DEBUFF",
			["token"] = {
				["SPELL_AURA_APPLIED"] = true,
				["SPELL_PERIODIC_DAMAGE"] = true,
			},
			["source"] = "Archavon the Stone Watcher",
		},
	},
}
