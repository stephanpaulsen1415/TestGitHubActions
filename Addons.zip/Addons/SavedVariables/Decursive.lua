
DecursiveDB = {
	["global"] = {
		["LastVersionAnnounce"] = 1675848392,
		["NewerVersionAlert"] = 1669830781,
	},
	["class"] = {
		["HUNTER"] = {
			["CureOrder"] = {
				-12, -- [1]
				1, -- [2]
				nil, -- [3]
				-13, -- [4]
				[8] = -14,
				[16] = -15,
				[32] = -16,
			},
		},
		["WARRIOR"] = {
			["CureOrder"] = {
				-12, -- [1]
				-16, -- [2]
				nil, -- [3]
				-13, -- [4]
				[8] = -14,
				[16] = -15,
				[32] = -11,
			},
		},
		["SHAMAN"] = {
			["CureOrder"] = {
				-14, -- [1]
				-13, -- [2]
				nil, -- [3]
				-15, -- [4]
				[8] = 1,
				[16] = 2,
				[32] = -16,
			},
		},
		["MAGE"] = {
			["CureOrder"] = {
				-13, -- [1]
				-16, -- [2]
				nil, -- [3]
				1, -- [4]
				[8] = -14,
				[16] = -15,
				[32] = -12,
			},
		},
		["PRIEST"] = {
			["CureOrder"] = {
				3, -- [1]
				4, -- [2]
				nil, -- [3]
				-16, -- [4]
				[8] = -15,
				[16] = 1,
				[32] = 2,
			},
		},
		["WARLOCK"] = {
			["CureOrder"] = {
				nil, -- [1]
				2, -- [2]
				nil, -- [3]
				-14, -- [4]
				[8] = -15,
				[16] = -16,
				[32] = -13,
			},
		},
		["PALADIN"] = {
			["CureOrder"] = {
				3, -- [1]
				-15, -- [2]
				nil, -- [3]
				-14, -- [4]
				[8] = 1,
				[16] = 2,
				[32] = -16,
			},
		},
		["DRUID"] = {
			["CureOrder"] = {
				-13, -- [1]
				-15, -- [2]
				nil, -- [3]
				1, -- [4]
				[8] = 2,
				[16] = -14,
				[32] = -16,
			},
		},
		["ROGUE"] = {
			["CureOrder"] = {
				-12, -- [1]
				-16, -- [2]
				nil, -- [3]
				-13, -- [4]
				[8] = -14,
				[16] = -15,
				[32] = -11,
			},
		},
		["DEATHKNIGHT"] = {
			["CureOrder"] = {
				-11, -- [1]
				-15, -- [2]
				nil, -- [3]
				-12, -- [4]
				[8] = -13,
				[16] = -14,
				[32] = -16,
			},
		},
	},
	["profileKeys"] = {
		["Nedro - Ashbringer"] = "Default",
		["Resonatorr - Venoxis"] = "Default",
		["Stoc - Everlook"] = "Default",
		["Postorc - Ashbringer"] = "Default",
		["Hoddl - Ewige Warte"] = "Default",
		["Gdgfgfdh - Venoxis"] = "Default",
		["Teststsws - Venoxis"] = "Default",
		["Knallus - Ewige Warte"] = "Default",
		["Schwerlast - Everlook"] = "Default",
		["Neilyoung - Everlook"] = "Default",
		["Postorc - Everlook"] = "Default",
		["Restset - Razorfen"] = "Default",
		["Resonator - Ewige Warte"] = "Default",
		["Felton - Lakeshire"] = "Default",
		["Radorn - Venoxis"] = "Default",
		["Testdgfz - Venoxis"] = "Default",
		["Drushnak - Lakeshire"] = "Default",
		["Resonatorr - Transcendence"] = "Default",
		["Nedro - Transcendence"] = "Default",
		["Crimora - Venoxis"] = "Default",
		["Hoddl - Everlook"] = "Default",
		["Fearleader - Lucifron"] = "Default",
		["Skatron - Ashbringer"] = "Default",
		["Skatron - Everlook"] = "Default",
		["Giselheer - Everlook"] = "Default",
		["Neilyoung - Ashbringer"] = "Default",
		["Testtata - Venoxis"] = "Default",
		["Biologe - Everlook"] = "Default",
		["Drushnak - Mograine"] = "Default",
		["Explorerr - Venoxis"] = "Default",
		["Sparbier - Everlook"] = "Default",
		["Akuhstiker - Transcendence"] = "Default",
		["Privee - Everlook"] = "Default",
		["Drushnak - Transcendence"] = "Default",
		["Lastenasd - Everlook"] = "Default",
		["Pädagoge - Everlook"] = "Default",
		["Schwerlast - Ashbringer"] = "Default",
		["Ragoûtfin - Everlook"] = "Default",
		["Tinyevil - Lakeshire"] = "Default",
		["Crimora - Everlook"] = "Default",
		["Postbotee - Ashbringer"] = "Default",
		["Dfsgdsgds - Venoxis"] = "Default",
		["Drushnak - Ashbringer"] = "Default",
		["Sibo - Lakeshire"] = "Default",
		["Resonator - Everlook"] = "Default",
		["Knallus - Everlook"] = "Default",
		["Drushnak - Venoxis"] = "Default",
		["Postbotee - Everlook"] = "Default",
		["Saucier - Everlook"] = "Default",
		["Nedro - Venoxis"] = "Default",
		["Clintfastfud - Everlook"] = "Default",
		["Sparbier - Ashbringer"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["DebuffsFrameContainer_y"] = 494.9333438223374,
			["MainBarX"] = 682.6666811342584,
			["MainBarY"] = -96.00000203450509,
			["DebuffsFrameContainer_x"] = 1024.000021701388,
		},
	},
}
