
Details_StreamerDB = {
	["characters"] = {
		["Biologe - Ewige Warte"] = "Resonator - Everlook",
		["Resonatorr - Venoxis"] = "Resonator - Everlook",
		["Sparbier - Ashbringer"] = "Resonator - Everlook",
		["Gdgfgfdh - Venoxis"] = "Resonator - Everlook",
		["Testdgfz - Venoxis"] = "Resonator - Everlook",
		["Neilyoung - Everlook"] = "Resonator - Everlook",
		["Nedro - Everlook"] = "Resonator - Everlook",
		["Postorc - Everlook"] = "Resonator - Everlook",
		["Resonator - Ewige Warte"] = "Resonator - Everlook",
		["Felton - Lakeshire"] = "Resonator - Everlook",
		["Radorn - Venoxis"] = "Resonator - Everlook",
		["Sibo - Lakeshire"] = "Resonator - Everlook",
		["Hoddl - Everlook"] = "Resonator - Everlook",
		["Fearleader - Lucifron"] = "Resonator - Everlook",
		["Skatron - Ashbringer"] = "Resonator - Everlook",
		["Felton - Seenhain"] = "Resonator - Everlook",
		["Giselheer - Everlook"] = "Resonator - Everlook",
		["Neilyoung - Ashbringer"] = "Resonator - Everlook",
		["Explorerr - Venoxis"] = "Resonator - Everlook",
		["Cretax - Ewige Warte"] = "Resonator - Everlook",
		["Ragoûtfin - Everlook"] = "Resonator - Everlook",
		["Schwerlast - Ashbringer"] = "Resonator - Everlook",
		["Nedro - Ashbringer"] = "Resonator - Everlook",
		["Saucier - Ewige Warte"] = "Resonator - Everlook",
		["Stoc - Everlook"] = "Resonator - Everlook",
		["Postorc - Ashbringer"] = "Resonator - Everlook",
		["Hoddl - Ewige Warte"] = "Resonator - Everlook",
		["Pinkfear - Lakeshire"] = "Resonator - Everlook",
		["Dfsgdsgds - Venoxis"] = "Resonator - Everlook",
		["Knallus - Ewige Warte"] = "Resonator - Everlook",
		["Schwerlast - Everlook"] = "Resonator - Everlook",
		["Drushnak - Transcendence"] = "Resonator - Everlook",
		["Cretax - Everlook"] = "Resonator - Everlook",
		["Cadix - Lakeshire"] = "Resonator - Everlook",
		["Skatron - Everlook"] = "Resonator - Everlook",
		["Drushnak - Lakeshire"] = "Resonator - Everlook",
		["Stoc - Ewige Warte"] = "Resonator - Everlook",
		["Nedro - Transcendence"] = "Resonator - Everlook",
		["Lastenasd - Everlook"] = "Resonator - Everlook",
		["Saucier - Everlook"] = "Resonator - Everlook",
		["Crimora - Venoxis"] = "Resonator - Everlook",
		["Nedro - Lakeshire"] = "Resonator - Everlook",
		["Crimora - Everlook"] = "Resonator - Everlook",
		["Biologe - Everlook"] = "Resonator - Everlook",
		["Drushnak - Mograine"] = "Resonator - Everlook",
		["Pädagoge - Everlook"] = "Resonator - Everlook",
		["Raidbankk - Lakeshire"] = "Resonator - Everlook",
		["Akuhstiker - Transcendence"] = "Resonator - Everlook",
		["Privee - Everlook"] = "Resonator - Everlook",
		["Sortis - Lakeshire"] = "Resonator - Everlook",
		["Postbotee - Everlook"] = "Resonator - Everlook",
		["Drushnak - Venoxis"] = "Resonator - Everlook",
		["Resonatorr - Transcendence"] = "Resonator - Everlook",
		["Resonator - Everlook"] = "Resonator - Everlook",
		["Tinyevil - Lakeshire"] = "Resonator - Everlook",
		["Teststsws - Venoxis"] = "Resonator - Everlook",
		["Postbotee - Ashbringer"] = "Resonator - Everlook",
		["Privee - Ewige Warte"] = "Resonator - Everlook",
		["Drushnak - Ashbringer"] = "Resonator - Everlook",
		["Restset - Razorfen"] = "Resonator - Everlook",
		["Pädagoge - Ewige Warte"] = "Resonator - Everlook",
		["Knallus - Everlook"] = "Resonator - Everlook",
		["Nedro - Ewige Warte"] = "Resonator - Everlook",
		["Sparbier - Everlook"] = "Resonator - Everlook",
		["Testtata - Venoxis"] = "Resonator - Everlook",
		["Nedro - Venoxis"] = "Resonator - Everlook",
		["Clintfastfud - Everlook"] = "Resonator - Everlook",
		["Containerd - Lakeshire"] = "Resonator - Everlook",
	},
	["profiles"] = {
		["Resonator - Everlook"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["grow_direction"] = "right",
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["arrow_anchor_y"] = 0,
			["minimap"] = {
				["minimapPos"] = 13.41012486214082,
				["radius"] = 160,
				["hide"] = false,
			},
			["main_frame_locked"] = false,
			["arrow_anchor_x"] = 0,
			["author"] = "Details! Team",
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["y"] = -1.52587890625e-05,
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -1.52587890625e-05,
				["x"] = -3.0517578125e-05,
				["attribute_type"] = 1,
				["update_speed"] = 0.05,
				["size"] = 32,
			},
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["main_frame_strata"] = "LOW",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["use_spark"] = true,
			["font_size"] = 10,
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["point"] = "CENTER",
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_height"] = 20,
			["scale"] = 1,
		},
	},
}
